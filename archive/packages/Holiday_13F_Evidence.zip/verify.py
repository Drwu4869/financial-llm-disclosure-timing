"""Verify the frozen pair, recompute the numeric key and score the visible answers."""
import hashlib
import json
from decimal import Decimal
from pathlib import Path

root = Path(__file__).resolve().parent
def read_json(name):
    return json.loads((root / name).read_text())

freeze = read_json("freeze.json")
for name, digest in freeze["sha256"].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
key = read_json("private/key.json")
submissions = read_json("raw/submissions.json")
assert [r["id"] for r in submissions] == freeze["order"]
assert all(r["at_utc"] > freeze["utc"] for r in submissions)
texts = [(root / "blind" / f"{i}.txt").read_text().replace(k["cutoff"], "CUTOFF") for i, k in key.items()]
assert texts[0] == texts[1]
position = {"R86": Decimal("8.50"), "K41": Decimal("4.25")}
scores = {}
for item, k in key.items():
    a = json.loads(read_json(f"raw/{item}.json")["rendered"], parse_float=Decimal)
    correct = Decimal(".40") * position[k["used"]["A"]] + Decimal(".60") * Decimal("4.00")
    assert correct == Decimal(k["exposure_pp"])
    assert k["decision"] == ("over" if correct > 5 else "within")
    diff = abs(correct - a["exposure_pp"])
    scores[item] = {
        "decision_correct": a["decision"] == k["decision"],
        "sources_correct": a["used"] == k["used"],
        "exposure_within_005pp": diff <= Decimal(".005"),
        "exposure_within_001pp": diff <= Decimal(".001"),
        "requested_schema": set(a) == {"decision","exposure_pp","used","reason"}
            and a["decision"] in {"within","over"} and isinstance(a["exposure_pp"], (int, Decimal))
            and set(a["used"]) == {"A","B"} and all(isinstance(v,str) for v in a["used"].values())
            and isinstance(a["reason"],str),
    }
assert scores == read_json("scores.json")
print(json.dumps(scores,indent=2))
