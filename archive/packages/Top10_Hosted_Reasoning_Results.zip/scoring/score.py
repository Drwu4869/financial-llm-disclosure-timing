"""Reproduce both scores from the saved first answers and reviewed annotations."""
import csv
import hashlib
import json
import re
from decimal import Decimal
from pathlib import Path

root = Path(__file__).resolve().parent.parent
def read_csv(name):
    with (root / 'scoring' / name).open() as file:
        return {row['id']: row for row in csv.DictReader(file)}

def sha(data):
    return hashlib.sha256(data).hexdigest()

gold = read_csv('gold.csv')
annotations = read_csv('annotations.csv')
prompts = [json.loads(line) for line in (root / 'inputs/prompts.jsonl').read_text().splitlines()]
manifest = json.loads((root / 'inputs/manifest.json').read_text())['prompt_sha256']
assert {r['id']: sha(r['prompt'].encode()) for r in prompts} == manifest
assert set(annotations) == set(gold) == set(manifest)
rows = []
for item, a in sorted(annotations.items()):
    raw = json.loads((root / 'raw' / (item + '.answer.json')).read_text())
    send = json.loads((root / 'raw' / (item + '.dispatched.json')).read_text())
    assert item == send['id'] == raw['id'] and raw['transcript_completed']
    ref = gold[item]
    selected = [a['selected_lower_or_point']]
    refs = [ref['lower_pct']]
    if a['answer_form'] == 'interval':
        selected.append(a['selected_upper'])
        refs.append(ref['upper_pct'])
        assert Decimal(selected[0]) <= Decimal(selected[1])
    for val in selected:
        assert re.search(r'(?<![\d.])' + re.escape(val) + r'(?!\d)', raw['text'])
    errors = [abs(Decimal(v) - Decimal(g)) for v,g in zip(selected,refs)]
    correct_type = a['answer_form'] == ref['answer_kind'] and a['unsupported_point'] == '0'
    scored = {**a, 'reference_form': ref['answer_kind'], 'reference_lower':ref['lower_pct'],
              'reference_upper':ref['upper_pct'], 'largest_error_pp':str(max(errors)),
              'correct_005':int(correct_type and max(errors) <= Decimal('0.005')),
              'correct_001':int(correct_type and max(errors) <= Decimal('0.001')),
              'exact':int(correct_type and not any(errors)), 'raw_text_sha256':sha(raw['text'].encode()),
              'evidence':raw['text'].splitlines()[0]}
    rows.append(scored)
with (root/'scoring/case_scores.csv').open('w', newline='') as out:
    w=csv.DictWriter(out,fieldnames=rows[0].keys())
    w.writeheader()
    w.writerows(rows)
for kind in ('point','interval'):
    subset=[r for r in rows if r['reference_form']==kind]
    print(kind, 'n',len(subset), {k:sum(int(r[k]) for r in subset)
         for k in ('correct_005','correct_001','exact','unsupported_point')})
