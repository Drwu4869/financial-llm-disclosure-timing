"""Score visible first replies and technical replays separately. Standard library only."""
from pathlib import Path
from decimal import Decimal
import csv
import hashlib
import json
import re
from collections import Counter

arm = Path(__file__).resolve().parent
raw = arm / 'raw'
def keyed(path):
    with path.open() as file:
        return {r['id']: r for r in csv.DictReader(file)}
gold = keyed(arm.parent / 'scoring/gold.csv')
annotations = keyed(arm / 'annotations.csv')
all_rows = []
totals = Counter()
for case, ref in sorted(gold.items()):
    assert (raw / (case + '.sent.json')).exists()
    receipts = [p for p in (raw / (case + '.answer.json'), raw / (case + '.retry.answer.json')) if p.exists()]
    assert len(receipts) <= 1
    kind = ref['answer_kind']
    row = dict(id=case, group=kind, reference_lower_or_point=ref['lower_pct'], reference_upper=ref['upper_pct'])
    if not receipts:
        assert case not in annotations
        row.update(stage='missing', answer_type='', selected_low_or_point='',selected_high='',final_low_or_point='',final_high='',unsupported_point='',max_error_pp='', pass_005='',pass_001='',response_sha256='')
        all_rows.append(row)
        continue
    receipt = json.loads(receipts[0].read_text())
    stage = 'technical replay' if receipt['technical_retry'] else 'first response'
    assert receipt['id'] == case
    if receipt['technical_retry']:
        assert (raw / (case + '.retry.sent.json')).exists()
    a = annotations[case]
    values = [a['selected_low_or_point']]
    target = [ref['lower_pct']]
    if a['answer_type'] == 'interval':
        values.append(a['selected_high'])
        target.append(ref['upper_pct'])
        assert Decimal(values[0]) <= Decimal(values[1])
    for v in values:
        assert re.search(r'(?<![\d.])'+re.escape(v)+r'(?!\d)',receipt['text'])
    err = max(abs(Decimal(v)-Decimal(t)) for v,t in zip(values,target))
    valid = a['answer_type'] == kind and a['unsupported_point'] == '0'
    row.update(stage=stage,**{k:v for k,v in a.items() if k!='id'})
    row.update(max_error_pp=str(err),pass_005=int(valid and err<=Decimal('0.005')),
               pass_001=int(valid and err<=Decimal('0.001')),
               response_sha256=hashlib.sha256(receipt['text'].encode()).hexdigest())
    totals[(stage,kind,'observed')] += 1
    totals[(stage,kind,'primary_correct')] += row['pass_005']
    totals[(stage,kind,'strict_correct')] += row['pass_001']
    all_rows.append(row)
with (arm/'case_scores.csv').open('w', newline='') as file:
    w=csv.DictWriter(file,fieldnames=list(all_rows[0]))
    w.writeheader()
    w.writerows(all_rows)
for group, count in sorted(totals.items()): print(*group,count)
