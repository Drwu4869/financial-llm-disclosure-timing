from pathlib import Path
import json,hashlib,sys
r=Path(__file__).resolve().parents[1];manifest=json.loads((r/'inputs/manifest.json').read_text());prompt_list=list(map(json.loads,(r/'inputs/prompts.jsonl').read_text().splitlines()));prompts={x['id']:x['prompt'] for x in prompt_list};cfg=json.loads((r/'local_protocol.json').read_text());assert len(prompts)==len(prompt_list)==20 and len(manifest['prompt_sha256'])==20
for id,text in prompts.items():assert hashlib.sha256(text.encode()).hexdigest()==manifest['prompt_sha256'][id]
for path in (r/'raw').glob('*.jsonl'):
 records=[json.loads(l) for l in path.read_text().splitlines() if l];seen=set()
 for rec in records:
  id=rec['question_id'];assert id in prompts and id not in seen;seen.add(id);assert rec['prompt_sha256']==manifest['prompt_sha256'][id]
  if rec['track']=='local_qwen3_8b':
   payload={'model':cfg['model'],'messages':[{'role':'system','content':cfg['system']},{'role':'user','content':prompts[id]}],'chat_template_kwargs':{'enable_thinking':True},'cache_prompt':False,'stream':False,**cfg['settings']};actual=hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest();assert actual==rec['request_sha256']
  assert isinstance(rec['final_text'],str)
 print(path.name,len(seen),'unique registered answers/attempts',flush=True)
