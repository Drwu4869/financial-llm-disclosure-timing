"""Independent new chats, fixed decoding, append and fsync each first answer."""
from concurrent.futures import ThreadPoolExecutor, as_completed, wait, FIRST_COMPLETED
from datetime import datetime, timezone
from hashlib import sha256, file_digest
from pathlib import Path
import fcntl,json,os,subprocess,time,urllib.request
BUNDLE=Path(__file__).resolve().parents[1]; LAB=BUNDLE.parent
NOW=lambda:datetime.now(timezone.utc).isoformat()
def post(path,data=None,timeout=3600):
    req=urllib.request.Request('http://127.0.0.1:8776'+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=timeout) as resp:return json.load(resp)
def write_json(path,data):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,indent=2)+'\n');tmp.replace(path)
def main():
    raw=BUNDLE/'raw/local_qwen3_8b.jsonl';raw.parent.mkdir(exist_ok=True);raw.touch(exist_ok=True)
    lock=(LAB/'engine/local.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    cfg=json.loads((BUNDLE/'local_protocol.json').read_text());ps=list(map(json.loads,(BUNDLE/'inputs/prompts.jsonl').read_text().splitlines()));mf=json.loads((BUNDLE/'inputs/manifest.json').read_text());assert len(ps)==len({p['id'] for p in ps})==20
    for p in ps:assert sha256(p['prompt'].encode()).hexdigest()==mf['prompt_sha256'][p['id']]
    ids=[json.loads(l)['question_id'] for l in raw.read_text().splitlines() if l];assert len(ids)==len(set(ids)) and set(ids)<=set(mf['prompt_sha256']);pending=[p for p in ps if p['id'] not in ids]
    if not pending:return
    model=LAB/'engine/experiment_v4/runtime/Qwen3-8B-Q4_K_M.gguf';binary=LAB/'engine/experiment_v3/runtime/llama/llama-b12110/llama-server'
    for path,key in [(model,'gguf_sha256'),(binary,'binary_sha256')]:
        with path.open('rb') as f:assert file_digest(f,'sha256').hexdigest()==cfg[key]
    command=[str(binary),'-m',str(model),'--host','127.0.0.1','--port','8776','-t','8','-tb','8','--parallel','2','-c','12288','--jinja','--reasoning','on','--reasoning-format','deepseek','--reasoning-budget','-1','--timeout','3600','--no-repack','--cache-ram','0','--no-cache-prompt']
    log=(LAB/'engine/server.log').open('a');server=subprocess.Popen(command,stdout=log,stderr=log)
    try:
        for _ in range(500):
            if server.poll() is not None:raise RuntimeError('Model server exited before startup')
            try:post('/health',timeout=3);break
            except Exception:time.sleep(.4)
        else:raise RuntimeError('Model server did not start')
        def messages(p):return [{'role':'system','content':cfg['system']},{'role':'user','content':p['prompt']}]
        for p in pending:
            rr=post('/apply-template',{'messages':messages(p),'add_generation_prompt':True,'chat_template_kwargs':{'enable_thinking':True}})['prompt'];assert '</think>' not in rr.split('<|im_start|>assistant')[-1];assert len(post('/tokenize',{'content':rr,'add_special':True})['tokens'])+cfg['settings']['max_tokens']<=6144
        with (BUNDLE/'status/local_segments.jsonl').open('a') as f:f.write(json.dumps({'at':NOW(),'completed_at_start':len(ids),'remaining':[p['id'] for p in pending],'settings':cfg['settings'],'weights_and_binary_verified':True})+'\n');f.flush();os.fsync(f.fileno())
        def infer(p):
            t=time.monotonic();at=NOW();payload={'model':cfg['model'],'messages':messages(p),'chat_template_kwargs':{'enable_thinking':True},'cache_prompt':False,'stream':False,**cfg['settings']};rec={'question_id':p['id'],'started_utc':at,'prompt_sha256':mf['prompt_sha256'][p['id']],'request_sha256':sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest(),'track':'local_qwen3_8b'}
            try:
                answer=post('/v1/chat/completions',payload);c=answer['choices'][0];msg=c['message'];rec.update(final_text=msg.get('content') or '',finish_reason=c.get('finish_reason'),usage=answer.get('usage'),reasoning_present=bool(msg.get('reasoning_content')),response_model=answer.get('model'),status='received')
            except Exception as e:rec.update(status='transport_error',error=repr(e),final_text='',finish_reason=None)
            rec.update(ended_utc=NOW(),elapsed_s=round(time.monotonic()-t,3));return rec
        with raw.open('a',buffering=1) as f,ThreadPoolExecutor(2) as pool:
            pending_jobs={pool.submit(infer,p) for p in pending}
            while pending_jobs:
                done,pending_jobs=wait(pending_jobs,timeout=30,return_when=FIRST_COMPLETED)
                for job in done:
                    rec=job.result();assert rec['question_id'] not in ids;f.write(json.dumps(rec,ensure_ascii=False)+'\n');f.flush();os.fsync(f.fileno());ids.append(rec['question_id']);print('Recorded',len(ids),'/20',rec['question_id'],rec['status'],rec['finish_reason'],flush=True)
                try:slots=[(v['id'],v['n_prompt_tokens']) for v in post('/slots',timeout=3) if v.get('is_processing')]
                except Exception:slots=[]
                write_json(BUNDLE/'status/local_progress.json',{'at':NOW(),'completed_ids':ids,'n':len(ids),'active_slot_context_counts':slots,'server_exit_code':server.poll()})
        assert len(set(ids))==20
    finally:
        server.terminate()
        try:server.wait(timeout=10)
        except subprocess.TimeoutExpired:server.kill();server.wait()
        log.close()
if __name__=='__main__':main()
