"""Score declared answer forms/endpoints and preserve response-level evidence."""
from collections import Counter,defaultdict
import csv,json,sys
from decimal import Decimal as D
from pathlib import Path
r=Path(__file__).resolve().parents[1]
def tabulate(track):
    keys={v['id']:v for v in csv.DictReader((r/'scoring/gold.csv').open())};answers={v['question_id']:v for v in map(json.loads,(r/'raw'/f'{track}.jsonl').read_text().splitlines())};codes=list(csv.DictReader((r/'grades'/f'{track}.csv').open()));tol=D('.001');seen=set();counts=defaultdict(Counter);rows=[]
    for code in codes:
        i=code['id'];assert i in answers and i not in seen;seen.add(i);case=keys[i];form=code['form'];assert form in ('point','range','uncertainty','mixed','unscorable','empty');lo,hi=D(case['lower_pct']),D(case['upper_pct']);p=D(code['point']) if code['point'] else None;l=D(code['lo']) if code['lo'] else None;u=D(code['hi']) if code['hi'] else None
        valid=answers[i].get('status')=='received' and answers[i].get('finish_reason')!='length';point=valid and form=='point' and p is not None and abs(p-lo)<=tol;bounds=valid and form=='range' and l is not None and u is not None and l<=u and abs(l-lo)<=tol and abs(u-hi)<=tol
        passed=bool(point if case['answer_kind']=='point' else bounds);unsupported=(case['answer_kind']=='interval' and code['asserted_point']=='yes');c=counts[case['answer_kind']];c['n']+=1;c['correct']+=passed;c['unsupported_point']+=int(unsupported);c['explicit_missing_as_zero']+=int(unsupported and code['explicit_absence_zero']=='yes');c['output_cap']+=int(answers[i].get('finish_reason')=='length');c['recognized_missing']+=int(code['recognized_missing']=='yes');
        if case['answer_kind']=='interval' and form=='range' and l is not None and u is not None and not bounds:
            c['wider_covering_range' if l<=lo+tol and u>=hi-tol and l<=u else 'range_excludes_feasible_values']+=1
        rows.append({'id':i,'family':case['family'],'source':case['publisher'],'target':case['target'],'gold_kind':case['answer_kind'],'gold_lower_pct':str(lo),'gold_upper_pct':str(hi),'reminder':case['reminder'],'passed':passed,'unsupported_point':unsupported,**code});
    assert seen==set(answers);return {'track':track,'records':len(answers),'groups':{k:dict(c) for k,c in counts.items()},'by_case':rows}
if __name__=='__main__':
    outcome=tabulate(sys.argv[1]);out=r/'grades'/(sys.argv[1]+'_scores.json');out.write_text(json.dumps(outcome,ensure_ascii=False,indent=2)+'\n');print(json.dumps(outcome['groups']))
