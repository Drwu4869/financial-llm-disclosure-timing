# Testing Portfolio Exposure from Text with Matched Holdings

Changyi Wu • Working paper v9 • 6 November 2026

Read `main.pdf` for the five-page paper. `full.pdf` combines the paper and its 28-page technical supplement. The supplement retains the detailed mathematics, including the conditions for fixed-weight identification, numerical counterexamples, the acceptance rule that covered zero cases, and the historical model and source-table results.

## Source and evidence

- Compile `main.tex` and `supplement.tex` from this directory with `latexmk -pdf main.tex` and `latexmk -pdf supplement.tex`, using a standard TeX Live installation with BibTeX. The `support/` files, `figures/` and `references.bib` supply the dependencies. Each LaTeX target has its own bibliography and internal reference numbering. After both PDFs have been built, `python make_full.py` (PyMuPDF) creates the combined PDF with navigable bookmarks.
- The v8 archive under `evidence/` is the original release, including the v5 and v7 study packages. The other ZIP is the final 100-response recheck archive. Its `thinking_recheck/results/evaluation/raw.jsonl` contains the new responses; `data/baseline_raw.jsonl` contains their original matched responses. See `results/scored.jsonl`, `results/analysis.json` and `data/protocol.json` in that archive.
- Run `python verify.py` with Python 3.12 and NumPy (the original analysis used NumPy 2.3.5). It checks both source archive digests, reruns request and ground-truth checks, reruns the frozen scoring and compares the complete result to the archived result. It also checks the numbers in the worked examples. The verification uses existing model responses. Its output for this release is `checks/verification.json`.

## Changes from v8

The main paper now leads with the matched exposure design, the 100-prompt comparison and individual ledger observations. Qwen's original 4/24 score on heterogeneous merged questions rose to 24/24. Across the 100 prompts, 64 originally unsuccessful responses became correct and one originally correct response failed. Both unsuccessful recheck outputs were capped. Their shared account, the other changed runtime settings and the reuse of previously examined cases are reported in the main paper. Technical detail from the earlier studies is available in the supplement and the complete historical source archive. No further inference was performed in preparing v9. No venue-specific submission template has been applied.
