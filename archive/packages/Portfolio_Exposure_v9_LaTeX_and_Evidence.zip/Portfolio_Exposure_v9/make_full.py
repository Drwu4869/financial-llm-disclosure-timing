"""Combine the compiled paper and supplement, retaining bookmarks and link targets."""
from pathlib import Path
import fitz

ROOT=Path(__file__).resolve().parent

def build():
    out=fitz.open(); toc=[]; expected=0
    for path,title in [(ROOT/'main.pdf','Main paper'),(ROOT/'supplement.pdf','Technical supplement')]:
        with fitz.open(path) as part:
            start=len(out);out.insert_pdf(part,links=False);toc.append([1,title,start+1]);toc.extend([[level+1,label,page+start] for level,label,page in part.get_toc() if page>0]);
            for idx,page in enumerate(part):
                dest=out[start+idx]
                for link in page.get_links():
                    kind=link['kind']; box=link['from']
                    if kind==fitz.LINK_URI:
                        dest.insert_link({'kind':kind,'from':box,'uri':link['uri']})
                    elif kind in (fitz.LINK_GOTO,fitz.LINK_NAMED) and link.get('page',-1)>=0:
                        target=link['page']; pos=link.get('to',fitz.Point(0,0));
                        if kind==fitz.LINK_NAMED:pos=pos*part[target].transformation_matrix
                        dest.insert_link({'kind':fitz.LINK_GOTO,'from':box,'page':start+target,'to':pos});
                    else:raise ValueError(f'Unknown link in {path.name}: {link}')
                    expected+=1
    out.set_toc(toc);out.set_metadata({'title':'Testing Portfolio Exposure from Text with Matched Holdings','author':'Changyi Wu','subject':'Working paper v9 and technical supplement'});out.set_page_labels([{'startpage':0,'prefix':'','style':'D','firstpagenum':1},{'startpage':toc[[e[1] for e in toc].index('Technical supplement')][2]-1,'prefix':'S','style':'D','firstpagenum':1}]);out.save(ROOT/'full.pdf',garbage=4,deflate=True);out.close()
    with fitz.open(ROOT/'full.pdf') as merged:
        links=[l for p in merged for l in p.get_links()]; assert len(links)==expected;assert all(0<=l['page']<len(merged) for l in links if l['kind']==fitz.LINK_GOTO);print(len(merged),'pages;',len(links),'working link annotations')
if __name__=='__main__':build()
