"""Check the immutable inputs and independently rerun the packaged Study C analysis."""
from pathlib import Path
from tempfile import TemporaryDirectory
from hashlib import sha256
import json
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
ARTIFACTS = {
    'Portfolio_Risk_Integrated_v8.zip': '690f8cb5587990b1e3973257feda76b6a1ae008a167172a246f5ada9ad2cc315',
    'Portfolio_Risk_Thinking_Recheck.zip': '0d06d8b6bd5149357769645997199bf20494ea711270247bc227f1210809cd74',
}

def run():
    for name, expected in ARTIFACTS.items():
        path = ROOT / 'evidence' / name
        assert sha256(path.read_bytes()).hexdigest() == expected, name
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None and len(archive.namelist()) == len(set(archive.namelist()))
    with TemporaryDirectory() as td:
        with zipfile.ZipFile(ROOT/'evidence'/'Portfolio_Risk_Thinking_Recheck.zip') as archive:
            archive.extractall(td)
        work = Path(td)/'thinking_recheck'
        expected = json.loads((work/'results/analysis.json').read_text())
        cmd = [sys.executable, 'verify_record_provenance.py']
        audit = json.loads(subprocess.check_output(cmd, cwd=work))
        subprocess.run([sys.executable,'analyze.py'],cwd=work,stdout=subprocess.DEVNULL,check=True)
        observed = json.loads((work/'results/analysis.json').read_text())
        assert observed == expected
        s = {v['configuration']: v['groups'] for v in observed['summaries'] if v['view']=='strict'}
        groups = ['controlled_homogeneous','controlled_heterogeneous','source_direct','source_ledger']
        counts = [[s[label][g]['answer_correct'] for g in groups] for label in ['original','thinking']]
        assert counts == [[24,4,2,5],[24,24,25,25]]
        assert [s['thinking'][g]['n'] for g in groups] == [24,24,26,26]
        scored = [json.loads(l) for l in (work/'results/scored.jsonl').read_text().splitlines()]
        cases = [v for v in scored if v['view']=='strict' and v['configuration']=='original' and v['corpus']=='source' and v['method']=='ledger' and v['ledger_exact'] and not v['answer_correct']]
        assert len(cases)==18 and all(v['calculator_correct'] for v in cases)
        original,new = [{v['request_id']:v for v in map(json.loads,p.read_text().splitlines())} for p in [work/'data/baseline_raw.jsonl',work/'results/evaluation/raw.jsonl']]
        total = lambda src,k: json.loads(src[k]['raw_text'])['total_a_percent']
        examples = {'new_00_homogeneous_merged_direct':(55,55),'new_00_heterogeneous_merged_direct':(44.44,55),'VG40_VG80_merged_ledger':(14.6,13.465),'VG20_VG60_fragmented_ledger':(14.8,10.212)}
        for k,pair in examples.items(): assert (total(original,k),total(new,k))==pair
        failed = sorted(v['request_id'] for v in observed['format_only_failure_census'])
        assert failed == ['BR4_BR5_fragmented_direct','BR4_BR5_fragmented_ledger']
        for k in failed:
            assert new[k]['raw_text']=='' and new[k]['response']['usage']['completion_tokens']==4096
        return {'status':'PASS','archive_digests':ARTIFACTS,'paired_prompt_ids':audit['unique_matched_ids'],'reference_totals_recomputed':audit['gold_totals_recomputed'],'strict_correct':[sum(x) for x in counts],'groups':dict(zip(groups,zip(*counts))),'failed_ids':failed,'original_ledgers_recovered_by_calculator':len(cases),'complete_analysis_matches_frozen_reference':True,'worked_examples_verified':list(examples)}

if __name__=='__main__': print(json.dumps(run(),indent=2))
