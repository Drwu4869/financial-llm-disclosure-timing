from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib, json, os, pathlib, time, urllib.request
root = pathlib.Path.cwd()
manifest = json.loads((root/'thinking_recheck/runtime/model_manifest.json').read_text())
size = manifest['bytes']; block = 32 * 1024 * 1024
out = root/'experiment_v4/runtime'/manifest['filename']; partial = out.with_suffix('.gguf.partial')
stamp = root/'recovery/model_parts.json'; verified = set(json.loads(stamp.read_text())) if partial.exists() and stamp.exists() else set()
fd = os.open(partial,os.O_CREAT|os.O_RDWR,0o600); os.ftruncate(fd,size)
def get_block(start):
 end = min(start+block,size)-1
 for attempt in range(4):
  try:
   url=manifest['url']+'?download=true&part='+str(start)
   request=urllib.request.Request(url,headers={'Range':f'bytes={start}-{end}','Accept-Encoding':'identity','User-Agent':'portfolio-exposure-replication/1.0'})
   with urllib.request.urlopen(request,timeout=60) as response:
    expected=f'bytes {start}-{end}/{size}'
    if response.status!=206 or response.headers.get('Content-Range')!=expected: raise RuntimeError('Unexpected range: '+str(response.headers.get('Content-Range')))
    pos=start
    while data:=response.read(1024*1024):
     if pos+len(data)>end+1:raise RuntimeError('Oversized range')
     if os.pwrite(fd,data,pos)!=len(data):raise IOError('Short write')
     pos+=len(data)
    if pos!=end+1:raise IOError('Incomplete range')
   return start
  except Exception as exc:
   if attempt==3: raise RuntimeError(f'Block {start}: {type(exc).__name__}: {str(exc)[:140]}') from None
   time.sleep(2**attempt)
starts=list(range(0,size,block))
with ThreadPoolExecutor(max_workers=5) as pool:
 futures=[pool.submit(get_block,k) for k in starts if k not in verified]
 for result in as_completed(futures):
  verified.add(result.result());temp=stamp.with_suffix('.tmp');temp.write_text(json.dumps(sorted(verified)));temp.replace(stamp)
  if len(verified)%10==0 or len(verified)==len(starts): print('model chunks',len(verified),'/',len(starts),flush=True)
os.fsync(fd);os.close(fd)
with partial.open('rb') as f: actual=hashlib.file_digest(f,'sha256').hexdigest()
assert actual==manifest['sha256'], 'Model digest mismatch';partial.replace(out);print('Model SHA-256 verified',actual,flush=True)
