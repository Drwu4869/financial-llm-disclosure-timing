"""Run the frozen evaluator with read-only local process/HTTP health telemetry."""
from pathlib import Path
from datetime import datetime,timezone
import json,os,signal,subprocess,sys,time,urllib.request
from observe_run import records
R=Path(__file__).resolve().parent

def main():
    log=open(R/'results/supervised_runner.log','a')
    run=subprocess.Popen([sys.executable,'-u',str(R/'run.py')],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try:
        while True:
            now=datetime.now(timezone.utc);rs=records();n=len(rs)
            assert n==len({x['request_id'] for x in rs}),'Duplicate records detected; inspect before proceeding'
            pids=[];p=Path(f'/proc/{run.pid}/task/{run.pid}/children')
            if p.exists():pids=[int(x) for x in p.read_text().split()]
            proc=[]
            for pid in pids:
                try:
                    stat=Path(f'/proc/{pid}/stat').read_text().split()
                    proc.append({'pid':pid,'state':stat[2],'cpu_seconds':round((int(stat[13])+int(stat[14]))/os.sysconf('SC_CLK_TCK'),1)})
                except OSError:pass
            health=None;slots=None
            try:
                with urllib.request.urlopen('http://127.0.0.1:8774/health',timeout=3) as f:health=json.load(f)
                with urllib.request.urlopen('http://127.0.0.1:8774/slots',timeout=3) as f:
                    values=json.load(f)
                    slots=[{k:v.get(k) for k in ['id','is_processing','n_ctx','n_decoded','n_prompt_tokens','n_predict','n_remaining']} for v in values]
            except Exception as e:health={'error':str(e)}
            sl=R/'results/evaluation/server.log'
            state={'observed_at_utc':now.isoformat(),'completed':n,'remaining':100-n,'runner_exit_code':run.poll(),'engine_health':health,'engine_processes':proc,'slots':slots,'engine_log_age_seconds':round(now.timestamp()-sl.stat().st_mtime,1) if sl.exists() else None}
            p=R/'results/engine_health.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(state,indent=2)+'\n');os.replace(tmp,p)
            print(json.dumps(state),flush=True)
            if run.poll() is not None:
                if run.returncode:raise RuntimeError('Frozen runner failed; see supervised_runner.log')
                return
            time.sleep(30)
    finally:
        if run.poll() is None:
            os.killpg(run.pid,signal.SIGINT)
            try:run.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(run.pid,signal.SIGKILL);run.wait()
        log.close()
if __name__=='__main__':main()
