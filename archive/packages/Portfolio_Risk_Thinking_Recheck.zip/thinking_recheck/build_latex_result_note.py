"""Build an English results sheet from the completed, paired strict analysis."""
import json
from pathlib import Path
from verify_record_provenance import audit

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent / 'output'

def to_tex():
    checked = audit()
    assert checked['unique_matched_ids'] == 100
    analysis = json.loads((ROOT/'results/analysis.json').read_text())
    assert analysis['status'] == 'COMPLETE' and analysis['evaluation_calls'] == 100
    strict = {entry['configuration']: entry for entry in analysis['summaries'] if entry['view']=='strict'}
    before = strict['original']['groups']; after = strict['thinking']['groups']
    groups = ['controlled_homogeneous','controlled_heterogeneous','source_direct','source_ledger']
    old_count = sum(before[k]['answer_correct'] for k in groups)
    new_count = sum(after[k]['answer_correct'] for k in groups)
    def row(label,group,metric='answer_correct'):
        a,b=before[group],after[group];assert a['n']==b['n']
        return f"{label} & {a[metric]}/{a['n']} & {b[metric]}/{b['n']} " + r'\\'
    rows = '\n'.join([
        row('Correct total with identical product allocations','controlled_homogeneous'),
        row('Correct total with different product allocations','controlled_heterogeneous'),
        r'\addlinespace[4pt]',
        row('Correct direct total from published tables','source_direct'),
        row('Correct total reported alongside the ledger','source_ledger'),
        r'\midrule',
        row('All reported ledger fields within tolerance','source_ledger','ledger_exact'),
        row('Calculator correct using the reported ledger','source_ledger','calculator_correct'),
        row('Ledger correct but reported total wrong','source_ledger','fields_right_total_wrong')])
    errors = 100-new_count
    trunc = analysis['truncated']
    other = errors-trunc
    residual = (f'Of the {errors} unsuccessful totals, {trunc} reached the 4,096-token limit. '
                f'The other {other} fell outside the scoring criterion for a final total.') if errors else 'All 100 final totals met the scoring criterion.'
    if errors and errors==trunc:
        residual = f'All {errors} unsuccessful totals came from responses that reached the 4,096-token limit.'
    failed_ids = {item['request_id'] for item in analysis['format_only_failure_census']}
    if failed_ids == {'BR4_BR5_fragmented_direct','BR4_BR5_fragmented_ledger'} and errors == trunc == 2:
        residual = 'Both remaining responses reached 4,096 tokens with an empty final answer. They used the fragmented MyMap 4/MyMap 5 account, once per response format.'
    original_gap = strict['original']['homogeneous_minus_heterogeneous_pp']
    reasoning_gap = strict['thinking']['homogeneous_minus_heterogeneous_pp']
    comparison = (f'The original configuration returned {old_count}/100 correct final totals. '
                  f'The reasoning-enabled configuration returned {new_count}/100 on the same prompts. '
                  f'The accuracy gap between the two controlled conditions changed from {original_gap:.1f} to {reasoning_gap:.1f} percentage points.')
    template = r'''\documentclass[11pt,a4paper]{article}
\usepackage[T1]{fontenc}
\usepackage[margin=22mm,top=20mm,bottom=18mm]{geometry}
\usepackage{booktabs,tabularx,array,xcolor}
\usepackage{lmodern}
\definecolor{navy}{HTML}{19384A}
\definecolor{muted}{HTML}{465C65}
\setlength{\parindent}{0pt}
\linespread{1.035}
\setlength{\parskip}{7pt}
\setlength{\tabcolsep}{5pt}
\renewcommand{\arraystretch}{1.23}
\pagestyle{empty}
\begin{document}
{\sffamily\small\color{muted} Financial NLP \hfill Experimental results \quad 6 November 2026}\par
\vspace{2pt}
{\color{navy}\rule{\linewidth}{0.8pt}}\par
{\sffamily\bfseries\fontsize{22}{25}\selectfont Portfolio exposure across two\\Qwen3-8B configurations}\par
{\large Matched re-evaluation of 100 portfolio questions}\par
\vspace{2pt}
@@COMPARISON@@

{\small
\begin{tabularx}{\linewidth}{@{}>{\raggedright\arraybackslash}Xrr@{}}
\toprule
\textbf{Task and scoring outcome} & \textbf{Original} & \textbf{Reasoning enabled}\\
\midrule
@@ROWS@@
\bottomrule
\end{tabularx}}

{\small\color{muted}Each entry counts prompts meeting the stated criterion. A correct total lies within 0.5 percentage points of the reference value. The last three rows describe the same 26 ledger prompts. A calculator weights each reported allocation by its reported investment amount. @@RESIDUAL@@}

\textbf{What the controlled questions measure.} In one family, all four products allocate 55\% to Asset A. Omitting a lot still leaves a weighted average of 55\%. The paired condition gives products different allocations, so errors in the relative amounts can change the answer. The recheck covers both conditions for each of 24 families, using their merged, direct-answer prompts.

\textbf{Evidence from published tables.} The other 52 prompts use cleaned holdings tables for eight funds from Vanguard and BlackRock. Thirteen constructed accounts each appear in two presentations and two response formats. The original configuration reported correct ledger fields alongside a wrong total in 18 cases. Recomputing those fields gave the correct exposure in all 18. Under the second configuration, all 25 returned ledgers had correct fields and a correct total.

\textbf{Reproduction and scope.} Both runs use the same Qwen3-8B Q4\_K\_M weights, input text and JSON-object constraint. The original uses greedy decoding with a 512-token limit. The second enables reasoning, uses temperature 0.6 and allows 4,096 tokens. Sampling, seed and runtime settings also differ, so the comparison estimates the combined configuration change on previously examined cases. Strict scoring includes truncated and invalid responses in the denominator. The final 31 prompts ran on a replacement CPU host after the model and inference-program hashes were verified.

\vfill
{\small\color{muted}\rule{\linewidth}{0.4pt}\\The companion archive includes \texttt{data/protocol.json}, \texttt{results/analysis.json} and \texttt{results/evaluation/raw.jsonl}.}
\end{document}
'''
    return template.replace('@@COMPARISON@@',comparison).replace('@@ROWS@@',rows).replace('@@RESIDUAL@@',residual)

if __name__=='__main__':
    OUT.mkdir(exist_ok=True)
    (OUT/'Portfolio_Risk_Recheck_Results.tex').write_text(to_tex())
