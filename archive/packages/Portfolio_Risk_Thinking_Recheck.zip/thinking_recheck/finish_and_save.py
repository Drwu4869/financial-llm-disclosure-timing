"""Finalize a completed run without changing any frozen inference/scoring rule.

Packaging only. Created after inference began. Supports restart: finalization
does not rerun models, select answers, repair outputs, or change scoring.
"""
from pathlib import Path
from datetime import datetime, timezone
import csv, hashlib, json, os, subprocess, sys, tempfile, time, zipfile

ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent/'output'
REPORT=OUT/'Portfolio_Risk_Thinking_Recheck_Report.txt'
ARCHIVE=OUT/'Portfolio_Risk_Thinking_Recheck.zip'
HELPER=Path('/home/agent/.codex/plugins/cache/openai-curated-remote/openai-library/0.1.69/skills/library/scripts/library_upload.py')

def now(): return datetime.now(timezone.utc).isoformat()
def atomic_write(path, data):
    # Keep existing local Library identity attributes on the destination.
    with open(path,'wb') as f:
        f.write(data);f.flush();os.fsync(f.fileno())

def build_report(report):
    rows=[]
    for view in ['strict','format_only']:
        old=next(x for x in report['summaries'] if x['view']==view and x['configuration']=='original')
        new=next(x for x in report['summaries'] if x['view']==view and x['configuration']=='thinking')
        for group in new['groups']:
            for metric in new['groups'][group]:
                if metric not in ['n','valid_answer']:
                    rows.append({'view':view,'group':group,'metric':metric,'n':new['groups'][group]['n'],'original':old['groups'][group][metric],'thinking':new['groups'][group][metric]})
    lines=['PORTFOLIO EXPOSURE: REASONING-ENABLED RECHECK',
           'Status: COMPLETE -- all 100 frozen evaluation responses recorded.',
           'Generated at UTC: '+now(),'',
           'This is an experimental result note, not a revised manuscript.',
           'The v5-v8 manuscripts remain unchanged. Four engineering development',
           'responses on two separate prompts are excluded from every result below.','',
           'MAIN COUNTS (original -> reasoning configuration; numerator / denominator)']
    names={'controlled_homogeneous':'Controlled homogeneous: correct final total',
           'controlled_heterogeneous':'Controlled heterogeneous: correct final total',
           'source_direct':'Published tables, direct: correct final total',
           'source_ledger':'Published tables, ledger: correct final total'}
    for view in ['strict','format_only']:
        old=next(x for x in report['summaries'] if x['view']==view and x['configuration']=='original')
        new=next(x for x in report['summaries'] if x['view']==view and x['configuration']=='thinking')
        lines+=['',view.upper()]
        for group,label in names.items():
            a,b=old['groups'][group],new['groups'][group]
            lines.append(f"{label}: {a['answer_correct']}/{a['n']} -> {b['answer_correct']}/{b['n']}")
        a,b=old['groups']['source_ledger'],new['groups']['source_ledger']
        for metric,label in [('ledger_exact','Published tables: exact reported ledger'),('calculator_correct','Published tables: calculator on reported ledger'),('fields_right_total_wrong','Correct ledger but wrong model-reported total')]:
            lines.append(f"{label}: {a[metric]}/26 -> {b[metric]}/26")
        lines.append(f"Homogeneous-minus-heterogeneous accuracy gap: {old['homogeneous_minus_heterogeneous_pp']:.2f} pp -> {new['homogeneous_minus_heterogeneous_pp']:.2f} pp")
        lines.append('Paired-family empirical bootstrap range for new gap: '+str(new['family_bootstrap_95_pp'])+' pp.')
    lines+=['','RUNTIME AND INTERPRETATION',
            f"Request errors: {report['request_errors']}; truncated responses: {report['truncated']}; responses with nonempty reasoning: {report['nonempty_reasoning']}/100.",
            'All failures remain in the denominator. A truncated response is an',
            'output-budget failure and does not establish inability to solve the task.',
            'Strict parsing is primary. The predeclared format-only view removes',
            'one enclosing code fence or aliases lots to rows; no numbers are repaired.',
            'The calculator uses only the model-reported ledger, with no oracle edits.','',
            'Same checkpoint, quantization, input texts and JSON-object constraint.',
            'Thinking, sampling, seed, output budget and runtime context/batching',
            'change together. Improvements cannot be assigned to thinking alone.',
            'The output limit is 4096 tokens, below the model card recommendation',
            'of 32768; remaining truncation requires separate budget analysis.',
            'The cases were previously examined. This is not a new blind holdout.',
            'The controlled recheck covers merged direct prompts only; it does not',
            'rerun all controlled fragmentation or changed-exposure conditions.',
            'Source evidence uses cleaned published tables and constructed accounts,',
            'not end-to-end PDF extraction or observed customer portfolios.',
            'The 13 source accounts reuse 8 funds; counts are descriptive.',
            'Neither zero observed errors nor a zero bootstrap range establishes equivalence.',
            'This note makes no automatic claim about novelty or publishability.','',
            'DECISION RULE',
            'If the old errors largely disappear under this configuration, the old',
            'practical failure claim must be narrowed. The algebraic weakness of',
            'homogeneous tests alone does not establish a difficult real-world task.',
            'If exact fields plus a calculator succeed while model totals fail, the',
            'remaining evidence concerns arithmetic and pipeline design.',
            'If field errors remain, use the complete failure census; a few cases',
            'do not establish a general extraction mechanism.','',
            'SOURCE AND EVIDENCE',
            'Official model settings: https://huggingface.co/Qwen/Qwen3-8B',
            'The companion ZIP contains frozen protocol, original and new raw',
            'answers, exact prompts, scoring code, paired comparisons, all failures',
            'and runtime manifests. Read results/analysis.json and results/counts.csv.',
            '',
            '中文说明：100 题已全部返回，以上为原始计分结果，尚未据此修改论文。',
            '先看异质组合正确率、真实材料明细正确率，以及计算器是否消除错误。',
            '不能把配置整体改善说成仅由开启推理导致，也不能只挑剩下的失败案例。']
    return '\n'.join(lines)+'\n', rows

def publish_files(text,state,raw_snapshot=None):
    atomic_write(REPORT,text.encode())
    status=ROOT/'results/finalization_status.json'
    status.write_text(json.dumps(state,indent=2)+'\n')
    with tempfile.NamedTemporaryFile(suffix='.zip',delete=False,dir='/tmp') as f:tmp=Path(f.name)
    try:
        with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as z:
            z.writestr('thinking_recheck/CHECKPOINT_STATUS.json',json.dumps(state,indent=2))
            for p in sorted(ROOT.rglob('*')):
                if p == ROOT/'CHECKPOINT_STATUS.json':
                    continue  # A restored archive can contain its earlier checkpoint header.
                if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and p.name not in ['library_targets.json','library_save_result.json','finalizer.log']:
                    arc=Path('thinking_recheck')/p.relative_to(ROOT)
                    if raw_snapshot is not None and p==ROOT/'results/evaluation/raw.jsonl':z.writestr(str(arc),raw_snapshot)
                    else:z.write(p,arc)
        atomic_write(ARCHIVE,tmp.read_bytes())
    finally:tmp.unlink(missing_ok=True)
    target_path=ROOT/'runtime/library_targets.json'
    targets=json.loads(target_path.read_text())
    uploads=[{'local_path':str(p),'purpose':'replace_library_file',**targets[k],'version_reason':f"Reasoning recheck: {state['evaluation_records']}/100 responses; {state['status']}."} for k,p in [('report',REPORT),('archive',ARCHIVE)]]
    uploaded=subprocess.run([sys.executable,str(HELPER)],input=json.dumps({'uploads':uploads}),text=True,capture_output=True)
    (ROOT/'results/library_save_result.json').write_text(json.dumps({'exit_code':uploaded.returncode,'stdout':uploaded.stdout,'stderr':uploaded.stderr},indent=2)+'\n')
    if uploaded.returncode:raise RuntimeError('Result upload failed or uncertain; inspect library_save_result.json before retrying')
    # The helper appends receipt lines after the one-line JSON response.
    response=None
    for line in uploaded.stdout.splitlines():
        try:candidate=json.loads(line)
        except ValueError:continue
        if isinstance(candidate,dict) and 'results' in candidate:response=candidate;break
    if response is None:raise RuntimeError('Upload acknowledgement could not be parsed; do not blindly retry')
    items=response['results']
    if len(items)!=2:raise RuntimeError('Unexpected number of upload acknowledgements')
    failed=[]
    for (key,path),item in zip([('report',REPORT),('archive',ARCHIVE)],items):
        version=item.get('current_version_number')
        returned_id=item.get('library_file_id')
        if (item.get('status')!='succeeded' or item.get('local_path')!=str(path)
            or item.get('file_name')!=path.name or item.get('purpose')!='replace_library_file'
            or not item.get('local_metadata_applied') or not returned_id or not isinstance(version,int)):
            failed.append(key)
            continue
        targets[key].update(library_file_id=returned_id,expected_current_version=version)
    target_path.write_text(json.dumps(targets,indent=2)+'\n')
    if failed:
        raise RuntimeError('Unconfirmed file(s): '+', '.join(failed)+'. Inspect the per-file receipt.')
    state={**state,'saved_at_utc':now(),'save_acknowledged':True}
    status.write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(state),flush=True)

def read_completed():
    p=ROOT/'results/evaluation/raw.jsonl'
    data=p.read_bytes() if p.exists() else b''
    if data and not data.endswith(b'\n'):data=data[:data.rfind(b'\n')+1]
    return data,[json.loads(line) for line in data.splitlines()]

def main():
    deadline=time.monotonic()+8*3600
    status=ROOT/'results/finalization_status.json'
    previous=json.loads(status.read_text()) if status.exists() else {}
    state={'status':'WAITING_FOR_100_RESPONSES','started_at_utc':now(),'pid':os.getpid()}
    status.write_text(json.dumps(state,indent=2)+'\n')
    print(json.dumps(state),flush=True)
    _,existing=read_completed();next_checkpoint=len(existing)+1
    if previous.get('save_acknowledged'):
        next_checkpoint=min(next_checkpoint,previous['evaluation_records']+1)
    while not (ROOT/'results/evaluation/completed.json').exists():
        if time.monotonic()>deadline:
            raise TimeoutError('Run still incomplete after 8 hours; evidence preserved, no final result claimed')
        raw,records=read_completed()
        if len(records)>=next_checkpoint and len(records)<100:
            text=('PORTFOLIO EXPOSURE: REASONING-ENABLED RECHECK\n'
                  f"Status: IN PROGRESS; {len(records)}/100 evaluation responses recorded.\n"
                  f"Checkpoint UTC: {now()}\n\n"
                  'These are partial results. No final scientific conclusion is claimed.\n'
                  'All frozen cases will be scored; saved errors are never replaced.\n'
                  'Four development responses are excluded. The v5-v8 manuscripts remain unchanged.\n'
                  'The companion ZIP preserves completed raw answers and the fixed protocol.\n'
                  'A completion task is configured to score all 100 and update these same files.\n'
                  'An interruption or transfer failure can prevent that update; only COMPLETE\n'
                  'marks the finished analysis. Sampling, thinking and budget change together,\n'
                  'so the experiment does not isolate the effect of thinking alone.\n\n'
                  '中文：实验仍在运行，以上是已保存的实际题数。尚无全套结果。\n')
            publish_files(text,{'status':'IN_PROGRESS','evaluation_records':len(records),'checkpoint_utc':now()},raw)
            next_checkpoint=len(records)+1
        time.sleep(10)
    result=subprocess.run([sys.executable,str(ROOT/'analyze.py')],text=True,capture_output=True)
    (ROOT/'results/analysis_execution.log').write_text(result.stdout+'\n'+result.stderr)
    if result.returncode:raise RuntimeError('Frozen analysis failed; see analysis_execution.log')
    report=json.loads((ROOT/'results/analysis.json').read_text());assert report['evaluation_calls']==100
    text,rows=build_report(report)
    (ROOT/'RESULTS.txt').write_text(text)
    with open(ROOT/'results/counts.csv','w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    state={'status':'COMPLETE_ANALYSIS_READY','finished_at_utc':now(),'evaluation_records':100,'protocol_sha256':hashlib.sha256((ROOT/'data/protocol.json').read_bytes()).hexdigest()}
    publish_files(text,state)

if __name__=='__main__':
    try:main()
    except Exception as e:
        (ROOT/'results/finalization_error.json').write_text(json.dumps({'error':repr(e),'time_utc':now()},indent=2)+'\n')
        raise
