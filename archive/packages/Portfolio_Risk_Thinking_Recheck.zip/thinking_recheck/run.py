"""Prospectively frozen reasoning-enabled recheck; append-only saved responses."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,json,hashlib,subprocess,time,urllib.request,random,concurrent.futures,os
ROOT=Path(__file__).resolve().parent
def load(p):return [json.loads(l) for l in p.read_text().splitlines() if l.strip()]
def sha(p):
    with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--development',action='store_true');ap.add_argument('--development-json',action='store_true');a=ap.parse_args()
    if a.development_json:assert a.development
    cfg=json.loads((ROOT/'data/protocol.json').read_text())
    for n,h in cfg['files'].items():assert sha(ROOT/n)==h,n
    meta=json.loads((ROOT/'runtime/model_manifest.json').read_text())
    model=ROOT.parent/'experiment_v4/runtime'/meta['filename']
    assert sha(model)==meta['sha256'],'Model bytes differ'
    binary=ROOT.parent/'experiment_v3/runtime/llama/llama-b12110/llama-server'
    assert sha(binary)==cfg['binary_sha256']
    ps=load(ROOT/'data'/('development.jsonl' if a.development else 'prompts.jsonl'))
    target=ROOT/'results'/('development_json' if a.development_json else 'development' if a.development else 'evaluation');target.mkdir(exist_ok=True)
    out=target/'raw.jsonl';old=load(out) if out.exists() else [];done={r['request_id'] for r in old};assert len(done)==len(old)
    random.Random(cfg['seed']).shuffle(ps);pending=[p for p in ps if p['request_id'] not in done]
    if not pending:print('All records already present');return
    slots=cfg['slots'];ctx=cfg['context_per_slot'];port=8774
    cmd=[str(binary),'-m',str(model),'--host','127.0.0.1','--port',str(port),'-t','8','-tb','8','-c',str(slots*ctx),'--parallel',str(slots),'--seed',str(cfg['seed']),'--jinja','--reasoning','on','--reasoning-format','deepseek','--reasoning-budget','-1','--timeout','3600','--no-repack','--cache-ram','0','--no-cache-prompt']
    log=open(target/'server.log','a');server=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
    def call(path,payload=None):
        req=urllib.request.Request(f'http://127.0.0.1:{port}'+path,data=None if payload is None else json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=3600) as f:return json.load(f)
    try:
        for _ in range(300):
            if server.poll() is not None:raise RuntimeError('Server exited; see server.log')
            try:call('/health');break
            except Exception:time.sleep(.5)
        else:raise RuntimeError('Server did not become healthy')
        (target/'server_properties.json').write_text(json.dumps(call('/props'),indent=2)+'\n')
        lengths={}
        for p in pending:
            msgs=[{'role':'system','content':p['system']},{'role':'user','content':p['prompt']}]
            rendered=call('/apply-template',{'messages':msgs,'add_generation_prompt':True,'chat_template_kwargs':{'enable_thinking':True}})['prompt']
            disabled=call('/apply-template',{'messages':msgs,'add_generation_prompt':True,'chat_template_kwargs':{'enable_thinking':False}})['prompt']
            assert '</think>' not in rendered.split('<|im_start|>assistant')[-1] and '</think>' in disabled.split('<|im_start|>assistant')[-1]
            length=len(call('/tokenize',{'content':rendered,'add_special':True})['tokens']);assert length+cfg['max_tokens']<=ctx,(p['request_id'],length)
            lengths[p['request_id']]=length
        (target/'preflight_lengths.json').write_text(json.dumps(lengths,indent=2)+'\n')
        segment={'started_at_utc':datetime.now(timezone.utc).isoformat(),'command':cmd,'model':meta,'protocol_sha256':sha(ROOT/'data/protocol.json'),'request_ids':[p['request_id'] for p in pending],'recorded_before':len(old),'max_preflight_tokens':max(lengths.values()),'model_sha256_verified':True,'thinking_template_verified':True}
        with open(target/'execution_segments.jsonl','a') as f:f.write(json.dumps(segment)+'\n');f.flush();os.fsync(f.fileno())
        def infer(p):
            payload={'model':meta['model_id'],'messages':[{'role':'system','content':p['system']},{'role':'user','content':p['prompt']}],'temperature':cfg['temperature'],'top_p':cfg['top_p'],'top_k':cfg['top_k'],'min_p':cfg['min_p'],'seed':cfg['seed'],'max_tokens':cfg['max_tokens'],'stream':False,'chat_template_kwargs':{'enable_thinking':True},'cache_prompt':False}
            if a.development_json or cfg['response_format_grammar'] is not None:payload['response_format']={'type':'json_object'}
            rec={'request_id':p['request_id'],'started_at_utc':datetime.now(timezone.utc).isoformat(),'request_payload':payload,'request_sha256':hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()};start=time.monotonic()
            try:
                resp=call('/v1/chat/completions',payload);msg=resp['choices'][0]['message'];rec.update(status='response_received',response=resp,raw_text=msg.get('content'),reasoning_text=msg.get('reasoning_content'))
            except Exception as e:rec.update(status='request_error',error=repr(e))
            rec['elapsed_seconds']=time.monotonic()-start;return rec
        with open(out,'a',buffering=1) as f,concurrent.futures.ThreadPoolExecutor(max_workers=slots) as ex:
            jobs=[ex.submit(infer,p) for p in pending]
            for n,job in enumerate(concurrent.futures.as_completed(jobs),len(old)+1):
                rec=job.result();f.write(json.dumps(rec)+'\n');f.flush();os.fsync(f.fileno())
                print(json.dumps({'completed':n,'total':len(ps),'request_id':rec['request_id'],'status':rec['status'],'elapsed_seconds':round(rec['elapsed_seconds'],2),'finish':rec.get('response',{}).get('choices',[{}])[0].get('finish_reason'),'tokens':rec.get('response',{}).get('usage',{}).get('completion_tokens')}),flush=True)
                (target/'progress.json').write_text(json.dumps({'completed':n,'total':len(ps),'updated_at_utc':datetime.now(timezone.utc).isoformat()})+'\n')
        if len(load(out))==len(ps):(target/'completed.json').write_text(json.dumps({'finished_at_utc':datetime.now(timezone.utc).isoformat(),'records':len(ps)})+'\n')
    finally:
        server.terminate()
        try:server.wait(timeout=10)
        except subprocess.TimeoutExpired:server.kill();server.wait()
        log.close()
if __name__=='__main__':main()
