"""Read-only observer using actual engine counters, not log freshness alone."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,json,os,time
R=Path(__file__).resolve().parent

def records():
 p=R/'results/evaluation/raw.jsonl';b=p.read_bytes() if p.exists() else b''
 if b and not b.endswith(b'\n'):b=b[:b.rfind(b'\n')+1]
 return [json.loads(x) for x in b.splitlines()]

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--once',action='store_true');a=ap.parse_args();last_sig=None;last_progress=None
 while True:
  now=datetime.now(timezone.utc);hp=R/'results/engine_health.json';h=json.loads(hp.read_text()) if hp.exists() else {}
  slots=h.get('slots') or [];sig=tuple((x.get('id'),x.get('is_processing'),x.get('n_prompt_tokens')) for x in slots)
  fresh=bool(hp.exists() and now.timestamp()-hp.stat().st_mtime<90)
  if fresh and sig and sig!=last_sig:last_progress=now;last_sig=sig
  rs=records();n=len(rs);unique=len({r['request_id'] for r in rs})
  sp=R/'results/finalization_status.json';saved=json.loads(sp.read_text()) if sp.exists() else {}
  advancing=last_progress is not None and (now-last_progress).total_seconds()<90
  status='COMPLETE_RESPONSES' if unique==100 else 'ENGINE_PROGRESS_OBSERVED' if fresh and advancing else 'ENGINE_ONLINE_NO_RECENT_COUNTER_CHANGE' if fresh and h.get('engine_health',{}).get('status')=='ok' else 'NO_RECENT_HEALTH_OBSERVATION'
  state={'observed_at_utc':now.isoformat(),'completed':n,'unique_completed':unique,'total':100,'remaining':100-unique,'state':status,
         'active_tasks':sum(bool(x.get('is_processing')) for x in slots),
         'engine_context_counters':[{'slot':x.get('id'),'processed_context_tokens':x.get('n_prompt_tokens')} for x in slots if x.get('is_processing')],
         'last_observed_counter_change_utc':last_progress.isoformat() if last_progress else None,
         'last_acknowledged_checkpoint':saved.get('evaluation_records') if saved.get('save_acknowledged') else None,
         'note':'Engine counters include prompt and generated tokens and only indicate activity. They are not a fraction of reasoning completed. Log silence alone does not establish a stall. A dated snapshot does not guarantee execution across turns.'}
  p=R/'results/live_progress.json';t=p.with_suffix('.tmp');t.write_text(json.dumps(state,indent=2)+'\n');os.replace(t,p)
  print(json.dumps(state,ensure_ascii=False),flush=True)
  if a.once or unique==100:return
  time.sleep(30)
if __name__=='__main__':main()
