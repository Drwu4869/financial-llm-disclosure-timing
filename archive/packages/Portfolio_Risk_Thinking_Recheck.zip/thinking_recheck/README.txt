REASONING-ENABLED RECHECK OF PORTFOLIO EXPOSURE TASKS

This package preserves a prospective protocol, the exact prompts, saved original
answers, executable inference and analysis code, and new raw outputs as they are
collected. It does not replace any version of the manuscript.

QUESTION
Does the large accuracy gap between homogeneous and heterogeneous account
descriptions survive a more generous reasoning configuration of the SAME
Qwen3-8B checkpoint? On the published-table tasks, are failures still in the
reported fields, or does reasoning and a deterministic calculator resolve them?

CASES
48 controlled direct questions: all 24 original families, each with one merged
homogeneous and one merged heterogeneous description. Their true total exposure
is matched within a family. Homogeneous cases are insensitive to many weighting
errors; that mathematical property is independent of whether a model fails.
52 published-table questions: all 13 constructed accounts, merged and fragmented,
with direct and ledger instructions. Published holdings and constructed account
amounts must not be confused with observed real customer accounts.
2 additional engineering prompts were each run with and without the original
JSON-object constraint (4 development calls); all are excluded from evaluation.

FAIRNESS AND LIMITS
User and system text are identical to the saved original requests. The weights
and quantization are unchanged. Thinking is enabled, the original JSON-object constraint is retained,
the output budget is raised to 4096 tokens, and sampling follows the
model author's thinking-mode recommendation. This is a configuration comparison:
it cannot isolate thinking from sampling, seed, budget and runtime differences.
The cases have previously been examined. This is not a new blind holdout.
There is one sampled answer per case; saved wrong answers are never replaced.

SCORING
The original strict JSON scorer remains the primary view: final exposure must be
within 0.5 percentage points. Exact ledger means correct lot identifiers, amounts
within GBP 0.005 and allocations within 0.00005 percentage points. These strict
field tolerances were inherited, not selected after observing these new answers.
The predeclared format-only secondary view removes a single enclosing JSON code
fence or aliases lots to rows when rows is absent. It never repairs numeric data.
Truncations count as failures. Reasoning text is saved but never mined for a final
answer. A deterministic calculator uses reported ledger values without replacing
them with the correct fields. It is not an autonomous tool-calling experiment.

INTERPRETATION BEFORE RESULTS
If errors largely disappear, the old setup underestimated this checkpoint's
capability; the existing evidence does not support a broad practical failure
claim. The mathematical benchmark blind spot may remain a methodological point.
If heterogeneous direct answers still fail but faithful ledgers plus calculation
work, the evidence supports an arithmetic/pipeline limitation, not an extraction
failure. If field errors persist, inspect all failures and report counts; a few
cases cannot establish a general mechanism. No outcome guarantees novelty,
publication, admission or a job. A ceiling result does not prove equivalence.

FILES AND REPRODUCTION
data/protocol.json records selection, settings and SHA-256 hashes frozen before
evaluation. data/prompts.jsonl and baseline_raw.jsonl contain the 100 paired cases.
runtime/model_manifest.json pins the model revision and bytes. Obtain the weights
and llama.cpp b12110 separately; they are not bundled in this evidence archive.
run.py expects them at the relative paths shown in its source; adjust only these
path settings when reproducing on another computer and document the adjustment.
Run python run.py, then python analyze.py. Development records are already
bundled; --development and --development-json are engineering-only switches.
The 4096-token budget is larger than the original 512 but below the author
recommended 32768; any remaining truncation is a budget limitation, not evidence
of inability. The original planning checkpoint had proposed removing grammar;
development verified compatibility and the final protocol retains it.
The original directory layout is documented in run.py. Python 3.12 and NumPy are
used; llama.cpp runs locally on CPU. Unfinished inference can resume unsaved IDs.
results/development and results/evaluation are separate. A completed.json marker
is written only after all 100 evaluation records exist; analysis.py refuses an
incomplete evaluation. Do not treat a partial checkpoint as final results.

Official setup reference:
https://huggingface.co/Qwen/Qwen3-8B
Recommended thinking settings: temperature 0.6, top_p 0.95, top_k 20, min_p 0.
The official model card specifically discourages greedy decoding in thinking mode.
