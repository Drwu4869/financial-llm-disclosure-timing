"""Produce an evidence-status note from completed analyses, without quality guarantees."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
EXP=ROOT/'experiment_v4' if (ROOT/'experiment_v4').exists() else ROOT.parent/'experiment_v4'

def load(p):return json.loads(p.read_text())

def main():
    audit=load(EXP/'results/release_audit.json')
    assert audit['status']=='PASS'
    lines=[
        'TEXTUAL FRAGMENTATION AND PORTFOLIO RISK — EVIDENCE STATUS',
        '',
        'The original research object is retained. This revision does not start the separate cross-document summarization project. The original manuscript and source ZIP remain archived.',
        '',
        'COMPLETED WORK',
        '- English LaTeX manuscript with formula provenance and primary-source references.',
        '- Proofs of a homogeneous-holdings blind spot, a contrast-rank identification condition, a bounded-noise reconstruction result, and a sharp worst-case exposure bound with a standard-deviation consequence.',
        '- An executable eight-call candidate diagnostic and a matched eight-call consistency comparator.',
        '- 3,840 explicitly injected aggregation rules; these are simulations, NOT model responses.',
        f"- {audit['new_evaluation_records']} original new-study evaluation records, {audit['runtime_recheck_records']} uniform-execution recheck records and {audit['development_records']} separate development records, plus the retained 472-record pilot. These totals exclude interrupted attempts without a saved response.",
        '- Per model: 576 controlled calls on 32 cases in 16 paired families; 60 source-derived calls on 20 constructed accounts sharing five official factsheets; 64 unseen-composition calls on the same 32 controlled cases.',
        '- Full saved responses, request hashes, model manifests, failure records, executable analyses, and an internal integrity audit.',
        '',
        'OBSERVED RESULTS (all-attempt denominators; invalid answers count as failures)',
    ]
    for m,label in [('smol','SmolLM3-3B'),('qwen8','Qwen3-8B')]:
        core=load(EXP/f'results/{m}/prompts_evaluation'/('analysis_uniform.json' if m=='qwen8' else 'analysis.json'))['all']
        source=load(EXP/f'results/{m}/source_prompts_evaluation/analysis.json')
        units=load(EXP/f'results/{m}/source_prompts_evaluation/unit_sensitivity.json')['summary']
        ch=load(EXP/f'results/{m}/challenge_prompts_evaluation'/('analysis_uniform.json' if m=='qwen8' else 'analysis.json'))
        a=core['audit'];co=core['consistency']
        lines.extend([
            f'{label}:',
            f"  Direct aggregate exposure: {core['base_correct']}/32; source-factored exposure: {core['ledger_correct']}/32; fully faithful copied ledgers: {core['ledger_faithful']}/32.",
            f"  Direct risk: {core['risk_direct_correct']}/32; risk given verified weights: {core['risk_oracle_correct']}/32; source-factored extraction + calculator: {core['ledger_calculator_correct']}/32.",
            f"  Contrast audit: accepts {a['accepted']}/32, with {a['wrong_accepts']} incorrect accepted base answers. Consistency: accepts {co['accepted']}/32, with {co['wrong_accepts']} incorrect accepts.",
            f"  Source-derived all-target accuracy: direct {source['correct']['direct']}/20, split {source['correct']['split']}/20, source-factored {source['correct']['ledger']}/20.",
            f"  Explicitly post hoc unit sensitivity: direct {units['direct']['converted_correct']}/20, split {units['split']['converted_correct']}/20, source-factored {units['ledger']['converted_correct']}/20; these do not replace primary scores.",
            f"  Both unseen compositions correct: {ch['challenge_pass']}/32; {ch['base_correct_but_challenge_fail']} currently correct base cases fail the challenge.",
        ])
        if a['accepted']==0:lines.append('  The contrast audit has zero coverage here. It is not an empirically useful acceptance policy at this operating point.')
    lines.extend([
        '',
        'WHAT IS AND IS NOT NEW',
        'The proposed contribution is a specific identifiability analysis and contrast-based diagnostic for portfolio-text aggregation. Weighted accounting, portfolio variance, normalization, finite differences, Hadamard identities, linear identification, and arithmetic delegation are established methods. The paper does not claim to have invented those components.',
        'The fixed-linear guarantees are proved under stated assumptions. They are not guarantees for an arbitrary LLM. The diagnostic uses known benchmark source structure; a calculator can directly solve these structured inputs. Reconstructed weights do not reveal hidden attention or internal model reasoning.',
        '',
        'CHRONOLOGY AND DATA PROVENANCE',
        'The core inputs and metrics were locally frozen before fresh core inference. Local hashes are not external preregistration. Analysis code was completed while inference ran.',
        'The unseen-composition extension was designed during core inference. An input-only amplitude amendment preceded every challenge response; both versions are archived. Neither gate was retuned.',
        'The all-query normalization diagnostic was added after observing Smol core failure and is explicitly post hoc. The source-copy audit was added during inference. Neither replaces a primary endpoint.',
        'A source-unit conversion sensitivity was added after both source evaluations completed, prompted by observed percentage/fraction interface failures. The fixed blockwise conversion rule does not consult gold answers, uses the unchanged tolerance, and does not alter primary scores or raw records.',
        'After 360 initial Qwen core records, a separate protocol selected all 167 records outside the final runtime profile using identifiers and commands only. All 167 are replaced in the uniform analysis by fresh responses under that profile, even when worse; original outputs remain archived and both views are reported. This is an execution amendment, not an independent sample or best-of-n selection.',
        'Controlled holdings and return states are constructed. Source-derived holdings use actual issuer-disclosed numbers, but account allocations and funded-lot splits are constructed. Two PDF engines and in-project visual inspection checked the source tables; there is no independent human annotation.',
        'An infrastructure interruption required resuming missing requests. Saved responses were never overwritten or selected by correctness. Complete failure records remain in the package.',
        '',
        'UNRESOLVED PUBLICATION CLAIMS',
        'This is a completed, reproducible research-manuscript revision, not a peer-reviewed or accepted paper. The experiments do not by themselves establish a superior general-purpose verification algorithm, a new universal diversification bias, profitable trading, or a new market-risk estimator.',
        'Novelty priority and venue suitability still require independent scholarly assessment. The small controlled sample, quantized non-thinking local models, one issuer/date in the source tier, and absence of independent annotation limit generalization. A broader empirical superiority claim requires fresh external tasks and a prespecified useful coverage/error target.',
        'The named author must understand and check the proofs, code and findings before submission. Venue formatting, authorship and AI-use disclosure requirements must be applied to the selected venue. Publication, funded-PhD admission and employment cannot be guaranteed.',
    ])
    lines.extend(['', 'REVISION 5 ADDENDUM', 'See V5_REVIEW_NOTES.txt for the post hoc exact-checkable incompatibility analysis. It reuses v4 observations, adds no model calls, and does not change the primary scores above.'])
    (ROOT/'RESEARCH_STATUS.txt').write_text('\n'.join(lines)+'\n')
    print('Wrote RESEARCH_STATUS.txt from completed evidence.')

if __name__=='__main__':main()
