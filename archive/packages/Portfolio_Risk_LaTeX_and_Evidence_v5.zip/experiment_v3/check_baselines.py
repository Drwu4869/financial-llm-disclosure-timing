"""A deliberately simple non-LLM baseline for the controlled text grammar."""
import json,re
from build_experiment import ROOT,DATA,load_jsonl,risk

pattern=re.compile(r'The account invests ([0-9.]+)% in product P\d+, which holds ([0-9.]+)% Asset_A and ([0-9.]+)% Asset_B\.')
cases={c['case_id']:c for c in load_jsonl(DATA/'cases.jsonl')}
gold={g['request_id']:g for g in load_jsonl(DATA/'answer_key.jsonl')}
rows=[]
for p in load_jsonl(DATA/'prompts.jsonl'):
    if p['split']!='evaluation' or p['task']!='extract':continue
    matches=pattern.findall(p['prompt'])
    w=[sum(float(q)/100*float(a)/100 for q,a,b in matches),sum(float(q)/100*float(b)/100 for q,a,b in matches)]
    g=gold[p['request_id']];c=cases[p['case_id']]
    rows.append({'request_id':p['request_id'],'exposure_l1_error':sum(abs(w[j]-g['weights'][a]) for j,a in enumerate(['Asset_A','Asset_B'])),'risk_error_pct':abs(risk(w,c['returns_pct'])-g['volatility_pct'])})
out={'status':'DETERMINISTIC_TEMPLATE_BASELINE_NOT_LLM_RESULTS','attempts':len(rows),'correct_exposures':sum(r['exposure_l1_error']<=1e-6 for r in rows),'max_risk_error_pct':max(r['risk_error_pct'] for r in rows),'scope':'Known controlled template only. This parser cannot be assumed to handle real fund disclosures. Success shows the benchmark does not establish a need for an LLM.','records':rows}
(ROOT/'results/rule_baseline.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='records'},indent=2))
