"""Post hoc format-only normalization. Never changes or overwrites raw responses."""
import copy,json,re
from pathlib import Path
from build_experiment import ROOT,load_jsonl,sha
from analyze_experiment import analyze


def normalize(text):
    if not isinstance(text,str):return text,[]
    t=text.strip();actions=[]
    m=re.fullmatch(r'```(?:json)?\s*\n?(.*?)\n?```',t,re.DOTALL|re.IGNORECASE)
    if m:t=m.group(1).strip();actions.append('removed_single_outer_code_fence')
    try:x=json.loads(t)
    except json.JSONDecodeError:return text,[]
    def visit(v):
        if isinstance(v,str) and re.fullmatch(r'-?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?',v):
            actions.append('numeric_string_to_number');return float(v)
        if isinstance(v,dict):return {k:visit(a) for k,a in v.items()}
        if isinstance(v,list):return [visit(a) for a in v]
        return v
    y=visit(x)
    return json.dumps(y),actions


def run(folder,joint=False):
    folder=Path(folder);dest=folder/'sensitivity';dest.mkdir(parents=True,exist_ok=True)
    rows=[];audit=[]
    for r in load_jsonl(folder/'raw_responses.jsonl'):
        z=copy.deepcopy(r);text,actions=normalize(r.get('raw_text'));z['raw_text']=text
        z['analysis_only_normalization']=actions;rows.append(z)
        audit.append({'request_id':r['request_id'],'actions':actions})
    path=dest/'normalized_responses.jsonl';path.write_text(''.join(json.dumps(r)+'\n' for r in rows))
    (dest/'normalization_audit.json').write_text(json.dumps({'source_raw_sha256':sha(folder/'raw_responses.jsonl'),'status':'POST_HOC_FORMAT_SENSITIVITY_NOT_PRIMARY_ANALYSIS','no_numeric_values_changed':True,'records':audit},indent=2)+'\n')
    if joint:
        from analyze_joint import analyze as analyze_joint
        return analyze_joint(folder,path,dest)
    return analyze(folder,path,dest)


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('folder');p.add_argument('--joint',action='store_true');a=p.parse_args();r=run(a.folder,a.joint)
    print(json.dumps({k:v for k,v in r.items() if k in ['valid_outputs','paired_effects','valid_joint','correct_reported_exposures','risk_within_5pct_given_correct_reported_exposures','inconsistent_with_own_weights_by_over_5pct_of_true_risk']},indent=2))
