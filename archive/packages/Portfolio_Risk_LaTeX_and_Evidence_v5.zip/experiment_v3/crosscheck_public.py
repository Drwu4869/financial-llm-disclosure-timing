"""Optional independent CSV-parser cross-check; requires pandas."""
import io,json,zipfile
import pandas as pd
from build_experiment import ROOT,DATA,load_jsonl

with zipfile.ZipFile(ROOT/'data/source/49_Industry_Portfolios_CSV.zip') as z:
    text=z.read('49_Industry_Portfolios.csv').decode('utf-8-sig')
a=text.index('Average Value Weighted Returns -- Monthly');b=text.index('Average Equal Weighted Returns -- Monthly')
section='\n'.join(text[a:b].splitlines()[1:]).strip()
df=pd.read_csv(io.StringIO(section),index_col=0);df.columns=df.columns.str.strip()
checks=0
for c in load_jsonl(DATA/'cases.jsonl'):
    if c['domain']!='public_returns':continue
    for month,row in zip(c['row_labels'],c['returns_pct']):
        for label,value in zip(c['provenance']['industry_codes'],row):
            assert float(df.loc[int(month),label])==value;checks+=1
out={'status':'SOURCE_VALUE_CROSSCHECK_PASS','independent_parser':'pandas.read_csv vs generator csv.reader','exact_scalar_matches':checks,'data_values_modified':False,'external_human_review':False}
(ROOT/'results/source_crosscheck.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
