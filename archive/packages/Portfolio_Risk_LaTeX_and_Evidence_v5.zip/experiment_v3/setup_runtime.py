"""Download pinned public inference artifacts; preserve their original licenses."""
import argparse,hashlib,json,tarfile,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def digest(path):
    with open(path,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def download(item):
    name=item.get('file',item.get('filename'));p=ROOT/'runtime'/name
    if p.exists() and digest(p)==item['sha256']:return p
    temp=p.with_suffix(p.suffix+'.part')
    print('Downloading',name,flush=True)
    with urllib.request.urlopen(item['url'],timeout=120) as r,open(temp,'wb') as f:
        while b:=r.read(8*1024*1024):f.write(b)
    if digest(temp)!=item['sha256']:raise RuntimeError('Artifact hash mismatch; refusing to use changed bytes')
    temp.replace(p);return p

def main():
    p=argparse.ArgumentParser();p.add_argument('--scale',choices=['1.5b','3b','both'],default='both');a=p.parse_args()
    items=json.loads((ROOT/'runtime/runtime_manifest.json').read_text())
    binary=download(items[0])
    with tarfile.open(binary) as t:t.extractall(ROOT/'runtime/llama',filter='data')
    if a.scale in ['1.5b','both']:download(items[1])
    if a.scale in ['3b','both']:download(json.loads((ROOT/'runtime/qwen3b_manifest.json').read_text()))
    print('Pinned runtime artifacts ready.')

if __name__=='__main__':main()
