"""Analyze actual inference logs. Test fixtures are never loaded as observations."""
import json
import math
import random
import statistics
from collections import defaultdict
from pathlib import Path

from build_experiment import ROOT, DATA, load_jsonl, risk, sha


def number(x):
    return isinstance(x,(float,int)) and not isinstance(x,bool) and math.isfinite(x)


def parse(text,task):
    try:
        x=json.loads(text)
        if not isinstance(x,dict):return None,'not_object'
    except (json.JSONDecodeError,TypeError):return None,'invalid_json'
    if task=='risk':
        v=x.get('volatility_pct')
        return (v,'valid') if number(v) and v>=0 else (None,'invalid_risk')
    w=x.get('weights')
    if not isinstance(w,dict) or set(w)!= {'Asset_A','Asset_B'}:return None,'invalid_assets'
    vals=[w[a] for a in ['Asset_A','Asset_B']]
    if not all(number(v) and 0<=v<=1 for v in vals):return None,'invalid_weight'
    if abs(sum(vals)-1)>1e-6:return None,'invalid_total'
    return vals,'valid'


def bootstrap(xs,seed=20261104):
    if not xs:return None
    rng=random.Random(seed);n=len(xs)
    means=sorted(statistics.mean(rng.choices(xs,k=n)) for _ in range(10000))
    return [means[249],means[9749]]


def mean(xs):return statistics.mean(xs) if xs else None


def analyze(results_dir=None,response_file=None,output_dir=None):
    res=Path(results_dir) if results_dir else ROOT/'results'
    destination=Path(output_dir) if output_dir else res
    destination.mkdir(parents=True,exist_ok=True)
    cases={c['case_id']:c for c in load_jsonl(DATA/'cases.jsonl')}
    prompts={p['request_id']:p for p in load_jsonl(DATA/'prompts.jsonl') if p['split']=='evaluation'}
    gold={g['request_id']:g for g in load_jsonl(DATA/'answer_key.jsonl')}
    input_path=Path(response_file) if response_file else res/'raw_responses.jsonl'
    raw=load_jsonl(input_path)
    if not raw:raise ValueError('No empirical observations')
    selected=set(prompts)
    sel_path=res/'selected_requests.json'
    if sel_path.exists():selected=set(json.loads(sel_path.read_text()))
    assert len(raw)==len({r['request_id'] for r in raw})
    parsed=[];lookup={}
    for r in raw:
        assert r['request_id'] in selected
        p=prompts[r['request_id']];c=cases[p['case_id']];g=gold[p['request_id']]
        value,status=parse(r.get('raw_text'),p['task'])
        predicted=risk(value,c['returns_pct']) if value is not None and p['task']=='extract' else value
        error=abs(predicted-g['volatility_pct'])/g['volatility_pct'] if predicted is not None else None
        l1=None
        if value is not None and p['task']=='extract':l1=sum(abs(value[j]-g['weights'][a]) for j,a in enumerate(['Asset_A','Asset_B']))
        z={'request_id':r['request_id'],'case_id':p['case_id'],'domain':p['domain'],'condition':p['condition'],'task':p['task'],'parse_status':status,'valid':value is not None,'predicted_risk_pct':predicted,'true_risk_pct':g['volatility_pct'],'relative_error':error,'exposure_l1_error':l1,'finish_reason':r.get('response',{}).get('choices',[{}])[0].get('finish_reason')}
        parsed.append(z);lookup[(p['case_id'],p['condition'])]=z
    conditions=defaultdict(list)
    for z in parsed:conditions[(z['domain'],z['condition'])].append(z)
    summary=[]
    for (domain,condition),rows in sorted(conditions.items()):
        errors=[z['relative_error'] for z in rows if z['valid']]
        summary.append({'domain':domain,'condition':condition,'attempts':len(rows),'valid':len(errors),'within_1pct_all_attempts':sum(z['valid'] and z['relative_error']<=.01 for z in rows),'within_5pct_all_attempts':sum(z['valid'] and z['relative_error']<=.05 for z in rows),'mean_relative_error_valid':mean(errors),'median_relative_error_valid':statistics.median(errors) if errors else None,'correct_exposures':sum(z['exposure_l1_error'] is not None and z['exposure_l1_error']<=1e-6 for z in rows) if rows[0]['task']=='extract' else None})
    effects=[]
    comparisons=[('direct','direct_one','direct_eight'),('matched','matched_one','matched_eight'),('oracle','oracle_one','oracle_eight'),('extraction_calculator','extract_one','extract_eight'),('heterogeneous','direct_one','direct_heterogeneous')]
    for domain in ['synthetic','public_returns']:
        for label,left,right in comparisons:
            ds=[];absds=[];planned=0
            for cid,c in cases.items():
                if c['split']!='evaluation' or c['domain']!=domain:continue
                if (cid,left) not in lookup or (cid,right) not in lookup:continue
                planned+=1;a=lookup[(cid,left)];b=lookup[(cid,right)]
                if a['valid'] and b['valid']:
                    d=(b['predicted_risk_pct']-a['predicted_risk_pct'])/a['true_risk_pct'];ds.append(d);absds.append(abs(d))
            effects.append({'domain':domain,'comparison':label,'attempted_pairs':planned,'valid_pairs':len(ds),'mean_normalized_gap':mean(ds),'mean_absolute_normalized_gap':mean(absds),'exploratory_case_bootstrap_95ci':bootstrap(ds),'case_gaps':ds})
    controls=[]
    for domain in ['synthetic','public_returns']:
        for base in ['direct_one','direct_eight','extract_one','extract_eight']:
            attempted=valid=correct=0;errs=[]
            for cid,c in cases.items():
                if c['split']!='evaluation' or c['domain']!=domain:continue
                if (cid,base) not in lookup or (cid,'control_'+base) not in lookup:continue
                attempted+=1;a=lookup[(cid,base)];b=lookup[(cid,'control_'+base)]
                if a['valid'] and b['valid']:
                    valid+=1;delta=b['predicted_risk_pct']-a['predicted_risk_pct'];truth=b['true_risk_pct']-a['true_risk_pct'];correct+=delta*truth>0
                    errs.append(abs(delta-truth)/a['true_risk_pct'])
            controls.append({'domain':domain,'pipeline':base,'attempted_pairs':attempted,'valid_pairs':valid,'correct_direction':correct,'direction_accuracy_all_pairs':correct/attempted if attempted else None,'mean_normalized_change_error_valid':mean(errs)})
    tokens=json.loads((res/'token_counts.json').read_text())
    matched_tokens=[]
    for cid,c in cases.items():
        a=cid+'__matched_one';b=cid+'__matched_eight'
        if a in tokens and b in tokens:matched_tokens.append({'case_id':cid,'one':tokens[a],'eight':tokens[b],'equal':tokens[a]==tokens[b]})
    report={'status':'OBSERVED_LOCAL_MODEL_PILOT','model_id':raw[0]['model_id'],'planned_requests':len(selected),'recorded_requests':len(raw),'complete':set(r['request_id'] for r in raw)==selected,'unique_evaluation_cases':len({r['case_id'] for r in parsed}),'valid_outputs':sum(r['valid'] for r in parsed),'request_errors':sum(r['status']!='response_received' for r in raw),'length_terminated_outputs':sum(r['finish_reason']=='length' for r in parsed),'conditions':summary,'paired_effects':effects,'risk_change_controls':controls,'matched_token_counts':matched_tokens,'raw_responses_sha256':sha(res/'raw_responses.jsonl'),'interpretation':'Exploratory, conditional on fixed small quantized model, selected task cases and deterministic decoding. Intervals do not measure market forecast uncertainty. A correct calculator after a correct extraction is not a novel algorithm.'}
    report['analysis_input_sha256']=sha(input_path)
    report['posthoc_output_normalization']=response_file is not None
    (destination/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
    (destination/'parsed_responses.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in parsed))
    return report


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--results-dir');a=p.parse_args()
    r=analyze(a.results_dir)
    print(json.dumps({k:v for k,v in r.items() if k in ['status','complete','recorded_requests','unique_evaluation_cases','valid_outputs','length_terminated_outputs','conditions','paired_effects','risk_change_controls']},indent=2))
