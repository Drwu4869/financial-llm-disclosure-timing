"""Check recorded evidence against frozen prompts; never run or invent a model."""
import hashlib
import json
from collections import Counter
from pathlib import Path
from build_experiment import ROOT, DATA, load_jsonl, sha


def main():
    protocol=json.loads((DATA/'protocol.json').read_text())
    extension=json.loads((DATA/'extension_protocol.json').read_text())
    posthoc=json.loads((DATA/'posthoc_protocol.json').read_text())
    for plan in [protocol,extension]:
        for name,digest in plan['files'].items():
            assert sha(DATA/name)==digest, name
    assert sha(DATA/'posthoc_prompts.jsonl')==posthoc['prompt_sha256']
    assert sha(ROOT/'data/source/49_Industry_Portfolios_CSV.zip')==protocol['source_sha256']
    prompt_sets={
        'core':{p['request_id']:p for p in load_jsonl(DATA/'prompts.jsonl')},
        'joint':{p['request_id']:p for p in load_jsonl(DATA/'joint_prompts.jsonl')},
        'posthoc':{p['request_id']:p for p in load_jsonl(DATA/'posthoc_prompts.jsonl')},
    }
    specs=[('results','core',240),('results/joint','joint',32),
           ('results/posthoc','posthoc',32),('results_3b','core',120),
           ('results_3b/joint','joint',16),('results_3b/posthoc','posthoc',32)]
    phases=[];seen_cases=set()
    for folder,kind,expected in specs:
        path=ROOT/folder/'raw_responses.jsonl';rows=load_jsonl(path)
        assert len(rows)==expected and len({r['request_id'] for r in rows})==expected
        finish=Counter()
        for r in rows:
            p=prompt_sets[kind][r['request_id']]
            assert p['split']=='evaluation'
            if folder.startswith('results_3b') and kind!='posthoc':
                assert int(p['case_id'].split('_')[-1])<=4
            seen_cases.add(p['case_id'])
            payload={'model':r['model_id'],
                     'messages':[{'role':'system','content':p['system']},
                                 {'role':'user','content':p['prompt']}],
                     'temperature':0,'seed':protocol['seed'],'max_tokens':128,
                     'stream':False,'cache_prompt':False}
            digest=hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()
            assert digest==r['request_sha256'],r['request_id']
            assert r['status']=='response_received'
            assert r['raw_text']==r['response']['choices'][0]['message']['content']
            finish[r['response']['choices'][0]['finish_reason']]+=1
            assert r['started_at_utc']>protocol['frozen_at_utc']
        phases.append({'folder':folder,'calls':len(rows),'request_hash_matches':len(rows),
                       'raw_sha256':sha(path),'finish_reasons':dict(finish)})
    assert len(seen_cases)==16
    # Verify the specific post hoc pattern discussed in the paper against raw outputs.
    rr={r['request_id']:r for r in load_jsonl(ROOT/'results_3b/raw_responses.jsonl')}
    gold={r['request_id']:r for r in load_jsonl(DATA/'answer_key.jsonl')}
    fixed=json.loads((ROOT/'results_3b/renormalization_analysis.json').read_text())['records']
    added=[r for r in fixed if r['condition']=='extract_eight' and r.get('changed') and r.get('exact_exposures')]
    assert len(added)==4
    for r in added:
        rid=r['request_id'];hetero=rid.replace('__extract_eight','__extract_heterogeneous')
        assert json.loads(rr[rid]['raw_text'])['weights']=={'Asset_A':.8,'Asset_B':.8}
        assert gold[rid]['weights']=={'Asset_A':.5,'Asset_B':.5}
        assert json.loads(rr[hetero]['raw_text'])['weights']=={'Asset_A':.8,'Asset_B':.2}
    report={'status':'PASS','scope':'Internal reproducibility audit, not independent external review',
            'calls':sum(x['calls'] for x in phases),'unique_evaluation_cases':len(seen_cases),
            'request_payload_hash_matches':sum(x['request_hash_matches'] for x in phases),
            'normalization_pattern_verified_cases':4,'phases':phases}
    (ROOT/'results/release_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
