"""Analyze the explicitly post hoc unit-example perturbations."""
import json
from collections import defaultdict
from pathlib import Path
from build_experiment import ROOT,DATA,load_jsonl,risk,sha
from analyze_experiment import parse
from parser_sensitivity import normalize


def analyze(folder):
    folder=Path(folder);raw=load_jsonl(folder/'raw_responses.jsonl')
    ps={p['request_id']:p for p in load_jsonl(DATA/'posthoc_prompts.jsonl')}
    cs={c['case_id']:c for c in load_jsonl(DATA/'cases.jsonl')}
    groups=defaultdict(list);records=[]
    for r in raw:
        p=ps[r['request_id']];c=cs[p['case_id']];text,actions=normalize(r.get('raw_text'))
        direct,_=parse(r.get('raw_text'),p['task']);v,status=parse(text,p['task'])
        row={'request_id':p['request_id'],'reference_request_id':p['reference_request_id'],'variant':p['variant'],'task':p['task'],'strict_valid':direct is not None,'normalized_valid':v is not None,'normalization_actions':actions,'parsed_value':v,'illustrative_cue':p['illustrative_numeric_cue']}
        if v is not None:
            predicted=risk(v,c['returns_pct']) if p['task']=='extract' else v
            true=risk(c['base_weights'],c['returns_pct'])
            row['relative_risk_error']=abs(predicted-true)/true
            row['correct_exposures']=sum(abs(a-b) for a,b in zip(v,c['base_weights']))<=1e-6 if p['task']=='extract' else None
            row['equals_changed_cue']=p['illustrative_numeric_cue'] is not None and abs((v[0] if p['task']=='extract' else v)-p['illustrative_numeric_cue'])<1e-12
        records.append(row);groups[(p['task'],p['variant'])].append(row)
    summary=[]
    for (task,variant),rows in sorted(groups.items()):
        summary.append({'task':task,'variant':variant,'attempts':len(rows),'strict_valid':sum(r['strict_valid'] for r in rows),'normalized_valid':sum(r['normalized_valid'] for r in rows),'within_5pct_all_attempts':sum(r.get('relative_risk_error',float('inf'))<=.05 for r in rows),'equals_changed_cue':sum(r.get('equals_changed_cue',False) for r in rows),'correct_exposures':sum(r.get('correct_exposures',False) or False for r in rows) if task=='extract' else None})
    out={'status':'POST_HOC_OBSERVED_CUE_SENSITIVITY','model_id':raw[0]['model_id'],'attempts':len(raw),'raw_sha256':sha(folder/'raw_responses.jsonl'),'summary':summary,'records':records}
    (folder/'analysis.json').write_text(json.dumps(out,indent=2)+'\n')
    return out


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('folder');a=p.parse_args();r=analyze(a.folder);print(json.dumps(r['summary'],indent=2))
