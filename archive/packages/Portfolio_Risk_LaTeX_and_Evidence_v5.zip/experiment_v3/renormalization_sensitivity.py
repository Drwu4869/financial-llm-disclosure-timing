"""Post hoc baseline: what does mechanically forcing weights to sum to one do?

This creates derived predictions, never altered or fabricated model responses.
"""
import json
from collections import defaultdict
from pathlib import Path
from build_experiment import ROOT,DATA,load_jsonl,risk
from analyze_experiment import number,parse
from parser_sensitivity import normalize


def analyze(folder):
    folder=Path(folder);ps={p['request_id']:p for p in load_jsonl(DATA/'prompts.jsonl')};cs={c['case_id']:c for c in load_jsonl(DATA/'cases.jsonl')};gold={g['request_id']:g for g in load_jsonl(DATA/'answer_key.jsonl')}
    rows=[];groups=defaultdict(list)
    for r in load_jsonl(folder/'raw_responses.jsonl'):
        p=ps[r['request_id']]
        if p['task']!='extract':continue
        text,actions=normalize(r.get('raw_text'))
        row={'request_id':r['request_id'],'condition':p['condition'],'admissible_for_renormalization':False}
        try:
            mapping=json.loads(text)['weights'];assert set(mapping)=={'Asset_A','Asset_B'}
            w=[mapping[a] for a in ['Asset_A','Asset_B']]
            assert all(number(v) and 0<=v<=1 for v in w) and sum(w)>0
            fixed=[v/sum(w) for v in w];truth=gold[r['request_id']]
            row.update({'admissible_for_renormalization':True,'original_total':sum(w),'changed':abs(sum(w)-1)>1e-6,'derived_weights':fixed,'exact_exposures':sum(abs(fixed[j]-truth['weights'][a]) for j,a in enumerate(['Asset_A','Asset_B']))<=1e-6,'relative_risk_error':abs(risk(fixed,cs[p['case_id']]['returns_pct'])-truth['volatility_pct'])/truth['volatility_pct']})
        except (AssertionError,KeyError,TypeError,json.JSONDecodeError):pass
        rows.append(row);groups[p['condition']].append(row)
    summary=[{'condition':name,'attempts':len(rs),'admissible':sum(r['admissible_for_renormalization'] for r in rs),'modified':sum(r.get('changed',False) for r in rs),'exact_exposures':sum(r.get('exact_exposures',False) for r in rs),'within_5pct':sum(r.get('relative_risk_error',float('inf'))<=.05 for r in rs)} for name,rs in sorted(groups.items())]
    out={'status':'POST_HOC_DERIVED_PREDICTION_BASELINE','interpretation':'Renormalization is a standard mathematical operation, not a new algorithm; it does not establish semantic correctness. Original observations remain unchanged.','summary':summary,'records':rows}
    (folder/'renormalization_analysis.json').write_text(json.dumps(out,indent=2)+'\n');return out


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('folder');a=p.parse_args();print(json.dumps(analyze(a.folder)['summary'],indent=2))
