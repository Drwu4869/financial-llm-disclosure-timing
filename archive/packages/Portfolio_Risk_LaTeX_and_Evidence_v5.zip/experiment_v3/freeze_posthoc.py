"""Post hoc cue perturbations motivated by the first completed model run."""
import json,hashlib
from datetime import datetime,timezone
from build_experiment import ROOT,DATA,load_jsonl,write_jsonl,sha

if (ROOT/'results/posthoc/raw_responses.jsonl').exists():raise RuntimeError('Already executed')
out=[]
for p in load_jsonl(DATA/'prompts.jsonl'):
    if p['split']!='evaluation' or int(p['case_id'].split('_')[-1])>2 or p['condition'] not in ['direct_one','direct_eight','extract_one','extract_eight']:continue
    for variant in ['no_example','changed_example']:
        q=dict(p);q['reference_request_id']=p['request_id'];q['request_id']=p['request_id']+'__'+variant;q['variant']=variant
        if p['task']=='risk':
            old='Report percentage points: 1.25 means 1.25%.'
            new='Report percentage points, not a decimal fraction.' if variant=='no_example' else 'Report percentage points: 7.91 means 7.91%.'
            q['illustrative_numeric_cue']=None if variant=='no_example' else 7.91
        else:
            old=' (0.8 means 80%)'
            new='' if variant=='no_example' else ' (0.37 means 37%)'
            q['illustrative_numeric_cue']=None if variant=='no_example' else .37
        assert old in q['prompt'];q['prompt']=q['prompt'].replace(old,new)
        q['prompt_sha256']=hashlib.sha256(q['prompt'].encode()).hexdigest();out.append(q)
write_jsonl(DATA/'posthoc_prompts.jsonl',out)
protocol={'specified_at_utc':datetime.now(timezone.utc).isoformat(),'status':'POST_HOC_DIAGNOSTIC_NOT_CONFIRMATORY','motivation':'First completed 1.5B core run failed strict numeric formatting and inspection showed repeated copying of the numeric unit example. This extension tests cue sensitivity without changing the original outputs.','selection':'first two evaluation cases in each domain, direct and extraction, one/eight products','requests_per_model':len(out),'models':['Qwen2.5-1.5B-Instruct-Q4_K_M','Qwen2.5-3B-Instruct-Q4_K_M'],'temperature':0,'seed':20261104,'max_tokens':128,'prompt_sha256':sha(DATA/'posthoc_prompts.jsonl'),'analysis':'report strict and format-normalized validity, accuracy, and exact equality to the altered numeric cue; no p-values or population claims'}
(DATA/'posthoc_protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
print(json.dumps(protocol,indent=2))
