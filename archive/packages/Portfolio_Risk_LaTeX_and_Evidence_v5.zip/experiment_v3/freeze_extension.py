"""Specify exploratory joint-output probes and a model-scale replication.

This is a dated extension, not a retroactive amendment to the original freeze.
"""
import json,hashlib
from datetime import datetime,timezone
from build_experiment import ROOT,DATA,load_jsonl,write_jsonl,sha

if (ROOT/'results/joint/raw_responses.jsonl').exists() or (ROOT/'results_3b/raw_responses.jsonl').exists():
    raise RuntimeError('Refusing to overwrite extension protocol after extension inference started')
requests=[]
for p in load_jsonl(DATA/'prompts.jsonl'):
    if p['split']!='evaluation' or p['condition'] not in ['direct_one','direct_eight']:continue
    q=dict(p);q['condition']=p['condition'].replace('direct','joint');q['request_id']=p['case_id']+'__'+q['condition'];q['task']='joint'
    old='Return only {"volatility_pct": number}. If unable, return {"volatility_pct": null}.'
    new='Return only {"weights": {"Asset_A": number, "Asset_B": number}, "volatility_pct": number}. Weights must be fractions summing to 1. Include the aggregate weights used in your risk calculation. If unable to compute risk, use null for volatility_pct.'
    assert old in q['prompt'];q['prompt']=q['prompt'].replace(old,new)
    q['prompt_sha256']=hashlib.sha256(q['prompt'].encode()).hexdigest();requests.append(q)
write_jsonl(DATA/'joint_prompts.jsonl',requests)
meta={'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'status':'EXPLORATORY_EXTENSION_SPECIFIED_DURING_FIRST_RUN_BEFORE_OUTCOME_ANALYSIS','joint_prompts':len(requests),'joint_primary_diagnostic':'Observed error identity: risk_hat - risk_true = (risk(declared_weights)-risk_true) + (risk_hat-risk(declared_weights)). This concerns reported outputs, not hidden reasoning.','joint_coverage':'all 16 evaluation cases for 1.5B; first four cases per domain for 3B','replication_model':'Qwen/Qwen2.5-3B-Instruct-GGUF','replication_revision':'7dabda4d13d513e3e842b20f0d435c732f172cbe','replication_quantization':'Q4_K_M','replication_selection':'case indices 01 through 04 in each domain; no selection based on model outputs','replication_core_requests':120,'replication_joint_requests':16,'decoding':'same as original: temperature 0, seed 20261104, max_tokens 128, one replicate','files':{'joint_prompts.jsonl':sha(DATA/'joint_prompts.jsonl')},'interpretation':'exploratory same-family size replication; not independent model-family evidence'}
(DATA/'extension_protocol.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2))
