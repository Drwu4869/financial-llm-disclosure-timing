"""Run the dated exploratory extension; never synthesize model responses."""
import argparse,hashlib,json,os,random,subprocess,time,urllib.request
from datetime import datetime,timezone
from build_experiment import ROOT,DATA,load_jsonl,sha
from run_local import post


def main():
    p=argparse.ArgumentParser();p.add_argument('--scale',choices=['1.5b','3b'],required=True);p.add_argument('--phase',choices=['standard','posthoc'],default='standard');a=p.parse_args()
    protocol=json.loads((DATA/'protocol.json').read_text());ext=json.loads((DATA/'extension_protocol.json').read_text())
    for name,digest in protocol['files'].items():assert sha(DATA/name)==digest
    for name,digest in ext['files'].items():assert sha(DATA/name)==digest
    if a.scale=='1.5b':
        model_id=protocol['model_id'];folder=ROOT/'results/joint'
        groups=[(folder,load_jsonl(DATA/'joint_prompts.jsonl'))]
    else:
        model_id=ext['replication_model'];folder=ROOT/'results_3b'
        select=lambda p:p['split']=='evaluation' and int(p['case_id'].split('_')[-1])<=4
        groups=[(folder,[p for p in load_jsonl(DATA/'prompts.jsonl') if select(p)]),(folder/'joint',[p for p in load_jsonl(DATA/'joint_prompts.jsonl') if select(p)])]
    if a.phase=='posthoc':
        ph=json.loads((DATA/'posthoc_protocol.json').read_text())
        assert sha(DATA/'posthoc_prompts.jsonl')==ph['prompt_sha256']
        folder=(ROOT/'results' if a.scale=='1.5b' else ROOT/'results_3b')/'posthoc'
        groups=[(folder,load_jsonl(DATA/'posthoc_prompts.jsonl'))]
    model=ROOT/f'runtime/qwen2.5-{a.scale}-instruct-q4_k_m.gguf'
    binary=ROOT/'runtime/llama/llama-b12110/llama-server'
    cmd=[str(binary),'-m',str(model),'--host','127.0.0.1','--port','8765','-t','8','-tb','8','-c','4096','--parallel','1','--seed',str(protocol['seed'])]
    folder.mkdir(parents=True,exist_ok=True)
    log=open(folder/'server.log','a');server=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
    try:
        for _ in range(60):
            if server.poll() is not None:raise RuntimeError('Server exited')
            try:
                with urllib.request.urlopen('http://127.0.0.1:8765/health',timeout=1) as h:
                    if h.status==200:break
            except Exception:time.sleep(.5)
        else:raise RuntimeError('Server not ready')
        for target,requests in groups:
            target.mkdir(parents=True,exist_ok=True)
            random.Random(protocol['request_order_seed']).shuffle(requests)
            (target/'selected_requests.json').write_text(json.dumps([p['request_id'] for p in requests],indent=2)+'\n')
            meta={'started_at_utc':datetime.now(timezone.utc).isoformat(),'command':cmd,'engine_version':subprocess.check_output([str(binary),'--version'],text=True,stderr=subprocess.STDOUT),'model_id':model_id,'model_sha256':sha(model),'protocol_sha256':sha(DATA/'protocol.json'),'extension_protocol_sha256':sha(DATA/'extension_protocol.json'),'request_retries':0,'scope':'exploratory dated extension'}
            if a.phase=='posthoc':meta['posthoc_protocol_sha256']=sha(DATA/'posthoc_protocol.json')
            (target/'execution_metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
            lengths={p['request_id']:len(post('tokenize',{'content':p['prompt']})['tokens']) for p in requests}
            (target/'token_counts.json').write_text(json.dumps(lengths,indent=2)+'\n')
            out=target/'raw_responses.jsonl';done={r['request_id'] for r in load_jsonl(out)} if out.exists() else set()
            with open(out,'a',buffering=1) as f:
                for i,p in enumerate(requests):
                    if p['request_id'] in done:continue
                    payload={'model':model_id,'messages':[{'role':'system','content':p['system']},{'role':'user','content':p['prompt']}],'temperature':0,'seed':protocol['seed'],'max_tokens':128,'stream':False,'cache_prompt':False}
                    start=time.monotonic();r={'request_id':p['request_id'],'model_id':model_id,'replicate':0,'started_at_utc':datetime.now(timezone.utc).isoformat(),'request_sha256':hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()}
                    try:
                        ans=post('v1/chat/completions',payload);r['response']=ans;r['raw_text']=ans['choices'][0]['message']['content'];r['status']='response_received'
                    except Exception as e:r['status']='request_error';r['error']=str(e)
                    r['elapsed_seconds']=time.monotonic()-start;f.write(json.dumps(r)+'\n');f.flush();os.fsync(f.fileno())
                    print(json.dumps({'model':a.scale,'group':str(target.relative_to(ROOT)),'completed':i+1,'total':len(requests),'seconds':round(r['elapsed_seconds'],2)}),flush=True)
    finally:
        server.terminate()
        try:server.wait(timeout=10)
        except subprocess.TimeoutExpired:server.kill();server.wait()
        log.close()


if __name__=='__main__':main()
