"""Hand-checks and invalid-input tests, not model observations."""
import math
import unittest
from build_experiment import risk,graph,holdings
from analyze_experiment import parse


class ExperimentChecks(unittest.TestCase):
    def test_known_variance(self):
        R=[[-2,-2],[-2,2],[2,-2],[2,2]]*2
        self.assertAlmostEqual(risk([.8,.2],R),math.sqrt(2.72))
        self.assertAlmostEqual(risk([.5,.5],R),math.sqrt(2))

    def test_heterogeneous_containers_preserve_exposure(self):
        w=[.8,.2];g=graph(w,'heterogeneous')
        self.assertGreater(len({tuple(v) for q,v in g}),1)
        for j in range(2):self.assertAlmostEqual(sum(q*v[j] for q,v in g),w[j])

    def test_structural_checks_do_not_certify_semantics(self):
        v,s=parse('{"weights":{"Asset_A":0.5,"Asset_B":0.5}}','extract')
        self.assertEqual(s,'valid')
        self.assertNotEqual(v,[.8,.2])

    def test_invalid_outputs(self):
        for text in ['{"volatility_pct":NaN}','{"volatility_pct":true}','{"volatility_pct":-1}','```json\n{"volatility_pct":1}\n```','null']:
            self.assertIsNone(parse(text,'risk')[0])
        for text in ['{"weights":{"Asset_A":0.8}}','{"weights":{"Asset_A":80,"Asset_B":20}}','{"weights":{"Asset_A":0.8,"Asset_B":0.3}}']:
            self.assertIsNone(parse(text,'extract')[0])

    def test_constant_answer_is_invariant_but_insensitive(self):
        same=1.5
        self.assertEqual(same-same,0)
        true_base=math.sqrt(2.72);true_control=math.sqrt(2)
        self.assertFalse((same-same)*(true_control-true_base)>0)


if __name__=='__main__':unittest.main()
