"""Run a frozen exploratory evaluation on a real local model; retain raw outputs."""
import argparse
import hashlib
import json
import os
import random
import subprocess
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from build_experiment import ROOT, DATA, load_jsonl, sha


def post(endpoint, payload, timeout=180):
    body=json.dumps(payload).encode()
    req=urllib.request.Request('http://127.0.0.1:8765/'+endpoint, data=body, headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=timeout) as r:return json.load(r)


def main():
    a=argparse.ArgumentParser();a.add_argument('--limit',type=int,default=0);args=a.parse_args()
    protocol=json.loads((DATA/'protocol.json').read_text())
    for name,digest in protocol['files'].items():assert sha(DATA/name)==digest
    requests=[p for p in load_jsonl(DATA/'prompts.jsonl') if p['split']=='evaluation']
    random.Random(protocol['request_order_seed']).shuffle(requests)
    if args.limit:requests=requests[:args.limit]
    out=ROOT/'results/raw_responses.jsonl'
    done={r['request_id'] for r in load_jsonl(out)} if out.exists() else set()
    binary=ROOT/'runtime/llama/llama-b12110/llama-server'
    model=ROOT/'runtime/qwen2.5-1.5b-instruct-q4_k_m.gguf'
    cmd=[str(binary),'-m',str(model),'--host','127.0.0.1','--port','8765','-t','8','-tb','8','-c','4096','--parallel','1','--seed',str(protocol['seed'])]
    log=open(ROOT/'runtime/inference_server.log','a')
    server=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
    try:
        for _ in range(60):
            if server.poll() is not None:raise RuntimeError('Local model server exited')
            try:
                with urllib.request.urlopen('http://127.0.0.1:8765/health',timeout=1) as h:
                    if h.status==200:break
            except Exception:time.sleep(.5)
        else:raise RuntimeError('Local model server not ready')
        meta={'started_at_utc':datetime.now(timezone.utc).isoformat(),'command':cmd,'engine_version':subprocess.check_output([str(binary),'--version'],text=True,stderr=subprocess.STDOUT),'model_sha256':sha(model),'protocol_sha256':sha(DATA/'protocol.json'),'selection':'evaluation split, fixed randomized order','api_or_model_response_retries':0,'limits':args.limit}
        (ROOT/'results/execution_metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
        lengths={}
        for p in requests:
            lengths[p['request_id']]=len(post('tokenize',{'content':p['prompt']})['tokens'])
        (ROOT/'results/token_counts.json').write_text(json.dumps(lengths,indent=2)+'\n')
        with open(out,'a',buffering=1) as f:
            for i,p in enumerate(requests):
                if p['request_id'] in done:continue
                payload={'model':protocol['model_id'],'messages':[{'role':'system','content':p['system']},{'role':'user','content':p['prompt']}],'temperature':protocol['temperature'],'seed':protocol['seed'],'max_tokens':protocol['max_tokens'],'stream':False,'cache_prompt':False}
                start=time.monotonic();record={'request_id':p['request_id'],'model_id':protocol['model_id'],'replicate':0,'started_at_utc':datetime.now(timezone.utc).isoformat(),'request_sha256':hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()}
                try:
                    answer=post('v1/chat/completions',payload)
                    record['response']=answer;record['raw_text']=answer['choices'][0]['message']['content'];record['status']='response_received'
                except Exception as e:
                    record['status']='request_error';record['error']=str(e)
                record['elapsed_seconds']=time.monotonic()-start
                f.write(json.dumps(record)+'\n');f.flush();os.fsync(f.fileno())
                print(json.dumps({'completed':i+1,'total':len(requests),'request_id':p['request_id'],'seconds':round(record['elapsed_seconds'],2),'status':record['status']}),flush=True)
    finally:
        server.terminate()
        try:server.wait(timeout=10)
        except subprocess.TimeoutExpired:server.kill();server.wait()
        log.close()


if __name__=='__main__':main()
