"""Independent algebraic checks, including deliberate counterexamples to certification."""
import itertools,math,random,statistics,unittest
from build import C,DELTA,dot,ROOT
from analyze import audit,exposure,ledger,ledger_faithful

class MethodTests(unittest.TestCase):
    def test_basis(self):
        for i in range(3):
            self.assertEqual(sum(C[i]),0)
            for j in range(3):self.assertEqual(dot(C[i],C[j]),4 if i==j else 0)

    def values(self,p,b,offset=0):
        vals={'base':dot(p,b)+offset,'anchor':offset}
        for k in range(3):
            for sign,label in [(-1,'minus'),(1,'plus')]:
                vals[f'probe{k}_{label}']=dot(p,[b[j]+sign*DELTA*C[k][j] for j in range(4)])+offset
        return vals

    def test_recovery_and_blind_spot(self):
        rng=random.Random(775)
        for _ in range(1000):
            q=[rng.uniform(.1,1) for _ in range(4)];q=[x/sum(q) for x in q]
            m=[rng.choice([0,1,2]) for _ in range(4)]
            if not any(m):continue
            p=[q[j]*m[j]/sum(q[k]*m[k] for k in range(4)) for j in range(4)]
            b=[rng.uniform(.2,.8) for _ in range(4)]
            a=audit(self.values(p,b),q,b,tol=1e-9)
            for x,y in zip(a['effective_weights'],p):self.assertAlmostEqual(x,y,places=12)
            self.assertEqual(a['accepted'],max(abs(x-y) for x,y in zip(p,q))<1e-9)
            w=rng.uniform(.2,.8)
            self.assertAlmostEqual(dot(q,[w]*4),dot(p,[w]*4),places=12)

    def test_no_arbitrary_black_box_certificate(self):
        q=[.1,.2,.3,.4];b=[.2,.4,.6,.8]
        # A nonlinear bump is wrong at the center and unchanged at all six tested shifts:
        # this is rejected by curvature, illustrating why slope alone is insufficient.
        vals=self.values(q,b);vals['base']+=.1
        self.assertFalse(audit(vals,q,b)['accepted'])
        # A finite query set cannot exclude a bump at an entirely unqueried point.
        self.assertTrue(audit(self.values(q,b),q,b)['accepted'])

    def test_bad_input(self):
        self.assertIsNone(exposure({'a':True,'b':0}))
        self.assertIsNone(exposure({'a':.8,'b':.8}))
        self.assertEqual(exposure({'a':.8,'b':.8},True),.5)
        self.assertIsNone(ledger({'rows':[{'id':'L1','q':1,'a':.5,'b':.5}]}))

    def test_frozen_tolerance_is_not_a_correctness_certificate(self):
        q=[.25]*4;p=[.2635,.2455,.2455,.2455];b=[.9,.1,.1,.1]
        observed=audit(self.values(p,b),q,b)
        self.assertTrue(observed['accepted'])
        self.assertAlmostEqual(abs(dot(p,b)-dot(q,b)),.0108,places=12)
        self.assertGreater(abs(dot(p,b)-dot(q,b)),.005)
        # Convexity puts the maximum of this norm over the cube at a vertex.
        maximum=max(sum(abs(sum(C[k][j]*s[k] for k in range(3))) for j in range(4))
                    for s in itertools.product([-1,1],repeat=3))
        self.assertEqual(maximum,6)

    def test_sharp_exposure_bound_by_vertex_enumeration(self):
        rng=random.Random(9981)
        for _ in range(100):
            p=[rng.random() for _ in range(4)];p=[x/sum(p) for x in p]
            q=[rng.random() for _ in range(4)];q=[x/sum(q) for x in q]
            e=[x-y for x,y in zip(p,q)]
            actual=max(abs(dot(e,b)) for b in itertools.product([.15,.85],repeat=4))
            bound=.7*sum(abs(x) for x in e)/2
            self.assertAlmostEqual(actual,bound,places=12)

    def test_correct_aggregate_does_not_imply_faithful_ledger(self):
        case={'q':[.1,.2,.3,.4],'b':[.5]*4}
        wrong={'rows':[{'id':f'L{j+1}','q':.25,'a':.5,'b':.5} for j in range(4)]}
        self.assertEqual(ledger(wrong),.5)
        self.assertFalse(ledger_faithful(wrong,case))
        for j,row in enumerate(wrong['rows']):row['q']=case['q'][j]
        self.assertTrue(ledger_faithful(wrong,case))

    def test_bounded_query_noise_at_all_sign_vertices(self):
        p=[.15,.2,.25,.4];q=[.1,.2,.3,.4];b=[.2,.4,.6,.8];eps=.001
        keys=[f'probe{k}_{s}' for k in range(3) for s in ['plus','minus']]
        bound=math.sqrt(3)*eps/(2*DELTA);largest=0
        for signs in itertools.product([-1,1],repeat=6):
            vals=self.values(p,b)
            for key,sign in zip(keys,signs):vals[key]+=sign*eps
            reconstructed=audit(vals,q,b)['effective_weights']
            error=math.sqrt(sum((x-y)**2 for x,y in zip(reconstructed,p)))
            self.assertLessEqual(error,bound+1e-12);largest=max(largest,error)
        self.assertAlmostEqual(largest,bound,places=12)

    def test_standard_deviation_lipschitz_bound(self):
        rng=random.Random(338)
        for _ in range(100):
            ra=[rng.gauss(0,3) for _ in range(20)];rb=[rng.gauss(0,2) for _ in range(20)]
            a1,a2=rng.random(),rng.random()
            s1=statistics.pstdev(a1*x+(1-a1)*y for x,y in zip(ra,rb))
            s2=statistics.pstdev(a2*x+(1-a2)*y for x,y in zip(ra,rb))
            bound=abs(a1-a2)*statistics.pstdev(x-y for x,y in zip(ra,rb))
            self.assertLessEqual(abs(s1-s2),bound+1e-12)

if __name__=='__main__':unittest.main()
