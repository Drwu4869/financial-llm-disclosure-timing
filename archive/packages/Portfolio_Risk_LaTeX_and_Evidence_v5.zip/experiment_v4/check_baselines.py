"""Known-template parser and an independent covariance calculation."""
import json,re,math
import numpy as np
from build import ROOT,DATA,read,risk,dot

def parse_template(text):
    rows=[]
    for line in text.splitlines():
        m=re.search(r'Lot L\w+: ([\d.]+)% of the account.*?allocates ([\d.]+)% to Asset_A and ([\d.]+)% to Asset_B',line)
        if m:q,a,b=map(float,m.groups());rows.append((q/100,a/100,b/100));continue
        m=re.search(r'Product_\d+, funded lot L\w+: internal composition = Asset_B ([\d.]+)%, Asset_A ([\d.]+)%; account allocation = ([\d.]+)%',line)
        if m:b,a,q=map(float,m.groups());rows.append((q/100,a/100,b/100));continue
        m=re.search(r'L\w+ / Product_\d+ \| account share ([\d.]+)% \| within product: Asset_A ([\d.]+)%, Asset_B ([\d.]+)%',line)
        if m:q,a,b=map(float,m.groups());rows.append((q/100,a/100,b/100))
    if not rows or abs(sum(r[0] for r in rows)-1)>1e-9:raise ValueError('Unknown grammar')
    return sum(q*a for q,a,b in rows)

def main():
    cases={c['case_id']:c for c in read(DATA/'cases.jsonl')}
    gold={r['request_id']:r for r in read(DATA/'answer_key.jsonl')}
    count=0;error=0.;cov_error=0.
    for p in read(DATA/'prompts.jsonl'):
        if p['condition']=='risk_oracle':continue
        a=parse_template(p['prompt']);diff=abs(a-gold[p['request_id']]['a']);assert diff<1e-7
        count+=1;error=max(error,diff)
    for c in cases.values():
        a=dot(c['q'],c['b']);R=np.array(c['returns_pct']);w=np.array([a,1-a]);sigma=math.sqrt(w@np.cov(R,rowvar=False,bias=True)@w)
        diff=abs(sigma-risk(a,c['returns_pct']));assert diff<1e-12;cov_error=max(cov_error,diff)
    out={'known_grammar_inputs':count,'max_exposure_discrepancy':error,'independent_covariance_checks':len(cases),'max_risk_discrepancy':cov_error,'interpretation':'A known-template parser solves this controlled language; no LLM necessity is established.'}
    (ROOT/'results/baselines.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

if __name__=='__main__':main()
