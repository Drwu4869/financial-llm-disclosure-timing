"""Check evidence completeness, chronology, payload integrity and independent gold arithmetic.

This is an internal reproducibility check, not independent peer review.
Run only after both frozen evaluations are complete.
"""
import hashlib,json,math
from datetime import datetime,timezone
from decimal import Decimal
from pathlib import Path
from build import ROOT,DATA,SEED,read,sha


def check_protocol(name):
    p=json.loads((DATA/name).read_text())
    for filename,digest in p['files'].items():
        assert sha(DATA/filename)==digest,('Changed frozen input',filename)
    return p


def check_run(model,corpus,split,expected,protocol):
    folder=ROOT/'results'/model/(corpus+'_'+split)
    raw=read(folder/'raw.jsonl')
    prompts={p['request_id']:p for p in read(DATA/(corpus+'.jsonl')) if p['split']==split}
    ids=[r['request_id'] for r in raw]
    assert len(ids)==len(set(ids))==expected,('Count or duplicates',folder)
    if split=='evaluation':assert set(ids)==set(prompts),('Incomplete evaluation',folder)
    meta=json.loads((folder/'execution_metadata.json').read_text())
    assert meta['protocol_sha256']==sha(DATA/'protocol.json')
    assert meta['corpus_sha256']==sha(DATA/(corpus+'.jsonl'))
    commands={rid:meta['command'] for rid in ids}
    segments=folder/'execution_segments.jsonl'
    if segments.exists():
        for segment in read(segments):
            for rid in segment['selected_new_requests']:commands[rid]=segment['command']
    checked=0;errors=0;truncated=0;max_prompt_tokens=0
    for r in raw:
        p=prompts[r['request_id']]
        payload={'model':meta['model']['model_id'],'messages':[{'role':'system','content':p['system']},{'role':'user','content':p['prompt']}],'temperature':0,'seed':SEED,'max_tokens':512,'stream':False,'response_format':{'type':'json_object'},'chat_template_kwargs':{'enable_thinking':False},'cache_prompt':False}
        actual=hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()
        assert actual==r['request_sha256'],('Payload mismatch',r['request_id'])
        assert datetime.fromisoformat(r['started_at_utc'])>=datetime.fromisoformat(protocol['frozen_at_utc'])
        assert math.isfinite(r['elapsed_seconds']) and r['elapsed_seconds']>=0
        if r['status']=='response_received':
            response=r['response'];choice=response['choices'][0]
            assert r['raw_text']==choice['message']['content']
            truncated+=choice.get('finish_reason')=='length'
            max_prompt_tokens=max(max_prompt_tokens,response.get('usage',{}).get('prompt_tokens',0))
            command=commands[r['request_id']]
            context=int(command[command.index('-c')+1]);slots=int(command[command.index('--parallel')+1])
            assert response.get('usage',{}).get('prompt_tokens',0)+512<=context//slots,('Context budget',model,corpus,r['request_id'])
        else:
            assert r['status']=='request_error' and 'error' in r
            errors+=1
        checked+=1
    if split=='evaluation':assert (folder/'completed.json').exists(),('No completion marker',folder)
    else:assert set(ids)==set(meta['request_ids']),('Incomplete development check',folder)
    profiles={}
    for rid in ids:
        c=commands[rid];key=(int(c[c.index('--parallel')+1]),int(c[c.index('-c')+1]),'--no-repack' not in c,int(c[c.index('--cache-ram')+1]) if '--cache-ram' in c else 8192)
        profiles[key]=profiles.get(key,0)+1
    return {'model':model,'corpus':corpus,'split':split,'records':checked,'request_errors':errors,'truncations':truncated,'max_prompt_tokens':max_prompt_tokens,'runtime_configurations':[{'slots':s,'total_context':c,'tokens_per_slot':c//s,'weight_repacking':rep,'prompt_ram_cache_mib':cache,'saved_records':n} for (s,c,rep,cache),n in sorted(profiles.items())],'raw_sha256':sha(folder/'raw.jsonl')}


def decimal_weighted(q,b):
    return float(sum(Decimal(str(x))*Decimal(str(y)) for x,y in zip(q,b)))


def check_gold():
    cases=read(DATA/'cases.jsonl');by={c['case_id']:c for c in cases}
    gold=read(DATA/'answer_key.jsonl');max_delta=0
    contrast=[[1,1,-1,-1],[1,-1,1,-1],[1,-1,-1,1]]
    for g in gold:
        cid,condition=g['request_id'].split('__');c=by[cid];b=c['b'][:]
        if condition=='anchor':b=[0]*4
        if condition.startswith('probe'):
            k=int(condition[5]);sign=1 if condition.endswith('plus') else -1
            b=[v+sign*.05*z for v,z in zip(b,contrast[k])]
        exposure=decimal_weighted(c['q'],b);max_delta=max(max_delta,abs(exposure-g['a']))
        assert abs(exposure-g['a'])<1e-12
        states=[exposure*x+(1-exposure)*y for x,y in c['returns_pct']]
        mean=sum(states)/4;variance=sum((s-mean)**2 for s in states)/4
        assert abs(math.sqrt(variance)-g['risk_pct'])<1e-12
    for c in cases:
        assert abs(sum(c['q'])-1)<1e-12 and min(c['q'])>0
        pair=by[c['family_id']+('_heterogeneous' if c['kind']=='identical' else '_identical')]
        assert abs(decimal_weighted(c['q'],c['b'])-decimal_weighted(pair['q'],pair['b']))<1e-12
    source=read(DATA/'source_cases.jsonl')
    for c in source:
        for k,v in c['answer'].items():
            b=[c['targets'][str(f)][k] for f in [c['left'],c['right']]]
            assert abs(decimal_weighted(c['q'],b)-v)<1e-12
    challenge=read(DATA/'challenge_answers.jsonl')
    shifts=[]
    for g in challenge:
        c=by[g['case_id']];a=decimal_weighted(c['q'],g['b_vector'])
        assert abs(a-g['a'])<1e-12
        shift=abs(a-decimal_weighted(c['q'],c['b']));shifts.append(shift)
        assert shift>=.01-1e-12 and min(g['b_vector'])>=0 and max(g['b_vector'])<=1
    assert len(challenge)==64
    return {'controlled_answers_checked':len(gold),'source_accounts_checked':len(source),'challenge_answers_checked':len(challenge),'max_decimal_gold_difference':max_delta,'minimum_challenge_gold_shift':min(shifts)}


def main():
    core=check_protocol('protocol.json');source=check_protocol('source_protocol.json');challenge=check_protocol('challenge_protocol.json')
    runs=[]
    for m in ['smol','qwen8']:
        runs.append(check_run(m,'prompts','development',4,core))
        for corpus,count,p in [('prompts',576,core),('source_prompts',60,source),('challenge_prompts',64,challenge)]:
            runs.append(check_run(m,corpus,'evaluation',count,p))
    recheck=check_protocol('runtime_recheck_protocol.json')
    runs.append(check_run('qwen8','runtime_recheck_prompts','evaluation',167,recheck))
    from analyze import load_core_records
    assert len(load_core_records('qwen8',uniform=True))==576
    original={r['request_id']:r for r in read(DATA/'prompts.jsonl')}
    for p in read(DATA/'runtime_recheck_prompts.jsonl'):assert p==original[p['request_id']]
    result={'checked_at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS','scope':'Internal integrity and arithmetic audit; not independent validation','new_evaluation_records':sum(r['records'] for r in runs if r['split']=='evaluation' and r['corpus']!='runtime_recheck_prompts'),'runtime_recheck_records':167,'development_records':sum(r['records'] for r in runs if r['split']=='development'),'uniform_primary_case_counts_unchanged':True,'runs':runs,'gold':check_gold()}
    (ROOT/'results'/'release_audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
