"""Source-derived holdings tables: two extraction engines, published rounding retained."""
import itertools,json,re,subprocess,hashlib
from datetime import datetime,timezone
from pathlib import Path
from pypdf import PdfReader
from build import ROOT,DATA,dump,sha

TARGETS={'world':'Vanguard FTSE Developed World ex-U.K. Equity Index Fund','uk':'Vanguard FTSE U.K. All Share Index Unit Trust','em':'Vanguard Emerging Markets Stock Index Fund'}

def rows(text):
    text=text.replace('ex -U.K.','ex-U.K.')
    text=text[text.index('Underlying funds and their proportion'):]
    text=text[:text.index('Investment breakdown')]
    return [(' '.join(m.group(1).split()),float(m.group(2))) for m in re.finditer(r'(Vanguard [^%\n]+?)\s+(\d+(?:\.\d+)?)\s*%',text)]

def main():
    if (DATA/'source_protocol.json').exists():raise RuntimeError('Do not overwrite frozen source experiment')
    manifest=json.loads((DATA/'source_manifest.json').read_text());tables={};checks=[]
    for item in manifest:
        p=DATA/item['file'];a=rows(PdfReader(p).pages[1].extract_text())
        text=subprocess.check_output(['pdftotext','-f','2','-l','2','-layout',str(p),'-'],text=True)
        b=rows(text)
        if sorted(a)!=sorted(b):raise AssertionError((item['fund'],a,b))
        assert len(a)>=7
        tables[item['fund']]={'fund':item['fund'],'as_of':'2026-09-30','page':2,'url':item['url'],'pdf_sha256':item['sha256'],'holdings':[{'name':k,'reported_percent':v} for k,v in a]}
        checks.append({'fund':item['fund'],'matched_rows':len(a),'two_pdf_text_engines_agree':True})
    (DATA/'source_tables.json').write_text(json.dumps(list(tables.values()),indent=2)+'\n')
    prompts=[];gold=[];cases=[]
    for i,(left,right) in enumerate(itertools.combinations(sorted(tables),2)):
        for j,q in enumerate([.30,.65]):
            cid=f'source_pair_{i:02d}_allocation_{j}'
            tabletext='\n\n'.join(f'Fund: Vanguard LifeStrategy {k}% Equity. Holdings reported 30 September 2026.\nUnderlying fund | reported percent of this fund\n'+'\n'.join(f"{r['name']} | {r['reported_percent']:.1f}%" for r in tables[k]['holdings']) for k in [left,right])
            values={k:{name:next(r['reported_percent']/100 for r in tables[k]['holdings'] if r['name']==target) for name,target in TARGETS.items()} for k in [left,right]}
            answer={name:q*values[left][name]+(1-q)*values[right][name] for name in TARGETS}
            cases.append({'case_id':cid,'family_id':f'source_pair_{i:02d}','left':left,'right':right,'q':[q,1-q],'targets':values,'answer':answer,'rounding_half_width':.0005})
            common=('The following are published fund-level holdings data, transcribed from issuer factsheets. '
                    'Use the reported percentages as displayed. Holdings are rounded and need not sum exactly to 100%. '
                    'Do not renormalize the table. The account allocations below are a constructed scenario. '
                    'Calculate ownership of the named underlying FUNDS, not individual stocks inside them.\n'+tabletext+'\n')
            suffix='\nTargets: '+json.dumps(TARGETS)+'. Return {"world": number, "uk": number, "em": number} as fractions of the entire account. These three targets are only a subset of holdings; do not force their sum to one.'
            for condition in ['direct','split','ledger']:
                if condition=='split':alloc=f'Account funded lots: {q*50:g}% in LifeStrategy {left}%; {q*50:g}% in LifeStrategy {left}%; {(1-q)*50:g}% in LifeStrategy {right}%; {(1-q)*50:g}% in LifeStrategy {right}%.'
                else:alloc=f'Account allocation: {q*100:g}% in LifeStrategy {left}% Equity and {(1-q)*100:g}% in LifeStrategy {right}% Equity.'
                end=suffix
                if condition=='ledger':
                    end='\nTargets: '+json.dumps(TARGETS)+'. Extract without aggregating. Return {"rows": [{"fund": '+str(left)+', "q": number, "world": number, "uk": number, "em": number}, {"fund": '+str(right)+', "q": number, "world": number, "uk": number, "em": number}]}. q is the account fraction invested in that fund; world, uk, em are fractions INSIDE that fund. Do not renormalize any values.'
                rid=cid+'__'+condition
                prompts.append({'request_id':rid,'case_id':cid,'family_id':f'source_pair_{i:02d}','split':'evaluation','condition':condition,'system':'Return exactly one JSON object, using only supplied evidence.','prompt':common+alloc+end})
                gold.append({'request_id':rid,**answer})
    dump(DATA/'source_prompts.jsonl',prompts);dump(DATA/'source_cases.jsonl',cases);dump(DATA/'source_answers.jsonl',gold)
    protocol={'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'status':'SOURCE_DERIVED_EXTENSION_FROZEN_BEFORE_ITS_INFERENCE','source_documents':5,'source_date':'2026-09-30','source_page':2,'scenarios':20,'pairs':10,'calls_per_model':60,'source_validation':checks,'tolerance_absolute':.0006,'primary':'all three target exposures within tolerance; invalid counts as failure','limits':['Five documents from one issuer and one date; related cases are not independent.','PDF holdings tables, not unrestricted narrative documents.','Two software text extractions plus assistant visual inspection; no independent human annotation.','Account allocations and splitting are constructed; underlying reported holdings are authentic.','No security-level overlap, covariance or market forecast is inferred from these fund-level numbers.'],'files':{p.name:sha(p) for p in DATA.glob('source_*.json*') if p.name!='source_protocol.json'}}
    (DATA/'source_protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    print(json.dumps({'checks':checks,'prompts':len(prompts)},indent=2))

if __name__=='__main__':main()
