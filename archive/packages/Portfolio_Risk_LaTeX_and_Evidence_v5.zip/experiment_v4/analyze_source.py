"""Score the source-derived tier without treating related allocations as independent data."""
import argparse,json,math
from build import ROOT,DATA,read
from analyze import parse,number

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--model',required=True);a=ap.parse_args()
    folder=ROOT/'results'/a.model/'source_prompts_evaluation'
    raw=read(folder/'raw.jsonl');rr={x['request_id']:x for x in raw};cases=read(DATA/'source_cases.jsonl')
    assert len(rr)==len(raw)==60
    keys=['world','uk','em'];rows=[]
    for c in cases:
        scores={};pred={};validity={};errors={}
        for cond in ['direct','split','ledger']:
            x=parse(rr[c['case_id']+'__'+cond]);valid=x is not None
            if cond=='ledger':
                rs=x.get('rows') if x else None
                valid=isinstance(rs,list) and len(rs)==2 and all(isinstance(r,dict) for r in rs)
                if valid:valid=sorted(str(r.get('fund')) for r in rs)==sorted([str(c['left']),str(c['right'])])
                if valid:valid=all(all(number(r.get(k)) and 0<=r[k]<=1 for k in ['q']+keys) for r in rs) and abs(sum(r['q'] for r in rs)-1)<1e-5
                vals={k:sum(r['q']*r[k] for r in rs) for k in keys} if valid else None
            else:
                valid=valid and all(number(x.get(k)) and 0<=x[k]<=1 for k in keys)
                vals={k:x[k] for k in keys} if valid else None
            scores[cond]=valid and all(abs(vals[k]-c['answer'][k])<=.0006 for k in keys)
            pred[cond]=vals
            validity[cond]=bool(valid)
            errors[cond]={k:abs(vals[k]-c['answer'][k]) for k in keys} if valid else None
        rows.append({'case_id':c['case_id'],'family_id':c['family_id'],'gold':c['answer'],'correct':scores,'predictions':pred,'valid':validity,'absolute_errors':errors})
    output={'source_documents':5,'fund_pairs':10,'constructed_allocations':20,'calls':60,'correct':{k:sum(r['correct'][k] for r in rows) for k in ['direct','split','ledger']},'invalid':{k:sum(not r['valid'][k] for r in rows) for k in ['direct','split','ledger']},'truncated':sum(r.get('response',{}).get('choices',[{}])[0].get('finish_reason')=='length' for r in raw),'request_errors':sum(r['status']!='response_received' for r in raw),'rows':rows}
    (folder/'analysis.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({k:v for k,v in output.items() if k!='rows'},indent=2))

if __name__=='__main__':main()
