"""Freeze unseen compositions for testing whether an audit predicts later failures."""
import json,random
from datetime import datetime,timezone
from build import ROOT,DATA,read,dump,sha,common,render,dot,risk

def main():
    if (DATA/'challenge_protocol.json').exists():raise RuntimeError('Already frozen')
    rng=random.Random(2026110511);prompts=[];gold=[]
    cases=[c for c in read(DATA/'cases.jsonl') if c['split']=='evaluation']
    for c in cases:
        while True:
            direction=rng.sample([.75,-.35,.45,-.85],4)
            if abs(.04*dot(c['q'],direction))>=.01:break
        for sign,label in [(1,'plus'),(-1,'minus')]:
            b=[v+sign*.04*z for v,z in zip(c['b'],direction)]
            assert min(b)>0 and max(b)<1
            rid=c['case_id']+'__unseen_'+label
            prompt=common()+render(c['q'],b,c['style'])+'\nCalculate total account exposures to the underlying assets. Return {"a": number, "b": number} as fractions, with a for Asset_A and b for Asset_B. Do not copy product-level percentages as account weights.'
            prompts.append({'request_id':rid,'case_id':c['case_id'],'family_id':c['family_id'],'split':'evaluation','condition':'unseen_'+label,'system':'Return one JSON object. Do not add explanatory prose.','prompt':prompt})
            gold.append({'request_id':rid,'case_id':c['case_id'],'b_vector':b,'a':dot(c['q'],b)})
    dump(DATA/'challenge_prompts.jsonl',prompts);dump(DATA/'challenge_answers.jsonl',gold)
    progress={str(p.relative_to(ROOT)):len(p.read_text().splitlines()) for p in (ROOT/'results').glob('*/prompts_evaluation/raw.jsonl')}
    protocol={'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'status':'PROSPECTIVELY_FROZEN_CHALLENGE_EXTENSION_DESIGNED_DURING_CORE_INFERENCE','core_progress_at_design':progress,'reason':'Distinguish rejection of a currently correct answer from prediction of errors on unqueried compositions.','input_validation_amendment':'Initial unexecuted design allowed 26/64 true shifts within the accuracy tolerance. Before any challenge inference, require all true shifts to be at least 0.01. The initial protocol and stimuli remain in protocol_history/challenge_v1. No model outcome was used to select these directions.','method_change':'None; original thresholds and both eight-call gates are unchanged.','analysis':'A family-case passes the challenge only if both unseen outputs are valid and within absolute exposure error 0.005. Report gate coverage, challenge-failing accepted cases, and challenge-passing rejected cases; retain base correctness separately. Challenge queries are evaluation-only and unavailable to either gate.','minimum_absolute_gold_shift':.01,'independence_limit':'New compositions reuse existing cases and the two related queries are not independent observations.','files':{p.name:sha(p) for p in [DATA/'challenge_prompts.jsonl',DATA/'challenge_answers.jsonl']}}
    (DATA/'challenge_protocol.json').write_text(json.dumps(protocol,indent=2)+'\n');print(json.dumps({'requests':len(prompts),'core_progress_at_freeze':progress},indent=2))

if __name__=='__main__':main()
