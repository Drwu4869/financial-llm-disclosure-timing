"""Post hoc model-class falsification. Reuses every v4 case; no new LLM calls."""
import itertools,json,re,statistics
from datetime import datetime,timezone
from fractions import Fraction as F
import numpy as np
from scipy.optimize import linprog
from build import ROOT,DATA,read,sha
from analyze import load_core_records,parse,exposure,audit
from verify_certificates import bounds

NAMES=['base','anchor']+[f'probe{k}_{s}' for k in range(3) for s in ['plus','minus']]

def source_vector(prompt):
    rows={}
    for line in prompt.splitlines():
        hit=re.search(r'Product_(\d+)',line)
        if hit:
            nums=re.findall(r'(\d+\.\d+)%',line)
            assert len(nums)==3
            rows[int(hit[1])]=F(nums[1])/100
    assert set(rows)=={1,2,3,4}
    return [rows[j] for j in range(1,5)]

def exact_output(record,normalize):
    if exposure(parse(record),normalize=normalize) is None:return None
    x=json.loads(record['raw_text'],parse_float=F,parse_int=F)
    return x['a']/(x['a']+x['b']) if normalize else x['a']

def witness(X,y,lam):
    return max(F(0),sum(v*z for v,z in zip(lam,y))-max(sum(lam[t]*X[t][j] for t in range(len(X))) for j in range(4)))

def elementary(X,y):
    candidates={'single':[],'pair':[],'midpoint':[]}
    for i in range(8):
        for sign in [-1,1]:
            lam=[F(0)]*8;lam[i]=F(sign);candidates['single'].append(witness(X,y,lam))
    for i in range(8):
        for j in range(i):
            for sign in [-1,1]:
                lam=[F(0)]*8;lam[i]=F(sign,2);lam[j]=-F(sign,2);candidates['pair'].append(witness(X,y,lam))
    for k in range(3):
        for sign in [-1,1]:
            lam=[F(0)]*8;lam[0]=-F(sign,2);lam[2+2*k]=lam[3+2*k]=F(sign,4)
            candidates['midpoint'].append(witness(X,y,lam))
    return {k:max(v) for k,v in candidates.items()}

def certificate(X,y):
    xf=np.array([[float(v) for v in row] for row in X]);yf=np.array(list(map(float,y)))
    n=len(y);one=np.ones(n)
    res=linprog([0]*4+[1],A_ub=np.vstack([np.c_[xf,-one],np.c_[-xf,-one]]),b_ub=np.r_[yf,-yf],A_eq=[[1,1,1,1,0]],b_eq=[1],bounds=[(0,None)]*5,method='highs')
    assert res.success
    pn=[max(0,int(round(v*10**9))) for v in res.x[:4]];p=[F(v,sum(pn)) for v in pn]
    # Sensitivity of the optimum with respect to y gives a dual witness.
    lf=res.ineqlin.marginals[:n]-res.ineqlin.marginals[n:]
    ln=[int(round(v*10**9)) for v in lf];den=max(10**9,sum(abs(v) for v in ln));lam=[F(v,den) for v in ln]
    lo=witness(X,y,lam);hi=max(abs(sum(a*b for a,b in zip(row,p))-z) for row,z in zip(X,y))
    r={'X':[[str(v) for v in row] for row in X],'y':list(map(str,y)),'primal_weights':list(map(str,p)),'dual_weights':list(map(str,lam)),'lower_exact':str(lo),'upper_exact':str(hi),'lower':float(lo),'upper':float(hi),'optimizer_value':float(res.fun)}
    bounds(r)
    return r

def main():
    folder=ROOT/'results/certificates';folder.mkdir(exist_ok=True)
    note=folder/'analysis_provenance.json'
    if not note.exists():
        note.write_text(json.dumps({'created_at_utc':datetime.now(timezone.utc).isoformat(),'status':'POST_HOC_EXPLORATORY_AFTER_ALL_V4_RESULTS','prior_inspection':'Ablations and preliminary LP fits were inspected before this release implementation. This is not a prospective validation.','new_model_calls':0,'selection':'All 32 evaluation cases per model; strict and normalized views both retained. No threshold tuning.','threshold':.005,'source_prompts_sha256':sha(DATA/'prompts.jsonl'),'claims':'Falsifies a fixed convex-combination explanation of recorded numbers at the stated error budget; does not verify correctness, diagnose hidden causation, or validate future answers.'},indent=2)+'\n')
    prompts={p['request_id']:p for p in read(DATA/'prompts.jsonl')};all_records=[];summaries=[]
    cases=[c for c in read(DATA/'cases.jsonl') if c['split']=='evaluation']
    for model in ['smol','qwen8']:
        raw=load_core_records(model,uniform=model=='qwen8')
        for mode in ['strict','normalized']:
            rows=[];gate={'valid':0,'slope':0,'curvature':0,'anchor':0,'all':0}
            for c in cases:
                ids=[c['case_id']+'__'+n for n in NAMES]
                y=[exact_output(raw[rid],mode=='normalized') for rid in ids]
                if any(z is None for z in y):continue
                X=[source_vector(prompts[rid]['prompt']) for rid in ids]
                d=audit(dict(zip(NAMES,map(float,y))),c['q'],c['b']);gate['valid']+=1
                gate['slope']+=d['slope_error']<=.02;gate['curvature']+=d['curvature']<=.005;gate['anchor']+=d['anchor_error']<=.005;gate['all']+=d['accepted']
                r=certificate(X,y);el=elementary(X,y)
                r.update(model=model,mode=mode,case_id=c['case_id'],family_id=c['family_id'],request_ids=ids,raw_payload_hashes=[raw[rid]['request_sha256'] for rid in ids],raw_text_hashes=[__import__('hashlib').sha256(raw[rid]['raw_text'].encode()).hexdigest() for rid in ids],simple_bounds={k:float(v) for k,v in el.items()},simple_bounds_exact={k:str(v) for k,v in el.items()},simple_max=float(max(el.values())),simple_max_exact=str(max(el.values())))
                rows.append(r);all_records.append(r)
            v=[r['lower'] for r in rows]
            summaries.append({'model':model,'mode':mode,'cases':32,'eligible':len(rows),'incompatible':sum(F(r['lower_exact'])>F(1,200) for r in rows),'minimum':min(v) if v else None,'median':statistics.median(v) if v else None,'maximum':max(v) if v else None,'gate_component_passes':gate,'simple_rejections':{k:sum(F(r['simple_bounds_exact'][k])>F(1,200) for r in rows) for k in ['single','pair','midpoint']},'simple_union_rejections':sum(F(r['simple_max_exact'])>F(1,200) for r in rows),'max_bound_gap':max((r['upper']-r['lower'] for r in rows),default=0)})
    (folder/'certificates.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in all_records))
    (folder/'summary.json').write_text(json.dumps(summaries,indent=2)+'\n')
    print(json.dumps(summaries,indent=2))

if __name__=='__main__':main()
