"""Explicitly post hoc unit-conversion sensitivity; never replaces primary scoring."""
import argparse,copy,json
from datetime import datetime,timezone
from build import ROOT,DATA,read,sha
from analyze import parse,number

KEYS=['world','uk','em']

def convert_block(values):
    if not all(number(v) and 0<=v<=100 for v in values):return values,False
    if any(v>1 for v in values):return [v/100 for v in values],True
    return values,False

def repair(x,condition):
    if not isinstance(x,dict):return x,False
    x=copy.deepcopy(x);changed=False
    if condition!='ledger':
        if all(k in x for k in KEYS):
            values,changed=convert_block([x[k] for k in KEYS])
            x.update(zip(KEYS,values))
    elif isinstance(x.get('rows'),list) and all(isinstance(r,dict) for r in x['rows']):
        rows=x['rows']
        if all('q' in r for r in rows):
            values,flag=convert_block([r['q'] for r in rows]);changed|=flag
            for r,v in zip(rows,values):r['q']=v
        for r in rows:
            if all(k in r for k in KEYS):
                values,flag=convert_block([r[k] for k in KEYS]);changed|=flag;r.update(zip(KEYS,values))
    return x,changed

def score(x,condition,case):
    if condition=='ledger':
        rows=x.get('rows') if isinstance(x,dict) else None
        valid=isinstance(rows,list) and len(rows)==2 and all(isinstance(r,dict) for r in rows)
        if valid:valid=sorted(str(r.get('fund')) for r in rows)==sorted([str(case['left']),str(case['right'])])
        if valid:valid=all(all(number(r.get(k)) and 0<=r[k]<=1 for k in ['q']+KEYS) for r in rows) and abs(sum(r['q'] for r in rows)-1)<1e-5
        values={k:sum(r['q']*r[k] for r in rows) for k in KEYS} if valid else None
    else:
        valid=isinstance(x,dict) and all(number(x.get(k)) and 0<=x[k]<=1 for k in KEYS)
        values={k:x[k] for k in KEYS} if valid else None
    return bool(valid and all(abs(values[k]-case['answer'][k])<=.0006 for k in KEYS)),values

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--model',choices=['smol','qwen8'],required=True);a=ap.parse_args()
    protocol_path=ROOT/'results/posthoc_source_unit_protocol.json'
    if not protocol_path.exists():
        assert all((ROOT/f'results/{m}/source_prompts_evaluation/completed.json').exists() for m in ['smol','qwen8'])
        protocol={'created_at_utc':datetime.now(timezone.utc).isoformat(),'status':'POST_HOC_AFTER_BOTH_SOURCE_EVALUATIONS','trigger':'Inspection of complete Qwen source outputs showed percentages in a fractional interface, including its one failed ledger.','rule':'For each target-value block, divide every entry by 100 if every entry is finite and in [0,100] and at least one exceeds 1. For a ledger, apply this independently to each row target block and to the vector of account weights. Otherwise leave values unchanged. No answer key is used to choose a conversion.','unchanged':'Raw outputs, primary scoring, all-target accuracy tolerance 0.0006. No extra inference.','limits':'A heuristic unit sensitivity analysis, not a justified repair for arbitrary data or unambiguous recovery of intended units. Numerically changes answers; do not call format-only cleanup.','source_prompts_sha256':sha(DATA/'source_prompts.jsonl')}
        protocol_path.write_text(json.dumps(protocol,indent=2)+'\n')
    folder=ROOT/f'results/{a.model}/source_prompts_evaluation'
    raw=read(folder/'raw.jsonl');records={r['request_id']:r for r in raw};cases=read(DATA/'source_cases.jsonl')
    assert len(records)==len(raw)==60
    rows=[]
    for c in cases:
        for condition in ['direct','split','ledger']:
            rid=c['case_id']+'__'+condition;original=parse(records[rid]);fixed,changed=repair(original,condition)
            before,_=score(original,condition,c);after,values=score(fixed,condition,c)
            rows.append({'request_id':rid,'condition':condition,'changed':changed,'original_correct':before,'converted_correct':after,'converted_predictions':values})
    primary=json.loads((folder/'analysis.json').read_text())
    summary={}
    for condition in ['direct','split','ledger']:
        rs=[r for r in rows if r['condition']==condition]
        assert sum(r['original_correct'] for r in rs)==primary['correct'][condition]
        summary[condition]={k:sum(r[k] for r in rs) for k in ['changed','original_correct','converted_correct']}
    output={'status':'POST_HOC_UNIT_SENSITIVITY_NOT_PRIMARY','summary':summary,'rows':rows}
    (folder/'unit_sensitivity.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({'model':a.model,'summary':summary},indent=2))

if __name__=='__main__':main()
