"""Recorded local inference; resumable without overwriting observations."""
import argparse,hashlib,json,os,random,subprocess,time,urllib.request,concurrent.futures
from datetime import datetime,timezone
from pathlib import Path
from build import ROOT,DATA,read,sha,SEED

def post(payload,port):
    req=urllib.request.Request(f'http://127.0.0.1:{port}/v1/chat/completions',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=600) as f:return json.load(f)

def main():
    p=argparse.ArgumentParser();p.add_argument('--model',choices=['smol','qwen8','qwen3'],required=True);p.add_argument('--split',choices=['development','evaluation'],default='evaluation');p.add_argument('--corpus',default='prompts');p.add_argument('--limit',type=int,default=0);p.add_argument('--batch-size',type=int,default=0);p.add_argument('--slots',type=int,choices=[4,8],default=4);p.add_argument('--context-per-slot',type=int,default=0);p.add_argument('--no-repack',action='store_true');p.add_argument('--disable-prompt-cache',action='store_true');a=p.parse_args()
    names={'smol':('SmolLM3-3B-GGUF.json','SmolLM3-Q4_K_M.gguf'),'qwen8':('Qwen3-8B-GGUF.json','Qwen3-8B-Q4_K_M.gguf')}
    if a.model=='qwen3':
        metadata=json.loads((ROOT.parent/'experiment_v3/runtime/qwen3b_manifest.json').read_text());model=ROOT.parent/'experiment_v3/runtime'/metadata['filename']
    else:
        metadata=json.loads((ROOT/'runtime'/names[a.model][0]).read_text());model=ROOT/'runtime'/metadata['filename']
    protocol=json.loads((DATA/'protocol.json').read_text())
    for n,h in protocol['files'].items():assert sha(DATA/n)==h
    if a.corpus=='source_prompts':
        source_protocol=json.loads((DATA/'source_protocol.json').read_text())
        for n,h in source_protocol['files'].items():assert sha(DATA/n)==h
    if a.corpus=='challenge_prompts':
        challenge_protocol=json.loads((DATA/'challenge_protocol.json').read_text())
        for n,h in challenge_protocol['files'].items():assert sha(DATA/n)==h
    if a.corpus=='runtime_recheck_prompts':
        recheck_protocol=json.loads((DATA/'runtime_recheck_protocol.json').read_text())
        for n,h in recheck_protocol['files'].items():assert sha(DATA/n)==h
    assert sha(model)==metadata['sha256']
    requests=[x for x in read(DATA/(a.corpus+'.jsonl')) if x['split']==a.split]
    random.Random(SEED).shuffle(requests)
    if a.limit:requests=requests[:a.limit]
    target=ROOT/'results'/a.model/(a.corpus+'_'+a.split);target.mkdir(parents=True,exist_ok=True)
    binary=ROOT.parent/'experiment_v3/runtime/llama/llama-b12110/llama-server'
    port=8770
    context_size='8192' if a.model=='qwen8' else '16384'
    if a.context_per_slot:context_size=str(a.slots*a.context_per_slot)
    cmd=[str(binary),'-m',str(model),'--host','127.0.0.1','--port',str(port),'-t','8','-tb','8','-c',context_size,'--parallel',str(a.slots),'--seed',str(SEED),'--jinja','--reasoning','off','--reasoning-budget','0']
    if a.no_repack:cmd.append('--no-repack')
    if a.disable_prompt_cache:cmd.extend(['--cache-ram','0','--no-cache-prompt'])
    log=open(target/'server.log','a');server=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
    try:
        for _ in range(120):
            if server.poll() is not None:raise RuntimeError('Server exited; inspect server.log')
            try:
                with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=1) as r:
                    if r.status==200:break
            except Exception:time.sleep(.5)
        else:raise RuntimeError('Server did not become healthy')
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/props',timeout=5) as r:
            (target/'server_properties.json').write_text(json.dumps(json.load(r),indent=2)+'\n')
        meta={'started_at_utc':datetime.now(timezone.utc).isoformat(),'command':cmd,'model':metadata,'protocol_sha256':sha(DATA/'protocol.json'),'corpus_sha256':sha(DATA/(a.corpus+'.jsonl')),'request_ids':[r['request_id'] for r in requests],'response_retries':0}
        mpath=target/'execution_metadata.json'
        if not mpath.exists():mpath.write_text(json.dumps(meta,indent=2)+'\n')
        out=target/'raw.jsonl';done={r['request_id'] for r in read(out)} if out.exists() else set()
        pending=[r for r in requests if r['request_id'] not in done]
        if a.batch_size:pending=pending[:a.batch_size]
        segment={'started_at_utc':datetime.now(timezone.utc).isoformat(),'recorded_before':len(done),'selected_new_requests':[r['request_id'] for r in pending],'command':cmd,'runner_sha256':sha(Path(__file__)),'note':'Resume never overwrites recorded responses. Infrastructure-interrupted requests without a saved response may be attempted again.'}
        with open(target/'execution_segments.jsonl','a') as sf:sf.write(json.dumps(segment)+'\n')
        def infer(r):
            payload={'model':metadata['model_id'],'messages':[{'role':'system','content':r['system']},{'role':'user','content':r['prompt']}],'temperature':0,'seed':SEED,'max_tokens':512,'stream':False,'response_format':{'type':'json_object'},'chat_template_kwargs':{'enable_thinking':False},'cache_prompt':False}
            start=time.monotonic();rec={'request_id':r['request_id'],'started_at_utc':datetime.now(timezone.utc).isoformat(),'request_sha256':hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()}
            try:
                response=post(payload,port);rec.update(status='response_received',response=response,raw_text=response['choices'][0]['message']['content'])
            except Exception as e:rec.update(status='request_error',error=repr(e))
            rec['elapsed_seconds']=time.monotonic()-start
            return rec
        with open(out,'a',buffering=1) as f,concurrent.futures.ThreadPoolExecutor(max_workers=a.slots) as ex:
            futures=[ex.submit(infer,r) for r in pending]
            for i,future in enumerate(concurrent.futures.as_completed(futures),start=len(done)+1):
                rec=future.result();f.write(json.dumps(rec)+'\n');f.flush();os.fsync(f.fileno())
                if i%20==0 or i==len(requests):print(json.dumps({'model':a.model,'completed':i,'total':len(requests),'seconds':round(rec['elapsed_seconds'],2),'status':rec['status']}),flush=True)
        if {r['request_id'] for r in read(out)}.issuperset({r['request_id'] for r in requests}):
            (target/'completed.json').write_text(json.dumps({'finished_at_utc':datetime.now(timezone.utc).isoformat(),'requests':len(requests)})+'\n')
    finally:
        server.terminate()
        try:server.wait(timeout=10)
        except subprocess.TimeoutExpired:server.kill();server.wait()
        log.close()

if __name__=='__main__':main()
