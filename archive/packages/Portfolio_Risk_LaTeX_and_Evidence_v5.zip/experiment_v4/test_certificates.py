import copy,unittest
from fractions import Fraction as F
from analyze_certificates import certificate
from verify_certificates import bounds

class CertificateTests(unittest.TestCase):
    def test_correct_linear_model(self):
        x=[[F(i==j) for j in range(4)] for i in range(4)];p=[F(1,10),F(2,10),F(3,10),F(4,10)]
        lo,hi=bounds(certificate(x,p));self.assertEqual(lo,0);self.assertLess(hi,F(1,10**8))

    def test_wrong_but_consistent_weights_are_not_falsified(self):
        # Consistency with some weighting rule does not establish the prescribed weights.
        x=[[F(i==j) for j in range(4)] for i in range(4)]
        wrong=[F(1,4)]*4
        self.assertLess(bounds(certificate(x,wrong))[1],F(1,10**8))
        self.assertNotEqual(wrong,[F(1,10),F(2,10),F(3,10),F(4,10)])

    def test_equal_input_contradiction_has_exact_known_distance(self):
        x=[[F(1,2)]*4,[F(1,2)]*4];y=[F(2,5),F(3,5)]
        lo,hi=bounds(certificate(x,y));self.assertEqual(lo,F(1,10));self.assertEqual(hi,F(1,10))

    def test_tampered_bound_rejected(self):
        r=certificate([[F(1,2)]*4],[F(4,5)]);r['lower_exact']='1/2'
        with self.assertRaises(AssertionError):bounds(r)

    def test_out_of_simplex_primal_rejected(self):
        r=certificate([[F(1,2)]*4],[F(4,5)]);r['primal_weights']=['2','0','0','0']
        with self.assertRaises(AssertionError):bounds(r)

if __name__=='__main__':unittest.main()
