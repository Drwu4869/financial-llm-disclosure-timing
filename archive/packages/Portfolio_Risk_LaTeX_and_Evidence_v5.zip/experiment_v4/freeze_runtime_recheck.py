"""Select EVERY non-final-profile core record, without inspecting answer correctness."""
import json
from datetime import datetime,timezone
from build import ROOT,DATA,read,dump,sha

def final_profile(cmd):
    return (cmd[cmd.index('--parallel')+1]=='8' and cmd[cmd.index('-c')+1]=='12288'
            and '--no-repack' in cmd and '--cache-ram' in cmd
            and cmd[cmd.index('--cache-ram')+1]=='0' and '--no-cache-prompt' in cmd)

def main():
    path=DATA/'runtime_recheck_protocol.json'
    if path.exists():raise RuntimeError('Already frozen; do not overwrite')
    folder=ROOT/'results/qwen8/prompts_evaluation'
    raw=read(folder/'raw.jsonl');meta=json.loads((folder/'execution_metadata.json').read_text())
    commands={r['request_id']:meta['command'] for r in raw}
    for segment in read(folder/'execution_segments.jsonl'):
        for rid in segment['selected_new_requests']:commands[rid]=segment['command']
    selected=sorted(r['request_id'] for r in raw if not final_profile(commands[r['request_id']]))
    assert len(selected)==167 and len(set(selected))==167
    prompts=[p for p in read(DATA/'prompts.jsonl') if p['request_id'] in set(selected)]
    assert len(prompts)==167
    dump(DATA/'runtime_recheck_prompts.jsonl',prompts)
    protocol={'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'status':'PROSPECTIVELY_FROZEN_INFRASTRUCTURE_RECHECK_AFTER_INITIAL_INFERENCE','selected_request_ids':selected,'selected_count':167,'original_core_progress_at_freeze':len(raw),'selection_rule':'Every saved Qwen core response executed outside the final profile; selection examines commands and identifiers only, never answers or correctness.','target_profile':{'slots':8,'total_context':12288,'weight_repacking':False,'prompt_ram_cache_mib':0,'prompt_cache':False},'unchanged':['model bytes','original question payload','temperature','seed','response cap','JSON constraints','reasoning mode','all accuracy thresholds','audit and consistency gates'],'analysis_rule':'The uniform analysis replaces ALL 167 selected records with one new saved response each, regardless of correctness; it reuses the 409 original final-profile core responses. Retain and report the initial mixed-profile view and paired discrepancies. Source and challenge inference already use the final profile and are not repeated.','limits':['This is a dated execution amendment, not an independent sample of cases or an externally preregistered replication.','All original responses remain archived; the additional responses must not inflate the number of independent cases.'],'files':{'runtime_recheck_prompts.jsonl':sha(DATA/'runtime_recheck_prompts.jsonl')},'original_prompts_sha256':sha(DATA/'prompts.jsonl')}
    path.write_text(json.dumps(protocol,indent=2)+'\n');print(json.dumps({k:v for k,v in protocol.items() if k!='selected_request_ids'},indent=2))

if __name__=='__main__':main()
