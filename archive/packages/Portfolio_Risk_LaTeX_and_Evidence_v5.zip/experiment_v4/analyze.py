"""Implements the frozen analysis plan; code completed during inference. No imputed observations."""
import argparse,json,math,random,statistics
from pathlib import Path
from build import ROOT,DATA,C,DELTA,SEED,read,dot,risk,sha

TOL=.005
def load_core_records(model,uniform=False):
    folder=ROOT/'results'/model/'prompts_evaluation'
    raw=read(folder/'raw.jsonl');records={r['request_id']:r for r in raw}
    assert len(records)==len(raw),'Duplicate original requests'
    if not uniform:return records
    assert model=='qwen8','Uniform execution amendment is specific to Qwen'
    from freeze_runtime_recheck import final_profile
    protocol=json.loads((DATA/'runtime_recheck_protocol.json').read_text())
    for name,h in protocol['files'].items():assert sha(DATA/name)==h
    assert sha(DATA/'prompts.jsonl')==protocol['original_prompts_sha256']
    recheck=ROOT/'results'/model/'runtime_recheck_prompts_evaluation'
    extra=read(recheck/'raw.jsonl');replacement={r['request_id']:r for r in extra}
    assert len(extra)==len(replacement)==protocol['selected_count']
    assert set(replacement)==set(protocol['selected_request_ids'])
    original_meta=json.loads((folder/'execution_metadata.json').read_text())
    meta=json.loads((recheck/'execution_metadata.json').read_text())
    assert original_meta['model']['sha256']==meta['model']['sha256']
    original_commands={rid:original_meta['command'] for rid in records}
    if (folder/'execution_segments.jsonl').exists():
        for segment in read(folder/'execution_segments.jsonl'):
            for rid in segment['selected_new_requests']:original_commands[rid]=segment['command']
    for rid in records:
        if rid not in replacement:assert final_profile(original_commands[rid])
    commands={rid:meta['command'] for rid in replacement}
    for segment in read(recheck/'execution_segments.jsonl'):
        for rid in segment['selected_new_requests']:commands[rid]=segment['command']
    for rid,new in replacement.items():
        assert rid in records and new['request_sha256']==records[rid]['request_sha256']
        assert final_profile(commands[rid])
        records[rid]=new  # Replace EVERY selected record, including worse or invalid responses.
    return records

def number(x):return isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x)

def parse(r):
    if not r or r.get('status')!='response_received':return None
    if r['response']['choices'][0].get('finish_reason')=='length':return None
    try:
        x=json.loads(r['raw_text'])
        return x if isinstance(x,dict) else None
    except (ValueError,TypeError):return None

def exposure(x,normalize=False):
    if not x or not all(number(x.get(k)) for k in ['a','b']):return None
    a,b=x['a'],x['b']
    if a<0 or b<0:return None
    if normalize:
        return a/(a+b) if a+b>0 else None
    if a>1 or b>1 or abs(a+b-1)>1e-5:return None
    return a

def ledger(x):
    if not x or not isinstance(x.get('rows'),list) or len(x['rows'])!=4:return None
    rows=x['rows']
    if any(not isinstance(r,dict) for r in rows):return None
    if sorted(str(r.get('id')) for r in rows)!=['L1','L2','L3','L4']:return None
    if any(not all(number(r.get(k)) and 0<=r[k]<=1 for k in ['q','a','b']) for r in rows):return None
    if abs(sum(r['q'] for r in rows)-1)>1e-5 or any(abs(r['a']+r['b']-1)>1e-5 for r in rows):return None
    return sum(r['q']*r['a'] for r in rows)

def ledger_faithful(x,case,tolerance=1e-6):
    """Supplementary source-copy check, distinct from aggregate correctness."""
    if ledger(x) is None:return False
    rows={r['id']:r for r in x['rows']}
    for j in range(4):
        expected={'q':case['q'][j],'a':case['b'][j],'b':1-case['b'][j]}
        if any(abs(rows[f'L{j+1}'][k]-v)>tolerance for k,v in expected.items()):return False
    return True

def audit(values,q,b,tol=TOL):
    base=values.get('base');anchor=values.get('anchor')
    names=[f'probe{k}_{s}' for k in range(3) for s in ['plus','minus']]
    if base is None or anchor is None or any(values.get(k) is None for k in names):return {'accepted':False,'valid':False}
    slopes=[(values[f'probe{k}_plus']-values[f'probe{k}_minus'])/(2*DELTA) for k in range(3)]
    residual=[slopes[k]-dot(C[k],q) for k in range(3)]
    curvature=max(abs((values[f'probe{k}_plus']+values[f'probe{k}_minus'])/2-base) for k in range(3))
    e=[sum(C[k][j]*residual[k] for k in range(3))/4 for j in range(4)]
    p=[q[j]+e[j] for j in range(4)]
    slope_error=max(abs(v) for v in residual)
    accepted=slope_error<=4*tol and curvature<=tol and abs(anchor)<=tol
    # This compatibility statistic does not establish the model's internal mechanism.
    return {'accepted':accepted,'valid':True,'slope_error':slope_error,'curvature':curvature,'anchor_error':abs(anchor),'effective_weights':p,'linear_fit_error':abs(base-dot(p,b)),'effective_weights_admissible':min(p)>=-tol and max(p)<=1+tol}

def consistency(values,tol=TOL):
    names=['base','split']+[f'order{k}' for k in range(6)]
    xs=[values.get(k) for k in names]
    return all(x is not None for x in xs) and max(xs)-min(xs)<=tol

def bootstrap(rows,left,right):
    families=sorted({r['family_id'] for r in rows});blocks={f:[r for r in rows if r['family_id']==f] for f in families}
    rng=random.Random(SEED);scores=[]
    for _ in range(10000):
        sample=[r for _ in families for r in blocks[rng.choice(families)]]
        scores.append(statistics.mean(int(r[left])-int(r[right]) for r in sample))
    scores.sort();return [scores[249],scores[9749]]

def summary(rows):
    out={'n':len(rows),'families':len({r['family_id'] for r in rows})}
    for key in ['base_correct','renorm_correct','split_correct','ledger_correct','ledger_faithful','risk_direct_correct','risk_oracle_correct','calculator_correct','ledger_calculator_correct']:
        out[key]=sum(r[key] for r in rows)
    for key in ['audit','consistency']:
        accepted=[r for r in rows if r[key+'_accept']]
        out[key]={'accepted':len(accepted),'wrong_accepts':sum(not r['base_correct'] for r in accepted),'correct_accepts':sum(r['base_correct'] for r in accepted),'false_rejects':sum(r['base_correct'] and not r[key+'_accept'] for r in rows),'coverage':len(accepted)/len(rows),'accepted_accuracy':statistics.mean(r['base_correct'] for r in accepted) if accepted else None}
    out['ledger_minus_base_ci']=bootstrap(rows,'ledger_correct','base_correct')
    out['split_minus_base_ci']=bootstrap(rows,'split_correct','base_correct')
    out['all_base_valid']=sum(r['base'] is not None for r in rows)
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--model',required=True);ap.add_argument('--uniform',action='store_true');args=ap.parse_args()
    directory=ROOT/'results'/args.model/'prompts_evaluation'
    records=load_core_records(args.model,args.uniform);raw=list(records.values())
    cases=[c for c in read(DATA/'cases.jsonl') if c['split']=='evaluation']
    prompts=[p for p in read(DATA/'prompts.jsonl') if p['split']=='evaluation']
    assert len(records)==len(raw),'Duplicate recorded requests'
    assert set(records)=={p['request_id'] for p in prompts},'Refuse a partial result analysis'
    rows=[]
    for c in cases:
        get=lambda name:parse(records.get(c['case_id']+'__'+name))
        names=['base','split','anchor']+[f'order{k}' for k in range(6)]+[f'probe{k}_{s}' for k in range(3) for s in ['plus','minus']]
        vals={name:exposure(get(name)) for name in names};gold=dot(c['q'],c['b']);sig=risk(gold,c['returns_pct'])
        base=vals['base'];tr=ledger(get('ledger'));norm=exposure(get('base'),normalize=True)
        correct=lambda x:x is not None and abs(x-gold)<=TOL
        rcorrect=lambda x:x is not None and abs(x-sig)/sig<=.05
        ar=audit(vals,c['q'],c['b'])
        rd=get('risk_direct');ro=get('risk_oracle')
        rv=lambda x:x.get('risk_pct') if x and number(x.get('risk_pct')) and x['risk_pct']>=0 else None
        rows.append({'case_id':c['case_id'],'family_id':c['family_id'],'kind':c['kind'],'style':c['style'],'gold':gold,'base':base,'ledger':tr,'base_correct':correct(base),'renorm_correct':correct(norm),'split_correct':correct(vals['split']),'ledger_correct':correct(tr),'ledger_faithful':ledger_faithful(get('ledger'),c),'risk_direct_correct':rcorrect(rv(rd)),'risk_oracle_correct':rcorrect(rv(ro)),'calculator_correct':rcorrect(risk(base,c['returns_pct'])) if base is not None else False,'ledger_calculator_correct':rcorrect(risk(tr,c['returns_pct'])) if tr is not None else False,'audit_accept':ar['accepted'],'consistency_accept':consistency(vals),'audit_diagnostics':ar,'values':vals})
    output={'model':args.model,'all':summary(rows),'by_kind':{k:summary([r for r in rows if r['kind']==k]) for k in ['identical','heterogeneous']},'calls':len(raw),'truncations':sum(r.get('response',{}).get('choices',[{}])[0].get('finish_reason')=='length' for r in raw),'request_errors':sum(r['status']!='response_received' for r in raw),'elapsed_seconds':sum(r['elapsed_seconds'] for r in raw),'completion_tokens':sum(r.get('response',{}).get('usage',{}).get('completion_tokens',0) for r in raw),'tolerance_sweep':{},'rows':rows}
    cby={c['case_id']:c for c in cases}
    for t in [.001,.005,.01,.02]:
        accepted=[r for r in rows if audit(r['values'],cby[r['case_id']]['q'],cby[r['case_id']]['b'],t)['accepted']]
        output['tolerance_sweep'][str(t)]={'accepted':len(accepted),'wrong_accepts':sum(not r['base_correct'] for r in accepted)}
    output['execution_view']='uniform_configuration_recheck' if args.uniform else 'original_recorded_view'
    output['additional_runtime_recheck_records']=167 if args.uniform else 0
    (directory/('analysis_uniform.json' if args.uniform else 'analysis.json')).write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({k:v for k,v in output.items() if k!='rows'},indent=2))

if __name__=='__main__':main()
