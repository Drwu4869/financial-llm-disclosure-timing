"""Protect against selective replacement, payload drift and incomplete rechecks."""
import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import analyze
from build import sha,dump

class UniformViewTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.data=self.root/'data';self.data.mkdir()
        self.old=self.root/'results/qwen8/prompts_evaluation';self.old.mkdir(parents=True)
        self.new=self.root/'results/qwen8/runtime_recheck_prompts_evaluation';self.new.mkdir(parents=True)
        for name in ['prompts.jsonl','runtime_recheck_prompts.jsonl']:(self.data/name).write_text('{}\n')
        self.records=[{'request_id':k,'request_sha256':'payload-'+k,'status':'response_received','raw_text':'original-'+k} for k in ['a','b','c']]
        self.replacements=[{'request_id':'a','request_sha256':'payload-a','status':'request_error','error':'test failure'}, {'request_id':'b','request_sha256':'payload-b','status':'response_received','raw_text':'replacement-b'}]
        dump(self.old/'raw.jsonl',self.records);dump(self.new/'raw.jsonl',self.replacements)
        cmd=['server','--parallel','8','-c','12288','--no-repack','--cache-ram','0','--no-cache-prompt']
        meta={'model':{'sha256':'same-model'},'command':cmd}
        for d in [self.old,self.new]:(d/'execution_metadata.json').write_text(json.dumps(meta))
        dump(self.new/'execution_segments.jsonl',[{'selected_new_requests':['a','b'],'command':cmd}])
        protocol={'selected_count':2,'selected_request_ids':['a','b'],'original_prompts_sha256':sha(self.data/'prompts.jsonl'),'files':{'runtime_recheck_prompts.jsonl':sha(self.data/'runtime_recheck_prompts.jsonl')}}
        (self.data/'runtime_recheck_protocol.json').write_text(json.dumps(protocol))
        for key,value in [('ROOT',self.root),('DATA',self.data)]:
            p=patch.object(analyze,key,value);p.start();self.addCleanup(p.stop)

    def test_every_selected_record_replaced_even_when_worse(self):
        original_bytes=(self.old/'raw.jsonl').read_bytes()
        r=analyze.load_core_records('qwen8',True)
        self.assertEqual(r['a']['status'],'request_error')
        self.assertEqual(r['b']['raw_text'],'replacement-b')
        self.assertEqual(r['c']['raw_text'],'original-c')
        self.assertEqual((self.old/'raw.jsonl').read_bytes(),original_bytes)

    def test_incomplete_recheck_rejected(self):
        dump(self.new/'raw.jsonl',self.replacements[:1])
        with self.assertRaises(AssertionError):analyze.load_core_records('qwen8',True)

    def test_payload_change_rejected(self):
        self.replacements[0]['request_sha256']='different'
        dump(self.new/'raw.jsonl',self.replacements)
        with self.assertRaises(AssertionError):analyze.load_core_records('qwen8',True)

    def test_wrong_runtime_profile_rejected(self):
        dump(self.new/'execution_segments.jsonl',[{'selected_new_requests':['a','b'],'command':['server','--parallel','4','-c','8192']}])
        with self.assertRaises(AssertionError):analyze.load_core_records('qwen8',True)

if __name__=='__main__':unittest.main()
