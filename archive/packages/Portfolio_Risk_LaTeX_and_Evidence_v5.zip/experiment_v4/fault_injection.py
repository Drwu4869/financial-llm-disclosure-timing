"""Mechanism simulation, NOT observed language-model errors."""
import itertools,json,math,random
from pathlib import Path
from build import ROOT,C,DELTA,dot
from analyze import audit

def values(p,b):
    ans={'base':dot(p,b),'anchor':0.}
    for k,code in enumerate(C):
        for sign,label in [(1,'plus'),(-1,'minus')]:ans[f'probe{k}_{label}']=dot(p,[x+sign*DELTA*z for x,z in zip(b,code)])
    return ans

def main():
    qs=list(itertools.permutations([.10,.15,.30,.45]))+list(itertools.permutations([.05,.20,.35,.40]))
    counts={'instances':0,'benign_uniform_multiplicity':0,'nonuniform_multiplicity':0,'identical_base_exact':0,'heterogeneous_base_exact':0,'one_contrast_detected':0,'three_contrasts_detected':0,'max_reconstruction_error':0.}
    rows=[]
    for qi,q in enumerate(qs):
        b=[.21,.38,.64,.79];w=dot(q,b)
        for m in itertools.product([0,1,2],repeat=4):
            if sum(m)==0:continue
            z=dot(q,m);p=[q[j]*m[j]/z for j in range(4)];bad=max(abs(x-y) for x,y in zip(p,q))>1e-10
            same=abs(dot(p,[w]*4)-w)<=1e-10;hetero=abs(dot(p,b)-w)<=1e-10
            ar=audit(values(p,b),q,b,tol=1e-10);s=[dot(code,[p[j]-q[j] for j in range(4)]) for code in C]
            counts['instances']+=1;counts['nonuniform_multiplicity']+=bad;counts['benign_uniform_multiplicity']+=not bad
            counts['identical_base_exact']+=same;counts['heterogeneous_base_exact']+=hetero
            counts['one_contrast_detected']+=bad and abs(s[0])>1e-10
            counts['three_contrasts_detected']+=bad and not ar['accepted']
            counts['max_reconstruction_error']=max(counts['max_reconstruction_error'],max(abs(x-y) for x,y in zip(p,ar['effective_weights'])))
            rows.append({'q_index':qi,'q':q,'multiplicities':m,'p':p,'homogeneous_correct':same,'heterogeneous_correct':hetero,'nonuniform':bad,'contrast_detected':not ar['accepted']})
    assert counts['identical_base_exact']==counts['instances']
    assert counts['three_contrasts_detected']==counts['nonuniform_multiplicity']
    assert counts['max_reconstruction_error']<1e-12
    out=ROOT/'results/theory';out.mkdir(parents=True,exist_ok=True)
    (out/'summary.json').write_text(json.dumps({'status':'DETERMINISTIC_FAULT_INJECTION_NOT_LLM_OUTPUT','design':'48 account allocations x 80 nonempty multiplicity vectors','counts':counts},indent=2)+'\n')
    (out/'injected_faults.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
    print(json.dumps(counts,indent=2))

if __name__=='__main__':main()
