"""Freeze a fresh, cue-free follow-up. Constructed stimuli are not market observations."""
import hashlib, itertools, json, math, random, statistics
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'
C=[[1,1,-1,-1],[1,-1,1,-1],[1,-1,-1,1]]
DELTA=.05
SEED=2026110507

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def dump(path,rows):
    path.write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in rows))

def read(path):
    return [json.loads(x) for x in Path(path).read_text().splitlines() if x.strip()]

def dot(x,y):return sum(a*b for a,b in zip(x,y))

def risk(a,returns):return statistics.pstdev(a*x+(1-a)*y for x,y in returns)

def render(q,b,style,order=None,split=False):
    order=range(4) if order is None else order
    rows=[]
    for j in order:
        copies=2 if split else 1
        for k in range(copies):
            lot=f'L{j+1}'+('ab'[k] if split else '')
            x=q[j]*100/copies;y=b[j]*100
            if style==0:
                rows.append(f'Lot {lot}: {x:.5f}% of the account is invested in Product_{j+1}. That product allocates {y:.5f}% to Asset_A and {100-y:.5f}% to Asset_B.')
            elif style==1:
                rows.append(f'Product_{j+1}, funded lot {lot}: internal composition = Asset_B {100-y:.5f}%, Asset_A {y:.5f}%; account allocation = {x:.5f}%.')
            else:
                rows.append(f'{lot} / Product_{j+1} | account share {x:.5f}% | within product: Asset_A {y:.5f}%, Asset_B {100-y:.5f}%')
    return '\n'.join(rows)

def common():
    return ('Use only these supplied holdings. Every listed lot is separately funded and must be counted. '
            'Product percentages are fractions of that product, not of the entire account. '
            'Products are bookkeeping containers with no fees, leverage, taxes, or additional risks.\n')

def main():
    DATA.mkdir(parents=True,exist_ok=True)
    if (DATA/'protocol.json').exists():raise RuntimeError('Frozen protocol already exists; do not overwrite.')
    rng=random.Random(SEED)
    cases=[];prompts=[];gold=[]
    permutations=[(1,0,3,2),(3,2,1,0),(2,3,0,1),(0,2,1,3),(3,0,2,1),(2,1,3,0)]
    def add(c,condition,text,task='exposure',b=None):
        rid=c['case_id']+'__'+condition
        prompts.append({'request_id':rid,'case_id':c['case_id'],'family_id':c['family_id'],'condition':condition,'task':task,'split':c['split'],'system':'Return one JSON object. Do not add explanatory prose.','prompt':text})
        a=dot(c['q'],c['b'] if b is None else b)
        gold.append({'request_id':rid,'a':a,'risk_pct':risk(a,c['returns_pct'])})
    suffix='\nCalculate total account exposures to the underlying assets. Return {"a": number, "b": number} as fractions, with a for Asset_A and b for Asset_B. Do not copy product-level percentages as account weights.'
    for f in range(18):
        split='development' if f<2 else 'evaluation'
        q=rng.sample([.10,.15,.30,.45],4) if f%2==0 else rng.sample([.05,.20,.35,.40],4)
        w=round(rng.uniform(.28,.72),3)
        deviations=[rng.uniform(-.09,.09) for _ in range(3)]
        deviations.append(-dot(q[:3],deviations)/q[3])
        scale=min(1.,.15/max(abs(x) for x in deviations))
        hetero=[round(w+scale*x,7) for x in deviations]
        # Preserve the aggregate exactly after rounding the first three entries.
        hetero[3]=(w-dot(q[:3],hetero[:3]))/q[3]
        sa=rng.uniform(1.1,4.8);sb=rng.uniform(.8,3.5);rho=rng.uniform(-.5,.7)
        returns=[[round(sa*x,7),round(sb*(rho*x+math.sqrt(1-rho*rho)*y),7)] for x,y in itertools.product([-1,1],repeat=2)]
        for kind,b in [('identical',[w]*4),('heterogeneous',hetero)]:
            c={'case_id':f'fresh_{f:02d}_{kind}','family_id':f'fresh_{f:02d}','split':split,'kind':kind,'q':q,'b':b,'style':f%3,'returns_pct':returns}
            cases.append(c)
            base=common()+render(q,b,c['style'])
            add(c,'base',base+suffix)
            add(c,'split',common()+render(q,b,c['style'],split=True)+suffix)
            for k,order in enumerate(permutations):add(c,f'order{k}',common()+render(q,b,c['style'],order)+suffix)
            for k,code in enumerate(C):
                for sign in [-1,1]:
                    shifted=[x+sign*DELTA*z for x,z in zip(b,code)]
                    assert all(0<=x<=1 for x in shifted)
                    add(c,f'probe{k}_{"plus" if sign==1 else "minus"}',common()+render(q,shifted,c['style'])+suffix,b=shifted)
            add(c,'anchor',common()+render(q,[0.]*4,c['style'])+suffix,b=[0.]*4)
            trace='\nExtract the four funded lots without aggregating. Return {"rows": [{"id": "L1", "q": number, "a": number, "b": number}, ...]}. Include L1, L2, L3, L4 exactly once. q is the fraction of the account in the lot; a and b are fractions inside its product. Use fractions, not percentages.'
            add(c,'ledger',base+trace,task='ledger')
            rtext='\nThe following four joint return states are equally likely. Returns are in percentage points.\nAsset_A | Asset_B\n'+'\n'.join(f'{x:.7f} | {y:.7f}' for x,y in returns)
            rtext+='\nCalculate the POPULATION standard deviation of the account return over these states, dividing the variance by four. Return {"risk_pct": number} in percentage points.'
            add(c,'risk_direct',base+rtext,task='risk')
            add(c,'risk_oracle',f'Verified account weights: Asset_A {w:.9f}; Asset_B {1-w:.9f}.'+rtext,task='risk')
    assert len({p['request_id'] for p in prompts})==len(prompts)
    dump(DATA/'cases.jsonl',cases);dump(DATA/'prompts.jsonl',prompts);dump(DATA/'answer_key.jsonl',gold)
    protocol={'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'status':'LOCALLY_FROZEN_FOLLOWUP_NOT_EXTERNALLY_PREREGISTERED','motivation':'Designed after v3 pilot; fresh prompts and parameter draws, no v4 outputs observed at freeze.','seed':SEED,'decoding':{'temperature':0,'max_tokens':512,'reasoning':'off','json_object':True},'evaluation_families':16,'evaluation_cases':32,'development_families':2,'models':['Qwen/Qwen3-8B-GGUF Q4_K_M','ggml-org/SmolLM3-3B-GGUF Q4_K_M'],'audit':{'C':C,'delta':DELTA,'slope_tolerance':.02,'curvature_tolerance':.005,'anchor_tolerance':.005,'budget':'8 calls: base, 6 perturbations, anchor. Matched comparator: base, 6 reorderings, split.'},'primary':{'exposure_absolute_tolerance':.005,'risk_relative_tolerance':.05,'unit':'family; identical and heterogeneous descriptions share a family','metrics':['accuracy','silent wrong accepts','coverage','conditional accepted accuracy','false rejects','paired split effect','cost and truncation'],'bootstrap':'10000 paired family resamples, seed 2026110507; exploratory intervals','missing':'invalid and truncated outputs are failures, no response retries','secondary':['normalization','source-factored calculator','slope reconstruction compatibility','tolerance sweep [.001,.005,.01,.02]']},'files':{p.name:sha(p) for p in DATA.glob('*.jsonl')},'limits':['Constructed text and returns; not authentic account statements.','Finite probes do not certify an arbitrary nonlinear language model.','Perturbation construction uses benchmark source structure; no autonomous verifier of arbitrary documents is claimed.','8B and 3B quantized local inference are not frontier-model evidence.']}
    (DATA/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    print(json.dumps({'cases':len(cases),'evaluation_cases':32,'requests_per_model':sum(p['split']=='evaluation' for p in prompts),'protocol_sha256':sha(DATA/'protocol.json')},indent=2))

if __name__=='__main__':main()
