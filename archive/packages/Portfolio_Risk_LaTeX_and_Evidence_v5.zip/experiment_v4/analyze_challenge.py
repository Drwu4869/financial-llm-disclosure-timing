"""Score prospective unseen-composition challenges using unchanged core gates."""
import argparse,json
from build import ROOT,DATA,read,dot
from analyze import parse,exposure

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--model',required=True);ap.add_argument('--uniform',action='store_true');a=ap.parse_args()
    folder=ROOT/'results'/a.model/'challenge_prompts_evaluation';raw=read(folder/'raw.jsonl')
    rr={r['request_id']:r for r in raw};gold={r['request_id']:r for r in read(DATA/'challenge_answers.jsonl')}
    assert len(rr)==len(raw)==len(gold)==64 and set(rr)==set(gold)
    core=json.loads((ROOT/'results'/a.model/'prompts_evaluation'/('analysis_uniform.json' if a.uniform else 'analysis.json')).read_text())
    rows=[]
    for r in core['rows']:
        ids=[r['case_id']+'__unseen_'+s for s in ['plus','minus']]
        predictions={rid:exposure(parse(rr[rid])) for rid in ids}
        passed=all(predictions[rid] is not None and abs(predictions[rid]-gold[rid]['a'])<=.005 for rid in ids)
        rows.append({'case_id':r['case_id'],'family_id':r['family_id'],'base_correct':r['base_correct'],'challenge_pass':passed,'audit_accept':r['audit_accept'],'consistency_accept':r['consistency_accept'],'predictions':predictions})
    out={'cases':32,'calls':64,'base_correct':sum(r['base_correct'] for r in rows),'challenge_pass':sum(r['challenge_pass'] for r in rows),'base_correct_but_challenge_fail':sum(r['base_correct'] and not r['challenge_pass'] for r in rows),'gates':{},'rows':rows}
    for k in ['audit','consistency']:
        selected=[r for r in rows if r[k+'_accept']]
        out['gates'][k]={'accepted':len(selected),'challenge_fail_among_accepted':sum(not r['challenge_pass'] for r in selected),'challenge_pass_among_accepted':sum(r['challenge_pass'] for r in selected),'challenge_pass_but_rejected':sum(r['challenge_pass'] and not r[k+'_accept'] for r in rows)}
    out['execution_view']='uniform_configuration_recheck' if a.uniform else 'original_recorded_view'
    (folder/('analysis_uniform.json' if a.uniform else 'analysis.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))

if __name__=='__main__':main()
