"""Explicitly post hoc normalization of all queries; thresholds unchanged."""
import argparse,json
from build import ROOT,DATA,read,dot
from analyze import parse,exposure,audit,consistency,load_core_records

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--model',required=True);ap.add_argument('--uniform',action='store_true');a=ap.parse_args()
    folder=ROOT/'results'/a.model/'prompts_evaluation'
    rr=load_core_records(a.model,a.uniform);raw=list(rr.values())
    expected={p['request_id'] for p in read(DATA/'prompts.jsonl') if p['split']=='evaluation'}
    assert len(rr)==len(raw)==len(expected) and set(rr)==expected
    names=['base','split','anchor']+[f'order{k}' for k in range(6)]+[f'probe{k}_{s}' for k in range(3) for s in ['plus','minus']]
    rows=[]
    for c in read(DATA/'cases.jsonl'):
        if c['split']!='evaluation':continue
        vals={k:exposure(parse(rr[c['case_id']+'__'+k]),normalize=True) for k in names}
        ar=audit(vals,c['q'],c['b']);base=vals['base'];gold=dot(c['q'],c['b'])
        rows.append({'case_id':c['case_id'],'kind':c['kind'],'normalized_base':base,'correct':base is not None and abs(base-gold)<=.005,'audit':ar,'consistency_accept':consistency(vals)})
    out={'status':'POST_HOC_ALL_QUERY_NORMALIZATION_NOT_PRIMARY_AUDIT','cases':32,'correct_normalized_base':sum(r['correct'] for r in rows),'all_audit_queries_valid':sum(r['audit']['valid'] for r in rows),'gates':{},'rows':rows}
    for k in ['audit','consistency']:
        selected=[r for r in rows if (r['audit']['accepted'] if k=='audit' else r['consistency_accept'])]
        out['gates'][k]={'accepted':len(selected),'wrong_accepts':sum(not r['correct'] for r in selected),'correct_accepts':sum(r['correct'] for r in selected)}
    out['execution_view']='uniform_configuration_recheck' if a.uniform else 'original_recorded_view'
    (folder/('normalized_analysis_uniform.json' if a.uniform else 'normalized_analysis.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))

if __name__=='__main__':main()
