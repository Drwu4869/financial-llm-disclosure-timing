"""Fetch exactly the pinned public artifacts; models are not redistributed."""
import argparse,hashlib,json,tarfile,urllib.request
from pathlib import Path
from build import ROOT

def digest(p):
    with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def fetch(item,directory):
    directory.mkdir(parents=True,exist_ok=True)
    p=directory/item.get('filename',item.get('file'))
    if p.exists() and digest(p)==item['sha256']:return p
    tmp=p.with_suffix(p.suffix+'.part')
    with urllib.request.urlopen(item['url'],timeout=120) as r,open(tmp,'wb') as f:
        while b:=r.read(8*1024*1024):f.write(b)
    if digest(tmp)!=item['sha256']:raise RuntimeError('Hash mismatch: refusing changed bytes')
    tmp.replace(p);print('Verified',p.name,flush=True);return p

def main():
    p=argparse.ArgumentParser();p.add_argument('--model',choices=['smol','qwen8','both'],default='both');a=p.parse_args()
    old=ROOT.parent/'experiment_v3/runtime'
    engine=json.loads((old/'runtime_manifest.json').read_text())[0]
    archive=fetch(engine,old)
    with tarfile.open(archive) as t:t.extractall(old/'llama',filter='data')
    for m,name in [('smol','SmolLM3-3B-GGUF.json'),('qwen8','Qwen3-8B-GGUF.json')]:
        if a.model in [m,'both']:fetch(json.loads((ROOT/'runtime'/name).read_text()),ROOT/'runtime')

if __name__=='__main__':main()
