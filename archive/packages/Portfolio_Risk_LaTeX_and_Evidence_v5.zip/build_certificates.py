"""Generate the v5 extension solely from exact-checked recorded evidence."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def main():
 data=json.loads((ROOT/'experiment_v4/results/certificates/summary.json').read_text())
 lines=['\\subsection{Post hoc incompatibility certificates}\\label{sec:certificate-results}',
 'The full diagnostic and its provenance are specified in Section~\\ref{sec:certificate}. No acceptance threshold was retuned. Table~\\ref{tab:incompatibility} distinguishes strict eligibility from numerical normalization; zero eligible cases do not constitute evidence of compatibility.']
 rows=[]
 for r in data:
  label='SmolLM3-3B' if r['model']=='smol' else 'Qwen3-8B'
  rows.append(f"{label} & {r['mode']} & {r['eligible']}/32 & {r['incompatible']} & "+('--- & ---' if not r['eligible'] else f"{100*r['minimum']:.3f} & {100*r['median']:.3f}")+r'\\')
 lines.append('\\begin{table}[H]\\centering\\small\n\\begin{tabular}{@{}llrrrr@{}}\\toprule\nModel & View & Eligible & Incompatible & Min. $d_*$ & Median $d_*$\\\\\\midrule\n'+'\n'.join(rows)+'\n\\bottomrule\\end{tabular}\n\\caption{Incompatible means that the exact lower bound exceeds 0.005. Minimum and median distances are in percentage points of account exposure; displayed values use certified lower bounds, whose upper-bound gaps are below $3.08\\times10^{-10}$ in fractional units.}\\label{tab:incompatibility}\\end{table}')
 lines.append('The SmolLM3 strict view supplies no complete eight-query vector. Qwen3 supplies 22, all incompatible at the reference budget. After numerical normalization, all 32 cases from each model remain incompatible: the smallest required uniform error is about 0.94 percentage points for SmolLM3 and 2.07 for Qwen3. Thus the normalized failure cannot be explained by a single fixed normalized multiplicity vector with answer errors bounded by half a percentage point. This rejects a proposed explanation of the recorded responses, not every possible arithmetic or prompt-dependent explanation.')
 lines.append('The component analysis also separates formatting from semantic restrictions. After normalization, all 32 cases per model have valid fractions; none passes the original slope criterion. The curvature criterion passes 0/32 SmolLM3 and 1/32 Qwen3 cases, while the anchor criterion passes 28/32 and 32/32. The zero-coverage result is therefore not solely an interface-validity artifact.')
 rows=[]
 for r in data:
  if r['mode']!='normalized':continue
  s=r['simple_rejections'];label='SmolLM3-3B' if r['model']=='smol' else 'Qwen3-8B'
  rows.append(f"{label} & {s['single']} & {s['pair']} & {s['midpoint']} & {r['simple_union_rejections']} & {r['incompatible']}"+r'\\')
 lines.append('\\begin{table}[H]\\centering\\small\n\\begin{tabular}{@{}lrrrrr@{}}\\toprule\nModel & One query & Two queries & Midpoint & Union & Full LP\\\\\\midrule\n'+'\n'.join(rows)+'\n\\bottomrule\\end{tabular}\n\\caption{Normalized cases rejected by lower-bound witnesses at the unchanged 0.005 budget, out of 32 per model. The union includes the three displayed families. The LP adds no rejected SmolLM3 case and one Qwen3 case; this does not show general superiority over simple tests.}\\label{tab:simple-witnesses}\\end{table}')
 lines.append('The release contains 86 exact-checked certificates: 22 strict Qwen3 vectors and 64 normalized vectors, with overlapping observations across views. They are not 86 independent cases. Five new software tests include consistent-but-wrong weights, a contradiction with a known exact optimum, and deliberate certificate corruption; the full suite has 18 passing tests. A separate checker also binds each certificate to archived prompt literals and raw outputs. These are internal checks, not independent human validation.')
 lines.append('\\paragraph{A global contradiction missed by the three simple witness families.} The sole additional normalized Qwen3 case is \\texttt{fresh\\_13\\_identical}. Its base and three positive-contrast responses are shown in Table~\\ref{tab:global-example}. The base answer is correct. Every one-query, two-query and centered-midpoint witness in the specified families has lower bound zero for this case, yet no nonnegative normalized weighting vector fits all responses exactly.')
 lines.append(r'''\begin{table}[H]\centering\small
\begin{tabular}{@{}llr@{}}\toprule
Query & Product A fractions & Reported A\\\midrule
Base & $(0.296,0.296,0.296,0.296)$ & 0.296\\
Contrast 1, plus & $(0.346,0.346,0.246,0.246)$ & 0.246\\
Contrast 2, plus & $(0.346,0.246,0.346,0.246)$ & 0.346\\
Contrast 3, plus & $(0.346,0.246,0.246,0.346)$ & 0.346\\\bottomrule
\end{tabular}
\caption{Actual saved Qwen3 responses; their original A/B fractions already sum to one, so normalization leaves these values unchanged. This example is the sole case added by the full LP over the stated simple-witness union.}\label{tab:global-example}\end{table}
Write the three positive-contrast input rows as $x_1,x_2,x_3$. Coordinatewise,
$-x_1+x_2+x_3=(0.346,0.146,0.346,0.346)$. Any nonnegative normalized weighting rule must therefore satisfy
\begin{equation}
-f(x_1)+f(x_2)+f(x_3)\leq0.346.
\end{equation}
The saved answers instead give $-0.246+0.346+0.346=0.446$. If each answer differs from some fixed rule by at most $\epsilon$, the three discrepancies can account for at most $3\epsilon$ of this gap. Consequently $\epsilon\geq0.100/3$, or $3.\overline3$ percentage points. The LP provides a matching upper bound. This is a falsification of an admissible fixed-rule explanation, not proof that the model literally used negative weights. It strengthens the diagnosis of this finite trace; it does not turn the original zero-coverage gate into a useful correctness verifier.''')
 (ROOT/'certificate_results.tex').write_text('\n\n'.join(lines)+'\n')
 print('Generated v5 certificate results from saved evidence.')
if __name__=='__main__':main()
