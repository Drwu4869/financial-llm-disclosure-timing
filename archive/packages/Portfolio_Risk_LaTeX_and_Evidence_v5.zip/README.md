# Textual Fragmentation and Portfolio Risk — revision 5

This revision retains the original research problem. It does **not** start the separate cross-document-summary project discussed during brainstorming.

The paper studies when a correct-looking portfolio exposure answer fails to establish correct aggregation. Its mathematical results concern a **fixed normalized linear aggregation rule**. The language-model audit has a narrower empirical scope and is not a universal certificate.

## What is in the package

- `main.tex`, `body.tex`, `appendix.tex`, `references.bib`: English LaTeX manuscript.
- `build_results.py`: result tables, observed abstract statements, and figure generated from completed saved analyses.
- `experiment_v4/`: fresh protocols, prompts, gold labels, model responses, analysis, tests, and pinned download manifests.
- `experiment_v3/`: unchanged recorded pilot, with its 472 model calls and original analyses.
- `archive/`: the earlier delivered source ZIP and PDF, retained for provenance.
- `RELEASE_MANIFEST.json`: hashes of the delivered evidence and source files.
- `RESEARCH_STATUS.txt`: a candid distinction between completed work and unresolved publication claims.

## Evidence types

1. **Analytical results:** homogeneous-holdings indistinguishability, a contrast-rank condition, a four-product reconstruction identity, and a bounded-noise result. The underlying linear algebra, Hadamard coding and standard risk formula are established mathematics.
2. **Injected-rule simulation:** 3,840 specified aggregation rules, including 3,744 nonuniform multiplicity errors. These are NOT model observations.
3. **Fresh controlled model evaluation:** 32 cases in 16 paired families, 18 conditions per case, two model families. Every model output is retained, including failures.
4. **Source-derived holdings evaluation:** 20 constructed accounts using five Vanguard issuer factsheets dated 30 September 2026. All 48 published holding rows agree across two PDF extraction engines and were visually checked within the project. This is NOT independent human annotation, real customer-account data, or original narrative-document understanding.
5. **Unseen-composition challenge:** two additional compositions per controlled case, frozen during core inference and never supplied to the eight-call gates. This is a separately dated exploratory extension; the acceptance rules were not retuned.
6. **Earlier pilot:** 472 calls, reported separately. Different models, output constraints, token budgets and prompts prevent a clean causal comparison with the fresh follow-up.
7. **Uniform execution recheck:** all 167 Qwen core observations produced outside the final runtime configuration are re-executed under one fixed profile, selected by commands rather than correctness. The main view uses these responses plus the 409 original final-profile responses. Both original and uniform views are retained. These are additional records on existing cases, not 167 new independent cases.

## Reproduce analysis without inference

Use Python 3.12 with numpy, matplotlib, pypdf, and Poppler available. The existing source tables suffice for analysis; the original issuer PDFs are not redistributed.

```sh
python -m unittest discover -s experiment_v4 -p 'test_*.py' -v
python experiment_v4/check_baselines.py
python experiment_v4/fault_injection.py
python experiment_v4/analyze.py --model smol
python experiment_v4/analyze.py --model qwen8
python experiment_v4/analyze.py --model qwen8 --uniform
python experiment_v4/analyze_normalized.py --model smol
python experiment_v4/analyze_normalized.py --model qwen8
python experiment_v4/analyze_normalized.py --model qwen8 --uniform
python experiment_v4/analyze_source.py --model smol
python experiment_v4/analyze_source.py --model qwen8
python experiment_v4/analyze_source_units.py --model smol
python experiment_v4/analyze_source_units.py --model qwen8
python experiment_v4/analyze_challenge.py --model smol
python experiment_v4/analyze_challenge.py --model qwen8
python experiment_v4/analyze_challenge.py --model qwen8 --uniform
python experiment_v4/audit_release.py
python build_results.py
python experiment_v4/analyze_certificates.py
python experiment_v4/verify_certificates.py
python build_certificates.py
python draw_method.py
python write_status.py
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

Analysis refuses a partial core or challenge evaluation. The raw records are the authority for model outputs; gold labels and simulated faults must never be represented as generated answers.

## Reproduce inference

Use a separate working copy. First archive the supplied `experiment_v4/results/smol` and `experiment_v4/results/qwen8` directories; otherwise the resumable runner correctly skips existing request identifiers. Do not regenerate the frozen prompts.

```sh
python experiment_v4/setup_runtime.py --model both
python experiment_v4/run.py --model smol --split development --limit 4 --context-per-slot 8192
python experiment_v4/run.py --model smol
python experiment_v4/run.py --model smol --corpus source_prompts
python experiment_v4/run.py --model smol --corpus challenge_prompts
python experiment_v4/run.py --model qwen8 --split development --limit 4
python experiment_v4/run.py --model qwen8 --slots 8 --context-per-slot 1536 --no-repack --disable-prompt-cache
python experiment_v4/run.py --model qwen8 --corpus source_prompts --slots 8 --context-per-slot 1536 --no-repack --disable-prompt-cache
python experiment_v4/run.py --model qwen8 --corpus challenge_prompts --slots 8 --context-per-slot 1536 --no-repack --disable-prompt-cache
python experiment_v4/run.py --model qwen8 --corpus runtime_recheck_prompts --slots 8 --context-per-slot 1536 --no-repack --disable-prompt-cache
```

Downloads total several gigabytes. No API key or paid model API is used. Model weights and inference binaries are intentionally omitted. Original model licenses apply.

The observed runs use llama.cpp b12110, Q4_K_M, greedy decoding, reasoning disabled, JSON-object constrained outputs, and 512 output tokens. SmolLM3 evaluation uses four slots and 16,384 total context tokens; its excluded development check used 32,768. Qwen3 development and its first 64 core responses use four slots and 8,192 context tokens. Memory pressure led to disabled weight repacking and eight slots with 12,288 context tokens for the next 42 saved core responses, then four slots and 6,144 context tokens for 61 more. After 167 saved core responses, the runtime's default 8,192 MiB prompt RAM cache was identified and disabled. The final profile uses eight slots, 12,288 context tokens, disabled repacking, and `--cache-ram 0 --no-cache-prompt`. HTTP requests already specified `cache_prompt=false` throughout. These infrastructure changes were based on memory/latency, not answer accuracy. No saved response was replaced; interrupted attempts without saved responses may be submitted again.

The commands above re-run the frozen inputs using the final stable Qwen runtime profile. They do not exactly replay the original mixed batching history; execution segments record the original commands and request selections. The release audit checks actual prompt lengths plus the full output budget against each response's applicable per-slot limit. One-response-per-prompt evaluations do not measure sampling variance. Hardware, batching, kernel choice and model-template date insertion can affect exact output reproducibility; raw responses and hashes preserve the actual recorded evidence. Use `--batch-size 64` repeatedly if your execution service imposes short job lifetimes. Reported call totals count saved evaluation records, not every interrupted inference attempt.

## Interpretation rules

- A model answering a homogeneous case correctly may still misweight individual products. This is the paper's analytical blind spot.
- A finite audit cannot certify arbitrary nonlinear behavior. Reconstructed weights are conditional diagnostics, not a measurement of internal reasoning.
- Zero incorrect accepts with zero accepted answers is not a useful verifier.
- Source-factored extraction plus a calculator is an established engineering baseline. Its accuracy improvements cannot be called a newly invented risk algorithm.
- Source-derived tables do not supply securities-level correlations or future-risk labels.
- Local protocol hashes document chronology but are not external preregistration.
- A separately dated source-unit diagnostic was added after both source runs completed. It applies a fixed blockwise percentage-to-fraction heuristic without consulting gold answers. These post hoc results do not replace primary scoring or establish a universal correction rule.
- Internal software checks and AI-assisted visual review are not independent expert validation.
- Publication, novelty priority, funded-PhD admission and employment outcomes are not guaranteed by this release.

The named author should understand and verify the proofs, source mappings, code, inference configuration and all manuscript claims before submitting. Select a venue and apply its formatting and disclosure requirements only after that review.

## Revision 5: exact-checkable failure diagnosis

This extension is explicitly post hoc. It reuses the existing raw observations and makes **zero new model calls**. `certificate_method.tex` states the model class and proof; `certificate_results.tex` reports all eligible cases and simple-witness comparators. `experiment_v4/results/certificates/` contains the dated analysis note, all rational primal/dual certificates and the summary. The independent checker uses only Python's standard library, verifies arithmetic exactly, and binds its inputs to prompt literals and saved responses. The generation script additionally needs SciPy 1.17.0.

All 64 normalized model/case traces are incompatible with a fixed convex-combination explanation at a 0.005 error budget. These are the same 32 paired cases per model from v4, not fresh independent tests. Strict eligibility is separately reported. The full LP adds one Qwen3 rejection over the union of the three stated simple-witness families, and none for SmolLM3. The original slope gate already rejects all cases. No correctness, repair, hidden-mechanism or future-reliability guarantee follows.

The prior v4 PDF and source ZIP are preserved under `archive/v4/`. V4 numerical results and raw records remain unchanged. `V5_REVIEW_NOTES.txt` describes what the extension adds and the remaining publication gap.
