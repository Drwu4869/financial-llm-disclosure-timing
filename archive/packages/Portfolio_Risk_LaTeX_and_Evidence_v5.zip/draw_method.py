"""An exact analytical illustration, never presented as model observations."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=Path(__file__).resolve().parent
q=np.array([.1,.2,.3,.4]);m=np.array([1,1,1,2]);p=q*m/(q@m)
C=np.array([[1,1,-1,-1],[1,-1,1,-1],[1,-1,-1,1]])
t=np.linspace(-.05,.05,101)
fig,axs=plt.subplots(1,3,figsize=(9.8,2.7),sharex=True,sharey=True,constrained_layout=True)
for k,ax in enumerate(axs):
    ax.plot(t,.6+t*(C[k]@q),color='#287d77',lw=2,label='Correct account weights')
    ax.plot(t,.6+t*(C[k]@p),color='#b98256',lw=2,ls='--',label='Last product counted twice')
    ax.scatter([0],[.6],s=28,color='#333333',zorder=3)
    ax.axvline(0,lw=.6,color='#999999',alpha=.7)
    ax.set_title(f'Contrast {k+1}',fontsize=11);ax.set_xlabel('Composition shift',fontsize=10)
    ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.15)
    ax.set_xticks([-.05,0,.05],['−0.05','0','+0.05'])
axs[0].set_ylabel('Reported A exposure',fontsize=10)
axs[1].legend(loc='lower center',bbox_to_anchor=(.5,1.15),ncol=2,frameon=False,fontsize=9)
(root/'figures').mkdir(exist_ok=True)
for suffix in ['pdf','png']:fig.savefig(root/'figures'/('analytical_contrasts.'+suffix),dpi=180)
plt.close(fig)
