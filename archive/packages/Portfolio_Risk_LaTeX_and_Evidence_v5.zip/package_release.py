"""Package revision 5 without overwriting the preserved revision 4 artifacts."""
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXCLUDED = {'.aux', '.log', '.bbl', '.blg', '.out', '.fls', '.fdb_latexmk', '.pyc', '.gguf', '.part', '.synctex.gz'}

def main():
    subprocess.run([sys.executable, str(ROOT/'experiment_v4/verify_certificates.py')], check=True)
    prior = ROOT/'archive/v4/Portfolio_Risk_LaTeX_and_Evidence_v4.zip'
    with zipfile.ZipFile(prior) as z:
        original = [n for n in z.namelist() if n.startswith(('experiment_v3/', 'experiment_v4/')) and not n.endswith('/')]
        for name in original:
            assert z.read(name) == (ROOT/name).read_bytes(), f'Changed original evidence: {name}'
    paths = []
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file() or '__pycache__' in p.parts or p.name.startswith('.'):
            continue
        if p.name == 'RELEASE_MANIFEST.json' or p.suffix in EXCLUDED:
            continue
        if 'runtime' in p.relative_to(ROOT).parts and p.suffix != '.json':
            continue
        paths.append(p)
    records = [{'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size,
                'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]
    manifest = {
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'revision': 5, 'status': 'COMPLETED_POST_HOC_EXTENSION',
        'original_new_study_evaluation_records': 1400,
        'runtime_recheck_records': 167, 'development_records': 8,
        'archived_pilot_records': 472, 'additional_v5_model_calls': 0,
        'post_hoc_certificates': 86, 'normalized_model_case_traces': 64,
        'original_experiment_files_verified_unchanged': len(original),
        'software_tests_passed': 18, 'exact_certificate_check': 'PASS',
        'limitations': 'Post hoc reuse of v4 observations. Certificate views overlap. No new independent cases, external validation, answer-correction claim, or publication guarantee.',
        'files': records,
    }
    mp = ROOT/'RELEASE_MANIFEST.json'
    mp.write_text(json.dumps(manifest, indent=2)+'\n')
    out = ROOT.parent/'output'
    out.mkdir(exist_ok=True)
    pdf = out/'Portfolio_Risk_Text_Fragmentation_English_v5.pdf'
    shutil.copyfile(ROOT/'main.pdf', pdf)
    archive = out/'Portfolio_Risk_LaTeX_and_Evidence_v5.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in paths+[mp]:
            z.write(p, str(p.relative_to(ROOT)))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in records:
            b = z.read(item['path'])
            assert len(b) == item['bytes']
            assert hashlib.sha256(b).hexdigest() == item['sha256']
    print(json.dumps({'pdf': str(pdf), 'zip': str(archive), 'files': len(records)+1,
                      'zip_bytes': archive.stat().st_size, 'archive_integrity': 'PASS'}, indent=2))

if __name__ == '__main__':
    main()
