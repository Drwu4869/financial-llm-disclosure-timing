"""Generate manuscript numbers only from completed, recorded analyses."""
import json,statistics,sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
EXP=ROOT/'experiment_v4' if (ROOT/'experiment_v4').exists() else ROOT.parent/'experiment_v4'
sys.path.insert(0,str(EXP))
from analyze import load_core_records
LABELS={'smol':'SmolLM3-3B','qwen8':'Qwen3-8B'}

def load(p):return json.loads(p.read_text())
def table(header,rows,caption,label,cols):
    return '\\begin{table}[htbp]\\centering\\small\n\\begin{tabular}{@{}'+cols+'@{}}\\toprule\n'+' & '.join(header)+'\\\\\\midrule\n'+'\n'.join(' & '.join(map(str,r))+'\\\\' for r in rows)+'\n\\bottomrule\\end{tabular}\n\\caption{'+caption+'}\\label{'+label+'}\n\\end{table}\n'

def main():
    results={m:load(EXP/f'results/{m}/prompts_evaluation'/('analysis_uniform.json' if m=='qwen8' else 'analysis.json')) for m in LABELS}
    sources={m:load(EXP/f'results/{m}/source_prompts_evaluation/analysis.json') for m in LABELS}
    challenges={m:load(EXP/f'results/{m}/challenge_prompts_evaluation'/('analysis_uniform.json' if m=='qwen8' else 'analysis.json')) for m in LABELS}
    normalized={m:load(EXP/f'results/{m}/prompts_evaluation'/('normalized_analysis_uniform.json' if m=='qwen8' else 'normalized_analysis.json')) for m in LABELS}
    text=['\\subsection{Fresh exposure and risk performance}','Main Qwen3 results use the uniform-configuration view described in the execution amendment. All affected responses are replaced according to runtime configuration, never correctness; the original mixed-profile results are reported in Appendix~\\ref{app:execution}.']
    rows=[]
    methods=[('Direct aggregate exposure','base_correct'),('Numerically normalized exposure','renorm_correct'),('Split-lot exposure','split_correct'),('Source-factored exposure','ledger_correct'),('Direct risk generation','risk_direct_correct'),('Risk with verified weights','risk_oracle_correct'),('Aggregate extraction + calculator','calculator_correct'),('Source-factored extraction + calculator','ledger_calculator_correct')]
    for label,key in methods:rows.append([label]+[f"{results[m]['all'][key]}/32" for m in LABELS])
    text.append(table(['Condition']+list(LABELS.values()),rows,'All-attempt accuracy on 32 cases from 16 paired families per model. Exposure tolerance is 0.005; risk tolerance is 5\\% relative error. Invalid and truncated outputs count as failures.','tab:fresh','lrr'))
    for m,label in LABELS.items():
        d=results[m];ci=d['all']['ledger_minus_base_ci'];si=d['all']['split_minus_base_ci']
        text.append(f"For {label}, the paired source-factored minus direct exposure-accuracy difference is {100*(d['all']['ledger_correct']-d['all']['base_correct'])/32:.1f} percentage points (exploratory 95\\% family-bootstrap interval [{100*ci[0]:.1f}, {100*ci[1]:.1f}]). The split-minus-base interval is [{100*si[0]:.1f}, {100*si[1]:.1f}] percentage points. The core evaluation has {d['request_errors']} request errors and {d['truncations']} output-cap terminations in {d['calls']} calls.")
        rr=d['rows'];aggregate=sum(r['calculator_correct'] and not r['base_correct'] for r in rr);factored=sum(r['ledger_calculator_correct'] and not r['ledger_correct'] for r in rr)
        text.append(f"Among calculated-risk successes for {label}, {aggregate} using aggregate extraction and {factored} using source-factored extraction fail the separate exposure-accuracy threshold. Risk and exposure tolerances differ, and risk is not generally an injective function of exposure. These counts demonstrate score disagreement; they do not by themselves identify an exact variance-symmetry mechanism in the observed errors.")
    text.append('\\subsection{Audit coverage and incorrect acceptances}')
    rows=[]
    for m,label in LABELS.items():
        for key,method in [('consistency','Consistency'),('audit','Contrast basis')]:
            a=results[m]['all'][key];rows.append([label,method,f"{a['accepted']}/32",a['wrong_accepts'],a['false_rejects'],'---' if a['accepted_accuracy'] is None else f"{100*a['accepted_accuracy']:.1f}\\%"])
    text.append(table(['Model','Eight-call check','Accepted','Wrong','False reject','Acc. accepted'],rows,'Both checks assess the same base answer. Wrong denotes incorrect accepted base answers; false reject denotes a rejected correct base answer. A dash means no answers were accepted, so conditional accuracy is undefined.','tab:audit','llrrrr'))
    rows=[]
    for m,label in LABELS.items():
        for kind in ['identical','heterogeneous']:
            d=results[m]['by_kind'][kind];rows.append([label,kind,f"{d['base_correct']}/16",f"{d['ledger_correct']}/16",d['audit']['accepted'],d['consistency']['accepted']])
    text.append(table(['Model','Holdings','Direct','Factored','Audit accepts','Consist. accepts'],rows,'Stratified descriptive counts. The two holdings types share economic exposure within each family; they are not independent samples.','tab:kind','llrrrr'))
    for m,label in LABELS.items():
        rr=results[m]['rows'];valid=[r['audit_diagnostics'] for r in rr if r['audit_diagnostics']['valid']]
        bad_weights=sum(not r['effective_weights_admissible'] for r in valid)
        poor_fit=sum(r['linear_fit_error']>.005 for r in valid)
        accidental=sum(r['ledger_correct'] and not r['ledger_faithful'] for r in rr)
        text.append(f"For {label}, {len(valid)}/32 cases provide valid outputs on all eight audit queries. Of these, {bad_weights} give reconstructed weights outside the admissible simplex tolerance and {poor_fit} have base-answer linear-fit error above 0.005. A supplementary source-copy audit finds {results[m]['all']['ledger_faithful']}/32 fully faithful ledgers at per-field tolerance $10^{{-6}}$; {accidental} aggregate-correct ledgers fail that stricter check. This copying check was added during inference and is descriptive, not a frozen primary endpoint.")
    rows=[]
    for t in ['0.001','0.005','0.01','0.02']:
        rows.append([t]+[f"{results[m]['tolerance_sweep'][t]['accepted']} / {results[m]['tolerance_sweep'][t]['wrong_accepts']}" for m in LABELS])
    text.append(table(['Base tolerance']+list(LABELS.values()),rows,'Sensitivity analysis: accepted / wrong-accepted counts. The slope threshold is four times the displayed tolerance; curvature and anchor thresholds equal it. Primary correctness labels remain fixed.','tab:sweep','lrr'))
    text.append('\\paragraph{Post hoc all-query normalization.} The completed SmolLM3 core run has no case with valid raw fractions on all eight audit queries. After inspecting that result, we added a separately dated diagnostic that renormalizes every query output using the same numerical normalization rule as the base-only baseline. This changes values; it is not format-only cleanup. The thresholds remain unchanged and these results do not replace the primary audit.')
    rows=[]
    for m,label in LABELS.items():
        n=normalized[m]
        rows.append([label,n['all_audit_queries_valid'],f"{n['gates']['audit']['accepted']} / {n['gates']['audit']['wrong_accepts']}",f"{n['gates']['consistency']['accepted']} / {n['gates']['consistency']['wrong_accepts']}"])
    text.append(table(['Model','Eight valid','Contrast accept/wrong','Consistency accept/wrong'],rows,'Explicitly post hoc diagnostic. Correctness is assessed against the normalized base answer. Every existing response is retained, with no threshold tuning or extra model calls.','tab:normalizedaudit','lrrr'))
    for m,label in LABELS.items():
        v=[r['audit'] for r in normalized[m]['rows'] if r['audit']['valid']]
        bad=sum(not d['effective_weights_admissible'] for d in v);poor=sum(d['linear_fit_error']>.005 for d in v)
        text.append(f"After normalization, {label} supplies {len(v)} complete diagnostic vectors: {bad} reconstruct inadmissible weights and {poor} fail the base-answer linear-fit check. These are compatibility diagnostics for the restricted model, not evidence that a particular hidden weighting mechanism has been discovered.")
    text.append('\\subsection{Unseen-composition challenge}')
    rows=[]
    for m,label in LABELS.items():
        ch=challenges[m]
        text.append(f"For {label}, {ch['challenge_pass']}/32 cases pass both new composition queries; {ch['base_correct_but_challenge_fail']} of the {ch['base_correct']} cases with a correct base answer fail at least one challenge query.")
        for key,method in [('consistency','Consistency'),('audit','Contrast basis')]:
            g=ch['gates'][key]
            rows.append([label,method,g['accepted'],g['challenge_fail_among_accepted'],g['challenge_pass_among_accepted'],g['challenge_pass_but_rejected']])
    text.append(table(['Model','Eight-call check','Accept','Fail after','Pass after','Pass but reject'],rows,'Exploratory transfer test using unchanged core-gate decisions. Fail/pass after means that accepted cases fail/pass the two-query challenge. The queries are withheld from the gate. This is a dated extension designed during core inference, not an independently preregistered benchmark.','tab:challenge','llrrrr'))
    text.append('\\subsection{Source-derived holdings results}')
    rows=[[LABELS[m]]+[f"{sources[m]['correct'][k]}/20" for k in ['direct','split','ledger']] for m in LABELS]
    text.append(table(['Model','Direct','Split lots','Source-factored'],rows,'All three requested exposures must be within 0.0006 of the displayed-data answer. These 20 constructed accounts reuse five factsheets and ten pairs; no independent-source significance claim is made.','tab:source','lrrr'))
    text.append('Source-tier format failures, complete predictions, and per-target errors are retained in the machine-readable analysis. Correctness concerns ownership of named underlying funds, not security-level diversification or future volatility.')
    text.append('\\paragraph{Post hoc unit sensitivity.} After both source runs completed, inspection of Qwen3 outputs revealed percentage values in the fractional interface. We therefore separately apply a fixed numerical heuristic: if a target-value block contains a value above one and all entries lie in $[0,100]$, divide the entire block by 100. For ledgers, apply this per row and separately to the account-weight vector. Conversion decisions do not consult gold answers; other values remain unchanged. This can misinterpret units in other settings and is not format-only cleanup. It leaves the primary results and tolerance unchanged.')
    for m,label in LABELS.items():
        u=load(EXP/f'results/{m}/source_prompts_evaluation/unit_sensitivity.json')['summary']
        text.append(f"For {label}, this changes {u['direct']['changed']} direct, {u['split']['changed']} split and {u['ledger']['changed']} factored responses. The resulting all-target accuracies are {u['direct']['converted_correct']}/20, {u['split']['converted_correct']}/20 and {u['ledger']['converted_correct']}/20, respectively. These exploratory numbers distinguish visible unit failures from the remaining aggregation errors; they do not establish a generally valid repair algorithm.")
    text.append('\\Needspace{8\\baselineskip}\\subsection{Query and token cost}\nThe two diagnostic gates use eight calls per case, while source-factored extraction uses one. Table~\\ref{tab:cost} reports the observed resource use; Figure~\\ref{fig:fresh} summarizes accuracy on the same controlled cases.')
    rows=[]
    for m,label in LABELS.items():
        rr=list(load_core_records(m,uniform=(m=='qwen8')).values())
        for group,conds in [('Contrast basis',{'base','anchor'}|{f'probe{k}_{s}' for k in range(3) for s in ['plus','minus']}),('Consistency',{'base','split'}|{f'order{k}' for k in range(6)}),('Source-factored',{'ledger'})]:
            selected=[r for r in rr if r['request_id'].split('__')[-1] in conds]
            toks=sum(r.get('response',{}).get('usage',{}).get('total_tokens',0) for r in selected)/32
            latency=sum(r['elapsed_seconds'] for r in selected)/32
            rows.append([label,group,len(selected)//32,f'{toks:.0f}',f'{latency:.1f}'])
    text.append(table(['Model','Method','Calls/case','Tokens/case','Sum latency (s)'],rows,'Recorded prompt plus completion tokens and summed latencies per case. This excludes interrupted attempts without a saved response. Calls run concurrently; summed latency is not wall-clock time. Different model profiles, request batches and host load prevent a controlled timing comparison.','tab:cost','llrrr').replace('[htbp]','[H]'))
    text.append('\\begin{figure}[H]\\centering\\includegraphics[width=\\linewidth]{figures/fresh_accuracy.pdf}\\caption{Recorded exposure and risk accuracy. Error bars are omitted because the paired family-bootstrap differences, rather than independent binomial intervals over prompts, are the reported uncertainty analysis.}\\label{fig:fresh}\\end{figure}')
    (ROOT/'observed_results.tex').write_text('\n\n'.join(text)+'\n')
    abstract=[]
    for m,label in LABELS.items():
        d=results[m]['all'];finding='the contrast audit has zero coverage' if d['audit']['accepted']==0 else f"the contrast audit accepts {d['audit']['accepted']}/32 base answers, including {d['audit']['wrong_accepts']} incorrect answers"
        abstract.append(f"For {label}, direct aggregate exposure is correct on {d['base_correct']}/32 cases and source-factored extraction on {d['ledger_correct']}/32; {finding}.")
    (ROOT/'abstract_observed.tex').write_text(' '.join(abstract)+'\n')
    discussion=[]
    for m,label in LABELS.items():
        d=results[m]['all'];aa=d['audit'];cc=d['consistency']
        discussion.append(f"For {label}, the contrast audit retains {aa['correct_accepts']} correct base answers and rejects {aa['false_rejects']} correct ones; the matched consistency check retains {cc['correct_accepts']} correct answers. These counts, together with {aa['wrong_accepts']} versus {cc['wrong_accepts']} incorrect acceptances, define the observed trade-off. They should not be reduced to a headline about zero false accepts or correctness among a selected subset.")
        ch=challenges[m];ca=ch['gates']['audit'];co=ch['gates']['consistency']
        discussion.append(f"In the unseen-composition extension for {label}, the contrast audit accepts {ca['accepted']} cases, of which {ca['challenge_fail_among_accepted']} later fail the challenge; consistency accepts {co['accepted']}, of which {co['challenge_fail_among_accepted']} fail. The contrast audit also rejects {ca['challenge_pass_but_rejected']} cases that pass the challenge. These small related samples assess a coverage--transfer trade-off, not a distribution-free reliability guarantee.")
    if any(results[m]['all']['audit']['accepted']==0 for m in LABELS):discussion.append('At least one model has zero coverage under the prespecified contrast audit. For that model, the audit is not an empirically useful acceptance policy at this operating point, irrespective of the validity of the conditional identification theorem.')
    discussion.append('The source-factored baseline separates copying local quantities from multiplying and summing them. Any improvement it shows supports this engineering decomposition on the tested inputs; it does not establish a new general-purpose reasoning algorithm. Conversely, a model that solves the small controlled task limits the scope of claims about widespread fragmentation failures. The complete tables are retained in either case.')
    (ROOT/'observed_discussion.tex').write_text('\n\n'.join(discussion)+'\n')
    accepted=[results[m]['all']['audit']['accepted'] for m in LABELS]
    if all(n==0 for n in accepted):
        conclusion='The prespecified contrast gate has zero coverage for both tested models. It therefore does not establish a useful acceptance policy, despite the conditional identification result. The contribution supported by these experiments is a benchmark-design diagnosis and a reproducible assessment of its limits.'
    else:
        conclusion='The observed contrast-gate coverage is '+', '.join(f"{LABELS[m]}: {results[m]['all']['audit']['accepted']}/32" for m in LABELS)+'. Its empirical trade-off must be judged against the matched consistency gate and the unseen-composition failures, not the conditional theorem alone. The evidence supports a focused diagnostic study, without establishing general superiority as an acceptance policy.'
    (ROOT/'observed_conclusion.tex').write_text(conclusion+'\n')
    release_audit=load(EXP/'results/release_audit.json');profiles={}
    for run in release_audit['runs']:
        if run['split']!='evaluation':continue
        for p in run['runtime_configurations']:
            key=(run['model'],p['slots'],p['tokens_per_slot'],p['weight_repacking'],p['prompt_ram_cache_mib'])
            profiles[key]=profiles.get(key,0)+p['saved_records']
    rows=[[LABELS[m],n,s,c,'on' if rep else 'off',cache] for (m,s,c,rep,cache),n in sorted(profiles.items())]
    (ROOT/'runtime_table.tex').write_text(table(['Model','Records','Slots','Tokens/slot','Repack','RAM cache (MiB)'],rows,'All raw evaluation and execution-recheck records, including the retained initial mixed-profile observations. The main Qwen3 view uses only the final profile. This excludes eight development responses and interrupted unsaved attempts. HTTP payloads specify cache\\_prompt=false throughout; zero RAM cache also disables the server-level prompt snapshot cache.','tab:runtime','lrrrrr'))
    old=load(EXP/'results/qwen8/prompts_evaluation/analysis.json');new=results['qwen8'];rows=[]
    for label,data in [('Initial mixed profile',old),('Uniform profile',new)]:
        d=data['all'];rows.append([label,f"{d['base_correct']}/32",f"{d['ledger_correct']}/32",f"{d['risk_direct_correct']}/32",d['audit']['accepted'],d['audit']['wrong_accepts']])
    original=load_core_records('qwen8');uniform=load_core_records('qwen8',uniform=True)
    ids=load(EXP/'data/runtime_recheck_protocol.json')['selected_request_ids']
    changed=sum(original[k].get('raw_text')!=uniform[k].get('raw_text') or original[k]['status']!=uniform[k]['status'] for k in ids)
    runtime_text=f'The recheck includes every one of the 167 observations recorded outside the final Qwen3 profile. Returned text differs on {changed}/167 paired requests; this includes formatting changes and is not an error-rate estimate. The 409 original final-profile core responses are reused. The two views therefore are not independent experiments.\n\n'
    runtime_text+=table(['Execution view','Direct','Factored','Direct risk','Audit accepts','Wrong accepts'],rows,'Paired execution sensitivity for the same 32 cases. Both views are retained regardless of which has higher accuracy; the uniform view is used in the main results.','tab:runtime_sensitivity','lrrrrr')
    (ROOT/'runtime_comparison.tex').write_text(runtime_text)
    tables=load(EXP/'data/source_tables.json');rows=[]
    names=['Vanguard FTSE Developed World ex-U.K. Equity Index Fund','Vanguard FTSE U.K. All Share Index Unit Trust','Vanguard Emerging Markets Stock Index Fund']
    for t in tables:
        by={r['name']:r['reported_percent'] for r in t['holdings']};rows.append([str(t['fund'])+'\\%']+[f'{by[n]:.1f}\\%' for n in names])
    (ROOT/'source_table.tex').write_text(table(['LifeStrategy fund','World ex-UK','UK all-share','Emerging markets'],rows,'Three target underlying-fund weights, as displayed on page 2 of the five issuer factsheets dated 30 September 2026. Complete disclosed holdings tables and source hashes are in the data package.','tab:sources','lrrr'))
    # Fixed display selection rule: first case ID with a correct base and a failed challenge.
    candidates=sorted([r for r in challenges['smol']['rows'] if r['base_correct'] and not r['challenge_pass']],key=lambda r:r['case_id'])
    if candidates:
        example=candidates[0];cid=example['case_id']
        cases={c['case_id']:c for c in map(json.loads,(EXP/'data/cases.jsonl').read_text().splitlines())};case=cases[cid]
        gold={c['request_id']:c for c in map(json.loads,(EXP/'data/challenge_answers.jsonl').read_text().splitlines())}
        records={r['request_id']:r for r in map(json.loads,(EXP/'results/smol/prompts_evaluation/raw.jsonl').read_text().splitlines())}
        records.update({r['request_id']:r for r in map(json.loads,(EXP/'results/smol/challenge_prompts_evaluation/raw.jsonl').read_text().splitlines())})
        rows=[]
        for condition,label in [('base','Base'),('unseen_plus','Plus challenge'),('unseen_minus','Minus challenge')]:
            rid=cid+'__'+condition;out=json.loads(records[rid]['raw_text'])
            b=case['b'] if condition=='base' else gold[rid]['b_vector'];truth=sum(q*x for q,x in zip(case['q'],b))
            rows.append([label,'('+', '.join(f'{v:.4f}' for v in b)+')',f'{truth:.4f}',f"{out['a']:.4f}",f"{out['b']:.4f}"])
        lead='The following SmolLM3 example is selected by the first case identifier with a correct base answer and a failed challenge, rather than by maximum error. Case \\texttt{'+cid.replace('_','\\_')+'} has fixed account weights $q=('+', '.join(f'{v:g}' for v in case['q'])+')$. The table displays saved numerical answers to four decimal places; full returned text is retained in the release.\n\n'
        (ROOT/'recorded_example.tex').write_text(lead+table(['Input','Within-product A weights','True A','Reported A','Reported B'],rows,'A recorded correct base answer does not transfer to either new composition. The minus response also violates A/B conservation. These are actual model responses, distinct from the specified faulty rule in Figure~\\ref{fig:contrasts}.','tab:example','llrrr'))
    fig,axs=plt.subplots(1,2,figsize=(10,3.8),constrained_layout=True)
    keys=['base_correct','ledger_correct','risk_direct_correct','ledger_calculator_correct'];labs=['Direct\nexposure','Factored\nexposure','Direct\nrisk','Factored +\ncalculator']
    for ax,(m,label) in zip(axs,LABELS.items()):
        yy=[100*results[m]['all'][k]/32 for k in keys];bars=ax.bar(np.arange(4),yy,color=['#54759b','#287d77','#b98256','#75a790'],width=.65)
        ax.set_title(label);ax.set_ylim(0,115);ax.set_xticks(range(4),labs,fontsize=9);ax.set_ylabel('Correct answers (%)');ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
        for bar,v in zip(bars,yy):ax.text(bar.get_x()+bar.get_width()/2,v+2,f'{v:.1f}',ha='center',fontsize=9)
    (ROOT/'figures').mkdir(exist_ok=True);fig.savefig(ROOT/'figures/fresh_accuracy.pdf');fig.savefig(ROOT/'figures/fresh_accuracy.png',dpi=180);plt.close(fig)
    print('Generated result tables, abstract observations, discussion and figure from completed analyses.')

if __name__=='__main__':main()
