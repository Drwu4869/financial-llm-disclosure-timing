"""Fetch only SUBMISSION.tsv from public SEC ZIPs using verified HTTP ranges.

No model calls. Uses only Python standard library. Saves untouched table bytes,
source URLs, retrieval time, ZIP CRC32, SHA256 and HTTP response metadata.
"""
import datetime as dt
import hashlib
import json
import pathlib
import re
import struct
import time
import urllib.request
import zlib

ROOT = pathlib.Path(__file__).resolve().parent
PAGE = 'https://www.sec.gov/data-research/sec-markets-data/form-n-port-data-sets'
UA = 'Academic reproducibility study; public SEC data metadata audit'

def fetch(url, byte_range=None):
    headers = {'User-Agent': UA}
    if byte_range:
        headers['Range'] = 'bytes=' + byte_range
    for attempt in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=40) as r:
                h = dict(r.headers)
                if byte_range:
                    if r.status != 206:
                        raise RuntimeError('Server did not honor Range; refusing full ZIP download')
                    cr = r.headers.get('Content-Range', '')
                    match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', cr)
                    if not match:
                        raise RuntimeError('Invalid Content-Range: ' + cr)
                    start, end, total = map(int, match.groups())
                    expected = (max(0, total-int(byte_range[1:])), total-1) if byte_range.startswith('-') else tuple(map(int, byte_range.split('-')))
                    if (start, end) != expected:
                        raise RuntimeError(f'Range mismatch: {cr}; expected {expected}')
                    data = r.read(end-start+2)
                    if len(data) != end-start+1:
                        raise RuntimeError('Incomplete range response')
                else:
                    data = r.read()
            time.sleep(0.35)
            return data, h
        except Exception:
            if attempt == 2:
                raise
            time.sleep(1+attempt)

def entries(tail):
    ep = tail.rfind(b'PK\x05\x06')
    if ep < 0:
        raise RuntimeError('ZIP end not found')
    e = struct.unpack_from('<4s4H2IH', tail, ep)
    if e[1] or e[2] or e[5] == 0xffffffff:
        raise RuntimeError('Unsupported split/ZIP64 archive')
    pos = ep-e[5]
    out = []
    while tail[pos:pos+4] == b'PK\x01\x02':
        v = struct.unpack_from('<4s6H3I5H2I', tail, pos)
        n, x, c = v[10:13]
        out.append(dict(name=tail[pos+46:pos+46+n].decode('utf-8'), method=v[4], crc32=v[7], compressed_size=v[8], size=v[9], offset=v[16]))
        pos += 46+n+x+c
    if len(out) != e[4]:
        raise RuntimeError('Central directory incomplete')
    return sorted(out, key=lambda x: x['offset'])

def download(url, quarter, member='SUBMISSION.tsv'):
    tail, th = fetch(url, '-65558')
    listing = entries(tail)
    i = next(i for i, x in enumerate(listing) if x['name'].upper() == member.upper())
    item = listing[i]
    end = listing[i+1]['offset']-1
    block, bh = fetch(url, f"{item['offset']}-{end}")
    local = struct.unpack_from('<4s5H3I2H', block)
    if local[0] != b'PK\x03\x04':
        raise RuntimeError('Invalid local header')
    p = 30+local[-2]+local[-1]
    compressed = block[p:p+item['compressed_size']]
    raw = zlib.decompress(compressed, -15) if item['method'] == 8 else compressed if item['method'] == 0 else None
    if raw is None or len(raw) != item['size'] or zlib.crc32(raw) != item['crc32']:
        raise RuntimeError('ZIP integrity failure')
    dest = ROOT/'data'/quarter/member
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(raw)
    return dict(quarter=quarter, url=url, member=item, sha256=hashlib.sha256(raw).hexdigest(), retrieved_at=dt.datetime.now(dt.timezone.utc).isoformat(), tail_response=th, member_response=bh, path=str(dest.relative_to(ROOT)))

def main():
    data, headers = fetch(PAGE)
    (ROOT/'sources'/'sec_dataset_index.html').write_bytes(data)
    urls = sorted(set(re.findall(r'href=[\"\']([^\"\']+nport\.zip)', data.decode())), reverse=True)
    urls = [urllib.request.urljoin(PAGE, u) for u in urls]
    urls = [u for u in urls if re.search(r'(2019q4|202[0-5]q[1-4]|2026q[1-3])_nport.zip', u)]
    manifest_path = ROOT/'data'/'download_manifest.json'
    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else []
    done = {x['url'] for x in manifest if 'sha256' in x}
    print(f'Found {len(urls)} quarterly archives; {len(done)} previously downloaded', flush=True)
    for number, url in enumerate(urls, 1):
        quarter = re.search(r'(\d{4}q[1-4])_nport.zip', url).group(1)
        if url in done:
            continue
        try:
            item = download(url, quarter)
            manifest.append(item)
            manifest_path.write_text(json.dumps(manifest, indent=2))
            print(f'{number}/{len(urls)} {quarter}: verified {item["member"]["size"]:,} bytes', flush=True)
        except Exception as exc:
            print(f'{quarter}: FAILED {type(exc).__name__}: {exc}', flush=True)
    print('Completed:', len(manifest), 'quarters', flush=True)

if __name__ == '__main__':
    main()
