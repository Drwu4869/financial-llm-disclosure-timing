"""Reproduce the specified accession-level metadata analysis (stdlib only)."""
import calendar
import collections
import csv
import datetime as dt
import hashlib
import json
import pathlib
import statistics as st

ROOT = pathlib.Path(__file__).resolve().parent

def parse(value):
    return dt.datetime.strptime(value, '%d-%b-%Y').date()

def stats(rows, field='wait_days'):
    vals = [x[field] for x in rows]
    pos = [x for x in vals if x > 0]
    n = len(vals)
    if not n:
        return {'n': 0}
    return {'n': n, 'positive_count': len(pos), 'positive_percent': 100*len(pos)/n,
            'ge5_percent': 100*sum(x>=5 for x in vals)/n, 'ge10_percent': 100*sum(x>=10 for x in vals)/n,
            'mean_days_all': st.mean(vals), 'median_days_all': st.median(vals),
            'mean_days_positive': st.mean(pos) if pos else None, 'median_days_positive': st.median(pos) if pos else None,
            'min': min(vals), 'max': max(vals)}

def main():
    spec = ROOT/'plan'/'analysis_spec_2026-11-07.txt'
    seen = {}; conflict=set(); identical=0; raw=0; subtype=collections.Counter()
    for p in sorted((ROOT/'data').glob('*/SUBMISSION.tsv')):
        with p.open(encoding='utf-8-sig', newline='') as f:
            for row in csv.DictReader(f, delimiter='\t'):
                raw+=1; subtype[row.get('SUB_TYPE','')]+=1
                acc=row.get('ACCESSION_NUMBER','')
                if acc in seen:
                    old={k:v for k,v in seen[acc].items() if k!='archive_quarter'}
                    if old!=row: conflict.add(acc)
                    else: identical+=1
                else:
                    seen[acc]=dict(row, archive_quarter=p.parent.name)
    excluded=collections.Counter(); keep=[]
    for acc,row in seen.items():
        reason=None
        if not acc: reason='missing_accession'
        elif acc in conflict: reason='conflicting_accession'
        elif row.get('SUB_TYPE')!='NPORT-P': reason='not_original_NPORT-P'
        if reason: excluded[reason]+=1;continue
        try:
            f,r,y=map(parse,(row['FILING_DATE'],row['REPORT_DATE'],row['REPORT_ENDING_PERIOD']))
        except (ValueError,TypeError,KeyError):
            excluded['invalid_date']+=1;continue
        if r<dt.date(2019,9,30): excluded['report_before_first_public_period']+=1;continue
        if f<r: excluded['filing_before_report']+=1;continue
        if (y.month-r.month)%3: excluded['not_fiscal_quarter_end_month']+=1;continue
        monthend=r.replace(day=calendar.monthrange(r.year,r.month)[1])
        lag=(f-r).days
        keep.append(dict(accession=acc,archive_quarter=row['archive_quarter'],filing_date=f.isoformat(),
                         report_date=r.isoformat(),fiscal_year_end=y.isoformat(),lag_days=lag,
                         wait_days=max(0,60-lag),monthend_wait_days=max(0,(monthend+dt.timedelta(days=60)-f).days),
                         report_monthend_gap=(monthend-r).days))
    keep.sort(key=lambda x:(x['archive_quarter'],x['accession']))
    out=ROOT/'results';out.mkdir(exist_ok=True)
    byq=collections.defaultdict(list)
    for row in keep: byq[row['archive_quarter']].append(row)
    bins=collections.Counter()
    for row in keep:
        x=row['wait_days']; bins['0' if x==0 else '1-2' if x<=2 else '3-4' if x<=4 else '5-9' if x<=9 else '10-19' if x<=19 else '20-59' if x<60 else '60+']+=1
    summary=dict(created_at=dt.datetime.now(dt.timezone.utc).isoformat(),
                 specification_sha256=hashlib.sha256(spec.read_bytes()).hexdigest(),
                 archives=len(list((ROOT/'data').glob('*/SUBMISSION.tsv'))),raw_rows=raw,
                 raw_subtypes=dict(subtype),identical_duplicate_rows=identical,conflicting_accessions=len(conflict),
                 unique_accessions=len(seen),excluded=dict(excluded),main=stats(keep),
                 report_lag={'mean':st.mean(x['lag_days'] for x in keep),'median':st.median(x['lag_days'] for x in keep),
                             'after_60_count':sum(x['lag_days']>60 for x in keep),
                             'after_60_percent':100*sum(x['lag_days']>60 for x in keep)/len(keep)},
                 bins=dict(bins),monthend_sensitivity=stats(keep,'monthend_wait_days'),
                 non_calendar_monthend_reports=sum(x['report_monthend_gap']>0 for x in keep),
                 monthend_gap_gt4=sum(x['report_monthend_gap']>4 for x in keep),
                 lag_0_to_120_sensitivity=stats([x for x in keep if x['lag_days']<=120]),
                 pre2021=stats([x for x in keep if x['filing_date']<'2021-01-01']),
                 from2021=stats([x for x in keep if x['filing_date']>='2021-01-01']),
                 by_archive_quarter={q:stats(rows) for q,rows in sorted(byq.items())})
    assert len(keep)+sum(excluded.values())==len(seen)
    assert sum(bins.values())==len(keep)
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    with (out/'eligible_accessions.tsv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(keep[0]),delimiter='\t');w.writeheader();w.writerows(keep)
    with (out/'quarterly_summary.tsv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['archive_quarter']+list(stats(keep)),delimiter='\t');w.writeheader()
        for q,rows in sorted(byq.items()):w.writerow(dict(archive_quarter=q,**stats(rows)))
    print(json.dumps({k:v for k,v in summary.items() if k!='by_archive_quarter'},indent=2))

if __name__=='__main__':main()
