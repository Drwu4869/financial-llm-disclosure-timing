NO LOOK-AHEAD, YET TOO LATE
Unnecessary Disclosure Delays in LLM-Generated Backtest Code
Changyi Wu | Integrated manuscript | 8 November 2026

READING AND EDITING
main.tex is the manuscript entry point. The compiled paper has 8 pages,
including all references, 3 figures and 3 tables. All principal experimental
findings and qualifications appear in the paper, not only in this archive.
references.bib contains 11 verified primary-source references. main.bbl is
included as a compilation fallback. figures/ contains vector PDF figures.

Build with a normal TeX Live or MiKTeX installation:
  bash build.sh
Or upload this directory as a ZIP to Overleaf and select main.tex / pdfLaTeX.
The paper uses standard article formatting. A destination's required template,
anonymous-review setting and submission declarations must be applied once a
venue is selected. No publication acceptance or independent review is claimed.
Author name is included without inventing affiliation, contact details or funding.

EVIDENCE AND SCOPE
This paper integrates the original discovery pilot and the separately frozen
A04 follow-up. It does not overwrite earlier reports or pool their results as
one model error rate. No additional model responses were generated while writing
the manuscript. Post-hoc analyses are labelled in the text and saved records.
The synthetic model experiments are distinct from the real SEC metadata audit.
There is no real-holdings PnL result and no claimed new algorithm or theorem.

The source ZIP is sufficient to compile the paper and regenerate its figures:
  python3 make_figures.py
Requires matplotlib and numpy. The precomputed evidence files are included.

The COMPLETE reproducibility ZIP additionally contains two sibling directories:
  disclosure_code_pilot/  raw first answers, prompts, local freezes, fixtures,
                         saved program outputs, original reports and audits
  rule_history/          the 28 public SUBMISSION.tsv tables, download manifest,
                         original data specification and accession-level results
After extracting that full archive, run from submission_paper/:
  python3 verify_evidence.py
This independently rechecks manuscript counts and SEC metadata without running
model-generated programs. It writes evidence/manuscript_verification.json.

Deeper saved-output audits, without new model calls or candidate execution:
  cd ../disclosure_code_pilot
  python3 audit_saved_results.py
  python3 audit_recovery.py
  python3 audit_full_horizon_saved.py
  cd extensions/A04_form_swap
  python3 audit_saved.py
  python3 audit_capture.py
These original scripts may refresh their audit timestamps. Preserve a copy if
byte-for-byte comparison against the package's original hashes is required.

Do not execute or import generated candidate source directly on the host.
Rerunning candidate programs requires the isolated runtime described in the
original project's README and A01 amendment. Verification of saved outputs
does not reproduce the commercial model generations themselves.

The full archive preserves prior protocol and report versions as provenance;
main.tex is the current integrated manuscript. Historical text can differ from
later corrections, which are explicitly identified in the current paper.
Package hashes are supplied in MANIFEST_SHA256.json at archive root.
