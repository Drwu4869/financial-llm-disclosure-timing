"""Record a first model response without executing it or overwriting earlier data."""
import argparse
import datetime as dt
import hashlib
import json
import pathlib
import re

ROOT=pathlib.Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--trial',required=True)
    p.add_argument('--model',required=True)
    p.add_argument('--raw',type=pathlib.Path)
    p.add_argument('--outcome',choices=['returned','missing'],default='returned')
    p.add_argument('--failure-reason',default='')
    p.add_argument('--submitted-at',required=True,help='ISO timestamp with timezone')
    p.add_argument('--returned-at',required=True,help='ISO timestamp with timezone')
    p.add_argument('--observed-tools',action='store_true')
    p.add_argument('--settings',required=True,help='Actual model label and reasoning settings')
    a=p.parse_args()
    frozen=json.loads((ROOT/'FREEZE.json').read_text())
    for name,sha in frozen['files'].items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=sha:
            raise SystemExit('Frozen file changed: '+name)
    trials={t['id']:t for t in json.loads((ROOT/'prompt_index.json').read_text())}
    config=json.loads((ROOT/'study_config.json').read_text())
    if a.trial not in trials or a.model not in config['models']:
        raise SystemExit('Unknown trial/model; amend prospectively rather than silently substitute.')
    submitted=dt.datetime.fromisoformat(a.submitted_at)
    returned=dt.datetime.fromisoformat(a.returned_at)
    if submitted.tzinfo is None or returned.tzinfo is None or returned<submitted:
        raise SystemExit('Invalid timestamps')
    log=json.loads((ROOT/'run_log.json').read_text())
    if any(r['trial']==a.trial and r['model']==a.model for r in log):
        raise SystemExit('First response already recorded; do not overwrite it.')
    token=('GPT' if a.model.startswith('GPT') else 'GEM')+'_'+a.trial
    out=ROOT/'model_responses';out.mkdir(exist_ok=True)
    if a.outcome=='returned' and not a.raw: p.error('--raw required for a returned answer')
    if a.outcome=='missing' and not a.failure_reason: p.error('--failure-reason required for missing answer')
    raw=a.raw.read_text() if a.raw else a.failure_reason
    (out/(token+'.txt')).write_text(raw)
    blocks=re.findall(r'```(?:python|py)?\s*\n(.*?)```',raw,re.S) if a.outcome=='returned' else []
    extracted=len(blocks)==1
    if extracted:
        (out/(token+'.py')).write_text(blocks[0])
    log.append({'trial':a.trial,'model':a.model,'submitted_at':a.submitted_at,
                'observation_closed_at':a.returned_at,'outcome':a.outcome,
                'failure_reason':a.failure_reason if a.outcome=='missing' else None,'settings':a.settings,
                'observed_tools':a.observed_tools,'raw_response':f'model_responses/{token}.txt',
                'raw_sha256':hashlib.sha256(raw.encode()).hexdigest(),
                'code_extracted':extracted,'code_file':f'model_responses/{token}.py' if extracted else None,
                'extraction_rule':'Exactly one fenced code block; no semantic editing or repair.'})
    (ROOT/'run_log.json').write_text(json.dumps(log,indent=2)+'\n')
    status={'status':'responses_recorded_execution_separate','planned':54,'submitted':len(log),
            'returned':sum(r.get('outcome')=='returned' for r in log),
            'missing':sum(r.get('outcome')=='missing' for r in log),'pending':0,
            'note':'Records closed attempts. Do not run a request without recording its outcome.'}
    (ROOT/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
    print(json.dumps(log[-1],indent=2))

if __name__=='__main__':main()
