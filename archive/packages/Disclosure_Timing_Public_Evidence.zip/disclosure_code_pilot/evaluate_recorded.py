"""Execute recorded, unmodified first answers with the A01 isolated runtime."""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path

from engine import make_fixture, interventions, score
from sandbox_bwrap import run_candidate

ROOT = Path(__file__).resolve().parent

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--token')
    args = parser.parse_args()
    for name, digest in json.loads((ROOT/'FREEZE.json').read_text())['files'].items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest() != digest:
            raise SystemExit('Frozen file changed: '+name)
    for name, digest in json.loads((ROOT/'amendments/A01_runtime.json').read_text())['files'].items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest() != digest:
            raise SystemExit('Runtime amendment file changed: '+name)
    cfg = json.loads((ROOT/'study_config.json').read_text())
    records = json.loads((ROOT/'run_log.json').read_text())
    destination = ROOT/'results/model_evaluation'
    destination.mkdir(exist_ok=True)
    for record in records:
        token = ('GPT' if record['model'].startswith('GPT') else 'GEM')+'_'+record['trial']
        if args.token and token != args.token:
            continue
        path = destination/(token+'.json')
        if path.exists():
            continue
        result = {'trial':record['trial'], 'model':record['model'],
                  'scored_at':dt.datetime.now(dt.timezone.utc).isoformat(),
                  'raw_sha256':record['raw_sha256'], 'observed_tools':record['observed_tools'],
                  'execution_amendment':'A01_runtime.json', 'seeds':[]}
        if record['outcome'] != 'returned' or not record['code_extracted']:
            result['outcome'] = 'missing' if record['outcome'] != 'returned' else 'format_failure'
        else:
            source = (ROOT/record['code_file']).read_text()
            result['code_sha256'] = hashlib.sha256(source.encode()).hexdigest()
            result['outcome'] = 'evaluated'
            schema = record['trial'].split('_')[0]
            for seed in cfg['evaluation_seeds']:
                fixture = make_fixture(seed, schema)
                jobs = interventions(fixture)
                item = {'seed':seed}
                try:
                    outputs, metadata = run_candidate(source, [fixture['payload']]+[j['payload'] for j in jobs])
                    item['environment'] = metadata
                    # Preserve complete outputs, including failures, for independent audit.
                    output_name = token+'_'+str(seed)+'_outputs.json'
                    (destination/output_name).write_text(json.dumps(outputs,indent=2)+'\n')
                    item['outputs_file'] = output_name
                    item['score'] = score(fixture, outputs, jobs)
                except Exception as exc:
                    item['execution_or_scoring_error'] = type(exc).__name__+': '+str(exc)
                result['seeds'].append(item)
        result['has_numerical_witness'] = any(x.get('score',{}).get('numerical_leakage_witness') is True for x in result['seeds'])
        result['valid_seeds'] = sum('score' in x for x in result['seeds'])
        path.write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps({'token':token,'outcome':result['outcome'],'valid_seeds':result['valid_seeds'],
                          'has_numerical_witness':result['has_numerical_witness']}),flush=True)

if __name__ == '__main__':
    main()
