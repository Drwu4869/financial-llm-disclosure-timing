"""Verify D01 saved evidence, without requesting models or executing candidates."""
import datetime as dt
import gzip
import hashlib
import json
from pathlib import Path
from audit_full_horizon import ROOT, DEST, records, make_fixture, policy, jobs_for, compare, maxdiff, validate_output, TOL

def main():
    count=0
    def check(ok,label):
        nonlocal count
        if not ok:raise AssertionError(label)
        count+=1
    def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
    for name in ('FREEZE.json','amendments/A01_runtime.json'):
        for path,digest in json.loads((ROOT/name).read_text())['files'].items():
            check(sha(ROOT/path)==digest,'Immutable '+path)
    ledger=[]; outcomes={};vectors=0;matches=0;executions=0;refusals=0
    for rec in records():
        result=json.loads((DEST/(rec['token']+'.json')).read_text())
        check(result['source_sha256']==sha(ROOT/rec['source']),'Source '+rec['token'])
        lines=(ROOT/rec['source']).read_text().splitlines()
        if rec['category']=='sixty_day_floor':
            anchors=[{'line':i+1,'text':line.strip()} for i,line in enumerate(lines) if 'timedelta(days=60)' in line]
            check(bool(anchors),'Sixty-day source expression '+rec['token'])
        elif rec['category']=='interface_refusal':
            anchors=[{'line':i+1,'text':line.strip()} for i,line in enumerate(lines) if 'no subsequent execution session' in line or 'events[event_index][0] < decision' in line]
        else:
            anchors=[{'line':i+1,'text':line.strip()} for i,line in enumerate(lines) if ('filing_date' in line or 'filing' in line)][:6]
        ledger.append({k:v for k,v in rec.items() if k!='result'}|{'source_anchors':anchors})
        for s in result['seeds']:
            f=make_fixture(s['seed'],rec['schema']);p=f['payload']
            original=ROOT/s['baseline_outputs_file']; base=json.loads(original.read_text())[0]
            check(sha(original)==s['baseline_outputs_sha256'],'Baseline hash')
            check(sha(DEST/s['outputs_file'])==s['outputs_sha256'],'D01 outputs hash')
            with gzip.open(DEST/s['outputs_file'],'rt') as stream:outputs=json.load(stream)
            jobs=jobs_for(f)
            check(len(outputs)==len(jobs)+1==s['executions'],'Execution count')
            executions+=len(outputs)
            check(outputs[0]['status']==base['status'] and maxdiff(validate_output(outputs[0],p),validate_output(base,p))<=TOL,'Baseline replay')
            recomputed=compare(base,outputs[1:],f,jobs)
            check(recomputed==s['checks'],'Saved checks')
            for c in recomputed:outcomes[c['outcome']]=outcomes.get(c['outcome'],0)+1
            # Verify grouped interventions cover every daily cutoff at which
            # an unavailable row of the relevant type actually exists.
            for kind in ('remove_unavailable','future_original_values','future_revision_values'):
                expected=[]
                for day in p['dates']:
                    future=[r for r in p['filings'] if r['filing_date']>day]
                    if kind!='remove_unavailable':
                        ver=0 if kind=='future_original_values' else 1
                        future=[r for r in future if r.get('version',0)==ver]
                    if future:expected.append(day)
                actual=[d for j in jobs if j['kind']==kind for d in j['daily_cutoffs']]
                check(actual==expected,'Every-day cutoff coverage '+kind)
            if base['status']=='insufficient_data':
                refusals+=1
                check(rec['category']=='interface_refusal' and s['policy_match_all_days'] is None,'Refusal exclusion')
            else:
                expected=policy(p,rec['rule'],rec['boundary']);bw=validate_output(base,p)
                check(maxdiff(bw,expected)<=TOL and s['policy_match_all_days'] is True,'All-day policy match')
                vectors+=len(bw);matches+=1
    summary=json.loads((DEST/'SUMMARY.json').read_text())
    check(summary['outcome_counts']==outcomes,'Summary outcomes')
    check(summary['usable_daily_vectors']==vectors==83475,'Daily vector count')
    check(summary['all_day_policy_matches']==matches==175,'Policy cases')
    check(summary['isolated_executions']==executions==3600,'Execution count total')
    check(refusals==5,'Refusal cases')
    check(len(ledger)==36 and sum(x['category']=='sixty_day_floor' for x in ledger)==10,'Rule classification')
    (DEST/'rule_classification.json').write_text(json.dumps({'analysis':'D01 post-hoc source classification','programs':ledger},indent=2)+'\n')
    out={'verified_at':dt.datetime.now(dt.timezone.utc).isoformat(),'passed':count,'total':count,
         'scope':'Saved-evidence reconstruction, source and output hashes, daily cutoff coverage, all-day policy agreement; no model calls or candidate execution.',
         'daily_vectors':vectors,'program_seed_cases':matches,'refusal_cases_excluded':refusals,'outcome_counts':outcomes}
    (DEST/'AUDIT.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
