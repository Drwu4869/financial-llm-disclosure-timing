"""A04 paired form-name replication, separate from the original frozen pilot."""
import copy
import datetime as dt
import hashlib
import json
from pathlib import Path
import random
import sys

ROOT=Path(__file__).resolve().parent
PILOT=ROOT.parents[1]
sys.path.insert(0,str(PILOT))
from engine import make_fixture as original_fixture, normalize, validate_output, add_days

SEEDS=[101,202,303,404,505]
HOLIDAYS=set('''2021-12-31 2022-01-17 2022-02-21 2022-05-30 2022-06-20 2022-07-04
2022-09-05 2022-10-10 2022-11-11 2022-11-24 2022-12-26
2023-01-02 2023-01-16 2023-02-20 2023-05-29 2023-06-19 2023-07-04
2023-09-04 2023-10-09 2023-11-10 2023-11-23 2023-12-25'''.split())

def edgar_day(day):
    return dt.date.fromisoformat(day).weekday()<5 and day not in HOLIDAYS

def next_edgar(day,strict=False):
    if strict:day=add_days(day,1)
    while not edgar_day(day):day=add_days(day,1)
    return day

def assigned_filing_date(started_at):
    # ET local wall clock. All simulated submissions are accepted successfully.
    # The SEC rule concerns BEGINNING transmission, not simply acceptance time.
    day,time=started_at.split('T')
    assert edgar_day(day)
    return next_edgar(day,strict=time>'17:30:00')

def fixture(seed=101):
    f=original_fixture(seed,'dates');p=f['payload']
    periods=sorted({r['period_end'] for r in p['filings']})
    lags=[12,25,40,44,46,61];random.Random(seed+401).shuffle(lags)
    releases={};provenance=[]
    for i,(period,lag) in enumerate(zip(periods,lags)):
        day=next_edgar(add_days(period,lag))
        clock='18:10:00' if i%2 else '16:00:00'
        stamp=day+'T'+clock
        public=assigned_filing_date(stamp);releases[period]=public
        provenance.append({'period_end':period,'transmission_started_at_ET':stamp,
                           'assigned_filing_date':public,'public_by_end_of_date':public,
                           'assumptions':'Ordinary public portions; accepted live transmission; no confidentiality, outages or exceptional handling.'})
    for r in p['filings']:r['filing_date']=releases[r['period_end']]
    f['gold']['rows']=copy.deepcopy(p['filings'])
    # Resolve the old final-session interface trap without editing model code:
    # prices, unlike decision dates, include one later executable session.
    last=p['prices'][-1]
    p['prices'].append({'date':add_days(last['date'],1),'close':last['close'][:]})
    f['release_provenance']=provenance
    f['note']='Prices retained as nuisance input only; NO economic-return claims in A04.'
    return f

POLICIES=['filing_inclusive','filing_strict','floor45_inclusive','floor45_strict',
          'floor60_inclusive','floor60_strict','fixed45_inclusive','fixed60_inclusive','report_date']

def policy(p,name):
    rows=[]
    for r in p['filings']:
        use=r['filing_date']
        if name.startswith('floor'):
            n=45 if name.startswith('floor45') else 60
            use=max(use,add_days(r['period_end'],n))
        elif name.startswith('fixed'):
            n=45 if name.startswith('fixed45') else 60
            use=add_days(r['period_end'],n)
        elif name=='report_date':use=r['period_end']
        rows.append((r,use))
    out=[]
    for day in p['dates']:
        values=[]
        for a in p['assets']:
            eligible=[r for r,u in rows if r['asset']==a and (u<day or (not name.endswith('strict') and u==day))]
            row=max(eligible,key=lambda r:r['period_end']) if eligible else None
            values.append(row['weight_pct'] if row else 100/len(p['assets']))
        out.append(normalize(values))
    return out

def validate():
    checks=[]
    cases=[('2023-02-17T16:00:00','2023-02-17'),('2023-02-17T17:30:00','2023-02-17'),
           ('2023-02-17T18:10:00','2023-02-21'),('2022-06-17T18:10:00','2022-06-21'),
           ('2023-06-16T18:10:00','2023-06-20'),('2023-11-09T18:10:00','2023-11-13')]
    for stamp,expected in cases:
        assert assigned_filing_date(stamp)==expected
        checks.append({'case':stamp,'expected':expected,'actual':assigned_filing_date(stamp)})
    for seed in SEEDS:
        f=fixture(seed);p=f['payload'];known=policy(p,'filing_inclusive')
        for name in POLICIES:
            values=policy(p,name)
            validate_output({'status':'ok','reason':'Hand-written control','weights':values},p)
            if name in ('floor45_inclusive','floor60_inclusive'):
                assert values!=known,'Early filing fixtures must distinguish embargo from publication.'
        assert p['prices'][-1]['date']>p['dates'][-1]
        assert sum(r['transmission_started_at_ET'].split('T')[1]>'17:30:00' for r in f['release_provenance'])==3
    return {'passed':True,'calendar_cases':checks,'seeds':SEEDS,'policies_validated':POLICIES,
            'scope':'Hand-written calendar/fixture validation, not model evidence.'}

def freeze():
    if (ROOT/'FREEZE.json').exists():raise SystemExit('A04 already frozen')
    for folder in ['prompts','fixtures','responses','results','capture_metadata']:(ROOT/folder).mkdir(exist_ok=True)
    prompts=[]
    for form in ['NPORT','F13']:
        for cond in ['P0','P1','P2']:
            # Use the original frozen dated prompt. The 13F edit is a documented
            # vocabulary substitution; no hints about 45, 60 or rule changes.
            original=(PILOT/'prompts'/('dates_'+cond+'_r1.txt')).read_text()
            if form=='F13':
                original=original.replace("the fund's holdings as-of date","the manager's holdings as-of date")
                original=original.replace('ordinary public portions of third-fiscal-month Form N-PORT reports','ordinary public portions of quarterly Form 13F reports')
                original=original.replace('This is one fund and one fixed security universe.','This is one institutional investment manager and one fixed security universe.')
            # The illustrative rows are replaced identically in both forms by
            # a shared A04 fixture, so only the vocabulary differs within pairs.
            sample=sorted(fixture(11)['payload']['filings'],key=lambda x:x['row_id'])
            sample=sample[:3]+sample[-2:]
            prompt=original.split('Example filing rows:')[0]+'Example filing rows:\n'+json.dumps(sample,indent=2)+'\n'
            for rep in range(1,4):
                token=f'{form}_{cond}_r{rep}'
                path=ROOT/'prompts'/(token+'.txt');path.write_text(prompt)
                prompts.append({'trial_id':token,'form':form,'condition':cond,'repeat':rep,
                                'file':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    order={}
    for model,seed in [('GPT',4401),('CLAUDE',4402)]:
        seq=[p['trial_id'] for p in prompts];random.Random(seed).shuffle(seq);order[model]=seq
    config={'id':'A04','planned_generations':36,'models':['GPT','CLAUDE'],
            'design':'2 forms x 3 prompts x 3 fresh first answers x 2 vendors; dated single-version schema only',
            'GPT_settings':'ChatGPT UI High (3/5); temporary unpersonalized chat; no requested tools; record actual product label',
            'CLAUDE_settings':'Strongest available subscribed reasoning model; record visible name and reasoning setting before first submission; fresh incognito or memory-off session. Do not purchase an upgrade.',
            'seeds':SEEDS,'primary':'Per first-answer source and executable evidence of a report-period +45-day floor for 13F, compared with +60-day floor for N-PORT. Also report floor with and without actual filing bound, strict-day guards, exact alignment, refusals and technical missingness.',
            'tolerance':1e-8,'historical_pilot_separate':True,
            'timing_truth':'filing_date is SEC-assigned filing date. Private release provenance maps successful transmissions after 17:30 ET to next EDGAR business day, including federal holidays. Do not shift an already assigned filing date again.',
            'boundary_scope':'The model receives assigned filing dates, not raw transmission timestamps. This tests unnecessary lag insertion, NOT whether it can infer 17:30 conversion from timestamps.',
            'sample_change':'Common lags [12,25,40,44,46,61], shuffled by seed; same rows/prices for both forms. Three after-hours submissions per seed. Nuisance prices are retained; no PnL reported. One extra price session prevents the known final-day interface trap.',
            'source_rule':'All ordinary public portions, no confidential treatment or outages. Decisions at end of date, execute next synthetic session.',
            'interpretation':['13F +45 and N-PORT +60, repeated in >=2/3 answers in a P0 or P1 cell: evidence consistent with cross-form deadline/publication conflation, not proof of a universal habit.',
                              'N-PORT +60 without 13F +45: form-specific observed error; old-rule memory remains a hypothesis, not established cause.',
                              'Claude matches: vendor contrast; Claude repeats floor: cross-vendor replication at tested setting only.',
                              'P2 supplies the rule and is an intervention; do not mix it with spontaneous rule knowledge.'],
            'stopping':'Complete this fixed mechanistic replication only. No adaptive harder cases or further model expansion. Existing primary stopping decision unchanged.',
            'failure_policy':'No returned answer regeneration or repair. One attempt per slot; two consecutive transport failures pause vendor. Auth/CAPTCHA-blocked unsent slots remain unattempted, not model failures.',
            'capture':'Save complete raw response and exact source; keep UI labels, timestamps, prompt hash and observed tools. Source execution only via original A01 isolated runner.',
            'concurrency':'At most 3 independent in-flight conversations per vendor, frozen relative submission order.'}
    sources={'checked_on':'2026-11-08','sources':[
        {'url':'https://www.sec.gov/rules-regulations/staff-guidance/frequently-asked-questions-about-form-13f','support':'45-day quarterly submission deadline; ordinary public submissions distinct from confidential treatment.'},
        {'url':'https://www.sec.gov/submit-filings/filer-support-resources/how-do-i-guides/determine-status-my-filing','support':'Start of transmission after 17:30; most forms assigned and disseminated next EDGAR business day; 13F not an exception.'},
        {'url':'https://www.sec.gov/files/rules/interim/2019/ic-33384.pdf','support':'N-PORT ordinary public third-month portions public upon filing; 60 days is submission deadline.'},
        {'url':'https://www.opm.gov/policy-data-oversight/pay-leave/federal-holidays/','support':'2022/2023 observed federal holidays; EDGAR business calendar is not NYSE trading calendar.'}]}
    (ROOT/'config.json').write_text(json.dumps(config,indent=2)+'\n')
    (ROOT/'source_audit.json').write_text(json.dumps(sources,indent=2)+'\n')
    (ROOT/'prompt_index.json').write_text(json.dumps(prompts,indent=2)+'\n')
    (ROOT/'run_order.json').write_text(json.dumps(order,indent=2)+'\n')
    (ROOT/'attempts.json').write_text('[]\n')
    for seed in SEEDS:(ROOT/'fixtures'/f'{seed}.json').write_text(json.dumps(fixture(seed),indent=2)+'\n')
    (ROOT/'validation.json').write_text(json.dumps(validate(),indent=2)+'\n')
    names=['study.py','config.json','source_audit.json','prompt_index.json','run_order.json','validation.json']+[p['file'] for p in prompts]+[f'fixtures/{s}.json' for s in SEEDS]
    data={'frozen_at':dt.datetime.now(dt.timezone.utc).isoformat(),'new_model_answers_at_freeze':0,
          'relation':'Prospective follow-up after observing the original pilot. Not a revision of its preregistration.',
          'files':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in names}}
    (ROOT/'FREEZE.json').write_text(json.dumps(data,indent=2)+'\n')
    (ROOT/'PROMPTS.txt').write_text('\n\n'.join('===== '+p['trial_id']+' =====\n'+(ROOT/p['file']).read_text() for p in prompts))
    print(json.dumps({'freeze':data['frozen_at'],'planned':36,'order':order},indent=2))

if __name__=='__main__':freeze()
