"""Execute A04 first answers without repair, using the original isolated runtime."""
import datetime as dt
import gzip
import hashlib
import json
from pathlib import Path
import re
import sys
from study import ROOT, PILOT, SEEDS, POLICIES, policy, validate_output
from sandbox_bwrap import run_candidate
from audit_full_horizon import jobs_for, compare, maxdiff

EXCHANGE=Path('/workspace/shared/disclosure_A04')

def sha(data):return hashlib.sha256(data).hexdigest()

def main():
    for base,manifest in [(ROOT,'FREEZE.json'),(PILOT,'FREEZE.json'),(PILOT,'amendments/A01_runtime.json')]:
        for name,digest in json.loads((base/manifest).read_text())['files'].items():
            assert sha((base/name).read_bytes())==digest,name
    attempts=json.loads((EXCHANGE/'attempts.json').read_text())
    (ROOT/'attempts.json').write_text(json.dumps(attempts,indent=2)+'\n')
    order=json.loads((ROOT/'run_order.json').read_text())
    for vendor in order:
        actual=[a['trial_id'] for a in attempts if a['vendor']==vendor]
        assert actual==order[vendor][:len(actual)],('First send-action order changed',vendor)
    index={p['trial_id']:p for p in json.loads((ROOT/'prompt_index.json').read_text())}
    for a in attempts:
        if a['status']!='returned':continue
        token=a['vendor']+'_'+a['trial_id'];target=ROOT/'results'/(token+'.json')
        if target.exists():continue
        raw=(EXCHANGE/'raw'/(token+'.txt')).read_text()
        (ROOT/'responses'/(token+'.txt')).write_text(raw)
        for source in (EXCHANGE/'raw').glob(token+'.*'):
            if source.suffix!='.txt' or source.name!=token+'.txt':
                (ROOT/'capture_metadata'/source.name).write_bytes(source.read_bytes())
        blocks=re.findall(r'```(?:python|py)?\s*\n(.*?)```',raw,re.S)
        result={'token':token,**a,'prompt_sha256':index[a['trial_id']]['sha256'],
                'raw_sha256':sha(raw.encode()),'evaluated_at':dt.datetime.now(dt.timezone.utc).isoformat(),
                'seeds':[],'code_blocks':len(blocks),'outcome':'format_failure'}
        if len(blocks)==1:
            source=blocks[0];(ROOT/'responses'/(token+'.py')).write_text(source)
            result.update(source_sha256=sha(source.encode()),outcome='evaluated',
                          rule_evidence=[{'line':i+1,'text':line.strip()} for i,line in enumerate(source.splitlines()) if re.search(r'\b(45|60)\b|filing_date\s*[<>]|[<>]=?\s*filing_date',line)])
            for seed in SEEDS:
                f=json.loads((ROOT/'fixtures'/f'{seed}.json').read_text());p=f['payload'];jobs=jobs_for(f)
                item={'seed':seed}
                try:
                    outputs,environment=run_candidate(source,[p,p]+[j['payload'] for j in jobs])
                    name=f'{token}_{seed}_outputs.json.gz'
                    with gzip.open(ROOT/'results'/name,'wt') as out:json.dump(outputs,out,separators=(',',':'))
                    item.update(outputs_file=name,outputs_sha256=sha((ROOT/'results'/name).read_bytes()),environment=environment,
                                status=outputs[0].get('status'),reason=outputs[0].get('reason'))
                    bw=validate_output(outputs[0],p);rw=validate_output(outputs[1],p)
                    item['repeat_stable']=outputs[0]['status']==outputs[1]['status'] and maxdiff(bw,rw)<=1e-8
                    item['checks']=compare(outputs[0],outputs[2:],f,jobs)
                    item['witnesses']=[c for c in item['checks'] if c['outcome']=='witness']
                    if item['status']=='insufficient_data':
                        item['classification']='refusal';item['matching_policies']=[]
                    else:
                        item['classification']='portfolio'
                        item['matching_policies']=[name for name in POLICIES if maxdiff(bw,policy(p,name))<=1e-8]
                        item['oracle_max_error']=maxdiff(bw,policy(p,'filing_inclusive'))
                        item['oracle_mismatch_days']=sum(maxdiff([a],[b])>1e-8 for a,b in zip(bw,policy(p,'filing_inclusive')))
                except Exception as exc:
                    item['execution_or_validation_error']=type(exc).__name__+': '+str(exc)
                result['seeds'].append(item)
            result['matching_policy_all_seeds']=[name for name in POLICIES if all(name in s.get('matching_policies',[]) for s in result['seeds'])]
            result['valid_portfolio_seeds']=sum(s.get('classification')=='portfolio' for s in result['seeds'])
            result['refusal_seeds']=sum(s.get('classification')=='refusal' for s in result['seeds'])
            result['has_witness']=any(s.get('witnesses') for s in result['seeds'])
        target.write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps({'token':token,'policies':result.get('matching_policy_all_seeds'),
                          'valid':result.get('valid_portfolio_seeds'),'witness':result.get('has_witness')}),flush=True)
    all_results=[json.loads(p.read_text()) for p in (ROOT/'results').glob('*.json') if p.stem.startswith(('GPT_','CLAUDE_'))]
    cells=[]
    for vendor in ['GPT','CLAUDE']:
        for form in ['NPORT','F13']:
            for condition in ['P0','P1','P2']:
                rs=[r for r in all_results if r['token'].startswith(vendor+'_'+form+'_'+condition+'_')]
                cells.append({'vendor':vendor,'form':form,'condition':condition,'planned':3,'evaluated':len(rs),
                              'all_seed_policy_counts':{name:sum(name in r.get('matching_policy_all_seeds',[]) for r in rs) for name in POLICIES},
                              'refusals':sum(r.get('refusal_seeds')==5 for r in rs),
                              'invalid_or_incomplete':sum(r.get('valid_portfolio_seeds',0)+r.get('refusal_seeds',0)!=5 for r in rs),
                              'witness_programs':sum(bool(r.get('has_witness')) for r in rs)})
    summary={'updated_at':dt.datetime.now(dt.timezone.utc).isoformat(),'planned':36,
             'send_action_attempts':len(attempts),'returned':sum(a['status']=='returned' for a in attempts),
             'pending':sum(a['status']=='pending' for a in attempts),'evaluated':len(all_results),
             'unattempted':36-len(attempts),'cells':cells,
             'scope':'A04 only; not pooled into original pilot. Execution seeds are not model generations.'}
    (ROOT/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
    status_path=ROOT/'VENDOR_STATUS.json'
    status=json.loads(status_path.read_text()) if status_path.exists() else {}
    status['updated_at']=summary['updated_at']
    for vendor in ['GPT','CLAUDE']:
        va=[a for a in attempts if a['vendor']==vendor]
        state=status.setdefault(vendor,{})
        state.update(planned=18,prompts_sent=len(va),model_answers=sum(a['status']=='returned' for a in va),
                     evaluated_answers=sum(r['vendor']==vendor for r in all_results),
                     pending=sum(a['status']=='pending' for a in va),unattempted=18-len(va))
        if va:
            state['status']='completed' if state['model_answers']==18 else 'collecting'
            state['next_requirement']='None; fixed collection complete.' if state['status']=='completed' else 'Complete remaining frozen slots without answer repair or regeneration.'
    status_path.write_text(json.dumps(status,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='cells'},indent=2),flush=True)

if __name__=='__main__':main()
