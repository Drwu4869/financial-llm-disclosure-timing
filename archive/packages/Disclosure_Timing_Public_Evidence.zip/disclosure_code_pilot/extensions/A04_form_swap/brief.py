"""Generate a Chinese plain-language readout from saved A04 results only."""
import json
from study import ROOT

def main():
    s = json.loads((ROOT / 'SUMMARY.json').read_text())
    rs = [json.loads(p.read_text()) for p in sorted((ROOT / 'results').glob('*.json'))
          if p.name.startswith(('GPT_', 'CLAUDE_'))]
    lines = ['A04 复验简读：N-PORT 的 60 天限制会迁移到 13F 吗？',
             '更新时间：' + s['updated_at'],
             f"进度：{s['evaluated']}/36 份新首答已计分；未完成部分不计成功或失败。", '',
             '模型 | N-PORT 默认/一般提醒时加 60 天 | 13F 默认/一般提醒时加 45 天 | 明确日期规则后准确对齐']
    for vendor in ['GPT', 'CLAUDE']:
        fields = []
        for form, days in [('NPORT', 60), ('F13', 45)]:
            group = [r for r in rs if r['token'].startswith(vendor + '_' + form + '_') and '_P2_' not in r['token']]
            n = sum(any(p.startswith('floor' + str(days) + '_') for p in r.get('matching_policy_all_seeds', [])) for r in group)
            fields.append(f'{n}/{len(group)}（计划 6）')
        group = [r for r in rs if r['token'].startswith(vendor + '_') and '_P2_' in r['token']]
        n = sum('filing_inclusive' in r.get('matching_policy_all_seeds', []) for r in group)
        fields.append(f'{n}/{len(group)}（计划 6）')
        lines.append(vendor + ' | ' + ' | '.join(fields))
    if s['evaluated']==36:
        lines += ['', '本轮结论：两家被测产品都出现 N-PORT 额外等待，13F 没有出现对应的 45 天门槛；不支持把本样本直接概括成通用的“截止日等于公开日”习惯。',
                  '贡献定位：即使输入已经给出实际申报日期，生成代码仍可能添加不存在的公开等待期。这轮证明了可复现的过度保守延迟；真实经济损失还没有测量。',
                  '明确给出日期合同后，两家各 6/6 精确对齐。但这不能证明模型无提示时稳定选择正确规则，也不能证明错误来自 2016 年旧规则记忆。']
    lines += ['',
              '这里的“加 60 天/45 天”是等到实际申报日和报告期末后第 60/45 天中较晚的一个；不是在申报日上再加 60/45 天。',
              'P0：只交代任务。P1：加一句避免前视偏差。P2：明确用申报日期，并说明日终决策规则。',
              '仅等到申报日之后的下一个决策日，单独标为 filing_strict，不混作 45/60 天错误，也不算精确对齐。', '',
              '如何解释',
              '若 N-PORT 反复出现 60 天限制、13F 不出现 45 天限制，支持本样本中的表单特异性；不能据此证明所有截止日都被当成公开日。',
              '另一个厂商复现同样限制，说明现象不限于一家；不等于所有模型都会这样。',
              '旧版规则记忆是可能解释，不是实验已经证明的机制。新实验也没有直接测模型转换 17:30 原始时间戳的能力。',
              'P2 是提供正确规则的干预；它的成功不能当作模型无提示时就知道规则。', '',
              '验证与边界',
              '每份代码使用 5 组固定合成数据、6 个报告期、477 个决策日期逐日比较。5 个种子是同一程序的测试，不是 5 次模型回答。',
              '所有首答保留，包括拒答和代码失败；不修复源代码、不重新生成回答。',
              '合成早报/晚报案例用于区分规则，不代表真实市场频率；本轮不能得出实际收益损失、Sharpe 或经济影响结论。',
              '两家网页产品的推理预算没有按计算量匹配；GPT High 3/5，Claude Opus 5.5 Extra。',
              '这一固定补充实验单独报告，不和原试点混合计数，也不改变原先停止大规模扩展的决定。']
    audit_path = ROOT / 'SAVED_AUDIT.json'
    if audit_path.exists():
        audit = json.loads(audit_path.read_text())
        lines += ['', '已保存输出的独立复核：' + audit['audited_at'],
                  f"完整性与逐日复核：{audit['verified_program_seed_cases']} 个程序-种子组合，{audit['baseline_daily_vectors']} 个基线每日权重向量。",
                  '干预结果：' + json.dumps(audit['intervention_outcomes'], ensure_ascii=False),
                  'no_witness 表示这项检查未观察到提前依赖；inconclusive_intervention_refusal 表示程序拒绝输出、该项无法判定。它们不能合并为全部通过。']
    ep=ROOT/'EXPLORATORY_CALENDAR.json'
    if ep.exists():
        ex=json.loads(ep.read_text())
        lines += ['', '事后解释：预先登记的策略之外的日历变体（不并入上表主评分）']
        for r in ex['programs']:
            if r['new_explanation_only']:
                lines.append(r['token']+'：'+', '.join(m['label'] for m in r['exploratory_calendar_matches'])+'；5 组数据全部日期匹配。')
        lines.append('该分析是看到 CLAUDE_NPORT_P1_r1 加入 EDGAR 工作日顺延后才增加的，使用保存的输出复核，没有修改原代码或预登记结果。')
    (ROOT / '简读_当前结果.txt').write_text('\n'.join(lines) + '\n')
    print('Updated Chinese brief from saved results.')

if __name__ == '__main__':
    main()
