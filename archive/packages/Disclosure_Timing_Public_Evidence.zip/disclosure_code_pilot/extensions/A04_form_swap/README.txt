A04 — Paired N-PORT / Form 13F replication — 8 November 2026

Purpose
Test whether the observed N-PORT period-end-plus-60 floor generalizes to a
13F period-end-plus-45 floor, and whether a new vendor reproduces the pattern.
This is an explicitly authorized, fixed mechanistic follow-up, not reopening
the original broad-expansion criterion or rewriting its negative result.

Design
36 fresh first answers: two form descriptions, three prompts (P0 task-only,
P1 generic anti-look-ahead warning, P2 explicit filing-date contract), three
repeats, ChatGPT High and one available Claude reasoning model. Only the dated
single-version schema is used. All first answers and failures are retained.
Old pilot answers are contextual evidence, not pooled into this sample.

Pairing
Both forms use the same synthetic payloads and illustrative rows. Within each
prompt condition, the only form differences are N-PORT versus 13F, fiscal-month
versus quarterly description, and fund versus institutional manager. Record
exact UI product/model and reasoning settings; these are not API snapshots.

17:30 boundary
The supplied filing_date is the SEC-assigned filing date, not the transmission
calendar date. Private provenance retains transmission_started_at_ET. Accepted
ordinary submissions starting after 17:30 ET map to the next EDGAR business
day, respecting US federal holidays. No exact intraday availability is claimed.
The model is NOT asked to reconstruct filing_date from raw timestamps, and this
experiment must NOT be described as testing its knowledge of the 17:30 rule.
Already adjusted filing_date must not be shifted a second time.

The boundary unit cases include Friday 17 February 2023 after 17:30 mapping to
Tuesday 21 February (weekend plus Washington's Birthday), and both 2022/2023
Juneteenth weekends. At exactly 17:30, the same filing day applies in the fixture.
Synthetic decision sessions are distinct from the EDGAR business calendar.

Inputs and interpretation
Five seeds, six quarterly periods, eight assets, 477 decision days. Three
transmissions per seed occur after 17:30. Early and late release stress lags
are common to both forms, not an empirical frequency distribution. A final
extra price session prevents the old last-day execution-interface trap. Prices
are nuisance inputs; no market-return or economic-materiality claims are made.

A +45-day rule in 13F together with +60 in N-PORT is evidence consistent with
cross-form deadline/publication conflation. It does not prove a universal habit.
If only N-PORT has the floor, the finding is form-specific in this sample;
remembering the 2016 rule remains one possible explanation, not a proven cause.
P2 is rule-provided assistance, not spontaneous knowledge. Small repeated cells
must not be presented as population failure rates.

Execution
study.py generated and locally froze prompts, fixtures, policies, order, calendar
validation and interpretation before any A04 answer existed. evaluate.py is an
operational capture/execution adapter written after submissions started, before
answers were inspected. It does not change the frozen policies or thresholds.
Candidate code runs only through the original A01 isolated runner. It is never
imported or executed directly in the host environment. Final code remains raw.

python evaluate.py
imports returned UI captures from /workspace/shared/disclosure_A04 and scores
unseen first answers. It skips already-scored programs. SUMMARY.json is live.

Collection caveats
A transport click can leave an unsent draft. Retargeting Send is allowed only
after verifying that no user turn or generation exists; retain its timestamps.
For GPT, first send actions followed the frozen order, but draft-only clicks required
later retargeting. This is a transport-induced deviation from the planned
relative delivery order: some later slots began generation before an earlier
unsent draft was delivered. Exact backend delivery timestamps are unavailable.
The original timestamps, recovery timestamps and slot identities are retained;
there is no answer-dependent reordering, regeneration or relabelling.
Claude's selected Google sign-in initially encountered a CAPTCHA and then a
browser-verification error. No experiment prompts were sent during the block.
The user later completed the login handoff; a signed-in Pro composer was verified.
Before the first Claude prompt, CLAUDE_SETTINGS.json recorded Opus 5.5, Extra
effort, fresh Incognito sessions. Extra was retained; Max was visible but not
selected. Fable required additional credits and was not purchased. No alternate
vendor was substituted. Effort budgets are not computationally matched across
the two vendor UIs; comparisons are limited to the recorded settings.

audit_saved.py recomputes classifications and intervention checks from preserved
sandbox outputs, verifies frozen/source/output hashes, and checks nine handwritten
policies per seed. The deliberate fixed-lag-without-filing-bound and report-date
controls trigger future-filing witnesses; filing-bound policies do not. These
are evaluator quality checks added during collection, not new model evidence.

Reading the outputs
Start with 简读_当前结果.txt or A04_addendum.pdf (two-page English LaTeX
addendum). RESULTS.txt contains the detailed per-program evidence and hashes.
The original nine-page paper is retained separately and is not overwritten.
A04_policy_counts.pdf/png plots frozen policy classifications, not a revised
or pooled success rate. All three repetitions per cell are shown.

Post-hoc calendar explanation
After CLAUDE_NPORT_P1_r1 returned, its source revealed a 60-day floor rolled to
an EDGAR business day. exploratory_calendar.py compares four handwritten
45/60-day calendar variants with saved weights; it does not execute candidate
code, edit frozen classifications or add model trials. EXPLORATORY_CALENDAR.json
retains the introduction time and identifies matches beyond the frozen family.
Those matches are separately labelled post-hoc, never silently included in the
confirmatory policy counts. audit_capture.py additionally compares Claude's
code-block Copy with its independent whole-message Copy.

Rebuild reports from saved data (no model calls)
python audit_saved.py
python audit_capture.py
python exploratory_calendar.py
python readout.py
python brief.py
python plot_results.py
python make_addendum.py
pdflatex A04_addendum.tex
The last two commands require matplotlib and a working LaTeX distribution.
The supplied PDF is already compiled. No web session is needed to verify
saved program outputs; rerunning generated programs still requires the original
isolated runtime, not direct execution on the host.
