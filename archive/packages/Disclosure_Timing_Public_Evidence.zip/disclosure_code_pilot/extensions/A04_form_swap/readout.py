"""Human-readable, denominator-explicit A04 results; never pools older answers."""
import json
from study import ROOT

def main():
    summary=json.loads((ROOT/'SUMMARY.json').read_text())
    results=[json.loads(p.read_text()) for p in sorted((ROOT/'results').glob('*.json')) if p.name.startswith(('GPT_','CLAUDE_'))]
    lines=['A04: Does a filing-deadline floor transfer from N-PORT to Form 13F?',
           ('Completed experimental readout — ' if summary['evaluated']==36 else 'Interim experimental readout — ')+summary['updated_at'],
           '',f"Fresh first answers evaluated: {summary['evaluated']}/36. Missing slots, if any, are not model successes or failures.",
           'Original pilot evidence is separate. This fixed follow-up was frozen after that pilot, before its own first answer.',
           '', 'Descriptive roll-up (P0 and P1 only; P2 reported separately)']
    for vendor in ['GPT','CLAUDE']:
        for form,days in [('NPORT',60),('F13',45)]:
            rr=[r for r in results if r['token'].startswith(vendor+'_'+form+'_') and '_P2_' not in r['token']]
            floor=sum(any(p.startswith('floor'+str(days)+'_') for p in r.get('matching_policy_all_seeds',[])) for r in rr)
            lines.append(f'{vendor} {form}: period-end + {days}-day floor in {floor}/{len(rr)} returned P0/P1 first answers (6 planned).')
        rr=[r for r in results if r['token'].startswith(vendor+'_') and '_P2_' in r['token']]
        lines.append(f"{vendor} P2 exact filing-day alignment: {sum('filing_inclusive' in r.get('matching_policy_all_seeds',[]) for r in rr)}/{len(rr)} returned answers (6 planned).")
    lines += [
           '', 'Condition-level evidence',
           'Vendor | Form | Prompt | Evaluated/planned | +45 floor | +60 floor | Filing day | Later-than-filing day | Other valid | Refusals | Invalid/incomplete']
    for c in summary['cells']:
        p=c['all_seed_policy_counts']
        other=c['evaluated']-sum(p.values())-c['refusals']-c['invalid_or_incomplete']
        lines.append(f"{c['vendor']} | {c['form']} | {c['condition']} | {c['evaluated']}/3 | {p['floor45_inclusive']+p['floor45_strict']} | {p['floor60_inclusive']+p['floor60_strict']} | {p['filing_inclusive']} | {p['filing_strict']} | {other} | {c['refusals']} | {c['invalid_or_incomplete']}")
    lines += ['', 'P0: task only. P1: generic warning to avoid look-ahead. P2: explicit filing-date and end-of-day contract.',
              'A floor waits until the later of actual filing date and period_end + N calendar days. This differs from blindly assigning period_end + N and from delaying only one decision day.',
              'Classifications require matching outputs on all dates in all five fixtures; rows and execution seeds are not independent model samples.',
              '', 'What this design can establish',
              'Repeated +45 behavior for 13F alongside +60 for N-PORT would support a cross-form deadline/publication-confusion pattern in these tested settings.',
              'N-PORT-only +60 behavior would establish form-specificity in this sample. It cannot by itself establish retrieval of the 2016 rule, a training-data cause, or a universal model habit.',
              'P2 tests compliance with supplied instructions; it is not an unaided rule-knowledge test.',
              '', 'Timing and scope',
              'Both form descriptions receive otherwise identical prompts, illustrative records and synthetic fixtures for the 2022–2023 regime.',
              'The supplied filing_date is already the SEC-assigned date. The reference maps ordinary after-17:30 ET transmission starts to the next EDGAR business day, including federal holidays. No double shift is added.',
              'Models are not given raw transmission times, so this experiment does not test whether they know the 17:30 conversion.',
              'Five seeds, six reporting periods and 477 daily decisions per seed; future-filing deletion/value interventions cover the full horizon. This is not a proof over all possible inputs or a new full-horizon future-price audit.',
              'Synthetic early/late submissions are diagnostic stress cases. No empirical frequency, realized Sharpe or financial-materiality estimate is inferred.',
              'Model code is executed only in the existing isolated runtime. No answer repair, answer regeneration or source edits are used.',
              'GPT transport deviation: first Send actions followed the frozen order, but some clicks left unsent drafts. Verified draft-only recoveries changed actual delivery order. Timestamps and identities are retained; exact backend delivery times are unavailable.',
              'The observed UI label is ChatGPT High (3/5), Temporary, Unpersonalized; an exact backend model snapshot is not exposed.',
              'Claude login was completed by the user after the original CAPTCHA/browser-verification block. Recorded before its first answer: Opus 5.5, Extra effort, Incognito. Extra was retained; Max effort was visible but not selected. Fable required additional usage credits and was not purchased.',
              'Cross-vendor comparisons apply to these observed UI settings; effort budgets are not API-controlled or computationally matched.',
              '', 'Per-program audit trail']
    for r in results:
        lines.append(r['token']+': '+', '.join(r.get('matching_policy_all_seeds',[])))
        lines.append('  Source SHA256: '+r.get('source_sha256','not extracted'))
        lines.append('  Oracle-different decision days per seed: '+str([s.get('oracle_mismatch_days') for s in r.get('seeds',[])]))
        for e in r.get('rule_evidence',[]):
            if '60' in e['text'] or '45' in e['text']:lines.append(f"  Source line {e['line']}: {e['text']}")
    ep=ROOT/'EXPLORATORY_CALENDAR.json'
    if ep.exists():
        ex=json.loads(ep.read_text())
        lines += ['', 'Post-hoc calendar explanation (NOT added to frozen-policy counts)',
                  'Introduced after observing CLAUDE_NPORT_P1_r1. No candidate rerun or frozen-score change.']
        for r in ex['programs']:
            if r['new_explanation_only']:
                lines.append(r['token']+': '+', '.join(m['label'] for m in r['exploratory_calendar_matches'])+'; all 5 seeds / 477 dates match saved outputs.')
    (ROOT/'RESULTS.txt').write_text('\n'.join(lines)+'\n')
    attempts=json.loads((ROOT/'attempts.json').read_text())
    order=json.loads((ROOT/'run_order.json').read_text())['CLAUDE']
    done={a['trial_id']:a['status'] for a in attempts if a['vendor']=='CLAUDE'}
    pending=['CLAUDE — frozen collection order and current status',
             'Use Opus 5.5 / Extra effort / a fresh Incognito conversation for every slot.',
             'Send prompts verbatim. Retain first answers, including failures; do not regenerate or repair.',
             'No more than three simultaneous generations. Two consecutive transport failures pause collection.',
             'Never send the model previous answers, evaluator code, results or hypothesis notes.','']
    pending.extend(f'{i+1:02d}. {t}: {done.get(t,"unattempted")} — prompts/{t}.txt' for i,t in enumerate(order))
    (ROOT/'CLAUDE_PENDING.txt').write_text('\n'.join(pending)+'\n')
    print('Written RESULTS.txt with '+str(len(results))+' evaluated first answers.')

if __name__=='__main__':main()
