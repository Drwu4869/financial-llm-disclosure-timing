"""Produce a short English LaTeX addendum from frozen-follow-up outputs."""
import json
from study import ROOT

def main():
    s = json.loads((ROOT/'SUMMARY.json').read_text())
    a = json.loads((ROOT/'SAVED_AUDIT.json').read_text())
    results=[json.loads(p.read_text()) for p in (ROOT/'results').glob('*.json') if p.name.startswith(('GPT_','CLAUDE_'))]
    ep=ROOT/'EXPLORATORY_CALENDAR.json'
    extras=[r for r in json.loads(ep.read_text())['programs'] if r['new_explanation_only']] if ep.exists() else []
    findings=[]
    for vendor in ['GPT','CLAUDE']:
        parts=[]
        for form,days in [('NPORT',60),('F13',45)]:
            group=[r for r in results if r['token'].startswith(vendor+'_'+form+'_') and '_P2_' not in r['token']]
            count=sum(any(p.startswith('floor'+str(days)+'_') for p in r.get('matching_policy_all_seeds',[])) for r in group)
            part=f'{count}/{len(group)} '+('N-PORT' if form=='NPORT' else '13F')+f' programs with a frozen +{days}-day policy'
            extra=sum(r['token'].startswith(vendor+'_'+form+'_') and '_P2_' not in r['token'] for r in extras)
            if extra:part+=f' (plus {extra} calendar variants, classified post hoc)'
            parts.append(part)
        findings.append(vendor+': '+', versus '.join(parts)+'.')
    rows = []
    for c in s['cells']:
        p = c['all_seed_policy_counts']
        rows.append(' & '.join(map(str, [c['vendor'], c['form'], c['condition'],
            f"{c['evaluated']}/3", p['floor60_inclusive']+p['floor60_strict'],
            p['floor45_inclusive']+p['floor45_strict'], p['filing_inclusive'],
            p['filing_strict'], c['evaluated']-sum(p[k] for k in ['floor60_inclusive','floor60_strict','floor45_inclusive','floor45_strict','filing_inclusive','filing_strict'])]))+r' \\')
    text = r'''\pdfoutput=1
\pdfmapfile{+lm.map}
\pdfmapfile{+cm.map}
\documentclass[10pt,a4paper]{article}
\usepackage[margin=19mm]{geometry}
\usepackage[T1]{fontenc}
\usepackage{lmodern,booktabs,graphicx,microtype,amsmath}
\usepackage[hidelinks]{hyperref}
\setlength{\parindent}{0pt}
\setlength{\parskip}{5pt}
\title{A04: Does a Disclosure-Deadline Floor Transfer\newline from N-PORT to Form 13F?}
\author{Fixed follow-up to the disclosure-code pilot}
\date{8 November 2026}
\begin{document}
\begin{center}
{\Large\bfseries A04: Does a Disclosure-Deadline Floor Transfer\\from N-PORT to Form 13F?}\par
\vspace{5pt}
{\small Fixed follow-up to the disclosure-code pilot \quad | \quad 8 November 2026}
\end{center}
\textbf{Status.} @SCORED@ of 36 fresh first answers scored. This addendum reports a separately frozen mechanistic follow-up; it does not pool earlier model answers or replace the original nine-page report.

\textbf{Main descriptive result (P0/P1).} @FINDING@ A calendar-adjusted variant is reported separately below; P2 is not pooled with these unaided/generic-warning conditions.

\section*{Question and design}
The earlier pilot observed an unnecessary N-PORT availability floor in generated code. A narrow competing explanation is a general tendency to treat filing deadlines as publication dates. We test whether changing the filing description to Form 13F induces a corresponding 45-day floor. Absence of that transfer would narrow the finding to the tested form and settings; it would not establish a particular training-data or memory mechanism.

The fixed grid contains two form descriptions, three prompt conditions, three fresh first answers per cell, and two vendors (36 answers). P0 gives the task only; P1 adds a generic warning to avoid look-ahead bias; P2 specifies the filing-date and end-of-day contract. Illustrative records and executable fixtures are otherwise identical across forms. Every answer is preserved without regeneration or source repair. Collection uses fresh temporary/incognito sessions, with at most three concurrent generations per vendor.

\textbf{Observed settings.} GPT: ChatGPT High (3/5), Temporary, Unpersonalized; no exact backend snapshot is exposed. Claude: Opus 5.5, Extra effort, Incognito, fixed before its first answer. The product settings are not API-controlled or matched for computational budget. GPT first Send actions followed the frozen order, but verified unsent-draft recoveries changed actual delivery order; the transport note preserves this deviation.

\section*{Executable results}
\begin{center}
\small
\begin{tabular}{lllrrrrrr}
\toprule
Vendor & Form & Prompt & Scored & +60 & +45 & On date & After date & Other\\
\midrule
@ROWS@
\bottomrule
\end{tabular}
\end{center}
\textit{Reading the table.} ``+60'' and ``+45'' mean waiting until the later of the actual assigned filing date and period end plus the stated number of calendar days. They do not mean adding those days to the filing date. ``After date'' is a distinct conservative one-decision-day boundary. ``On date'' matches the supplied end-of-day filing-date oracle. Counts refer to first-answer programs, not execution seeds. A missing or invalid answer is never counted as a timing success.

\textbf{Post-hoc explanation.} The ``Other'' column includes valid outputs outside the frozen policy family. After observing \texttt{CLAUDE\_NPORT\_P1\_r1}, a separate saved-output check identifies @CALENDAR_COUNT@ programs with a 60-day floor rolled to the next EDGAR business day (inclusive/strict variants; zero discrepancy on every date in all five seeds). This does not change the frozen table counts; program identities and evidence are in \texttt{EXPLORATORY\_CALENDAR.json}.

\textbf{Interpretive boundary.} Repeated +60 behavior without corresponding +45 behavior supports form-specificity here, not universal deadline/publication confusion or a causal old-rule-memory claim. P2 measures compliance with an explicit rule. The original stopping decision against broad adaptive expansion remains unchanged.

\newpage
\section*{Validation and timing reference}
\begin{center}
\includegraphics[width=.98\linewidth]{A04_policy_counts.pdf}
\end{center}
Each program is executed in the existing isolated runtime on five fixed synthetic seeds, six reporting periods, and 477 decision dates per seed. Classification requires agreement with a candidate policy on every decision date in every seed, at tolerance $10^{-8}$. The audit recomputes classifications from saved outputs and verifies source, output, and frozen-file hashes. Handwritten positive and negative controls check that the evaluator can distinguish premature availability from conservative delay.

The saved audit verifies @CASES@ program--seed cases and @VECTORS@ baseline daily weight vectors. It contains @EXECUTIONS@ isolated executions in total. Future-filing deletion/value interventions yield @NO_WITNESS@ no-witness comparisons, @WITNESS@ witnesses, and @INCONCLUSIVE@ refusal-based inconclusive comparisons. Refusal-based interventions are not passes. These checks cover the full filing horizon but are not a proof over arbitrary inputs or an expanded full-horizon future-price audit.

\textbf{Date semantics.} The payload's \texttt{filing\_date} is already the SEC-assigned filing date. Private release provenance moves ordinary accepted transmissions beginning after 17:30 Eastern to the next EDGAR business day, including federal holidays; the reference does not shift that date again. Models do not receive the raw transmission timestamps, so this experiment does not test their knowledge of that conversion. Only ordinary publicly available portions are in scope; confidential treatment, outages, and exceptional cases are excluded.

\textbf{Economic limits.} The common early/late filing lags are diagnostic stress cases, not estimates of real filing frequencies. Prices are nuisance inputs. No realized-return, Sharpe, profit-loss, or economic-materiality claim follows from this experiment. Any real-data availability-loss estimate requires its own verified filing-date analysis. Three answers per cell provide a descriptive replication, not a population estimate of model behavior.

\section*{Sources and reproducibility}
Primary sources underlying the fixed date reference are the SEC's 2019 N-PORT interim final rule (Release IC-33384), Form 13F instructions, and EDGAR filing-status guidance. The experiment uses the 2022--2023 regime; it does not substitute later rule changes into those historical cases.

\small
\begin{itemize}
\item SEC N-PORT rule: \url{https://www.sec.gov/files/rules/interim/2019/ic-33384.pdf}
\item Form 13F instructions: \url{https://www.sec.gov/pdf/form13f.pdf}
\item EDGAR status guidance: \url{https://www.sec.gov/submit-filings/filer-support-resources/how-do-i-guides/determine-status-my-filing}
\end{itemize}
\normalsize
The accompanying package contains the freeze manifest, exact prompts and randomized order, raw first answers and source files, timestamps and UI settings, five fixtures, isolated outputs, scoring scripts, saved-output audit, and this LaTeX source. The main paper remains separate. Audit timestamp: \texttt{@AUDIT@}.
\end{document}
'''
    replacements={'SCORED':s['evaluated'], 'ROWS':'\n'.join(rows),'FINDING':' '.join(findings),'CALENDAR_COUNT':len(extras),
       'CASES':a['verified_program_seed_cases'],'VECTORS':f"{a['baseline_daily_vectors']:,}",
       'EXECUTIONS':f"{a['isolated_executions_in_saved_files']:,}",
       'NO_WITNESS':a['intervention_outcomes'].get('no_witness',0),
       'WITNESS':a['intervention_outcomes'].get('witness',0),
       'INCONCLUSIVE':a['intervention_outcomes'].get('inconclusive_intervention_refusal',0),
       'AUDIT':a['audited_at'].split('.')[0]+' UTC'}
    for key, val in replacements.items():text=text.replace('@'+key+'@',str(val))
    (ROOT/'A04_addendum.tex').write_text(text)
    print('Generated LaTeX addendum from saved counts.')

if __name__=='__main__':main()
