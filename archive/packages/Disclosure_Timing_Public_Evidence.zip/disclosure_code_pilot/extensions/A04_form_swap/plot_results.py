"""Reproducible descriptive figure. Each bar contains first answers, not seeds."""
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from study import ROOT

def main():
    s = json.loads((ROOT / 'SUMMARY.json').read_text())
    colors = {'floor60': '#cb6843', 'floor45': '#9b4d9a', 'filing_strict': '#80a4c4',
              'filing_inclusive': '#226b62', 'other': '#c1c6cc', 'pending': '#f2f3f5'}
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.8), sharey=True)
    for ax, vendor in zip(axes, ['GPT', 'CLAUDE']):
        cells = [c for c in s['cells'] if c['vendor'] == vendor]
        for i, c in enumerate(cells):
            p = c['all_seed_policy_counts']
            counts = {'floor60': p['floor60_inclusive'] + p['floor60_strict'],
                      'floor45': p['floor45_inclusive'] + p['floor45_strict'],
                      'filing_strict': p['filing_strict'], 'filing_inclusive': p['filing_inclusive']}
            counts['other'] = c['evaluated'] - sum(counts.values())
            counts['pending'] = c['planned'] - c['evaluated']
            bottom = 0
            for name, n in counts.items():
                if n:
                    ax.bar(i, n, bottom=bottom, color=colors[name], width=.7,
                           edgecolor='white', linewidth=1)
                    if name != 'pending':
                        ax.text(i, bottom+n/2, str(n), ha='center', va='center', fontsize=11,
                                color='white' if name in ('floor60', 'floor45', 'filing_inclusive') else '#17212b')
                    bottom += n
        ax.set_xticks(range(6), ['N-PORT\n'+c['condition'] if c['form']=='NPORT' else '13F\n'+c['condition'] for c in cells], fontsize=9)
        ax.set_title(vendor, fontsize=13, weight='bold')
        ax.set_ylim(0, 3.35)
        ax.set_yticks([0, 1, 2, 3])
        ax.spines[['top', 'right']].set_visible(False)
        ax.set_axisbelow(True)
        ax.yaxis.grid(True, color='#e9ecef')
    axes[0].set_ylabel('Fresh first answers (3 per condition)')
    fig.suptitle(f"A04: form-specific timing policies ({s['evaluated']}/36 scored)", fontsize=15, y=.98)
    labels = {'floor60': 'Period-end +60 floor', 'floor45': 'Period-end +45 floor',
              'filing_strict': 'After filing day', 'filing_inclusive': 'On filing day',
              'other': ('Other / invalid / refusal' if any(c['refusals'] or c['invalid_or_incomplete'] for c in s['cells']) else 'Outside frozen policies'), 'pending': 'Not yet scored'}
    names = ['floor60', 'floor45', 'filing_strict', 'filing_inclusive', 'other', 'pending']
    fig.legend([Patch(facecolor=colors[n]) for n in names], [labels[n] for n in names],
               loc='lower center', bbox_to_anchor=(.5, .075), ncol=3, frameon=False, fontsize=9)
    fig.text(.5, .025, 'P0: task only   |   P1: generic look-ahead warning   |   P2: explicit filing-date contract',
             ha='center', fontsize=9, color='#444444')
    fig.tight_layout(rect=[0, .21, 1, .94])
    fig.savefig(ROOT / 'A04_policy_counts.png', dpi=180)
    fig.savefig(ROOT / 'A04_policy_counts.pdf')
    plt.close(fig)
    print('Saved descriptive policy-count figure; no inferential claims.')

if __name__ == '__main__':
    main()
