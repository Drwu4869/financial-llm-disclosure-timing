"""Verify independently copied Claude code blocks against whole-message copies."""
import datetime as dt
import hashlib
import json
import re
from study import ROOT

def main():
    rows=[]
    for p in sorted((ROOT/'responses').glob('CLAUDE_*.py')):
        message=ROOT/'capture_metadata'/(p.stem+'.message_copy.txt')
        raw=message.read_text()
        blocks=re.findall(r'```(?:python|py)?\s*\n(.*?)```',raw,re.S)
        exact=len(blocks)==1 and blocks[0].strip()==p.read_text().strip()
        rows.append({'token':p.stem,'whole_message_code_blocks':len(blocks),
                     'code_copy_matches_whole_message':exact,
                     'whole_message_sha256':hashlib.sha256(message.read_bytes()).hexdigest(),
                     'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
        assert exact,('Capture mismatch',p.stem)
    result={'audited_at':dt.datetime.now(dt.timezone.utc).isoformat(),
            'scope':'UI code Copy compared with independent whole-response Copy; excludes hidden reasoning and normalizes only outer whitespace.',
            'verified_claude_answers':len(rows),'programs':rows}
    (ROOT/'CAPTURE_INTEGRITY.json').write_text(json.dumps(result,indent=2)+'\n')
    print('Claude independent-copy agreement:',len(rows))

if __name__=='__main__':main()
