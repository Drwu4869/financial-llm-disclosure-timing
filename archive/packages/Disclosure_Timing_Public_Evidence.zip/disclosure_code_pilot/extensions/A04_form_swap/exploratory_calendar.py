"""Post-observation explanation, separate from frozen nine-policy classification.

Motivation: CLAUDE_NPORT_P1_r1 adds an EDGAR roll to its 60-day floor.
No candidate execution, no changed frozen scores, no new prompts or stopping rule.
"""
import copy
import datetime as dt
import gzip
import hashlib
import json
from study import ROOT, SEEDS, add_days, next_edgar, policy
from audit_full_horizon import maxdiff

def calendar_policy(payload, days, strict):
    p = copy.deepcopy(payload)
    for row in p['filings']:
        row['filing_date'] = max(row['filing_date'], next_edgar(add_days(row['period_end'], days)))
    return policy(p, 'filing_strict' if strict else 'filing_inclusive')

def main():
    assert next_edgar('2023-05-29') == '2023-05-30'
    assert next_edgar('2022-11-29') == '2022-11-29'
    rows = []
    for path in sorted((ROOT/'results').glob('*.json')):
        if not path.name.startswith(('GPT_', 'CLAUDE_')):continue
        r = json.loads(path.read_text())
        if r.get('valid_portfolio_seeds') != 5:continue
        tests = []
        for n in [45, 60]:
            for strict in [False, True]:
                errors = []
                for item in r['seeds']:
                    op = ROOT/'results'/item['outputs_file']
                    assert hashlib.sha256(op.read_bytes()).hexdigest() == item['outputs_sha256']
                    with gzip.open(op, 'rt') as fp:out = json.load(fp)[0]
                    payload = json.loads((ROOT/'fixtures'/f"{item['seed']}.json").read_text())['payload']
                    errors.append(maxdiff(out['weights'], calendar_policy(payload, n, strict)))
                if max(errors) <= 1e-8:
                    tests.append({'label':f"floor{n}_edgar_"+('strict' if strict else 'inclusive'),
                                  'all_seed_max_errors':errors})
        rows.append({'token':r['token'],'frozen_matches':r.get('matching_policy_all_seeds',[]),
                     'exploratory_calendar_matches':tests,
                     'new_explanation_only':not r.get('matching_policy_all_seeds') and bool(tests)})
    now=dt.datetime.now(dt.timezone.utc).isoformat()
    prior_path=ROOT/'EXPLORATORY_CALENDAR.json'
    prior=json.loads(prior_path.read_text()) if prior_path.exists() else {}
    result={'updated_at':now,'introduced_at':prior.get('introduced_at',prior.get('updated_at',now)),
            'designation':'POST-HOC explanatory analysis; not part of frozen policy family or confirmatory counts',
            'trigger':'Observed CLAUDE_NPORT_P1_r1 source and saved output after its first answer; 9 Claude answers had been returned.',
            'method':'Handwritten 45/60-day floors with next-EDGAR-business-day roll, inclusive/strict variants; compare all five seeds and all 477 dates using saved baseline weights.',
            'no_changes':'No frozen files, primary scores, candidate code, prompts or stopping rules changed.',
            'programs':rows}
    (ROOT/'EXPLORATORY_CALENDAR.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps([r for r in rows if r['new_explanation_only']],indent=2))

if __name__=='__main__':main()
