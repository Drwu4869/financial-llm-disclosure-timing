from datetime import date, timedelta
from math import fsum, isfinite


def build_strategy(payload):
    """
    Build a point-in-time, holdings-based, dollar-neutral signal.

    Returns:
        {
            "status": "ok" | "assumption" | "insufficient_data",
            "reason": str,
            "weights": list[list[float]]
        }

    Each weights row corresponds to a decision date, with columns
    matching the input asset order.

    Trading convention:
      - Signal determined at the end of the decision date.
      - Positions execute at the next supplied session's open.
      - Positions liquidate at that session's close.
      - Return evaluation is performed independently.
      - Prices are never used to construct or optimize signals.

    Historical disclosure convention:
      - Use the 2022-2023 Form N-PORT third-fiscal-month
        public-disclosure framework (60 calendar days).
      - A record cannot become usable before its SEC filing date.
      - Without intraday publication timestamps, records becoming
        available on a decision date are conservatively excluded.
      - Later filings can revise earlier reported weights.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Date must be an ISO string.")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Date must use YYYY-MM-DD.")

        return parsed

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        assets = payload["assets"]
        decision_strings = payload["dates"]
        filings = payload["filings"]

        if (
            not isinstance(assets, list)
            or not assets
            or any(
                not isinstance(a, str) or not a
                for a in assets
            )
            or len(set(assets)) != len(assets)
        ):
            return insufficient(
                "Assets must be a nonempty list of unique names."
            )

        if not isinstance(decision_strings, list) or not decision_strings:
            return insufficient("No decision dates supplied.")

        if not isinstance(filings, list):
            return insufficient("Filings must be a list.")

        decision_dates = [
            parse_date(x) for x in decision_strings
        ]

        if any(
            decision_dates[i] >= decision_dates[i + 1]
            for i in range(len(decision_dates) - 1)
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n = len(assets)
        asset_index = {
            asset: i for i, asset in enumerate(assets)
        }

        # The fund's percentage weight represented by an asset
        # before any applicable public observation.
        baseline = 100.0 / n

        # Each event:
        # (public_date, period_end, filing_date, asset_index, weight)
        events = []

        seen_ids = set()
        seen_versions = {}

        for row in filings:
            if not isinstance(row, dict):
                return insufficient(
                    "Each filing must be a dictionary."
                )

            row_id = row["row_id"]
            asset = row["asset"]
            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])
            raw_weight = row["weight_pct"]

            if not isinstance(row_id, str) or not row_id:
                return insufficient("Invalid filing row_id.")

            if row_id in seen_ids:
                return insufficient("Duplicate filing row_id.")

            seen_ids.add(row_id)

            if asset not in asset_index:
                return insufficient(
                    "Filing contains an asset outside the universe."
                )

            if (
                isinstance(raw_weight, bool)
                or not isinstance(raw_weight, (int, float))
            ):
                return insufficient(
                    "Filing weight_pct must be numeric."
                )

            weight = float(raw_weight)

            if not isfinite(weight):
                return insufficient(
                    "Filing weight_pct must be finite."
                )

            if filing_date < period_end:
                return insufficient(
                    "Filing date precedes report period end."
                )

            # Two conflicting revisions with the same period and
            # filing date cannot be ordered using opaque row IDs.
            version_key = (asset, period_end, filing_date)

            if version_key in seen_versions:
                if seen_versions[version_key] != weight:
                    return insufficient(
                        "Conflicting same-day versions cannot "
                        "be ordered without publication timestamps."
                    )
                continue

            seen_versions[version_key] = weight

            # Conservative public availability:
            # later of the SEC filing date and the historical
            # 60-calendar-day third-month disclosure boundary.
            public_date = max(
                filing_date,
                period_end + timedelta(days=60)
            )

            events.append((
                public_date,
                period_end,
                filing_date,
                asset_index[asset],
                weight
            ))

        # Unordered filings must not determine temporal priority.
        events.sort(key=lambda event: (
            event[0], event[1], event[2], event[3]
        ))

        # Most recent applicable (period_end, filing_date)
        # for each individual asset.
        latest_versions = [None] * n
        current_levels = [baseline] * n

        weights = []
        event_cursor = 0
        used_baseline = False

        for decision_date in decision_dates:

            # Strict inequality prevents same-day disclosure
            # ambiguity from introducing look-ahead bias.
            while (
                event_cursor < len(events)
                and events[event_cursor][0] < decision_date
            ):
                (
                    public_date,
                    period_end,
                    filing_date,
                    idx,
                    weight
                ) = events[event_cursor]

                version = (period_end, filing_date)
                previous = latest_versions[idx]

                # Newer report periods dominate older periods.
                # Within the same period, a later filing wins.
                if previous is None or version > previous:
                    latest_versions[idx] = version
                    current_levels[idx] = weight

                event_cursor += 1

            if any(v is None for v in latest_versions):
                used_baseline = True

            # An all-equal holdings vector has no cross-sectional
            # signal and must produce an all-cash position.
            if max(current_levels) == min(current_levels):
                weights.append([0.0] * n)
                continue

            mean_level = fsum(current_levels) / n

            centered = [
                value - mean_level
                for value in current_levels
            ]

            # Remove residual floating-point centering error.
            # The final component balances the other components.
            centered[-1] = -fsum(centered[:-1])

            gross = fsum(abs(x) for x in centered)

            if gross == 0.0:
                weights.append([0.0] * n)
                continue

            # L1 normalization:
            # sum(abs(weights)) = 1 mathematically,
            # sum(weights) = 0 mathematically.
            signal = [x / gross for x in centered]

            # Protect against floating-point rounding making
            # measured gross exposure slightly greater than 1.
            measured_gross = fsum(abs(x) for x in signal)

            if measured_gross > 1.0:
                scale = (
                    (1.0 - 2.0**-52) / measured_gross
                )
                signal = [x * scale for x in signal]

            if not all(isfinite(x) for x in signal):
                return insufficient(
                    "Numerical overflow in signal normalization."
                )

            weights.append(signal)

        reason = (
            "Each decision uses the latest publicly applicable "
            "report period per asset and its latest filed version. "
            "Availability is conservatively no earlier than the "
            "later of filing_date and period_end plus 60 calendar "
            "days; same-day disclosures are excluded because "
            "intraday timestamps are unavailable. "
            "Unobserved assets use the equal-weight percentage "
            "baseline. Holdings are cross-sectionally centered "
            "and L1-normalized; zero signals remain in cash. "
            "Weights are indexed by decision date and are intended "
            "for execution at the next synthetic session's open "
            "and liquidation at its close. Prices are not used "
            "for signal generation. Close-only prices cannot "
            "independently establish open-to-close returns."
        )

        if used_baseline:
            reason += (
                " At least one decision used the prescribed "
                "baseline for an asset without an applicable filing."
            )

        return {
            "status": "assumption",
            "reason": reason,
            "weights": weights
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            "Invalid or incomplete payload: " + str(exc)
        )

