import math
from collections.abc import Mapping
from datetime import date, datetime

_REL_TOL = 1e-12


def _parse_date(value):
    """Return a date for ISO 'YYYY-MM-DD' input (date/datetime objects accepted), else None."""
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if not isinstance(value, str):
        return None
    s = value.strip()
    if len(s) < 10 or s[4] != "-" or s[7] != "-":
        return None
    if len(s) > 10 and s[10] not in "T ":
        return None
    try:
        return datetime.strptime(s[:10], "%Y-%m-%d").date()
    except ValueError:
        return None


def _parse_number(value):
    """Finite float or None (booleans rejected)."""
    if value is None or isinstance(value, bool):
        return None
    try:
        x = float(value.strip().rstrip("%")) if isinstance(value, str) else float(value)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def _neutralize(levels):
    """Demean, then scale so gross = 1 and net = 0 (long 0.5 / short 0.5); cash if flat."""
    n = len(levels)
    mean = math.fsum(levels) / n
    tol = _REL_TOL * max(1.0, max(abs(x) for x in levels))
    centred = [x - mean for x in levels]
    centred = [0.0 if abs(c) <= tol else c for c in centred]
    long_sum = math.fsum(c for c in centred if c > 0.0)
    short_sum = -math.fsum(c for c in centred if c < 0.0)
    if long_sum <= tol or short_sum <= tol:
        return [0.0] * n, False
    w = [0.5 * c / long_sum if c > 0.0 else (0.5 * c / short_sum if c < 0.0 else 0.0)
         for c in centred]
    gross = math.fsum(abs(x) for x in w)
    if gross > 1.0:  # guard against last-ulp rounding
        shrink = (1.0 - 1e-15) / gross
        w = [x * shrink for x in w]
    return [x + 0.0 for x in w], True


def _result(status, reason, weights=None):
    out = {"status": status, "reason": reason}
    if weights is not None:
        out["weights"] = weights
    return out


def _build(payload):
    if not isinstance(payload, Mapping):
        return _result("insufficient_data", "Payload is not a mapping.")

    # ---- decision dates -------------------------------------------------
    raw_dates = payload.get("dates")
    if not isinstance(raw_dates, (list, tuple)) or not raw_dates:
        return _result("insufficient_data", "No decision dates supplied.", [])
    dates = [_parse_date(d) for d in raw_dates]
    n_bad = sum(d is None for d in dates)
    if n_bad:
        return _result("insufficient_data",
                       f"{n_bad} decision date(s) are not ISO YYYY-MM-DD; rows cannot be aligned.")

    # ---- asset universe -------------------------------------------------
    raw_assets = payload.get("assets")
    if not isinstance(raw_assets, (list, tuple)) or not raw_assets:
        return _result("insufficient_data", "No assets supplied.")
    keys = [str(a).strip() for a in raw_assets]
    if len(set(keys)) != len(keys):
        return _result("insufficient_data",
                       "Duplicate asset names make the column mapping ambiguous.")
    n_assets = len(keys)
    col = {k: i for i, k in enumerate(keys)}
    if n_assets < 2:
        return _result("insufficient_data",
                       "Fewer than two assets: the demeaned vector is identically zero, "
                       "so every decision is cash.",
                       [[0.0] * n_assets for _ in dates])

    # ---- filing rows ----------------------------------------------------
    raw_filings = payload.get("filings")
    if raw_filings is None:
        raw_filings = []
    if not isinstance(raw_filings, (list, tuple)):
        return _result("insufficient_data", "Filings are not a list of rows.",
                       [[0.0] * n_assets for _ in dates])

    skipped = {"malformed": 0, "asset outside universe": 0,
               "filed before period_end": 0, "weight_pct outside [0, 100]": 0,
               "exact duplicate": 0}
    seen = set()
    records = []  # (filing_date, column, period_end, weight_pct)
    for row in raw_filings:
        if not isinstance(row, Mapping) or row.get("asset") is None:
            skipped["malformed"] += 1
            continue
        idx = col.get(str(row.get("asset")).strip())
        if idx is None:
            skipped["asset outside universe"] += 1
            continue
        period_end = _parse_date(row.get("period_end"))
        filing_date = _parse_date(row.get("filing_date"))
        weight = _parse_number(row.get("weight_pct"))
        if period_end is None or filing_date is None or weight is None:
            skipped["malformed"] += 1
            continue
        if filing_date < period_end:  # a 13F cannot be filed before its as-of date
            skipped["filed before period_end"] += 1
            continue
        if weight < 0.0 or weight > 100.0 + 1e-9:  # 13F holdings are long-only percentages
            skipped["weight_pct outside [0, 100]"] += 1
            continue
        sig = (str(row.get("row_id")), idx, period_end, filing_date, weight)
        if sig in seen:
            skipped["exact duplicate"] += 1
            continue
        seen.add(sig)
        records.append((filing_date, idx, period_end, weight))
    records.sort(key=lambda r: r[0])

    # ---- point-in-time walk over decision dates --------------------------
    ew_level = 100.0 / n_assets
    versions = [dict() for _ in range(n_assets)]  # period_end -> [filing_date, [weights]]
    current = [None] * n_assets
    conflicts = set()
    by_date = {}
    ptr = 0
    for d in sorted(set(dates)):
        touched = set()
        # Only rows filed strictly before the decision date are known (one-session lag).
        while ptr < len(records) and records[ptr][0] < d:
            filing_date, idx, period_end, weight = records[ptr]
            ptr += 1
            slot = versions[idx].get(period_end)
            if slot is None or filing_date > slot[0]:
                versions[idx][period_end] = [filing_date, [weight]]  # newer version restates
            else:
                slot[1].append(weight)  # same filing date (records are sorted)
            touched.add(idx)
        for idx in touched:
            latest_period = max(versions[idx])
            ws = versions[idx][latest_period][1]
            if max(ws) - min(ws) > _REL_TOL * max(1.0, max(ws)):
                conflicts.add((keys[idx], latest_period))
            current[idx] = math.fsum(ws) / len(ws)
        levels = [ew_level if v is None else v for v in current]
        vec, active = _neutralize(levels)
        by_date[d] = (vec, active, any(v is not None for v in current))

    weights = [list(by_date[d][0]) for d in dates]
    observed_days = sum(1 for d in dates if by_date[d][2])
    active_dates = [d for d in dates if by_date[d][1]]
    cash_days = len(dates) - len(active_dates)

    notes = []
    dropped = ", ".join(f"{v} {k}" for k, v in skipped.items() if v)
    if dropped:
        notes.append(f"Dropped rows: {dropped}.")
    if conflicts:
        notes.append(f"{len(conflicts)} asset/period(s) had conflicting same-day versions; averaged.")
    if any(b <= a for a, b in zip(dates, dates[1:])):
        notes.append("Dates are not strictly increasing; each row still uses only "
                     "information known at its own date.")

    if observed_days == 0:
        reason = (f"No valid 13F row ({len(records)} of {len(raw_filings)} usable) was filed "
                  "strictly before any decision date, so every vector is the equal-weight "
                  "level and every decision is cash. " + " ".join(notes))
        return _result("insufficient_data", reason.strip(), weights)

    first = min(active_dates).isoformat() if active_dates else "none"
    reason = " ".join([
        "13F rows enter only on decision dates strictly after filing_date: no intraday "
        "times are given, and a filing dated d can post after d's decision, so a "
        "one-session lag is assumed. period_end is only the holdings as-of date, and late "
        "filings count from when they were actually filed.",
        "Per asset, the signal uses the latest report period among rows filed by then, "
        "with that period's latest-filed version. Omission from a newer public report is "
        "not read as zero, because public portions can exclude confidential positions.",
        f"Assets with no usable row sit at the equal-weight level 100/N = {ew_level:.4g}%. "
        "The vector is demeaned and scaled to gross 1 (net 0), with cash when flat. "
        "Prices are not used.",
        f"{len(records)} of {len(raw_filings)} rows valid; first non-cash decision {first}; "
        f"{cash_days} cash day(s).",
    ] + notes)
    return _result("assumption", reason, weights)


def build_strategy(payload):
    try:
        return _build(payload)
    except Exception as exc:  # never raise into the evaluator
        return _result("insufficient_data",
                       f"Unexpected payload structure ({type(exc).__name__}: {exc}); "
                       "no positions produced.")
