from datetime import date
import math


def build_strategy(payload):
    """
    Build a point-in-time, holdings-based, dollar-neutral strategy.

    Inputs:
        payload["dates"]:
            Ordered ISO decision dates.

        payload["assets"]:
            Assets in fixed output-column order.

        payload["filings"]:
            Unordered records containing:
                row_id
                asset
                period_end
                filing_date
                weight_pct

        payload["prices"]:
            Not used. Historical execution and return evaluation
            are performed independently.

    Rules:
        - A filing becomes usable at the end of its filing_date.
        - For each asset, select the latest available report period.
        - Within that period, select the latest filed version.
        - Never backdate revisions.
        - Before an asset's first applicable filing, use 100/N.
        - Cross-sectionally center holdings percentages.
        - Normalize to gross exposure 1 and net exposure 0.
        - Return zero weights when all holdings levels are equal.
        - Do not use prices to construct or optimize signals.

    Returns:
        {
            "status": "ok" | "assumption" | "insufficient_data",
            "reason": str,
            "weights": list[list[float]]
        }

    Each weights row corresponds to one input decision date.
    Each column corresponds to one input asset.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Dates must use ISO YYYY-MM-DD format.")

        return parsed

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        dates_raw = payload.get("dates")
        assets = payload.get("assets")
        filings = payload.get("filings")

        if not isinstance(dates_raw, list):
            return insufficient("Missing or invalid decision dates.")

        if not isinstance(assets, list) or not assets:
            return insufficient("A nonempty asset universe is required.")

        if not all(
            isinstance(asset, str) and asset
            for asset in assets
        ):
            return insufficient("Asset identifiers must be nonempty strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        if not isinstance(filings, list):
            return insufficient("Missing or invalid filing records.")

        # Parse and verify chronological decision dates.
        decision_dates = [parse_date(d) for d in dates_raw]

        if any(
            decision_dates[i] <= decision_dates[i - 1]
            for i in range(1, len(decision_dates))
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n_assets = len(assets)
        asset_index = {
            asset: i for i, asset in enumerate(assets)
        }

        # Historical alignment requires actual public filing dates.
        # Never substitute period_end or estimate a filing lag.
        for row in filings:
            if not isinstance(row, dict):
                return insufficient(
                    "Every filing must be a dictionary."
                )

            if row.get("filing_date") is None:
                return insufficient(
                    "Actual SEC filing_date is missing; exact "
                    "historical alignment cannot be established."
                )

        # Events are:
        # (filing_date, period_end, asset_index, weight_pct)
        events = []

        # Detect conflicting versions that cannot be ordered
        # because intraday filing timestamps are unavailable.
        same_day_versions = {}

        seen_row_ids = set()

        for row in filings:
            asset = row.get("asset")
            row_id = row.get("row_id")

            if asset not in asset_index:
                return insufficient(
                    f"Filing references an unknown asset: {asset!r}."
                )

            if not isinstance(row_id, str) or not row_id:
                return insufficient(
                    "Every filing requires a nonempty row_id."
                )

            if row_id in seen_row_ids:
                return insufficient(
                    "Filing row_id values must be unique."
                )

            seen_row_ids.add(row_id)

            period_end = parse_date(row.get("period_end"))
            filing_date = parse_date(row["filing_date"])

            if filing_date < period_end:
                return insufficient(
                    "A filing_date precedes its report period_end."
                )

            weight = row.get("weight_pct")

            if (
                isinstance(weight, bool)
                or not isinstance(weight, (int, float))
            ):
                return insufficient(
                    "Every weight_pct must be numeric."
                )

            try:
                weight = float(weight)
            except (OverflowError, ValueError):
                return insufficient(
                    "A weight_pct cannot be represented as a finite float."
                )

            if not math.isfinite(weight):
                return insufficient(
                    "All weight_pct values must be finite."
                )

            idx = asset_index[asset]

            version_key = (idx, period_end, filing_date)

            if version_key in same_day_versions:
                previous_weight = same_day_versions[version_key]

                if previous_weight != weight:
                    return insufficient(
                        "Conflicting versions for the same asset, "
                        "report period, and filing date cannot be "
                        "ordered without intraday timestamps."
                    )

                # Identical same-day observations carry no new
                # information; do not duplicate the event.
                continue

            same_day_versions[version_key] = weight

            events.append(
                (filing_date, period_end, idx, weight)
            )

        # Order by public availability, not by report period
        # or opaque row_id.
        events.sort(key=lambda event: (event[0], event[1], event[2]))

        equal_weight_pct = 100.0 / n_assets

        # Each state entry is either None or:
        # (period_end, filing_date, weight_pct)
        latest = [None] * n_assets

        def normalized_signal(levels):
            """
            Center the cross-section and normalize.

            In exact arithmetic, L1 normalization of a centered
            vector assigns total positive exposure +0.5 and total
            negative exposure -0.5.

            Normalize the two sides separately to minimize floating
            point drift in gross and net exposure.
            """

            if all(x == levels[0] for x in levels):
                return [0.0] * n_assets

            mean = math.fsum(levels) / n_assets
            centered = [x - mean for x in levels]

            positive_indices = [
                i for i, x in enumerate(centered) if x > 0.0
            ]
            negative_indices = [
                i for i, x in enumerate(centered) if x < 0.0
            ]

            if not positive_indices or not negative_indices:
                return [0.0] * n_assets

            positive_total = math.fsum(
                centered[i] for i in positive_indices
            )
            negative_total = math.fsum(
                -centered[i] for i in negative_indices
            )

            if positive_total <= 0.0 or negative_total <= 0.0:
                return [0.0] * n_assets

            weights = [0.0] * n_assets

            # Positive positions sum to +0.5.
            for i in positive_indices[:-1]:
                weights[i] = (
                    0.5 * (centered[i] / positive_total)
                )

            last_positive = positive_indices[-1]

            weights[last_positive] = (
                0.5
                - math.fsum(
                    weights[i] for i in positive_indices[:-1]
                )
            )

            # Negative positions sum to -0.5.
            for i in negative_indices[:-1]:
                weights[i] = (
                    -0.5 * (-centered[i] / negative_total)
                )

            last_negative = negative_indices[-1]

            weights[last_negative] = (
                -0.5
                - math.fsum(
                    weights[i] for i in negative_indices[:-1]
                )
            )

            return weights

        result_weights = []
        event_cursor = 0

        # Process filing events only when publicly available.
        # Equality is intentional: date-only filings are usable
        # for decisions at the END of their filing day.
        for decision_day in decision_dates:

            while (
                event_cursor < len(events)
                and events[event_cursor][0] <= decision_day
            ):
                filing_date, period_end, idx, weight = (
                    events[event_cursor]
                )

                current = latest[idx]

                if current is None:
                    latest[idx] = (
                        period_end,
                        filing_date,
                        weight,
                    )

                else:
                    current_period, current_filing, _ = current

                    # Most recent report period takes priority.
                    # Within the same period, a later filed
                    # revision supersedes an earlier version.
                    #
                    # A later revision to an older report period
                    # must not replace a newer report period.
                    if (
                        period_end > current_period
                        or (
                            period_end == current_period
                            and filing_date > current_filing
                        )
                    ):
                        latest[idx] = (
                            period_end,
                            filing_date,
                            weight,
                        )

                event_cursor += 1

            # Assets without applicable observations receive the
            # equal-weight holdings LEVEL, not a trading position.
            levels = [
                equal_weight_pct
                if observation is None
                else observation[2]
                for observation in latest
            ]

            signal = normalized_signal(levels)

            # Guard against unexpected numerical problems.
            if not all(math.isfinite(w) for w in signal):
                return insufficient(
                    "Signal normalization produced nonfinite weights."
                )

            gross = math.fsum(abs(w) for w in signal)
            net = math.fsum(signal)

            # Floating-point tolerance is used only for checking
            # arithmetic, never for choosing trading parameters.
            tolerance = 1e-12

            if gross > 1.0 + tolerance:
                return insufficient(
                    "Signal violates the gross exposure constraint."
                )

            if abs(net) > tolerance:
                return insufficient(
                    "Signal violates the net exposure constraint."
                )

            result_weights.append(signal)

        return {
            "status": "ok",
            "reason": (
                "Point-in-time alignment uses each record's actual "
                "SEC filing_date, inclusive of end-of-day decisions "
                "on that date. For each asset, the latest publicly "
                "available report period and its latest applicable "
                "filed version are used. Revisions are never "
                "backdated; assets without observations use the "
                "100/N holdings level. Holdings are cross-sectionally "
                "centered and normalized to dollar-neutral exposure, "
                "with zero weights for a constant cross-section. "
                "Prices are not used to generate or optimize signals. "
                "Each weight row applies to the corresponding "
                "decision day's close; next-listed-session open-to-close "
                "execution and returns are evaluated independently."
            ),
            "weights": result_weights,
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            f"Invalid input or historical alignment: {exc}"
        )
