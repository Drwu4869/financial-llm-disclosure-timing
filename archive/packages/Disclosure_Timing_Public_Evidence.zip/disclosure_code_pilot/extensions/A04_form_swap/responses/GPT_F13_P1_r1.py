from datetime import date
from math import fsum, isfinite


def build_strategy(payload):
    """
    Build a point-in-time, holdings-based, market-neutral strategy.

    Information alignment:
      - period_end identifies when holdings were measured.
      - filing_date identifies when the information was disclosed.
      - A filing is eligible only when filing_date < decision_date.
      - This conservative one-calendar-date lag avoids assuming
        same-day availability without intraday filing timestamps.
      - For each asset, select the latest eligible report period.
      - Within that period, use the latest eligible revision.
      - Before an asset's first eligible filing, use 100 / N percent.

    Signal:
      - Subtract the cross-sectional mean of the holdings vector.
      - Normalize by the sum of absolute centered values.
      - Return all-zero weights when the vector is constant.

    Evaluation alignment:
      - Each output row belongs to its corresponding decision date.
      - The independent evaluator executes those weights at the
        next session's open and liquidates at that session's close.
      - Prices are deliberately excluded from signal construction.
      - Close-only prices cannot establish open-to-close returns.

    Returns:
        {
            "status": "ok" | "assumption" | "insufficient_data",
            "reason": str,
            "weights": list[list[float]]
        }
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason
        }

    def parse_date(value, field):
        if not isinstance(value, str):
            raise ValueError(f"{field} must be an ISO date string")

        try:
            parsed = date.fromisoformat(value)
        except (TypeError, ValueError):
            raise ValueError(f"Invalid {field}: {value!r}")

        if parsed.isoformat() != value:
            raise ValueError(
                f"{field} must use YYYY-MM-DD format"
            )

        return parsed

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        dates_raw = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]

        if not isinstance(dates_raw, list) or not dates_raw:
            return insufficient("No decision dates supplied.")

        if not isinstance(assets, list) or not assets:
            return insufficient("No assets supplied.")

        if not isinstance(filings, list):
            return insufficient("Filings must be a list.")

        if any(
            not isinstance(asset, str) or not asset
            for asset in assets
        ):
            return insufficient(
                "Asset identifiers must be nonempty strings."
            )

        if len(set(assets)) != len(assets):
            return insufficient(
                "Asset identifiers must be unique."
            )

        decision_dates = [
            parse_date(value, "decision date")
            for value in dates_raw
        ]

        if any(
            decision_dates[i] <= decision_dates[i - 1]
            for i in range(1, len(decision_dates))
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n_assets = len(assets)

        asset_index = {
            asset: index
            for index, asset in enumerate(assets)
        }

        # All holdings percentages and fallback values use
        # the same percentage-point scale.
        fallback_level = 100.0 / n_assets

        # Each entry:
        # (filing_date, period_end, asset_index, weight_pct)
        observations = []

        seen_row_ids = set()

        # Identical asset/period/filing-date combinations cannot
        # establish an ordering between conflicting revisions.
        seen_versions = {}

        for row in filings:
            if not isinstance(row, dict):
                return insufficient(
                    "Each filing must be a dictionary."
                )

            row_id = row["row_id"]
            asset = row["asset"]
            period_end = parse_date(
                row["period_end"], "period_end"
            )
            filing_date = parse_date(
                row["filing_date"], "filing_date"
            )

            if not isinstance(row_id, str) or not row_id:
                return insufficient(
                    "Each row_id must be a nonempty string."
                )

            if row_id in seen_row_ids:
                return insufficient(
                    "Duplicate row_id encountered."
                )

            seen_row_ids.add(row_id)

            if asset not in asset_index:
                # Filings outside the fixed strategy universe
                # cannot contribute to its asset vector.
                continue

            if period_end > filing_date:
                return insufficient(
                    "A filing precedes its reported period_end."
                )

            raw_weight = row["weight_pct"]

            if (
                isinstance(raw_weight, bool)
                or not isinstance(raw_weight, (int, float))
            ):
                return insufficient(
                    "weight_pct must be numeric."
                )

            try:
                weight = float(raw_weight)
            except (ValueError, OverflowError):
                return insufficient(
                    "weight_pct cannot be represented as a "
                    "finite numeric value."
                )

            if not isfinite(weight):
                return insufficient(
                    "Non-finite weight_pct encountered."
                )

            idx = asset_index[asset]

            version_key = (
                idx,
                period_end,
                filing_date
            )

            if version_key in seen_versions:
                if seen_versions[version_key] != weight:
                    return insufficient(
                        "Conflicting revisions share the same "
                        "asset, report period, and filing date; "
                        "their order cannot be determined."
                    )

                # Duplicate observations with identical values
                # do not change the holdings information.
                continue

            seen_versions[version_key] = weight

            observations.append(
                (
                    filing_date,
                    period_end,
                    idx,
                    weight
                )
            )

        # Sort exclusively by disclosure information, never prices.
        observations.sort(
            key=lambda item: (
                item[0],
                item[1],
                item[2]
            )
        )

        # State contains the most recent eligible report
        # and its latest eligible version for each asset.
        latest_period = [None] * n_assets
        latest_filing = [None] * n_assets
        current_levels = [fallback_level] * n_assets

        weights = []
        observation_cursor = 0
        observation_count = len(observations)

        # Decision dates are already strictly increasing.
        # Sweep through filings once in chronological order.
        for decision_date in decision_dates:

            # Strict inequality is intentional:
            # a filing dated today could have been published
            # after today's market close.
            while (
                observation_cursor < observation_count
                and observations[observation_cursor][0]
                < decision_date
            ):
                (
                    filing_date,
                    period_end,
                    idx,
                    weight
                ) = observations[observation_cursor]

                previous_period = latest_period[idx]
                previous_filing = latest_filing[idx]

                use_observation = (
                    previous_period is None
                    or period_end > previous_period
                    or (
                        period_end == previous_period
                        and (
                            previous_filing is None
                            or filing_date > previous_filing
                        )
                    )
                )

                if use_observation:
                    latest_period[idx] = period_end
                    latest_filing[idx] = filing_date
                    current_levels[idx] = weight

                observation_cursor += 1

            # Cross-sectional centering.
            mean_level = fsum(current_levels) / n_assets

            centered = [
                level - mean_level
                for level in current_levels
            ]

            # Enforce the zero-net construction while reducing
            # floating-point summation residuals.
            if n_assets > 1:
                centered[-1] = -fsum(centered[:-1])

            gross = fsum(abs(value) for value in centered)

            if gross == 0.0:
                # No cross-sectional holdings difference:
                # remain entirely in cash.
                strategy_row = [0.0] * n_assets

            else:
                strategy_row = [
                    value / gross
                    for value in centered
                ]

                # Remove any remaining floating-point net
                # residual and renormalize gross exposure.
                if n_assets > 1:
                    strategy_row[-1] = -fsum(
                        strategy_row[:-1]
                    )

                final_gross = fsum(
                    abs(value)
                    for value in strategy_row
                )

                if final_gross > 1.0:
                    strategy_row = [
                        value / final_gross
                        for value in strategy_row
                    ]

            weights.append(strategy_row)

        return {
            "status": "assumption",
            "reason": (
                "Point-in-time holdings alignment uses only "
                "filings with filing_date strictly earlier than "
                "the decision date. Same-day filings are excluded "
                "because intraday publication times are unavailable. "
                "For each asset, the latest eligible report period "
                "and latest eligible revision are selected; "
                "unobserved assets receive the equal-weight "
                "percentage baseline. Signals are cross-sectionally "
                "centered and gross-normalized, with zero exposure "
                "for constant vectors. Weights correspond to "
                "end-of-day decisions for execution at the next "
                "synthetic session's open and liquidation at its "
                "close. Prices are not used to construct or tune "
                "the strategy; the independent evaluator determines "
                "historical returns."
            ),
            "weights": weights
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            f"Invalid or incomplete input: {exc}"
        )
