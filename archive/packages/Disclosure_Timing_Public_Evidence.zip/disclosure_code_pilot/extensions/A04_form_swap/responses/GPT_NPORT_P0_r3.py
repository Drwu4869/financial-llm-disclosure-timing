from datetime import date, timedelta
from math import fsum, isfinite


def build_strategy(payload):
    """
    Construct a point-in-time, holdings-based, dollar-neutral signal.

    Assumptions:
    - Filings are public third-fiscal-month Form N-PORT observations
      under the 2022-2023 disclosure regime.
    - Third-month holdings become eligible no earlier than 60
      calendar days after the report period ends.
    - Actual availability cannot precede filing_date.
    - Because intraday publication times are unavailable, a record
      is used only on decision dates strictly AFTER its assumed
      public-availability date.
    - Revisions replace earlier versions of the same asset/period.
    - Missing observations use the equal-weight level, 100 / N.
    - Prices are never used to construct or tune the signal.
    - Returned weights are decision-time signals; the evaluator
      independently handles next-session execution and returns.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")
        parsed = date.fromisoformat(value)
        if parsed.isoformat() != value:
            raise ValueError("Dates must use ISO YYYY-MM-DD format.")
        return parsed

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        dates_raw = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]

        if not isinstance(dates_raw, list) or not dates_raw:
            return insufficient("No decision dates provided.")

        if not isinstance(assets, list) or not assets:
            return insufficient("No assets provided.")

        if not isinstance(filings, list):
            return insufficient("Filings must be a list.")

        if (
            any(not isinstance(a, str) or not a for a in assets)
            or len(set(assets)) != len(assets)
        ):
            return insufficient("Asset identifiers must be unique strings.")

        decision_dates = [parse_date(d) for d in dates_raw]

        if any(
            decision_dates[i] <= decision_dates[i - 1]
            for i in range(1, len(decision_dates))
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n_assets = len(assets)
        asset_index = {asset: i for i, asset in enumerate(assets)}
        equal_weight_level = 100.0 / n_assets

        # Events contain:
        # (public_date, asset_index, period_end, filing_date, weight)
        #
        # row_id is an opaque identifier, never a temporal ordering key.
        events = []
        seen_ids = set()
        seen_versions = set()

        for row in filings:
            if not isinstance(row, dict):
                return insufficient("Each filing must be a dictionary.")

            asset = row["asset"]
            row_id = row["row_id"]
            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])

            if asset not in asset_index:
                return insufficient(
                    "A filing references an asset outside the universe."
                )

            if not isinstance(row_id, str) or not row_id:
                return insufficient("Invalid row_id.")

            if row_id in seen_ids:
                return insufficient("Duplicate row_id.")

            seen_ids.add(row_id)

            if filing_date < period_end:
                return insufficient(
                    "A filing date precedes its report period."
                )

            raw_weight = row["weight_pct"]

            if isinstance(raw_weight, bool) or not isinstance(
                raw_weight, (int, float)
            ):
                return insufficient("weight_pct must be numeric.")

            weight = float(raw_weight)

            if not isfinite(weight):
                return insufficient("Non-finite filing weight.")

            # A later filing_date identifies a later revision.
            # Two versions for the same asset, period and filing day
            # cannot be ordered reliably without intraday metadata.
            version_key = (asset, period_end, filing_date)

            if version_key in seen_versions:
                return insufficient(
                    "Ambiguous versions for an asset, period and filing date."
                )

            seen_versions.add(version_key)

            # Third-month N-PORT public disclosure constraint.
            embargo_end = period_end + timedelta(days=60)

            assumed_public_date = max(
                filing_date,
                embargo_end,
            )

            events.append(
                (
                    assumed_public_date,
                    asset_index[asset],
                    period_end,
                    filing_date,
                    weight,
                )
            )

        # Process public-information events chronologically,
        # independently of the input filing-row order.
        events.sort(key=lambda event: event[0])

        # Current selected observation for each asset:
        # (period_end, filing_date)
        latest_version = [None] * n_assets

        # Levels are holdings percentages, not trading weights.
        levels = [equal_weight_level] * n_assets

        weights = []
        event_pos = 0

        for decision_day in decision_dates:

            # Strict inequality prevents same-day publication
            # uncertainty from creating look-ahead bias.
            while (
                event_pos < len(events)
                and events[event_pos][0] < decision_day
            ):
                (
                    _public_date,
                    asset_idx,
                    period_end,
                    filing_date,
                    weight,
                ) = events[event_pos]

                candidate = (period_end, filing_date)
                current = latest_version[asset_idx]

                # Most recent report period takes precedence.
                # Within the same period, latest applicable revision wins.
                if current is None or candidate > current:
                    latest_version[asset_idx] = candidate
                    levels[asset_idx] = weight

                event_pos += 1

            # Exactly equal holdings levels imply a cash position.
            if all(level == levels[0] for level in levels):
                weights.append([0.0] * n_assets)
                continue

            # Cross-sectional demeaning.
            mean_level = fsum(levels) / n_assets
            centered = [
                level - mean_level
                for level in levels
            ]

            # Restore the zero-sum identity against floating-point
            # accumulation error.
            centered[-1] = -fsum(centered[:-1])

            gross = fsum(abs(value) for value in centered)

            if gross == 0.0:
                weights.append([0.0] * n_assets)
                continue

            # Gross-one normalized long/short portfolio.
            signal = [
                value / gross
                for value in centered
            ]

            # Correct residual floating-point net exposure.
            signal[-1] -= fsum(signal)

            # Ensure gross exposure cannot exceed one, including
            # after the small numerical correction above.
            actual_gross = fsum(abs(w) for w in signal)

            if actual_gross > 1.0:
                signal = [
                    w / actual_gross
                    for w in signal
                ]

            weights.append(signal)

        return {
            "status": "assumption",
            "reason": (
                "Uses the latest applicable report period and revision "
                "per asset. Assumes third-month N-PORT data become public "
                "no earlier than max(filing_date, period_end + 60 "
                "calendar days), and excludes same-day disclosures "
                "because intraday times are unknown. Missing holdings "
                "use 100/N; equal centered levels produce cash. "
                "Prices are excluded from signal construction; "
                "next-session execution and return evaluation are "
                "handled independently."
            ),
            "weights": weights,
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            f"Invalid or incomplete input: {exc}"
        )
