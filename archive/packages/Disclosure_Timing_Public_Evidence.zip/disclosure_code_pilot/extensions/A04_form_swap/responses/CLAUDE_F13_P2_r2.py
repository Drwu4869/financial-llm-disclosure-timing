import math
import re
from datetime import date, datetime
from fractions import Fraction

_ISO_DATE = re.compile(r"^(\d{4})-(\d{2})-(\d{2})$")
_QUARTER_ENDS = {(3, 31), (6, 30), (9, 30), (12, 31)}
_DEADLINE_DAYS = 45  # Form 13F deadline under the 2022-2023 regime; informational only, never used as a lag


def _parse_date(value):
    """Strict ISO YYYY-MM-DD string (or a date object). Returns None when unusable."""
    if isinstance(value, datetime):
        if (value.hour, value.minute, value.second, value.microsecond) == (0, 0, 0, 0):
            return value.date()
        return None
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        m = _ISO_DATE.match(value.strip())
        if m:
            try:
                return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            except ValueError:
                return None
    return None


def _to_fraction(value):
    """Exact rational from a numeric value; None for missing, bool, NaN, inf or junk."""
    if value is None or isinstance(value, bool):
        return None
    try:
        if isinstance(value, int):
            return Fraction(value)
        if isinstance(value, str):
            text = value.strip()
            return Fraction(text) if text else None
        f = float(value)
        if not math.isfinite(f):
            return None
        return Fraction(repr(f))
    except (TypeError, ValueError, ZeroDivisionError, OverflowError):
        return None


def _ids(ids, limit=3):
    shown = ", ".join(str(i) for i in ids[:limit])
    return shown + (", ..." if len(ids) > limit else "")


def _signal_row(levels):
    """Demean cross-sectionally, scale to unit gross; zero centered vector -> cash."""
    n = len(levels)
    mean = sum(levels, Fraction(0)) / n
    centered = [v - mean for v in levels]
    gross = sum((abs(c) for c in centered), Fraction(0))
    if gross == 0:
        return [0.0] * n
    row = [float(c / gross) for c in centered]
    g = math.fsum(abs(x) for x in row)
    if g > 1.0:  # guard against float rounding pushing gross above one
        row = [x / g * (1.0 - 1e-12) for x in row]
    return row


def build_strategy(payload):
    def insufficient(msg, weights=None):
        out = {"status": "insufficient_data", "reason": msg}
        if weights is not None:
            out["weights"] = weights
        return out

    if not isinstance(payload, dict):
        return insufficient("Payload must be a mapping with dates, assets, filings and prices.")

    # ---- decision dates (authoritative synthetic session list) ----
    raw_dates = payload.get("dates")
    if not isinstance(raw_dates, (list, tuple)):
        return insufficient("Missing or malformed 'dates' list.")
    dates, bad_dates = [], []
    for x in raw_dates:
        d = _parse_date(x)
        if d is None:
            bad_dates.append(x)
        dates.append(d)
    if bad_dates:
        return insufficient(f"Unparseable decision date(s) {_ids(bad_dates)}; expected ISO YYYY-MM-DD.")
    if not dates:
        return insufficient("No decision dates supplied.", weights=[])

    # ---- asset universe (fixed column order) ----
    raw_assets = payload.get("assets")
    if not isinstance(raw_assets, (list, tuple)) or not raw_assets:
        return insufficient("Missing or empty 'assets' list.")
    if any(a is None or isinstance(a, bool) for a in raw_assets):
        return insufficient("Asset identifiers must be non-empty strings.")
    assets = [str(a) for a in raw_assets]
    if any(not a for a in assets):
        return insufficient("Asset identifiers must be non-empty strings.")
    if len(set(assets)) != len(assets):
        return insufficient("Duplicate asset identifiers make the fixed column order ambiguous.")
    col = {a: i for i, a in enumerate(assets)}
    n = len(assets)

    # ---- filings ----
    raw_filings = payload.get("filings")
    if raw_filings is None:
        return insufficient("No 'filings' supplied; holdings cannot be aligned to decision dates.")
    if not isinstance(raw_filings, (list, tuple)):
        return insufficient("'filings' must be a list of rows.")

    notes = []
    flagged = False
    missing_fd, bad_fd = [], []
    malformed, outside, bad_period, impossible, bad_weight = [], [], [], [], []
    clean, seen = [], set()
    exact_dupes = 0

    for k, row in enumerate(raw_filings):
        if not isinstance(row, dict):
            malformed.append(f"#{k}")
            continue
        rid = str(row.get("row_id", f"#{k}"))
        asset = row.get("asset")
        if asset is None or isinstance(asset, bool):
            malformed.append(rid)
            continue
        asset = str(asset)
        if asset not in col:
            outside.append(rid)
            continue
        if "filing_date" not in row or row.get("filing_date") in (None, ""):
            missing_fd.append(rid)
            continue
        fd = _parse_date(row.get("filing_date"))
        if fd is None:
            bad_fd.append(rid)
            continue
        pe = _parse_date(row.get("period_end"))
        if pe is None:
            bad_period.append(rid)
            continue
        if pe > fd:
            impossible.append(rid)
            continue
        val = _to_fraction(row.get("weight_pct"))
        if val is None or val < 0:
            bad_weight.append(rid)
            continue
        key = (rid, asset, pe, fd, val)
        if key in seen:
            exact_dupes += 1
            continue
        seen.add(key)
        clean.append((asset, pe, fd, val, rid))

    if missing_fd or bad_fd:
        parts = []
        if missing_fd:
            parts.append(f"{len(missing_fd)} in-universe row(s) lack an actual filing_date (e.g. {_ids(missing_fd)})")
        if bad_fd:
            parts.append(f"{len(bad_fd)} row(s) have an unparseable filing_date (e.g. {_ids(bad_fd)})")
        return insufficient(
            "; ".join(parts)
            + ". Exact historical alignment cannot be established from these inputs: "
              "no filing dates or fixed reporting lag were invented and period_end is not used as a proxy."
        )

    # ---- one value per (asset, period, filing day); detect revisions/conflicts ----
    groups = {}
    for asset, pe, fd, val, rid in clean:
        groups.setdefault((asset, pe, fd), []).append((rid, val))

    events, conflicts = [], []
    redundant = 0
    for (asset, pe, fd), items in groups.items():
        distinct = sorted({v for _, v in items})
        if len(distinct) > 1:
            conflicts.append(items[0][0])
            value = sum(distinct, Fraction(0)) / len(distinct)
        else:
            value = distinct[0]
            redundant += len(items) - 1
        events.append((fd, pe, asset, value))
    events.sort(key=lambda e: (e[0], e[1], e[2]))

    versions = {}
    for (asset, pe, fd) in groups:
        versions.setdefault((asset, pe), set()).add(fd)
    revised = sum(1 for s in versions.values() if len(s) > 1)
    non_qe = sum(1 for (_, pe) in versions if (pe.month, pe.day) not in _QUARTER_ENDS)
    late = sum(1 for (_, pe, fd) in groups if (fd - pe).days > _DEADLINE_DAYS)

    # ---- notes ----
    if malformed:
        flagged = True
        notes.append(f"Excluded {len(malformed)} malformed row(s) ({_ids(malformed)}).")
    if outside:
        notes.append(f"Ignored {len(outside)} row(s) for assets outside the universe.")
    if bad_period:
        flagged = True
        notes.append(f"Excluded {len(bad_period)} row(s) with unparseable period_end ({_ids(bad_period)}).")
    if impossible:
        flagged = True
        notes.append(f"Excluded {len(impossible)} row(s) filed before their period_end ({_ids(impossible)}).")
    if bad_weight:
        flagged = True
        notes.append(f"Excluded {len(bad_weight)} row(s) with missing, non-finite or negative weight_pct ({_ids(bad_weight)}).")
    if exact_dupes:
        notes.append(f"Dropped {exact_dupes} exact duplicate row(s).")
    if redundant:
        notes.append(f"Merged {redundant} redundant same-day row(s) with identical weights.")
    if conflicts:
        flagged = True
        notes.append(f"{len(conflicts)} asset/period(s) had conflicting same-day versions with no intraday order; "
                     f"their distinct values were averaged ({_ids(conflicts)}).")
    if revised:
        flagged = True
        notes.append(f"{revised} asset/period(s) had multiple filed versions despite the one-version premise; "
                     "each was used only from its own filing date.")
    if non_qe:
        flagged = True
        notes.append(f"{non_qe} asset/period(s) have a non-quarter-end period_end; used as given.")
    if late:
        notes.append(f"{late} version(s) were filed more than {_DEADLINE_DAYS} days after period end; "
                     "their actual filing dates were used.")
    if any(b <= a for a, b in zip(dates, dates[1:])):
        flagged = True
        notes.append("Dates are not strictly increasing; each output row is computed for its own date in input order.")
    if n == 1:
        notes.append("Single-asset universe: the centered vector is always zero, so every decision is cash.")
    if not events:
        notes.append("No usable filings: every decision is cash.")

    # ---- point-in-time sweep over decision dates ----
    ew = Fraction(100, n)              # equal-weight level, in portfolio percent
    state = [None] * n                 # per asset: (period_end, filing_date, level)
    current = [0.0] * n                # all assets at the equal-weight level -> cash
    by_date, idx = {}, 0
    for d in sorted(set(dates)):
        changed = False
        while idx < len(events) and events[idx][0] <= d:   # usable at end of its filing day
            fd, pe, asset, value = events[idx]
            j = col[asset]
            cur = state[j]
            # newer report period wins; same period -> later-filed version wins;
            # a late-filed older period never displaces a newer one
            if cur is None or pe > cur[0] or (pe == cur[0] and fd >= cur[1]):
                state[j] = (pe, fd, value)
                changed = True
            idx += 1
        if changed:
            current = _signal_row([s[2] if s is not None else ew for s in state])
        by_date[d] = current

    weights = [list(by_date[d]) for d in dates]
    first_live = next((d.isoformat() for d, w in zip(dates, weights) if any(x != 0.0 for x in w)), None)

    base = (
        "Point-in-time 13F alignment on actual SEC filing dates: each row becomes usable at the end of its "
        "filing_date (the first listed date on or after it) and is traded at the next listed session's open; "
        "period_end is never used as a proxy and no fixed lag is assumed. Per asset, the latest period_end "
        "already filed is used, with the latest-filed version of that period; versions are never carried "
        "backward. Assets with no applicable filing sit at the equal-weight level (100/N%). The vector is "
        "demeaned and scaled to unit gross exposure (net zero); a zero centered vector is cash. Prices are not used."
    )
    summary = f" {len(events)} usable version(s); first non-cash decision: {first_live or 'none'}."
    reason = base + summary + ("" if not notes else " " + " ".join(notes))

    return {"status": "assumption" if flagged else "ok", "reason": reason, "weights": weights}
