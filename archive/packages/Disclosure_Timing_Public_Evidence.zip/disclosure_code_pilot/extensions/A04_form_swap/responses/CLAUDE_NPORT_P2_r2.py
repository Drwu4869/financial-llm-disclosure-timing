def build_strategy(payload):
    """Point-in-time, holdings-based cross-sectional signal from public N-PORT records.

    Row t of the output is the target book decided at the end of dates[t]. It uses only
    records whose own filing_date is on or before dates[t]; the evaluator executes it at
    the next listed session. Prices are never read.
    """
    import math
    import re
    from datetime import date, datetime
    from fractions import Fraction

    iso_re = re.compile(r"\d{4}-\d{2}-\d{2}")

    def parse_date(x):
        if isinstance(x, datetime):
            return x.date()
        if isinstance(x, date):
            return x
        if isinstance(x, str):
            s = x.strip()
            if iso_re.fullmatch(s):
                try:
                    return date.fromisoformat(s)
                except ValueError:
                    return None
        return None

    def parse_weight(x):
        if x is None or isinstance(x, bool):
            return None
        try:
            v = float(x.strip() if isinstance(x, str) else x)
        except (TypeError, ValueError, OverflowError):
            return None
        return Fraction(v) if math.isfinite(v) else None

    def to_weights(levels):
        # Exact rational centering and L1 scaling, then a single rounding to float.
        m = len(levels)
        mean = sum(levels, Fraction(0)) / m
        centered = [x - mean for x in levels]
        gross = sum((abs(x) for x in centered), Fraction(0))
        if gross == 0:
            return [0.0] * m  # centered vector is zero -> cash
        w = [float(x / gross) for x in centered]
        # Guard against float rounding pushing gross a few ulps above one.
        for _ in range(64):
            if math.fsum(abs(x) for x in w) <= 1.0:
                break
            w = [math.nextafter(x, 0.0) for x in w]
        return [x + 0.0 for x in w]

    def insufficient(msg):
        return {"status": "insufficient_data", "reason": msg}

    # ---------------- validate the frame ----------------
    if not isinstance(payload, dict):
        return insufficient("Payload must be a mapping with dates, assets, filings and prices.")
    raw_dates = payload.get("dates")
    raw_assets = payload.get("assets")
    filings = payload.get("filings")

    if not isinstance(raw_dates, (list, tuple)) or not raw_dates:
        return insufficient("No decision dates supplied.")
    if not isinstance(raw_assets, (list, tuple)) or not raw_assets:
        return insufficient("No assets supplied.")

    idx = {}
    try:
        for j, a in enumerate(raw_assets):
            if a in idx:
                return insufficient(f"Duplicate asset column {a!r}; the universe is ambiguous.")
            idx[a] = j
    except TypeError:
        return insufficient("Asset identifiers must be hashable labels.")
    n = len(raw_assets)

    dates = []
    for d in raw_dates:
        pd_ = parse_date(d)
        if pd_ is None:
            return insufficient(f"Decision date {d!r} is not an ISO YYYY-MM-DD date.")
        dates.append(pd_)

    if filings is None:
        return insufficient("No filings field supplied; holdings cannot be aligned to decision days.")
    if not isinstance(filings, (list, tuple)):
        return insufficient("filings must be a list of rows.")

    # ---------------- parse filing rows ----------------
    n_nondict = n_unknown = n_bad_period = n_bad_weight = n_premature = 0
    n_missing_fd = 0
    in_universe = 0
    groups = {}  # (asset, period_end, filing_date) -> list of weight values

    for row in filings:
        if not isinstance(row, dict):
            n_nondict += 1
            continue
        a = row.get("asset")
        try:
            known = a in idx
        except TypeError:
            known = False
        if not known:
            n_unknown += 1
            continue
        in_universe += 1
        fd = parse_date(row.get("filing_date"))
        if fd is None:
            n_missing_fd += 1
            continue
        pe = parse_date(row.get("period_end"))
        if pe is None:
            n_bad_period += 1
            continue
        v = parse_weight(row.get("weight_pct"))
        if v is None:
            n_bad_weight += 1
            continue
        if fd < pe:
            # A public record of holdings cannot predate its own as-of date.
            n_premature += 1
            continue
        groups.setdefault((a, pe, fd), []).append(v)

    if n_missing_fd:
        return insufficient(
            f"filing_date is absent or not an ISO date for {n_missing_fd} of {in_universe} "
            "in-universe rows: exact historical alignment cannot be established from these "
            "inputs, and period_end or a fixed filing lag will not be substituted for actual "
            "public filing dates."
        )

    # ---------------- build version events ----------------
    events = []
    n_conflict = n_dupe = 0
    version_count = {}
    for (a, pe, fd), vals in groups.items():
        uniq = sorted(set(vals))
        n_dupe += len(vals) - len(uniq)
        if len(uniq) > 1:
            # Same asset/period/filing day with different values: intraday order is
            # unknowable and row_id is opaque, so use the mean of the distinct values.
            n_conflict += 1
            val = sum(uniq, Fraction(0)) / len(uniq)
        else:
            val = uniq[0]
        events.append((fd, pe, idx[a], val))
        version_count[(a, pe)] = version_count.get((a, pe), 0) + 1
    n_multi = sum(1 for c in version_count.values() if c > 1)
    events.sort(key=lambda e: (e[0], e[1], e[2]))

    # ---------------- point-in-time sweep over decision days ----------------
    eq_level = Fraction(100, n)          # equal-weight level in weight_pct units
    level = [eq_level] * n
    best_period = {}                     # asset index -> latest period_end filed so far
    latest_val = {}                      # (asset index, period_end) -> latest version filed so far
    cache = {}
    by_date = {}
    k = 0
    for d in sorted(set(dates)):
        while k < len(events) and events[k][0] <= d:
            fd, pe, j, val = events[k]
            latest_val[(j, pe)] = val    # later filing date overwrites; never applied earlier
            bp = best_period.get(j)
            if bp is None or pe > bp:
                best_period[j] = pe
                bp = pe
            level[j] = latest_val[(j, bp)]
            k += 1
        key = tuple(level)
        w = cache.get(key)
        if w is None:
            w = to_weights(key)
            cache[key] = w
        by_date[d] = w

    weights = [list(by_date[d]) for d in dates]

    # ---------------- status and reason ----------------
    assumption = False
    notes = []
    if any(dates[i] >= dates[i + 1] for i in range(len(dates) - 1)):
        assumption = True
        notes.append("dates are not strictly increasing; each row still uses only records filed on or before its own date")
    if n_unknown:
        assumption = True
        notes.append(f"{n_unknown} row(s) for assets outside the universe ignored")
    if n_nondict:
        assumption = True
        notes.append(f"{n_nondict} malformed row(s) ignored")
    if n_bad_period:
        assumption = True
        notes.append(f"{n_bad_period} row(s) with invalid period_end excluded")
    if n_bad_weight:
        assumption = True
        notes.append(f"{n_bad_weight} row(s) with missing/non-finite weight_pct excluded (asset keeps its prior applicable version or equal weight)")
    if n_premature:
        assumption = True
        notes.append(f"{n_premature} row(s) with filing_date before period_end treated as invalid and excluded")
    if n_conflict:
        assumption = True
        notes.append(f"{n_conflict} asset/period/filing-day group(s) had conflicting values and were averaged (row_id not used for ordering)")
    if n_multi:
        notes.append(f"{n_multi} asset/period(s) have several filed versions; each applies only from its own filing date")
    if n_dupe:
        notes.append(f"{n_dupe} identical duplicate row(s) collapsed")

    sessions = set(dates)
    lo, hi = min(dates), max(dates)
    off = len({e[0] for e in events if lo <= e[0] <= hi and e[0] not in sessions})
    if off:
        notes.append(f"{off} filing date(s) are not listed sessions; those records first enter the next listed decision day")
    if not events:
        notes.append("no usable filings, so every asset sits at the equal-weight level and all rows are cash")
    elif n == 1:
        notes.append("single asset, so the centered vector is always zero and all rows are cash")
    n_cash = sum(1 for row in weights if all(x == 0.0 for x in row))
    notes.append(f"{n_cash} of {len(weights)} rows are cash")

    reason = (
        "Point-in-time alignment on actual SEC filing dates: each public third-fiscal-month "
        "N-PORT record is usable from the end of its own filing_date, so the row for decision "
        "day d uses, per asset, the latest period_end among records filed on or before d and, "
        "within that period, the latest version filed by d (no revision is applied before its "
        "own filing date; period_end and fixed lags are not used for timing). Assets with no "
        "such record take the equal-weight level 100/N%. The vector is demeaned and scaled to "
        "unit gross exposure with zero net, or cash when the centered vector is zero. Weights "
        "are formed at d's close for execution at the next listed session; prices are not read."
    )
    reason += " Notes: " + "; ".join(notes) + "."

    return {
        "status": "assumption" if assumption else "ok",
        "reason": reason,
        "weights": weights,
    }
