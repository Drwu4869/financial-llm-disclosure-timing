from datetime import date
from fractions import Fraction
from math import fsum


def build_strategy(payload):
    """
    Construct a point-in-time, holdings-based, dollar-neutral portfolio.

    Timing:
      - period_end is the holdings observation date, not its publication date.
      - filing_date determines when information becomes publicly available.
      - Because intraday filing times are unavailable, a filing is eligible
        only on decision dates strictly later than its filing_date.
      - The supplied decision dates are authoritative; no exchange calendar
        or assumed reporting lag is introduced.

    Selection:
      - For each asset, use its latest eligible report period.
      - Within that period, use the latest eligible filed version.
      - Until an asset has an eligible observation, use 100 / N percent.
      - Center cross-sectionally and normalize gross exposure to one.
      - Return cash if all centered observations are zero.

    Prices are intentionally unused. The evaluator independently calculates
    next-session open-to-close returns.

    Returns:
        {
            "status": "ok" | "assumption" | "insufficient_data",
            "reason": str,
            "weights": list[list[float]]
        }
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be YYYY-MM-DD strings.")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Dates must use YYYY-MM-DD format.")

        return parsed

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        dates_raw = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]

        if not isinstance(dates_raw, (list, tuple)) or not dates_raw:
            return insufficient("At least one decision date is required.")

        if not isinstance(assets, (list, tuple)) or not assets:
            return insufficient("At least one asset is required.")

        if not isinstance(filings, (list, tuple)):
            return insufficient("Filings must be a list.")

        if any(not isinstance(asset, str) for asset in assets):
            return insufficient("Asset identifiers must be strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        decision_dates = [parse_date(value) for value in dates_raw]

        if decision_dates != sorted(decision_dates):
            return insufficient("Decision dates must be chronological.")

        asset_set = set(assets)
        decision_date_set = set(decision_dates)
        n_assets = len(assets)

        # Equal-weight baseline expressed in the same percentage units
        # as weight_pct. Fractions avoid unnecessary rounding errors.
        baseline = Fraction(100, n_assets)

        # A version is identified by asset, period_end, and filing_date.
        # row_id is opaque and must never be used to infer chronology.
        versions = {}
        seen_row_ids = set()

        for record in filings:
            if not isinstance(record, dict):
                return insufficient("Each filing row must be a dictionary.")

            row_id = record["row_id"]
            asset = record["asset"]
            period_end = parse_date(record["period_end"])
            filing_date = parse_date(record["filing_date"])
            raw_weight = record["weight_pct"]

            if not isinstance(row_id, str) or not row_id:
                return insufficient("Each row_id must be a nonempty string.")

            if row_id in seen_row_ids:
                return insufficient("Duplicate row_id encountered.")

            seen_row_ids.add(row_id)

            if not isinstance(asset, str):
                return insufficient("Filing asset identifiers must be strings.")

            if isinstance(raw_weight, bool) or not isinstance(
                raw_weight, (int, float)
            ):
                return insufficient("weight_pct must be a finite number.")

            weight = Fraction(str(raw_weight))

            if filing_date < period_end:
                return insufficient(
                    "A filing cannot precede its holdings report period."
                )

            # Securities outside the supplied fixed universe cannot
            # contribute to its cross-sectional signal.
            if asset not in asset_set:
                continue

            key = (asset, period_end, filing_date)

            if key in versions and versions[key] != weight:
                return insufficient(
                    "Conflicting versions share an asset, report period, "
                    "and filing date; their order cannot be determined."
                )

            versions[key] = weight

        # Sort by public filing date, rather than by holdings period or row_id.
        # This makes incremental historical processing point-in-time safe.
        events = sorted(
            (filing_date, period_end, asset, weight)
            for (asset, period_end, filing_date), weight
            in versions.items()
        )

        # Per-asset selected observation:
        # asset -> (period_end, filing_date, weight_pct)
        latest = {}

        event_index = 0
        weights = []

        for decision_date in decision_dates:

            # Strict inequality is the conservative publication-time rule.
            # Same-day filings cannot be assumed available at market close.
            while (
                event_index < len(events)
                and events[event_index][0] < decision_date
            ):
                filing_date, period_end, asset, weight = events[event_index]

                previous = latest.get(asset)

                if (
                    previous is None
                    or (period_end, filing_date)
                    > (previous[0], previous[1])
                ):
                    latest[asset] = (
                        period_end,
                        filing_date,
                        weight,
                    )

                event_index += 1

            # Build holdings levels in the exact supplied asset order.
            levels = [
                latest[asset][2] if asset in latest else baseline
                for asset in assets
            ]

            # Exact cross-sectional centering.
            cross_sectional_mean = sum(
                levels, Fraction(0)
            ) / n_assets

            centered = [
                level - cross_sectional_mean
                for level in levels
            ]

            gross = sum(
                (abs(value) for value in centered),
                Fraction(0),
            )

            if gross == 0:
                # Identical holdings levels carry no relative signal.
                row = [0.0] * n_assets

            else:
                # Exact rational normalization before float conversion.
                row = [
                    float(value / gross)
                    for value in centered
                ]

                # Remove floating-point net-exposure drift.
                row[-1] = -sum(row[:-1])

                # Guard against tiny gross-exposure overshoots caused
                # by floating-point conversion and neutrality correction.
                if fsum(abs(value) for value in row) > 1.0:
                    scale = 1.0 - 1e-12

                    row = [
                        value * scale
                        for value in row
                    ]

                    row[-1] = -sum(row[:-1])

            weights.append(row)

        # A same-day filing creates a genuine availability ambiguity
        # because the payload contains no intraday publication timestamp.
        same_day_ambiguity = any(
            filing_date in decision_date_set
            for filing_date, _, _, _ in events
        )

        status = "assumption" if same_day_ambiguity else "ok"

        reason = (
            "Point-in-time alignment uses filing_date, not period_end, "
            "as the public-information timestamp. Because intraday "
            "publication times are unavailable, filings become eligible "
            "only on decision dates strictly after filing_date. "
            "For each asset, the latest eligible report period and "
            "then latest filed version are selected; earlier values "
            "persist until superseded. Assets without observations "
            "use the equal-weight baseline. Signals are centered, "
            "gross-normalized, and net-neutral. Prices are not used; "
            "execution and returns are evaluated independently."
        )

        return {
            "status": status,
            "reason": reason,
            "weights": weights,
        }

    except (KeyError, TypeError, ValueError, OverflowError, ZeroDivisionError) as exc:
        return insufficient(
            f"Invalid or incomplete input data: {exc}"
        )
