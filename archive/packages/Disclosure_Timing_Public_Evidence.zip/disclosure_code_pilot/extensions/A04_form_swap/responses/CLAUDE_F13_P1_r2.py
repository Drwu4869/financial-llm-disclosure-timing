import math
from datetime import date, datetime
from fractions import Fraction


def build_strategy(payload):
    """Holdings-based 13F signal with point-in-time alignment on filing_date.

    Row t of `weights` is decided at the end of dates[t]. It is meant to be
    traded at the next session's open and liquidated at that session's close.
    Prices are never read, so no parameter can be fitted to them.
    """

    # ---------------- helpers ----------------
    def to_date(x):
        if isinstance(x, datetime):
            return x.date()
        if isinstance(x, date):
            return x
        if isinstance(x, str):
            s = x.strip()
            if len(s) > 10 and s[10] in "T ":
                s = s[:10]
            try:
                return date.fromisoformat(s)
            except ValueError:
                return None
        return None

    def to_frac(x):
        # Exact rational parsing, so equal levels centre to exactly zero (cash)
        # instead of producing float noise that normalisation would blow up.
        if x is None or isinstance(x, bool):
            return None
        if isinstance(x, int):
            return Fraction(x)
        if isinstance(x, str):
            s = x.strip()
            if s.endswith("%"):
                s = s[:-1].strip()
            try:
                return Fraction(s)
            except (ValueError, ZeroDivisionError):
                return None
        try:
            f = float(x)
        except (TypeError, ValueError, OverflowError):
            return None
        if not math.isfinite(f):
            return None
        return Fraction(repr(f))

    def name(a):
        return None if a is None else str(a).strip()

    def is_quarter_end(d):
        return (d.month, d.day) in ((3, 31), (6, 30), (9, 30), (12, 31))

    def to_float_toward_zero(q):
        # Rounding toward zero guarantees the exact sum of |weights| is <= 1.
        if q == 0:
            return 0.0
        f = float(q)
        if abs(Fraction(f)) > abs(q):
            f = math.nextafter(f, 0.0)
        return f

    def normalise(levels):
        mean = sum(levels, Fraction(0)) / len(levels)
        centred = [v - mean for v in levels]
        gross = sum((abs(c) for c in centred), Fraction(0))
        if gross == 0:
            return [0.0] * len(levels)  # cash
        return [to_float_toward_zero(c / gross) for c in centred]

    def insufficient(msg):
        return {"status": "insufficient_data", "reason": msg}

    # ---------------- validate the frame ----------------
    if not isinstance(payload, dict):
        return insufficient("Payload is not a mapping.")

    raw_dates = payload.get("dates")
    if not isinstance(raw_dates, (list, tuple)) or not raw_dates:
        return insufficient("No decision dates supplied.")
    dates = [to_date(d) for d in raw_dates]
    if any(d is None for d in dates):
        return insufficient("A decision date is not a valid ISO YYYY-MM-DD date.")

    raw_assets = payload.get("assets")
    if not isinstance(raw_assets, (list, tuple)) or not raw_assets:
        return insufficient("No assets supplied.")
    assets = [name(a) for a in raw_assets]
    if any(a in (None, "") for a in assets) or len(set(assets)) != len(assets):
        return insufficient("Asset list has blank or duplicate names; columns are ambiguous.")

    raw_rows = payload.get("filings")
    if raw_rows is None:
        raw_rows = []
    if not isinstance(raw_rows, (list, tuple)):
        return insufficient("Filings is not a list of rows.")

    n = len(assets)
    col = {a: i for i, a in enumerate(assets)}

    # ---------------- clean filing rows ----------------
    skipped = {
        "malformed": 0,
        "unknown asset": 0,
        "missing/invalid date": 0,
        "invalid weight_pct": 0,
        "filing_date before period_end": 0,
    }
    non_quarter = 0
    obs = []        # (filing_date, asset_idx, period_end, value)
    versions = {}   # (asset_idx, period_end) -> {filing_date: set(values)}

    for r in raw_rows:
        if not isinstance(r, dict):
            skipped["malformed"] += 1
            continue
        ai = col.get(name(r.get("asset")))
        if ai is None:
            skipped["unknown asset"] += 1
            continue
        pe = to_date(r.get("period_end"))
        fd = to_date(r.get("filing_date"))
        if pe is None or fd is None:
            # Without a filing date the public-availability time is unknown,
            # so the row cannot be used without risking look-ahead.
            skipped["missing/invalid date"] += 1
            continue
        v = to_frac(r.get("weight_pct"))
        if v is None or v < 0 or v > 100:
            # 13F reports long positions only, as a share of the reported portfolio.
            skipped["invalid weight_pct"] += 1
            continue
        if fd < pe:
            # A 13F cannot be filed before its report period ends.
            skipped["filing_date before period_end"] += 1
            continue
        if not is_quarter_end(pe):
            non_quarter += 1
        obs.append((fd, ai, pe, v))
        versions.setdefault((ai, pe), {}).setdefault(fd, set()).add(v)

    # ---------------- point-in-time sweep ----------------
    # Filing dates carry no intraday time, so a row filed on day D is first
    # used at the end of the first supplied date strictly after D.
    obs.sort(key=lambda t: t[0])
    equal_level = Fraction(100, n)
    newest = {}                 # (ai, pe) -> (filing_date, [values]) latest public version
    best_period = [None] * n    # latest public period_end per asset
    ptr = 0
    cache = {}
    weights = [None] * len(dates)
    used_filing = False

    for i in sorted(range(len(dates)), key=lambda k: dates[k]):
        d = dates[i]
        if d not in cache:
            while ptr < len(obs) and obs[ptr][0] < d:
                fd, ai, pe, v = obs[ptr]
                ptr += 1
                cur = newest.get((ai, pe))
                if cur is None or fd > cur[0]:
                    newest[(ai, pe)] = (fd, [v])   # later filing restates the period
                else:                               # same filing_date (rows are sorted)
                    cur[1].append(v)
                if best_period[ai] is None or pe > best_period[ai]:
                    best_period[ai] = pe
            levels = []
            for ai in range(n):
                pe = best_period[ai]
                if pe is None:
                    levels.append(equal_level)
                else:
                    vals = newest[(ai, pe)][1]
                    levels.append(sum(vals, Fraction(0)) / len(vals))
                    used_filing = True
            cache[d] = normalise(levels)
        weights[i] = list(cache[d])

    # ---------------- reason ----------------
    reason = (
        "Point-in-time 13F alignment: a row is used only on decision dates strictly after "
        "its filing_date (no intraday filing time, so same-day use is not assumed); row t "
        "trades at the next session's open. Per asset: latest period_end among public rows, "
        "using its latest-filed version; equal-weight level 100/N before any. The vector is "
        "demeaned and scaled to gross 1, net 0; a zero vector is cash. Prices are not used."
    )
    notes = []
    if any(dates[k] >= dates[k + 1] for k in range(len(dates) - 1)):
        notes.append("dates not strictly increasing; rows kept in input order, each "
                     "using only filings dated before its own date")
    dropped = {k: v for k, v in skipped.items() if v}
    if dropped:
        notes.append("ignored rows: " + ", ".join(f"{v} {k}" for k, v in dropped.items()))
    if non_quarter:
        notes.append(f"{non_quarter} row(s) with a non-quarter-end period_end kept as given")
    revised = sum(1 for fds in versions.values() if len(fds) > 1)
    if revised:
        notes.append(f"{revised} asset/period(s) had several filing dates; "
                     "the latest public one was used")
    conflicted = sum(1 for fds in versions.values() for vals in fds.values() if len(vals) > 1)
    if conflicted:
        notes.append(f"{conflicted} same-day conflicting version(s) averaged "
                     "(row_id is opaque, not an ordering)")
    if notes:
        reason += " Notes: " + "; ".join(notes) + "."

    if not used_filing:
        return {
            "status": "insufficient_data",
            "reason": "No valid 13F row was public before any decision date, so every "
                      "row is cash. " + reason,
            "weights": weights,
        }

    return {"status": "assumption", "reason": reason, "weights": weights}
