import math
import re
import datetime as _dt
from fractions import Fraction

_ISO_DATE = re.compile(r"\d{4}-\d{2}-\d{2}")
_QUARTER_ENDS = frozenset({(3, 31), (6, 30), (9, 30), (12, 31)})


def _parse_date(value):
    """Strict YYYY-MM-DD string (or a plain date object). Anything else -> None."""
    if isinstance(value, _dt.datetime):
        return None  # a time component would be ambiguous; schema has dates only
    if isinstance(value, _dt.date):
        return value
    if isinstance(value, str):
        s = value.strip()
        if _ISO_DATE.fullmatch(s):
            try:
                return _dt.date.fromisoformat(s)
            except ValueError:
                return None
    return None


def _parse_weight(value):
    """Finite number -> exact Fraction (floats read via their decimal repr). Else None."""
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, Fraction):
        return value
    if isinstance(value, int):
        return Fraction(value)
    try:
        f = float(value.strip() if isinstance(value, str) else value)
    except (TypeError, ValueError, OverflowError):
        return None
    if not math.isfinite(f):
        return None
    if isinstance(value, str):
        try:
            return Fraction(value.strip())
        except (ValueError, ZeroDivisionError):
            pass
    return Fraction(repr(f))


def _signal(values, equal_level):
    """Demean, scale to unit gross exposure. Exact arithmetic; zero vector -> cash."""
    x = [equal_level if v is None else v for v in values]
    mean = sum(x, Fraction(0)) / len(x)
    centered = [v - mean for v in x]
    gross = sum((abs(v) for v in centered), Fraction(0))
    if gross == 0:
        return [0.0] * len(x), False
    w = [float(v / gross) for v in centered]
    if math.fsum(abs(v) for v in w) > 1.0:  # guard against float rounding above 1
        scale = (1 - Fraction(1, 10 ** 12)) / gross
        w = [float(v * scale) for v in centered]
    return w, True


def build_strategy(payload):
    def insufficient(msg, weights=None):
        out = {"status": "insufficient_data", "reason": msg}
        if weights is not None:
            out["weights"] = weights
        return out

    # ---------- structural validation ----------
    if not isinstance(payload, dict):
        return insufficient("Payload is not a mapping with dates/assets/filings.")
    raw_dates = payload.get("dates")
    raw_assets = payload.get("assets")
    raw_filings = payload.get("filings")

    if not isinstance(raw_dates, (list, tuple)) or len(raw_dates) == 0:
        return insufficient("No decision dates supplied.")
    if not isinstance(raw_assets, (list, tuple)) or len(raw_assets) == 0:
        return insufficient("No assets supplied.")
    if raw_filings is None:
        raw_filings = []
    if not isinstance(raw_filings, (list, tuple)):
        return insufficient("Filings are not a list of rows.")

    assets = [str(a) for a in raw_assets]
    if len(set(assets)) != len(assets):
        return insufficient("Asset list contains duplicates; column mapping is ambiguous.")
    col = {a: j for j, a in enumerate(assets)}
    n = len(assets)

    dates = []
    for k, raw in enumerate(raw_dates):
        d = _parse_date(raw)
        if d is None:
            return insufficient(f"Decision date at position {k} is not a valid YYYY-MM-DD date.")
        dates.append(d)
    cash_rows = [[0.0] * n for _ in dates]

    notes = []
    flagged = False
    if any(b <= a for a, b in zip(dates, dates[1:])):
        notes.append("decision dates not strictly increasing; each row computed as of its own date, "
                     "kept in input order")
        flagged = True

    # ---------- clean filing rows ----------
    excluded = {}

    def drop(why):
        excluded[why] = excluded.get(why, 0) + 1

    groups = {}  # (asset column, period_end, filing_date) -> set of distinct weights
    off_quarter = 0
    for row in raw_filings:
        if not isinstance(row, dict):
            drop("malformed row")
            continue
        a = row.get("asset")
        j = col.get(str(a)) if a is not None else None
        if j is None:
            drop("asset outside universe")
            continue
        pe = _parse_date(row.get("period_end"))
        if pe is None:
            drop("invalid period_end")
            continue
        fd = _parse_date(row.get("filing_date"))
        if fd is None:
            drop("missing/invalid filing_date")
            continue
        w = _parse_weight(row.get("weight_pct"))
        if w is None:
            drop("non-numeric weight_pct")
            continue
        if fd < pe:
            drop("filing_date before period_end")
            continue
        if (pe.month, pe.day) not in _QUARTER_ENDS:
            off_quarter += 1
        groups.setdefault((j, pe, fd), set()).add(w)

    events = []
    conflicts = 0
    version_count = {}
    for (j, pe, fd), vals in groups.items():
        if len(vals) > 1:
            # Same asset/period/filing day with different weights: row_id is opaque and
            # cannot order them, so use the mean of the distinct values.
            conflicts += 1
            val = sum(vals, Fraction(0)) / len(vals)
        else:
            val = next(iter(vals))
        events.append((fd, j, pe, val))
        version_count[(j, pe)] = version_count.get((j, pe), 0) + 1
    events.sort(key=lambda e: (e[0], e[1], e[2]))
    restated = sum(1 for c in version_count.values() if c > 1)

    if excluded:
        notes.append("excluded rows: " + ", ".join(f"{k}={v}" for k, v in sorted(excluded.items())))
        flagged = True
    if conflicts:
        notes.append(f"{conflicts} asset/period/filing-day group(s) had conflicting weights; averaged")
        flagged = True
    if restated:
        notes.append(f"{restated} asset/period(s) have several filed versions (schema expects one); "
                     "each version applied only from its own filing_date")
        flagged = True
    if off_quarter:
        notes.append(f"{off_quarter} row(s) with non-quarter-end period_end kept as reported")
        flagged = True

    if not events:
        return insufficient("No usable 13F rows for the asset universe"
                            + (" (" + "; ".join(notes) + ")" if notes else "")
                            + "; all-cash rows returned.", cash_rows)

    same_day = len({e[0] for e in events} & set(dates))
    if same_day:
        notes.append(f"{same_day} filing date(s) coincide with decision dates; those filings were "
                     "deferred to the next decision (no intraday acceptance time)")
        flagged = True

    # ---------- point-in-time sweep ----------
    equal_level = Fraction(100, n)  # equal-weight level in weight_pct units
    cur_period = [None] * n
    cur_value = [None] * n
    out = [None] * len(dates)
    ptr = 0
    row, active, dirty = [0.0] * n, False, True
    active_days = 0
    for i in sorted(range(len(dates)), key=lambda k: dates[k]):
        d = dates[i]
        # Strict inequality: a filing dated d is public only after the end-of-day-d decision.
        while ptr < len(events) and events[ptr][0] < d:
            fd, j, pe, val = events[ptr]
            if cur_period[j] is None or pe >= cur_period[j]:
                # newer report period, or a later-filed restatement of the current period
                cur_period[j] = pe
                cur_value[j] = val
                dirty = True
            # older-period restatements never displace a newer period
            ptr += 1
        if dirty:
            row, active = _signal(cur_value, equal_level)
            dirty = False
        out[i] = list(row)
        if active:
            active_days += 1

    notes.append(f"signal non-zero on {active_days} of {len(dates)} dates")

    reason = (
        "Aligned on SEC filing_date, not period_end: a row is usable at decision date d only if "
        "filing_date < d (intraday acceptance times are absent), so it first enters the weights decided "
        "at the end of the first supplied session after filing and is traded at the following open. "
        "Per asset: latest report period public at d, latest-filed version of that period; absence from a "
        "later report is not read as zero. No public observation -> equal-weight level 100/N%. "
        "Vector demeaned and scaled to gross 1, net 0; zero vector -> cash. Prices are not used. "
        "Notes: " + "; ".join(notes) + "."
    )
    return {
        "status": "assumption" if flagged else "ok",
        "reason": reason,
        "weights": out,
    }
