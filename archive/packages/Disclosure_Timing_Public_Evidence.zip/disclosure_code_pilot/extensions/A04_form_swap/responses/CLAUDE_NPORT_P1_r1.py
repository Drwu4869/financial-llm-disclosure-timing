import math
from datetime import date, datetime, timedelta
from fractions import Fraction

# Form N-PORT regime in force during 2022-2023: the three monthly reports of a fiscal quarter are
# filed within 60 days of quarter end. Only the third-month report is public, and the SEC releases
# it 60 days after the end of the fiscal quarter, even if the fund filed earlier. A late filing or
# a restatement becomes public when it is filed.
_PUBLIC_LAG_DAYS = 60
_HOLIDAY_CACHE = {}


def _parse_date(x):
    """Strict ISO YYYY-MM-DD; a trailing time part is tolerated and dropped."""
    if isinstance(x, datetime):
        return x.date()
    if isinstance(x, date):
        return x
    if not isinstance(x, str):
        return None
    s = x.strip()
    head, tail = s[:10], s[10:]
    if len(head) != 10 or head[4] != "-" or head[7] != "-" or (tail and tail[0] not in "T "):
        return None
    digits = head[:4] + head[5:7] + head[8:]
    if not (digits.isascii() and digits.isdigit()):
        return None
    try:
        return date(int(head[:4]), int(head[5:7]), int(head[8:]))
    except ValueError:
        return None


def _to_fraction(x):
    """Exact rational from a finite number or numeric string; None otherwise."""
    if x is None or isinstance(x, bool):
        return None
    if isinstance(x, (int, Fraction)):
        return Fraction(x)
    if isinstance(x, str):
        try:
            return Fraction(x.strip())
        except (ValueError, ZeroDivisionError):
            return None
    try:
        fx = float(x)
    except (TypeError, ValueError, OverflowError):
        return None
    if not math.isfinite(fx):
        return None
    return Fraction(repr(fx))


def _observed(d):
    wd = d.weekday()
    if wd == 5:
        return d - timedelta(days=1)
    if wd == 6:
        return d + timedelta(days=1)
    return d


def _nth_weekday(y, m, wd, n):
    first = date(y, m, 1)
    return first + timedelta(days=(wd - first.weekday()) % 7 + 7 * (n - 1))


def _last_weekday(y, m, wd):
    last = date(y + (m == 12), m % 12 + 1, 1) - timedelta(days=1)
    return last - timedelta(days=(last.weekday() - wd) % 7)


def _federal_holidays(y):
    hol = _HOLIDAY_CACHE.get(y)
    if hol is None:
        hol = {
            _observed(date(y, 1, 1)),
            _nth_weekday(y, 2, 0, 3),    # Washington's Birthday
            _last_weekday(y, 5, 0),      # Memorial Day
            _observed(date(y, 7, 4)),
            _nth_weekday(y, 9, 0, 1),    # Labor Day
            _nth_weekday(y, 10, 0, 2),   # Columbus Day
            _observed(date(y, 11, 11)),
            _nth_weekday(y, 11, 3, 4),   # Thanksgiving
            _observed(date(y, 12, 25)),
        }
        if y >= 1986:
            hol.add(_nth_weekday(y, 1, 0, 3))   # MLK Day
        if y >= 2021:
            hol.add(_observed(date(y, 6, 19)))  # Juneteenth
        _HOLIDAY_CACHE[y] = hol
    return hol


def _edgar_business_day(d):
    if d.weekday() >= 5 or d in _federal_holidays(d.year):
        return False
    # A Saturday New Year's Day is observed on Friday 31 December of the prior year.
    return not (d.month == 12 and d.day == 31 and d.weekday() == 4)


def _public_release_day(period_end):
    """SEC release of the third-month public report: quarter end + 60 days, next EDGAR business day."""
    d = period_end + timedelta(days=_PUBLIC_LAG_DAYS)
    while not _edgar_business_day(d):
        d += timedelta(days=1)
    return d


def _signal_row(levels):
    """Demean, divide by the L1 norm (gross 1, net 0); return cash if the cross-section is flat."""
    n = len(levels)
    mean = sum(levels, Fraction(0)) / n
    centred = [v - mean for v in levels]
    tol = max(Fraction(1), max(abs(v) for v in levels)) / 10 ** 10
    if max(abs(c) for c in centred) <= tol:
        return [0.0] * n
    l1 = sum((abs(c) for c in centred), Fraction(0))
    w = [float(c / l1) for c in centred]
    gross = math.fsum(abs(x) for x in w)
    if gross > 1.0:  # guard against float rounding
        f = (1.0 - 1e-15) / gross
        w = [x * f for x in w]
    resid = math.fsum(w)
    if resid != 0.0:  # shrink the largest leg on the residual side; gross can only fall
        j = max(range(n), key=w.__getitem__) if resid > 0 else min(range(n), key=w.__getitem__)
        w[j] -= resid
    return w


def build_strategy(payload):
    def insufficient(msg, weights=None):
        out = {"status": "insufficient_data", "reason": msg}
        if weights is not None:
            out["weights"] = weights
        return out

    if not isinstance(payload, dict):
        return insufficient("Payload must be a dict with dates, assets, filings and prices.")
    raw_dates, raw_assets = payload.get("dates"), payload.get("assets")
    filings = payload.get("filings")
    if not isinstance(raw_dates, (list, tuple)) or not raw_dates:
        return insufficient("No decision dates supplied.", [])
    if not isinstance(raw_assets, (list, tuple)) or not raw_assets or any(a is None for a in raw_assets):
        return insufficient("Asset universe is missing or contains null names.")
    assets = [str(a).strip() for a in raw_assets]
    if any(not a for a in assets) or len(set(assets)) != len(assets):
        return insufficient("Asset names must be non-empty and unique to fix the column order.")
    dates = [_parse_date(d) for d in raw_dates]
    n_bad = sum(d is None for d in dates)
    if n_bad:
        return insufficient(f"{n_bad} decision date(s) are not ISO YYYY-MM-DD; cannot align filings.")
    if filings is None:
        filings = []
    if not isinstance(filings, (list, tuple)):
        return insufficient("Filings must be a list of row dicts.")

    n = len(assets)
    col = {a: i for i, a in enumerate(assets)}
    cnt = dict.fromkeys(("malformed", "foreign", "duplicate", "conflict", "restated", "pre_period"), 0)

    # Clean rows and group them by asset, report period and filing date.
    seen, groups = set(), {}
    for row in filings:
        if not isinstance(row, dict):
            cnt["malformed"] += 1
            continue
        name = row.get("asset")
        name = None if name is None else str(name).strip()
        pe = _parse_date(row.get("period_end"))
        fd = _parse_date(row.get("filing_date"))
        val = _to_fraction(row.get("weight_pct"))
        if not name or pe is None or fd is None or val is None:
            cnt["malformed"] += 1  # no provable availability date -> never used
            continue
        if name not in col:
            cnt["foreign"] += 1
            continue
        rid = row.get("row_id")
        try:
            hash(rid)
        except TypeError:
            rid = repr(rid)
        sig = (rid, name, pe, fd, val)
        if sig in seen:
            cnt["duplicate"] += 1
            continue
        seen.add(sig)
        if fd < pe:
            cnt["pre_period"] += 1
        groups.setdefault((col[name], pe, fd), set()).add(val)

    # Point-in-time events. Availability is the later of the filing date and the SEC public release.
    events, versions = [], {}
    for (i, pe, fd), vals in groups.items():
        try:
            avail = max(fd, _public_release_day(pe))
        except (OverflowError, ValueError):
            cnt["malformed"] += 1
            continue
        if len(vals) > 1:
            cnt["conflict"] += 1
        level = sum(vals, Fraction(0)) / len(vals)
        versions[(i, pe)] = versions.get((i, pe), 0) + 1
        events.append((avail, i, pe, fd, level))
    cnt["restated"] = sum(1 for v in versions.values() if v > 1)
    events.sort(key=lambda e: (e[0], e[1], e[2], e[3]))

    # Sweep the decision dates in time order. A record is usable only when avail < decision date,
    # because intraday times are absent and same-day records may post-date the decision.
    levels = [Fraction(100, n)] * n          # equal-weight level before any applicable observation
    known = [{} for _ in range(n)]           # per asset: period_end -> (filing_date, level)
    weights = [None] * len(dates)
    row, dirty, p = None, True, 0
    for k in sorted(range(len(dates)), key=dates.__getitem__):
        t = dates[k]
        touched = set()
        while p < len(events) and events[p][0] < t:
            _, i, pe, fd, level = events[p]
            p += 1
            prev = known[i].get(pe)
            if prev is None or fd > prev[0]:  # latest-filed version restates the period
                known[i][pe] = (fd, level)
                touched.add(i)
        for i in touched:
            new = known[i][max(known[i])][1]  # most recent report period available
            if new != levels[i]:
                levels[i] = new
                dirty = True
        if dirty:
            row, dirty = _signal_row(levels), False
        weights[k] = list(row)

    reason = (
        "Point-in-time: a third-month N-PORT row (2022-23 regime) is public at the later of its "
        "filing_date and the SEC release 60 days after quarter end (period_end+60d, rolled to the next "
        "EDGAR business day). With no intraday times, it is used only for decision dates strictly after "
        "that day. Each asset takes its latest public period_end (latest-filed version), else 100/N%. "
        "The vector is demeaned and scaled to unit gross (net 0), cash if flat. Weights are set at the "
        "close of each date for the next listed session's open-to-close. Prices are never read."
    )
    if not events:
        return insufficient("No usable filing rows, so every date is all-cash. " + reason, weights)

    issues = []
    if cnt["malformed"]:
        issues.append(f"{cnt['malformed']} malformed or undated row(s) ignored")
    if cnt["foreign"]:
        issues.append(f"{cnt['foreign']} row(s) for assets outside the universe ignored")
    if cnt["duplicate"]:
        issues.append(f"{cnt['duplicate']} exact duplicate row(s) dropped")
    if cnt["conflict"]:
        issues.append(f"{cnt['conflict']} asset/period/filing-date group(s) with conflicting weights averaged")
    if cnt["restated"]:
        issues.append(f"{cnt['restated']} asset-period(s) had several filings despite the one-version "
                      "schema; the latest-filed public one was used as a restatement")
    if cnt["pre_period"]:
        issues.append(f"{cnt['pre_period']} row(s) filed before period_end, still gated by the 60-day release")
    if any(a >= b for a, b in zip(dates, dates[1:])):
        issues.append("decision dates not strictly increasing; each date used only its own information set")

    if issues:
        reason += " Assumptions: " + "; ".join(issues) + "."
    return {"status": "assumption" if issues else "ok", "reason": reason, "weights": weights}
