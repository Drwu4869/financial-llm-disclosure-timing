import math
import datetime as _dt


def build_strategy(payload):
    """Point-in-time Form 13F holdings signal with one weight row per decision date.

    Alignment rules:
    - A row is usable only for decisions taken at the end of a supplied date that is
      on or after its actual SEC filing_date. A date-only record is usable at the end
      of its filing day. A record filed on a non-listed day is first used at the next
      listed date. The evaluator then trades the decision at the following session's
      open, so nothing is used before it was public.
    - For each asset, use the most recent report period that is public by the decision
      date, in its latest version filed by that date. A revision never acts before its
      own filing date and never changes an earlier decision.
    - Before any public record, an asset sits at the equal-weight level of 100/N percent.
    - The vector is demeaned across assets, then scaled so that sum(|w|) = 1.
      A flat vector means cash.
    - Prices are never read, so nothing is fitted to returns.
    """
    REL_TOL = 1e-12  # numerical flatness guard only; not a tuned parameter

    def fail(msg):
        return {"status": "insufficient_data", "reason": msg}

    def parse_day(x):
        if isinstance(x, _dt.datetime):
            return x.date()
        if isinstance(x, _dt.date):
            return x
        if not isinstance(x, str):
            return None
        s = x.strip()
        if len(s) < 10 or s[4] != "-" or s[7] != "-":
            return None
        if len(s) > 10 and s[10] not in "T ":
            return None
        try:
            return _dt.date.fromisoformat(s[:10])
        except ValueError:
            return None

    def parse_num(x):
        if x is None or isinstance(x, bool):
            return None
        try:
            v = float(x)
        except (TypeError, ValueError):
            return None
        return v if math.isfinite(v) else None

    # ---------------- decision dates and asset universe ----------------
    if not isinstance(payload, dict):
        return fail("Payload is not a mapping with dates, assets and filings.")

    raw_dates = payload.get("dates")
    if not isinstance(raw_dates, (list, tuple)) or len(raw_dates) == 0:
        return fail("No decision dates were supplied.")
    days = [parse_day(d) for d in raw_dates]
    if any(d is None for d in days):
        return fail("Every decision date must be an ISO YYYY-MM-DD string.")
    if any(b <= a for a, b in zip(days, days[1:])):
        return fail("Decision dates are not strictly increasing, so next-session "
                    "execution order is undefined.")

    raw_assets = payload.get("assets")
    if not isinstance(raw_assets, (list, tuple)) or len(raw_assets) == 0:
        return fail("No assets were supplied.")
    if any(a is None for a in raw_assets):
        return fail("Asset identifiers must not be null.")
    assets = [str(a).strip() for a in raw_assets]
    if any(a == "" for a in assets) or len(set(assets)) != len(assets):
        return fail("Asset identifiers must be non-empty and unique.")
    col = {a: j for j, a in enumerate(assets)}
    n = len(assets)
    eq_level = 100.0 / n

    filings = payload.get("filings")
    if not isinstance(filings, (list, tuple)):
        return fail("No filings list was supplied.")
    if len(filings) == 0:
        return fail("The filings list is empty; there are no holdings to align.")

    first_day, last_day = days[0], days[-1]
    sessions = set(days)

    # ---------------- validate and index filing rows ----------------
    records = {}  # (asset, period_end, filing_date) -> weight_pct
    malformed = impossible = conflicts = exact_dupes = dup_ids = 0
    in_universe = dated_in_universe = filed_after_window = 0
    undated_in_window = undated_after_window = 0
    unknown = set()
    seen_ids = set()

    for row in filings:
        if not isinstance(row, dict):
            malformed += 1
            continue
        rid = row.get("row_id")
        if rid is not None:
            rk = str(rid)
            if rk in seen_ids:
                dup_ids += 1
            seen_ids.add(rk)
        raw_a = row.get("asset")
        a = "" if raw_a is None else str(raw_a).strip()
        if a == "":
            malformed += 1
            continue
        if a not in col:
            unknown.add(a)
            continue
        in_universe += 1
        pe = parse_day(row.get("period_end"))
        if pe is None:
            malformed += 1
            continue
        fd = parse_day(row.get("filing_date"))
        if fd is None:
            # A filing cannot precede its period end, so a period ending after the
            # last decision date cannot have been public inside the window.
            if pe > last_day:
                undated_after_window += 1
            else:
                undated_in_window += 1
            continue
        dated_in_universe += 1
        if fd > last_day:
            filed_after_window += 1
            continue
        if fd < pe:
            impossible += 1
            continue
        w = parse_num(row.get("weight_pct"))
        if w is None:
            malformed += 1
            continue
        key = (a, pe, fd)
        if key in records:
            if records[key] == w:
                exact_dupes += 1
            else:
                conflicts += 1
            continue
        records[key] = w

    if in_universe == 0:
        return fail("No filing rows refer to the supplied assets.")
    if undated_in_window > 0 or (dated_in_universe == 0 and undated_after_window > 0):
        missing = undated_in_window + undated_after_window
        return fail(
            f"Actual SEC filing dates are absent for {missing} of {in_universe} holdings "
            "rows; exact historical alignment cannot be established from these inputs, "
            "so no weights are produced (no filing date or fixed lag is invented)."
        )
    if malformed:
        return fail(f"{malformed} filing row(s) have a missing asset, an unparseable "
                    "period_end or a non-numeric weight_pct; the point-in-time vector "
                    "cannot be formed exactly.")
    if impossible:
        return fail(f"{impossible} row(s) show a filing_date earlier than their own "
                    "period_end, which is impossible for a 13F; the alignment is unreliable.")
    if conflicts:
        return fail(f"{conflicts} row(s) share asset, period and filing_date with a "
                    "different weight_pct; without intraday times the applicable version "
                    "cannot be determined.")

    # ---------------- signal construction ----------------
    shrink = math.nextafter(1.0, 0.0)

    def to_weights(levels):
        mean = math.fsum(levels) / n
        centred = [x - mean for x in levels]
        tol = REL_TOL * max(1.0, max(abs(x) for x in levels))
        if max(abs(x) for x in centred) <= tol:
            return [0.0] * n  # flat cross-section -> cash
        gross = math.fsum(abs(x) for x in centred)
        w = [x / gross for x in centred]
        # Remove floating-point residue in net exposure without raising gross.
        resid = math.fsum(w)
        if resid > 0.0:
            j = max(range(n), key=w.__getitem__)
            w[j] -= resid
        elif resid < 0.0:
            j = min(range(n), key=w.__getitem__)
            w[j] -= resid
        for _ in range(16):
            if math.fsum(abs(x) for x in w) <= 1.0:
                break
            w = [x * shrink for x in w]
        return [x + 0.0 for x in w]  # normalise -0.0

    events = sorted(((fd, pe, a, w) for (a, pe, fd), w in records.items()),
                    key=lambda t: (t[0], t[1], t[2]))
    latest = [dict() for _ in range(n)]  # period_end -> latest-filed weight seen so far
    best = [None] * n                    # most recent public report period per asset
    level = [eq_level] * n
    weights = []
    first_live = None
    k = 0
    for d in days:
        while k < len(events) and events[k][0] <= d:  # usable at end of filing day
            fd, pe, a, w = events[k]
            k += 1
            j = col[a]
            latest[j][pe] = w
            if best[j] is None or pe > best[j]:
                best[j] = pe
            level[j] = latest[j][best[j]]
        row = to_weights(level)
        if first_live is None and any(x != 0.0 for x in row):
            first_live = d
        weights.append(row)

    # ---------------- reporting ----------------
    per_period = {}
    for (a, pe, fd) in records:
        per_period[(a, pe)] = per_period.get((a, pe), 0) + 1
    multi = sum(1 for c in per_period.values() if c > 1)
    off_session = sum(1 for (_, _, fd) in records
                      if first_day < fd <= last_day and fd not in sessions)

    reason = [
        "Aligned on actual SEC filing_date: a row counts for decisions at the end of "
        "listed dates on or after its filing day (off-session filings from the next "
        "listed date), so it trades at the following session's open; no lag is "
        "invented and no version is used before filing or carried backward.",
        f"Per asset, the latest report period public by each date is used; assets "
        f"without one sit at the equal-weight level {eq_level:.6g}%. The vector is "
        f"demeaned across {n} assets and scaled to gross 1 and net 0 (cash when flat). "
        "Prices are not used.",
    ]
    if not records:
        reason.append(f"No holdings row was public by {last_day.isoformat()}; "
                      "every decision is cash.")
    elif first_live is not None:
        reason.append(f"First non-cash decision: {first_live.isoformat()}.")
    else:
        reason.append("Public levels never differ across assets; every decision is cash.")
    if off_session:
        reason.append(f"{off_session} row(s) filed on non-listed dates enter at the "
                      "next listed date.")
    if filed_after_window:
        reason.append(f"{filed_after_window} row(s) filed after "
                      f"{last_day.isoformat()} are unused.")

    assumptions = []
    if unknown:
        names = sorted(unknown)
        shown = ", ".join(names[:3]) + ("..." if len(names) > 3 else "")
        assumptions.append(f"Ignored rows for {len(names)} asset(s) outside the "
                           f"supplied universe ({shown}).")
    if exact_dupes:
        assumptions.append(f"Dropped {exact_dupes} exact duplicate row(s).")
    if dup_ids:
        assumptions.append(f"{dup_ids} repeated row_id(s) were treated as "
                           "separate records.")
    if multi:
        assumptions.append(f"{multi} asset/period(s) carry more than one version "
                           "despite the one-version premise; each version was applied "
                           "only from its own filing date.")
    if undated_after_window:
        assumptions.append(f"Ignored {undated_after_window} undated row(s) whose "
                           "period ends after the last decision date, since they "
                           "could not have been public in the window.")
    if assumptions:
        reason.append("Assumptions: " + " ".join(assumptions))

    return {
        "status": "assumption" if assumptions else "ok",
        "reason": " ".join(reason),
        "weights": weights,
    }
