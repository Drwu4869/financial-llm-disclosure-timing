import math
import re
from datetime import date, datetime

_ISO_DAY = re.compile(r"\d{4}-\d{2}-\d{2}")
_FLAT_TOL = 1e-12


def _parse_day(value):
    """Return a date for an ISO YYYY-MM-DD string (or a date object), else None."""
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        text = value.strip()
        if _ISO_DAY.fullmatch(text):
            try:
                return date.fromisoformat(text)
            except ValueError:
                return None
    return None


def _parse_num(value):
    """Return a finite float, else None (bools rejected)."""
    if value is None or isinstance(value, bool):
        return None
    try:
        out = float(value)
    except (TypeError, ValueError):
        return None
    return out if math.isfinite(out) else None


def _signal(levels):
    """Demean, scale to gross exposure 1, or return cash if there is no dispersion."""
    n = len(levels)
    lo, hi = min(levels), max(levels)
    if hi - lo <= _FLAT_TOL * max(1.0, abs(lo), abs(hi)):
        return [0.0] * n
    mean = math.fsum(levels) / n
    centered = [x - mean for x in levels]
    gross = math.fsum(abs(x) for x in centered)
    if not gross > 0.0:
        return [0.0] * n
    w = [x / gross for x in centered]
    # Guard against rounding pushing gross exposure above one.
    g2 = math.fsum(abs(x) for x in w)
    if g2 > 1.0:
        w = [x / g2 for x in w]
        if math.fsum(abs(x) for x in w) > 1.0:
            w = [x * (1.0 - 1e-15) for x in w]
    return [x + 0.0 for x in w]  # turn -0.0 into 0.0


def build_strategy(payload):
    def insufficient(msg, weights=None):
        out = {"status": "insufficient_data", "reason": msg}
        if weights is not None:
            out["weights"] = weights
        return out

    if not isinstance(payload, dict):
        return insufficient("Payload must be a mapping with dates, assets, filings and prices.")

    # ---- asset universe (fixed column order) ----
    raw_assets = payload.get("assets")
    if not isinstance(raw_assets, (list, tuple)) or len(raw_assets) == 0:
        return insufficient("No asset universe supplied.")
    col = {}
    for j, a in enumerate(raw_assets):
        try:
            if a in col:
                return insufficient(f"Duplicate asset column {a!r}; column order is ambiguous.")
            col[a] = j
        except TypeError:
            return insufficient("Asset identifiers must be hashable labels.")
    n = len(raw_assets)

    # ---- decision dates ----
    raw_dates = payload.get("dates")
    if not isinstance(raw_dates, (list, tuple)) or len(raw_dates) == 0:
        return insufficient("No decision dates supplied.")
    days = []
    for d in raw_dates:
        p = _parse_day(d)
        if p is None:
            return insufficient(f"Decision date {d!r} is not an ISO YYYY-MM-DD date.")
        days.append(p)
    unordered = any(b <= a for a, b in zip(days, days[1:]))

    # ---- filings (unordered rows) ----
    raw_rows = payload.get("filings")
    if raw_rows is None:
        raw_rows = []
    if not isinstance(raw_rows, (list, tuple)):
        return insufficient("Filings must be a list of row mappings.")

    malformed = outside = impossible = duplicates = 0
    versions = {}  # (column, period_end) -> {filing_date: weight_pct}
    for row in raw_rows:
        if not isinstance(row, dict):
            malformed += 1
            continue
        try:
            j = col.get(row.get("asset"))
        except TypeError:
            j = None
        if j is None:
            outside += 1
            continue
        period = _parse_day(row.get("period_end"))
        filed = _parse_day(row.get("filing_date"))
        weight = _parse_num(row.get("weight_pct"))
        if period is None or filed is None or weight is None or weight < 0.0:
            malformed += 1  # 13F rows are long holdings; negative weights are invalid
            continue
        if filed < period:
            impossible += 1  # a holdings report cannot be filed before its as-of date
            continue
        slot = versions.setdefault((j, period), {})
        if filed in slot:
            if math.isclose(slot[filed], weight, rel_tol=1e-12, abs_tol=1e-12):
                duplicates += 1
                continue
            return insufficient(
                f"Conflicting weights for {raw_assets[j]!r}, period {period.isoformat()}, "
                f"both filed {filed.isoformat()}; without timestamps the applicable version "
                "cannot be determined."
            )
        slot[filed] = weight

    revised = sum(1 for slot in versions.values() if len(slot) > 1)
    events = sorted(
        (filed, j, period, w)
        for (j, period), slot in versions.items()
        for filed, w in slot.items()
    )
    day_set = set(days)
    same_day = sum(1 for e in events if e[0] in day_set)

    # ---- point-in-time sweep over decision dates (chronological), rows kept in input order ----
    equal_level = 100.0 / n  # weight_pct is in percent
    cur_period = [None] * n
    cur_level = [equal_level] * n
    weights = [None] * len(days)
    k = 0
    cash_days = 0
    for i in sorted(range(len(days)), key=days.__getitem__):
        t = days[i]
        # Available at end of t only if filed on an earlier calendar day.
        while k < len(events) and events[k][0] < t:
            filed, j, period, w = events[k]
            # Newer report period replaces; a later-filed version of the same period restates it.
            if cur_period[j] is None or period >= cur_period[j]:
                cur_period[j] = period
                cur_level[j] = w
            k += 1
        row = _signal(cur_level)
        if not any(row):
            cash_days += 1
        weights[i] = row

    base = (
        "Row t uses only 13F rows whose EDGAR filing_date is strictly before t "
        "(period_end is never treated as an availability date). Per asset: the latest "
        "available period_end and its latest-filed version; with none available, the "
        f"equal-weight level 100/{n}%. The vector is demeaned and scaled to gross 1 "
        "(cash if flat). Row t is meant for the next session's open-to-close. "
        "Prices are not used."
    )

    if not events:
        return insufficient(
            base + " No usable filing rows, so every date stays at the equal-weight "
            "level and all rows are cash.",
            weights,
        )

    assumptions = []
    if same_day:
        assumptions.append(
            f"{same_day} version(s) filed on a decision date were first used on the "
            "next decision date, because filing times are absent"
        )
    if revised:
        assumptions.append(
            f"{revised} asset-period(s) had several filing dates; each version was "
            "applied only after its own filing_date"
        )
    if duplicates:
        assumptions.append(f"{duplicates} exact duplicate row(s) merged")
    if outside:
        assumptions.append(f"{outside} row(s) for assets outside the universe ignored")
    if malformed:
        assumptions.append(f"{malformed} malformed or invalid row(s) dropped")
    if impossible:
        assumptions.append(f"{impossible} row(s) filed before their period_end dropped")
    if unordered:
        assumptions.append(
            "decision dates were not strictly increasing; each row was still computed "
            "from its own date"
        )

    reason = base
    if assumptions:
        reason += " Assumptions: " + "; ".join(assumptions) + "."
    if cash_days:
        reason += f" {cash_days}/{len(days)} date(s) are cash (no cross-sectional dispersion)."

    return {
        "status": "assumption" if assumptions else "ok",
        "reason": reason,
        "weights": weights,
    }
