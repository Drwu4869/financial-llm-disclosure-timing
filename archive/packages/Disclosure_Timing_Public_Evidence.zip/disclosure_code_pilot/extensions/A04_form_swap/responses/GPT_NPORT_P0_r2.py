def build_strategy(payload):
    """
    Build a point-in-time, holdings-based, market-neutral portfolio signal.

    Python 3.11; standard library only.

    Alignment:
      - Use only public third-fiscal-month Form N-PORT observations.
      - Under the 2022-2023 reporting regime, public availability is
        no earlier than 60 calendar days after the report period ends.
      - A record's earliest eligible date is therefore the later of
        its SEC filing date and period_end + 60 calendar days.
      - Because intraday publication times are unavailable, a record
        becomes usable only on decision dates strictly after that date.
      - For each asset, prefer the latest eligible report period, then
        the latest eligible filing version within that period.
      - Never use row_id to infer chronological order.
      - Before an asset's first eligible observation, use 100 / N
        as its equal-weight percentage baseline.

    Signal:
      - Cross-sectionally demean the resulting percentage levels.
      - Normalize by the sum of absolute deviations.
      - Return cash when all levels are equal.
      - Target zero net exposure and unit gross exposure.

    Execution:
      - Decisions are made at the end of each supplied decision date.
      - Execution belongs to the first subsequent synthetic session.
      - Session dates come from payload["prices"], not an exchange calendar.
      - Close prices are never used in signal construction.
      - An independent evaluator handles next-session open-to-close
        execution returns.

    Output:
      {
          "status": "ok" | "assumption" | "insufficient_data",
          "reason": str,
          "weights": list[list[float]]
      }
    """
    from bisect import bisect_right
    from datetime import date, timedelta
    from math import fsum, isfinite

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")

        result = date.fromisoformat(value)

        if result.isoformat() != value:
            raise ValueError("Dates must use exact YYYY-MM-DD format.")

        return result

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        assets = payload["assets"]
        decision_strings = payload["dates"]
        filings = payload["filings"]
        prices = payload["prices"]

        if not isinstance(assets, list) or not assets:
            return insufficient("A nonempty asset universe is required.")

        if (
            any(not isinstance(a, str) or not a for a in assets)
            or len(set(assets)) != len(assets)
        ):
            return insufficient("Asset identifiers must be unique strings.")

        if not isinstance(decision_strings, list) or not decision_strings:
            return insufficient("At least one decision date is required.")

        if not isinstance(filings, list):
            return insufficient("Filings must be a list.")

        if not isinstance(prices, list) or not prices:
            return insufficient("A synthetic session list is required.")

        decision_dates = [parse_date(x) for x in decision_strings]

        if any(
            decision_dates[i] >= decision_dates[i + 1]
            for i in range(len(decision_dates) - 1)
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        # Only price-row dates are used. No price values are inspected.
        session_dates = []

        for record in prices:
            if not isinstance(record, dict):
                return insufficient("Invalid synthetic session record.")

            session_dates.append(parse_date(record["date"]))

        if len(set(session_dates)) != len(session_dates):
            return insufficient(
                "Synthetic session dates must be unique."
            )

        session_dates.sort()

        # Every decision must have a subsequent execution session.
        # The next session need not be the next calendar/business day.
        for decision_date in decision_dates:
            next_index = bisect_right(session_dates, decision_date)

            if next_index == len(session_dates):
                return insufficient(
                    "No subsequent synthetic execution session exists "
                    f"for decision date {decision_date.isoformat()}."
                )

        n_assets = len(assets)
        asset_index = {
            asset: index for index, asset in enumerate(assets)
        }

        equal_weight_pct = 100.0 / n_assets

        # Event structure:
        # (
        #     public_available_date,
        #     report_period_end,
        #     filing_date,
        #     asset_index,
        #     weight_percentage
        # )
        events = []

        # Detect records that cannot be ordered using the supplied
        # date fields. An opaque row_id cannot resolve such conflicts.
        version_values = {}

        for record in filings:
            if not isinstance(record, dict):
                return insufficient("Invalid filing record.")

            asset = record["asset"]

            # Only securities in the specified trading universe
            # contribute to the signal.
            if asset not in asset_index:
                continue

            period_end = parse_date(record["period_end"])
            filing_date = parse_date(record["filing_date"])

            raw_weight = record["weight_pct"]

            if isinstance(raw_weight, bool):
                return insufficient("Invalid holdings percentage.")

            weight_pct = float(raw_weight)

            if not isfinite(weight_pct):
                return insufficient(
                    "Holdings percentages must be finite."
                )

            if filing_date < period_end:
                return insufficient(
                    "A filing date precedes its report period end."
                )

            # Form N-PORT third-fiscal-month public disclosure lag.
            public_date = max(
                filing_date,
                period_end + timedelta(days=60),
            )

            version_key = (asset, period_end, filing_date)

            if version_key in version_values:
                if version_values[version_key] != weight_pct:
                    return insufficient(
                        "Conflicting weights for the same asset, "
                        "report period, and filing date; publication "
                        "order cannot be established."
                    )

                # Identical duplicate observation contributes once.
                continue

            version_values[version_key] = weight_pct

            events.append(
                (
                    public_date,
                    period_end,
                    filing_date,
                    asset_index[asset],
                    weight_pct,
                )
            )

        # Sorting makes input filing-row order irrelevant.
        # Within a common public date, later filing versions are
        # processed after earlier ones.
        events.sort()

        # latest[i] stores:
        # (period_end, filing_date, weight_pct)
        #
        # Report period takes precedence over filing date:
        # a later revision to an older period must not overwrite
        # an already eligible newer report period.
        latest = [None] * n_assets

        weights = []
        event_cursor = 0

        for decision_date in decision_dates:

            # Strict inequality avoids assuming that an SEC filing
            # or public release was available before market close
            # on its calendar date.
            while (
                event_cursor < len(events)
                and events[event_cursor][0] < decision_date
            ):
                (
                    public_date,
                    period_end,
                    filing_date,
                    index,
                    weight_pct,
                ) = events[event_cursor]

                previous = latest[index]

                if (
                    previous is None
                    or (period_end, filing_date)
                    > (previous[0], previous[1])
                ):
                    latest[index] = (
                        period_end,
                        filing_date,
                        weight_pct,
                    )

                event_cursor += 1

            # Form the as-of holdings vector in fixed asset order.
            levels = [
                equal_weight_pct
                if observation is None
                else observation[2]
                for observation in latest
            ]

            # Identical holdings levels imply no cross-sectional
            # information and therefore a fully cash portfolio.
            if all(level == levels[0] for level in levels):
                weights.append([0.0] * n_assets)
                continue

            # Cross-sectional centering.
            cross_sectional_mean = fsum(levels) / n_assets

            centered = [
                level - cross_sectional_mean
                for level in levels
            ]

            gross = fsum(abs(value) for value in centered)

            if gross == 0.0:
                weights.append([0.0] * n_assets)
                continue

            # Unit-gross, zero-net long/short portfolio.
            portfolio_row = [
                value / gross
                for value in centered
            ]

            # Guard against floating-point rounding that might
            # make computed gross exposure slightly greater than 1.
            realized_gross = fsum(
                abs(value) for value in portfolio_row
            )

            if realized_gross > 1.0:
                correction = (1.0 - 1e-12) / realized_gross

                portfolio_row = [
                    value * correction
                    for value in portfolio_row
                ]

            weights.append(portfolio_row)

        return {
            "status": "assumption",
            "reason": (
                "Point-in-time holdings signal using each asset's "
                "latest eligible report period and filing version. "
                "Public availability is bounded by the later of "
                "SEC filing_date and period_end plus 60 calendar days, "
                "under the 2022-2023 third-month Form N-PORT regime. "
                "Because intraday timestamps are absent, observations "
                "are conservatively usable only on later decision "
                "dates. Missing observations use the 100/N equal-weight "
                "percentage baseline. Holdings levels are demeaned "
                "and normalized to a market-neutral, at-most-unit-gross "
                "portfolio, with cash for a zero centered signal. "
                "Trades are aligned to the first subsequent synthetic "
                "session; price levels and returns are not used."
            ),
            "weights": weights,
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            f"Invalid or insufficient input data: {exc}"
        )
