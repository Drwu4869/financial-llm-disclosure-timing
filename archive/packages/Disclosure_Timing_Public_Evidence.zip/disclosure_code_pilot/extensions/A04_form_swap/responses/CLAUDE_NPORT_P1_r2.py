import math
from datetime import date, datetime, timedelta

# Form N-PORT, 2022-2023 regime: the public portion of the third-fiscal-month
# report is released 60 calendar days after fiscal-quarter end (period_end),
# even when the fund files earlier. A late filing is public on its filing date.
PUBLIC_RELEASE_LAG = timedelta(days=60)
ZERO_TOL = 1e-12


def _parse_date(x):
    if isinstance(x, datetime):
        return x.date()
    if isinstance(x, date):
        return x
    if not isinstance(x, str):
        return None
    s = x.strip()
    if len(s) < 10 or (len(s) > 10 and s[10] not in "T "):
        return None
    try:
        return date.fromisoformat(s[:10])
    except ValueError:
        return None


def _number(x):
    if x is None or isinstance(x, bool):
        return None
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) else None


def _signal(levels):
    """Demean across assets, scale to unit gross exposure; cash if flat."""
    n = len(levels)
    mean = math.fsum(levels) / n
    centered = [v - mean for v in levels]
    scale = max(1.0, max(abs(v) for v in levels))
    if max(abs(c) for c in centered) <= ZERO_TOL * scale:
        return [0.0] * n
    gross = math.fsum(abs(c) for c in centered)
    w = [c / gross for c in centered]
    for _ in range(4):  # guard against gross > 1 from float rounding
        g = math.fsum(abs(x) for x in w)
        if g <= 1.0:
            break
        w = [x / g * (1.0 - 1e-15) for x in w]
    return [x + 0.0 for x in w]  # turn -0.0 into 0.0


def build_strategy(payload):
    if not isinstance(payload, dict):
        return {"status": "insufficient_data", "reason": "payload is not a mapping"}

    raw_dates = payload.get("dates")
    raw_assets = payload.get("assets")
    filings = payload.get("filings")

    if not isinstance(raw_dates, (list, tuple)) or len(raw_dates) == 0:
        return {"status": "insufficient_data", "reason": "no decision dates supplied"}
    if not isinstance(raw_assets, (list, tuple)) or len(raw_assets) == 0:
        return {"status": "insufficient_data", "reason": "no assets supplied"}

    assets = [str(a) for a in raw_assets]
    if len(set(assets)) != len(assets):
        return {"status": "insufficient_data",
                "reason": "duplicate asset names make the column mapping ambiguous"}

    dates = [_parse_date(d) for d in raw_dates]
    if any(d is None for d in dates):
        return {"status": "insufficient_data",
                "reason": "a decision date is not an ISO YYYY-MM-DD string"}

    n, T = len(assets), len(dates)
    cash = [[0.0] * n for _ in range(T)]
    if n < 2:
        return {"status": "insufficient_data",
                "reason": "a cross-sectional signal needs at least two assets; returning cash",
                "weights": cash}

    notes = []
    if any(b <= a for a, b in zip(dates, dates[1:])):
        notes.append("decision dates not strictly increasing; each date evaluated on its own "
                     "information set, output kept in input order")
    if filings is None:
        filings = []
    if not isinstance(filings, (list, tuple)):
        notes.append("filings is not a list; treated as empty")
        filings = []

    # Group valid rows: (asset column, period_end) -> {filing_date: [weight_pct, ...]}
    col = {a: i for i, a in enumerate(assets)}
    groups = {}
    bad = unknown = 0
    for row in filings:
        if not isinstance(row, dict) or row.get("asset") is None:
            bad += 1
            continue
        a = str(row.get("asset"))
        if a not in col:
            unknown += 1
            continue
        pe = _parse_date(row.get("period_end"))
        fd = _parse_date(row.get("filing_date"))
        w = _number(row.get("weight_pct"))
        if pe is None or fd is None or w is None:
            bad += 1
            continue
        groups.setdefault((col[a], pe), {}).setdefault(fd, []).append(w)

    # Turn each version into an event that becomes usable on its public release date.
    events = []
    held_back = late = pre_period = multi = dupes = conflicts = 0
    for (i, pe), versions in groups.items():
        release = pe + PUBLIC_RELEASE_LAG
        if len(versions) > 1:
            multi += 1
        for fd, vals in versions.items():
            if len(vals) > 1:
                spread = max(vals) - min(vals)
                if spread > ZERO_TOL * max(1.0, max(abs(v) for v in vals)):
                    conflicts += 1
                else:
                    dupes += 1
            if fd < pe:
                pre_period += len(vals)
            if fd < release:
                held_back += len(vals)
            elif fd > release:
                late += len(vals)
            available = max(fd, release)
            events.append((available, pe, fd, i, math.fsum(vals) / len(vals)))
    events.sort(key=lambda e: (e[0], e[1], e[2], e[3]))

    # Walk forward through decision dates. Only rows public on or before d are used.
    eq_level = 100.0 / n
    cur_pe = [None] * n
    cur_fd = [None] * n
    level = [eq_level] * n
    weights = [None] * T
    k = 0
    for t in sorted(range(T), key=lambda t: dates[t]):
        d = dates[t]
        while k < len(events) and events[k][0] <= d:
            _, pe, fd, i, v = events[k]
            k += 1
            if (cur_pe[i] is None or pe > cur_pe[i]
                    or (pe == cur_pe[i] and fd >= cur_fd[i])):
                cur_pe[i], cur_fd[i], level[i] = pe, fd, v
        weights[t] = _signal(level)
    used_events = k

    if bad:
        notes.append(f"{bad} malformed row(s) dropped (missing/invalid asset, date or weight; "
                     "no release date is guessed)")
    if unknown:
        notes.append(f"{unknown} row(s) for assets outside the universe ignored")
    if multi:
        notes.append(f"{multi} asset/period pair(s) had several filing dates despite the "
                     "one-version schema; the latest-filed version public by d was used")
    if dupes:
        notes.append(f"{dupes} identical duplicate version(s) collapsed")
    if conflicts:
        notes.append(f"{conflicts} conflicting same-date version(s) averaged")
    if pre_period:
        notes.append(f"{pre_period} row(s) dated before period_end; still held back "
                     "until period_end + 60 days")

    reason = (
        "Each row is usable from max(filing_date, period_end + 60 days): under the 2022-2023 "
        "N-PORT regime the public third-fiscal-month portion is released 60 days after "
        "fiscal-quarter end even if filed earlier "
        f"({held_back} row(s) held back to that date, {late} late filing(s) public on "
        "filing_date). A row informs date d only if its release date <= d (decision at end "
        "of d, execution next session). Per asset: latest public period_end and latest-filed "
        "version, else the 100/N% equal-weight level; demeaned and scaled to unit gross "
        "(net 0), cash when flat. Prices are not used."
    )
    if notes:
        reason += " Assumptions: " + "; ".join(notes) + "."

    if not events:
        return {"status": "insufficient_data",
                "reason": "no usable filing rows; every date is cash. " + reason,
                "weights": cash}
    if used_events == 0:
        return {"status": "insufficient_data",
                "reason": "no filing becomes public on or before the last decision date; "
                          "every date is cash. " + reason,
                "weights": cash}

    return {"status": "assumption" if notes else "ok",
            "reason": reason,
            "weights": weights}
