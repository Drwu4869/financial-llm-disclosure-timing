from datetime import date
from fractions import Fraction
from math import fsum, isfinite
from collections.abc import Mapping


def build_strategy(payload):
    """
    Build a point-in-time, holdings-based, dollar-neutral portfolio signal.

    Rules:
      - Use actual SEC filing dates, never an estimated publication lag.
      - A filing dated D is available for a decision at the close of D.
      - Select the most recent publicly available report period per asset.
      - For revisions of that period, use the latest applicable filing.
      - Never apply a revision before its own filing date.
      - Before an asset's first available observation, use 100 / N percent.
      - Cross-sectionally center and L1-normalize the holdings vector.
      - Return cash if the centered vector is zero.
      - Do not use prices to construct, tune, or evaluate the signal.

    Output weights correspond to decision dates, not execution dates.
    An independent evaluator executes each decision at the next listed
    session's open and liquidates at that session's close.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason
        }

    def parse_date(value):
        if (
            not isinstance(value, str)
            or len(value) != 10
            or value[4] != "-"
            or value[7] != "-"
        ):
            raise ValueError("Expected ISO date YYYY-MM-DD.")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Noncanonical ISO date.")

        return parsed

    try:
        if not isinstance(payload, Mapping):
            return insufficient("Payload must be a mapping.")

        dates = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]

        if not isinstance(dates, (list, tuple)) or not dates:
            return insufficient("No decision dates were supplied.")

        if not isinstance(assets, (list, tuple)) or not assets:
            return insufficient("No asset universe was supplied.")

        if not isinstance(filings, (list, tuple)):
            return insufficient("Filings must be a list of records.")

        if any(not isinstance(a, str) or not a for a in assets):
            return insufficient("Asset identifiers must be nonempty strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        decision_dates = [parse_date(d) for d in dates]

        if any(
            decision_dates[i] <= decision_dates[i - 1]
            for i in range(1, len(decision_dates))
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n = len(assets)
        asset_index = {asset: i for i, asset in enumerate(assets)}

        # Holdings are percentages, so the missing-observation
        # baseline is 100/N, not 1/N.
        baseline = Fraction(100, n)

        # Each parsed row:
        # (filing_date, period_end, asset_index, weight)
        observations = []

        # A row_id identifies a record; it does not establish
        # chronological priority.
        seen_ids = set()

        # Date-only records cannot resolve conflicting revisions
        # of the same asset and report period filed on the same day.
        seen_versions = {}

        for row in filings:
            if not isinstance(row, Mapping):
                return insufficient("A filing row is not a mapping.")

            if "filing_date" not in row or row["filing_date"] in (None, ""):
                return insufficient(
                    "Actual SEC filing dates are missing; exact "
                    "historical alignment cannot be established "
                    "without them."
                )

            required = (
                "row_id",
                "asset",
                "period_end",
                "weight_pct"
            )

            if any(field not in row for field in required):
                return insufficient(
                    "A filing row is missing required fields."
                )

            row_id = row["row_id"]

            if not isinstance(row_id, str) or not row_id:
                return insufficient("Invalid filing row_id.")

            if row_id in seen_ids:
                return insufficient(
                    "Duplicate row_id; filing records are not unique."
                )

            seen_ids.add(row_id)

            asset = row["asset"]

            if asset not in asset_index:
                return insufficient(
                    "A filing references an asset outside the "
                    "fixed security universe."
                )

            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])

            if filing_date < period_end:
                return insufficient(
                    "A filing date precedes its report period end."
                )

            raw_weight = row["weight_pct"]

            if isinstance(raw_weight, bool):
                return insufficient("Invalid holdings weight.")

            try:
                numeric_weight = float(raw_weight)

                if not isfinite(numeric_weight):
                    return insufficient(
                        "Holdings weights must be finite."
                    )

                # Exact rational arithmetic avoids spurious signals
                # caused by floating-point centering.
                weight = Fraction(str(raw_weight))

            except (TypeError, ValueError, OverflowError, ZeroDivisionError):
                return insufficient("Invalid holdings weight.")

            version_key = (asset, period_end, filing_date)

            if version_key in seen_versions:
                if seen_versions[version_key] != weight:
                    return insufficient(
                        "Conflicting weights for the same asset, "
                        "report period, and filing date; date-only "
                        "records cannot establish revision order."
                    )

                # Identical observations on the same date are
                # redundant, regardless of their row identifiers.
                continue

            seen_versions[version_key] = weight

            observations.append(
                (
                    filing_date,
                    period_end,
                    asset_index[asset],
                    weight
                )
            )

        # Actual public availability controls the event stream.
        # Period end is only a secondary ordering key for filings
        # that become available on the same day.
        observations.sort(key=lambda r: (r[0], r[1]))

        latest_period = [None] * n
        latest_weight = [baseline] * n

        weights = []
        cursor = 0
        total_observations = len(observations)

        for decision_date in decision_dates:

            # Date-only SEC filings become usable at the end
            # of their actual filing day, inclusively.
            while (
                cursor < total_observations
                and observations[cursor][0] <= decision_date
            ):
                filing_date, period_end, index, weight = (
                    observations[cursor]
                )

                current_period = latest_period[index]

                # Never replace a more recent report period with
                # a late-filed revision of an older period.
                #
                # For the same report period, chronological processing
                # ensures that the latest applicable revision wins.
                if (
                    current_period is None
                    or period_end >= current_period
                ):
                    latest_period[index] = period_end
                    latest_weight[index] = weight

                cursor += 1

            # Each asset has its most recent applicable observation,
            # or the equal-weight percentage baseline if unobserved.
            levels = latest_weight

            # Exact cross-sectional centering.
            mean_level = sum(levels, Fraction(0)) / n

            centered = [
                value - mean_level
                for value in levels
            ]

            gross_signal = sum(
                (abs(value) for value in centered),
                Fraction(0)
            )

            if gross_signal == 0:
                # An identical holdings vector has no cross-sectional
                # signal. Hold cash rather than introduce exposure.
                portfolio = [0.0] * n

            else:
                # Normalize using exact arithmetic before conversion.
                portfolio = [
                    float(value / gross_signal)
                    for value in centered
                ]

                # Remove floating-point residual net exposure.
                # In exact arithmetic, centered weights sum to zero.
                portfolio[-1] = -fsum(portfolio[:-1])

                gross = fsum(abs(value) for value in portfolio)

                # Floating-point conversion can exceed gross=1
                # by a few ULPs. Correct only if necessary.
                if gross > 1.0:
                    scale = (1.0 - 2.0**-48) / gross

                    portfolio = [
                        value * scale
                        for value in portfolio
                    ]

                    portfolio[-1] = -fsum(portfolio[:-1])

            weights.append(portfolio)

        if not observations:
            reason = (
                "No holdings observations were supplied. Every asset "
                "uses the equal-weight percentage baseline, producing "
                "cash on every decision date. Prices are not used."
            )
        else:
            reason = (
                "Point-in-time alignment uses actual SEC filing dates "
                "inclusive of each decision day's close. Each asset "
                "uses its latest publicly available report period and "
                "latest applicable revision; older-period revisions "
                "cannot overwrite newer reports. Unobserved assets "
                "use 100/N percent. Holdings are cross-sectionally "
                "centered and gross-normalized, with cash for a zero "
                "signal. Weights belong to decision dates and are "
                "intended for the next listed session's open-to-close "
                "execution. Prices are not used; returns are evaluated "
                "independently."
            )

        return {
            "status": "ok",
            "reason": reason,
            "weights": weights
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            "Invalid or incomplete input: " + str(exc)
        )
