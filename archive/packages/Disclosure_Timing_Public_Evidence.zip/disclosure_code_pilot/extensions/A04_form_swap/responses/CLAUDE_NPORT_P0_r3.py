import calendar
import math
from datetime import date, datetime, timedelta

# Third-month N-PORT data (2019-2024 regime) was made public 60 days after the
# fiscal-quarter end. A filing made after that point was public on its filing date.
_PUBLIC_LAG_DAYS = 60


def _to_date(value):
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = str(value).strip()
    if len(text) < 10:
        raise ValueError("bad date: %r" % (value,))
    return date.fromisoformat(text[:10])


def _month_end(d):
    return date(d.year, d.month, calendar.monthrange(d.year, d.month)[1])


def _signal_row(levels):
    n = len(levels)
    mean = math.fsum(levels) / n
    centered = [x - mean for x in levels]
    scale = max(1.0, max(abs(x) for x in levels))
    if max(abs(x) for x in centered) <= 1e-12 * scale:
        return [0.0] * n  # flat cross-section -> cash
    total = math.fsum(abs(x) for x in centered)
    w = [x / total for x in centered]
    resid = math.fsum(w) / n
    if resid != 0.0:
        w = [x - resid for x in w]
    for _ in range(10):
        gross = math.fsum(abs(x) for x in w)
        if gross <= 1.0:
            break
        w = [x / gross * (1.0 - 1e-15) for x in w]
    return [float(x) for x in w]


def build_strategy(payload):
    def insufficient(msg):
        return {"status": "insufficient_data", "reason": msg}

    if not isinstance(payload, dict):
        return insufficient("Payload is not a dictionary.")
    dates_raw = payload.get("dates")
    assets_raw = payload.get("assets")
    if not isinstance(dates_raw, (list, tuple)) or len(dates_raw) == 0:
        return insufficient("No decision dates supplied.")
    if not isinstance(assets_raw, (list, tuple)) or len(assets_raw) == 0:
        return insufficient("No assets supplied.")

    assets = [str(a).strip() for a in assets_raw]
    if any(a == "" for a in assets) or len(set(assets)) != len(assets):
        return insufficient("Asset list contains blank or duplicate names.")
    try:
        decisions = [_to_date(d) for d in dates_raw]
    except (TypeError, ValueError):
        return insufficient("Decision dates are not valid ISO YYYY-MM-DD strings.")

    filings = payload.get("filings")
    if filings is None:
        filings = []
    if not isinstance(filings, (list, tuple)):
        return insufficient("Filings field is not a list of rows.")

    notes = []
    if any(decisions[i] >= decisions[i + 1] for i in range(len(decisions) - 1)):
        notes.append("dates not strictly increasing; each row uses only data public before its own date")

    col = {a: i for i, a in enumerate(assets)}
    n = len(assets)

    # Each event is (public date, column, report period, filing date, weight).
    events = []
    seen_ids = set()
    n_bad = n_unknown = n_dup = 0
    for row in filings:
        if not isinstance(row, dict):
            n_bad += 1
            continue
        rid = row.get("row_id")
        if rid is not None:
            key = str(rid)
            if key in seen_ids:
                n_dup += 1
                continue
            seen_ids.add(key)
        asset = str(row.get("asset", "")).strip()
        if asset not in col:
            n_unknown += 1
            continue
        try:
            period = _to_date(row["period_end"])
            filed = _to_date(row["filing_date"])
            weight = float(row["weight_pct"])
        except (KeyError, TypeError, ValueError, AttributeError):
            n_bad += 1
            continue
        if not math.isfinite(weight):
            n_bad += 1
            continue
        public = max(filed, _month_end(period) + timedelta(days=_PUBLIC_LAG_DAYS))
        events.append((public, col[asset], period, filed, weight))
    events.sort()

    if n_bad:
        notes.append("%d malformed row(s) skipped" % n_bad)
    if n_unknown:
        notes.append("%d row(s) for assets outside the universe ignored" % n_unknown)
    if n_dup:
        notes.append("%d duplicate row_id(s) ignored" % n_dup)

    equal_level = 100.0 / n
    # Per asset: [latest period, latest filing for that period, [weights]]
    state = [None] * n
    out = [None] * len(decisions)
    conflicts = set()
    active_days = 0
    k = 0
    for i in sorted(range(len(decisions)), key=lambda t: decisions[t]):
        d = decisions[i]
        while k < len(events) and events[k][0] < d:  # strictly before decision day
            _, j, period, filed, weight = events[k]
            k += 1
            st = state[j]
            if st is None or period > st[0] or (period == st[0] and filed > st[1]):
                state[j] = [period, filed, [weight]]
            elif period == st[0] and filed == st[1]:
                st[2].append(weight)
        levels = []
        observed = False
        for j in range(n):
            st = state[j]
            if st is None:
                levels.append(equal_level)
            else:
                observed = True
                vals = st[2]
                if len(set(vals)) > 1:
                    conflicts.add(assets[j])
                levels.append(math.fsum(vals) / len(vals))
        if observed:
            active_days += 1
        out[i] = _signal_row(levels)

    if conflicts:
        notes.append("same-day conflicting versions averaged for " + ", ".join(sorted(conflicts)))

    reason = (
        "Third-month N-PORT holdings (2022-2023 regime) are treated as public on "
        "max(filing_date, period month-end + 60 calendar days), not on filing_date. "
        "There are no intraday times, so a row is used only on decision dates strictly after "
        "that public date. Decisions are made at the end of each date, traded at the next "
        "session's open and closed at its close. Each asset uses its latest public report "
        "period and the latest-filed version, or the 100/N equal-weight level before any. "
        "The vector is demeaned and scaled to gross 1 and net 0, or cash when flat. "
        "Prices are not used."
    )
    if notes:
        reason += " Notes: " + "; ".join(notes) + "."

    if active_days == 0:
        return {
            "status": "insufficient_data",
            "reason": "No holdings row was public before any decision date, so every day is cash. " + reason,
            "weights": out,
        }
    return {"status": "assumption", "reason": reason, "weights": out}
