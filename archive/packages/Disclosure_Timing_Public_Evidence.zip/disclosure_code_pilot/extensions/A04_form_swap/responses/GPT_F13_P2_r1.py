from datetime import date
from math import fsum, isfinite


def build_strategy(payload):
    """
    Build a point-in-time, holdings-based, dollar-neutral portfolio signal.

    Rules
    -----
    - Use actual SEC filing dates, never assumed reporting lags.
    - A filing is available at the end of its filing_date.
    - For each asset, select the latest publicly available report period.
    - Within that period, select the latest available revision.
    - Never apply a revision before its own filing date.
    - Use 100 / number_of_assets as the fallback holding percentage.
    - Cross-sectionally demean the holdings vector.
    - Normalize gross exposure to one and net exposure to zero.
    - Return cash (all zero weights) when holdings are equal.
    - Do not use prices to construct or optimize signals.
    - Returned weights are decisions, not execution-day returns.

    The external evaluator is responsible for executing each decision
    at the next listed session's open and liquidating at its close.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason
        }

    def parse_date(value):
        if not isinstance(value, str) or len(value) != 10:
            raise ValueError("Expected ISO date YYYY-MM-DD")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Expected ISO date YYYY-MM-DD")

        return parsed

    def normalize(levels):
        """
        Cross-sectionally demean and normalize.

        Positive and negative exposures are each normalized to 0.5.
        This is equivalent to gross-L1 normalization of a centered
        vector, apart from floating-point rounding.

        Residual allocation to the largest position in each group
        minimizes floating-point drift in net and gross exposure.
        """

        n = len(levels)

        if n <= 1:
            return [0.0] * n

        if all(value == levels[0] for value in levels):
            return [0.0] * n

        mean = fsum(levels) / n
        centered = [value - mean for value in levels]

        positive = [
            i for i, value in enumerate(centered)
            if value > 0.0
        ]

        negative = [
            i for i, value in enumerate(centered)
            if value < 0.0
        ]

        if not positive or not negative:
            return [0.0] * n

        weights = [0.0] * n

        for indices, sign in (
            (positive, 1.0),
            (negative, -1.0)
        ):
            total = fsum(abs(centered[i]) for i in indices)

            # Allocate the rounding residual to the largest position.
            pivot = max(indices, key=lambda i: abs(centered[i]))

            others = [i for i in indices if i != pivot]

            for i in others:
                weights[i] = (
                    sign * 0.5 * (abs(centered[i]) / total)
                )

            allocated = fsum(abs(weights[i]) for i in others)

            weights[pivot] = sign * (0.5 - allocated)

        return weights

    # ------------------------------------------------------------
    # 1. Validate payload
    # ------------------------------------------------------------

    if not isinstance(payload, dict):
        return insufficient("Payload must be a dictionary.")

    decision_dates_raw = payload.get("dates")
    assets = payload.get("assets")
    filings = payload.get("filings")

    if not isinstance(decision_dates_raw, (list, tuple)):
        return insufficient("Missing or invalid decision dates.")

    if not isinstance(assets, (list, tuple)) or not assets:
        return insufficient("A nonempty asset universe is required.")

    if not all(
        isinstance(asset, str) and asset
        for asset in assets
    ):
        return insufficient("Asset identifiers must be nonempty strings.")

    if len(set(assets)) != len(assets):
        return insufficient("Asset identifiers must be unique.")

    if not isinstance(filings, (list, tuple)):
        return insufficient("Missing or invalid filings collection.")

    try:
        decision_dates = [
            parse_date(value)
            for value in decision_dates_raw
        ]
    except (ValueError, TypeError):
        return insufficient("Invalid decision date format.")

    if any(
        decision_dates[i] >= decision_dates[i + 1]
        for i in range(len(decision_dates) - 1)
    ):
        return insufficient(
            "Decision dates must be strictly increasing."
        )

    # ------------------------------------------------------------
    # 2. Validate filings and construct availability events
    # ------------------------------------------------------------

    universe = set(assets)

    # Each event:
    # (availability_date, report_period, filing_date, asset, weight_pct)
    events = []

    # Detect ambiguous same-day versions.
    # row_id is deliberately not used to infer revision chronology.
    seen_versions = {}

    for row in filings:

        if not isinstance(row, dict):
            return insufficient("Invalid filing row.")

        if row.get("filing_date") is None:
            return insufficient(
                "Actual SEC filing_date is missing; exact historical "
                "alignment cannot be established from these inputs."
            )

        try:
            asset = row["asset"]
            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])

            raw_weight = row["weight_pct"]

            if (
                isinstance(raw_weight, bool)
                or not isinstance(raw_weight, (int, float))
            ):
                raise ValueError("Invalid weight_pct")

            weight_pct = float(raw_weight)

            if not isfinite(weight_pct):
                raise ValueError("Nonfinite weight_pct")

        except (KeyError, ValueError, TypeError, OverflowError):
            return insufficient(
                "A filing contains invalid or missing required fields."
            )

        # Rows outside the selected fixed universe do not affect
        # its holdings vector.
        if asset not in universe:
            continue

        version_key = (asset, period_end, filing_date)

        if version_key in seen_versions:
            if seen_versions[version_key] != weight_pct:
                return insufficient(
                    "Conflicting weights for the same asset, report "
                    "period, and filing date; revision order is unknown."
                )

            # Identical duplicate observations have no additional effect.
            continue

        seen_versions[version_key] = weight_pct

        # A holdings observation cannot be used before either its
        # report period has ended or its public filing date.
        availability_date = max(period_end, filing_date)

        events.append(
            (
                availability_date,
                period_end,
                filing_date,
                asset,
                weight_pct
            )
        )

    # Sorting by public availability prevents look-ahead.
    # No ordering assumption is made about the input filings.
    events.sort(key=lambda event: (
        event[0],
        event[1],
        event[2],
        event[3]
    ))

    # ------------------------------------------------------------
    # 3. Walk forward through decision dates
    # ------------------------------------------------------------

    n_assets = len(assets)

    equal_weight_pct = 100.0 / n_assets

    # asset -> (report_period, filing_date, weight_pct)
    latest = {}

    event_index = 0
    weights = []

    try:
        for decision_day in decision_dates:

            # Make all filings available through this day's close
            # eligible for the decision.
            while (
                event_index < len(events)
                and events[event_index][0] <= decision_day
            ):
                (
                    availability_date,
                    period_end,
                    filing_date,
                    asset,
                    weight_pct
                ) = events[event_index]

                previous = latest.get(asset)

                # Prefer the newest report period.
                # For the same period, prefer the newest public revision.
                #
                # A late revision to an older report must not replace
                # an already available newer report.
                if (
                    previous is None
                    or (period_end, filing_date)
                    > (previous[0], previous[1])
                ):
                    latest[asset] = (
                        period_end,
                        filing_date,
                        weight_pct
                    )

                event_index += 1

            # Preserve the caller's exact asset column ordering.
            levels = [
                latest[asset][2]
                if asset in latest
                else equal_weight_pct
                for asset in assets
            ]

            # Center and normalize, or hold cash if there is no
            # cross-sectional difference.
            row_weights = normalize(levels)

            weights.append(row_weights)

    except (ArithmeticError, OverflowError, ValueError):
        return insufficient(
            "Numerical failure while constructing normalized weights."
        )

    # ------------------------------------------------------------
    # 4. Return decision-time portfolio weights
    # ------------------------------------------------------------

    # Prices are intentionally unused. In particular, next-session
    # prices cannot influence positions decided at the previous close.
    #
    # The evaluator independently maps each decision to the next
    # authoritative synthetic session and computes execution returns.

    return {
        "status": "ok",
        "reason": (
            "Point-in-time alignment uses actual SEC filing dates, "
            "with date-only records eligible at filing-day close. "
            "Each asset uses its newest available report period and "
            "latest eligible revision; unavailable observations use "
            "equal-weight levels. Positions are cross-sectionally "
            "demeaned and gross-normalized, with zero-signal cash. "
            "Prices are excluded from signal construction; execution "
            "and returns are evaluated independently on the next "
            "listed session."
        ),
        "weights": weights
    }
