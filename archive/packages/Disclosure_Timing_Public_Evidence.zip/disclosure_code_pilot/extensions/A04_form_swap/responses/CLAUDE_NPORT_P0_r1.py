def build_strategy(payload):
    """Cross-sectional holdings signal from public third-fiscal-month Form N-PORT rows.

    weights[t] is the target portfolio decided at the end of dates[t]. The evaluator
    trades it at the next session's open and liquidates it at that session's close.
    Prices are never used to build or tune the signal.
    """
    import calendar
    import datetime as dt
    import math
    import re
    from collections.abc import Mapping

    ONE_DAY = dt.timedelta(days=1)
    # 2022-2023 regime: the public third-month report was released 60 calendar days
    # after the fiscal quarter end, even when it was filed earlier.
    PUBLIC_LAG = dt.timedelta(days=60)
    ISO_DATE = re.compile(r"\s*(\d{4})-(\d{2})-(\d{2})(?!\d)")

    # ------------------------------------------------------------------ parsing
    def as_date(value):
        if isinstance(value, dt.datetime):
            return value.date()
        if isinstance(value, dt.date):
            return value
        if isinstance(value, str):
            match = ISO_DATE.match(value)
            if match:
                try:
                    return dt.date(*(int(g) for g in match.groups()))
                except ValueError:
                    return None
        return None

    def as_number(value):
        if value is None or isinstance(value, bool):
            return None
        try:
            if isinstance(value, str):
                value = value.strip().rstrip("%").strip()
            number = float(value)
        except (TypeError, ValueError, OverflowError):
            return None
        return number if math.isfinite(number) else None

    # ------------------------------------------------- EDGAR business calendar
    holiday_cache = {}

    def federal_holidays(year):
        """Observed US federal holidays (EDGAR closed). Jan 1 on a Saturday is
        observed on Dec 31 of the prior year, so callers also check year + 1."""
        if year in holiday_cache:
            return holiday_cache[year]

        def nth_weekday(month, weekday, n):
            first = dt.date(year, month, 1)
            return first + dt.timedelta(days=(weekday - first.weekday()) % 7 + 7 * (n - 1))

        def last_weekday(month, weekday):
            last = dt.date(year, month, calendar.monthrange(year, month)[1])
            return last - dt.timedelta(days=(last.weekday() - weekday) % 7)

        def observed(month, day):
            d = dt.date(year, month, day)
            if d.weekday() == 5:
                return d - ONE_DAY
            if d.weekday() == 6:
                return d + ONE_DAY
            return d

        days = {
            observed(1, 1), observed(7, 4), observed(11, 11), observed(12, 25),
            nth_weekday(1, 0, 3),   # Martin Luther King Jr. Day
            nth_weekday(2, 0, 3),   # Washington's Birthday
            last_weekday(5, 0),     # Memorial Day
            nth_weekday(9, 0, 1),   # Labor Day
            nth_weekday(10, 0, 2),  # Columbus Day
            nth_weekday(11, 3, 4),  # Thanksgiving
        }
        if year >= 2021:
            days.add(observed(6, 19))  # Juneteenth
        holiday_cache[year] = days
        return days

    def edgar_day_on_or_after(d):
        try:
            while (d.weekday() >= 5 or d in federal_holidays(d.year)
                   or d in federal_holidays(d.year + 1)):
                d += ONE_DAY
        except (OverflowError, ValueError):
            pass
        return d

    # ------------------------------------------------------------------ signal
    def target_weights(levels):
        n = len(levels)
        mean = math.fsum(levels) / n
        centered = [v - mean for v in levels]
        tolerance = 1e-12 * max(1.0, max(abs(v) for v in levels))
        if max(abs(v) for v in centered) <= tolerance:
            return [0.0] * n  # centered vector is zero -> cash
        gross = math.fsum(abs(v) for v in centered)
        weights = [v / gross for v in centered]
        for _ in range(3):  # guard against floating-point gross marginally above 1
            g = math.fsum(abs(v) for v in weights)
            if g <= 1.0:
                break
            weights = [v / g for v in weights]
        return weights

    def insufficient(reason, weights=None):
        result = {"status": "insufficient_data", "reason": reason}
        if weights is not None:
            result["weights"] = weights
        return result

    # --------------------------------------------------------------- structure
    if not isinstance(payload, Mapping):
        return insufficient("Payload is not a mapping with dates, assets and filings.")
    raw_assets = payload.get("assets")
    raw_dates = payload.get("dates")
    raw_filings = payload.get("filings")
    if not isinstance(raw_assets, (list, tuple)) or not raw_assets:
        return insufficient("No asset universe supplied, so no weight columns can be formed.")
    if not isinstance(raw_dates, (list, tuple)) or not raw_dates:
        return insufficient("No decision dates supplied.", [])

    names = [str(a).strip() for a in raw_assets]
    n_assets = len(names)
    known = set(names)
    equal_level = 100.0 / n_assets  # equal-weight level in weight_pct units

    dates = []
    for raw in raw_dates:
        d = as_date(raw)
        if d is None:
            return insufficient(
                f"Decision date {raw!r} is not an ISO YYYY-MM-DD date; rows cannot be aligned.")
        dates.append(d)
    cash = [[0.0] * n_assets for _ in dates]

    anomalies = []
    if len(known) < n_assets:
        anomalies.append("duplicate asset names share one value per name")
    if any(b <= a for a, b in zip(dates, dates[1:])):
        anomalies.append("dates are not strictly increasing; each row is still computed for its own date")
    if raw_filings is None:
        raw_filings = []
    if not isinstance(raw_filings, (list, tuple)):
        return insufficient(
            "Filings are not a list of rows; no holdings signal can be formed (all cash).", cash)

    # -------------------------------------------- rows -> public-dated versions
    groups = {}  # (asset, period_end, public_date, filing_date) -> [weight_pct]
    seen = set()
    malformed = exact_duplicates = filed_before_period = deferred = accepted = 0
    unknown_assets = set()
    for row in raw_filings:
        if not isinstance(row, Mapping):
            malformed += 1
            continue
        asset = row.get("asset")
        asset = str(asset).strip() if asset is not None else ""
        period_end = as_date(row.get("period_end"))
        filing_date = as_date(row.get("filing_date"))
        weight = as_number(row.get("weight_pct"))
        if not asset or period_end is None or filing_date is None or weight is None:
            malformed += 1
            continue
        if asset not in known:
            unknown_assets.add(asset)
            continue
        signature = (repr(row.get("row_id")), asset, period_end, filing_date, weight)
        if signature in seen:
            exact_duplicates += 1
            continue
        seen.add(signature)
        try:
            quarter_end = dt.date(period_end.year, period_end.month,
                                  calendar.monthrange(period_end.year, period_end.month)[1])
            public_date = edgar_day_on_or_after(max(filing_date, quarter_end + PUBLIC_LAG))
        except (OverflowError, ValueError):
            malformed += 1
            continue
        accepted += 1
        if filing_date < period_end:
            filed_before_period += 1
        if public_date > filing_date:
            deferred += 1
        groups.setdefault((asset, period_end, public_date, filing_date), []).append(weight)

    events = []
    versions = {}
    conflicting = redundant = 0
    for (asset, period_end, public_date, filing_date), values in groups.items():
        if len(values) > 1:
            spread = max(values) - min(values)
            if spread > 1e-12 * max(1.0, max(abs(v) for v in values)):
                conflicting += 1
            else:
                redundant += len(values) - 1
            value = math.fsum(values) / len(values)
        else:
            value = values[0]
        versions[(asset, period_end)] = versions.get((asset, period_end), 0) + 1
        events.append((public_date, filing_date, period_end, asset, value))
    events.sort(key=lambda e: e[:4])  # public date, then filing date (restatements last)
    multi_version = sum(1 for count in versions.values() if count > 1)

    if malformed:
        anomalies.append(f"{malformed} malformed row(s) skipped")
    if unknown_assets:
        anomalies.append(f"rows for {len(unknown_assets)} asset name(s) outside the universe ignored")
    if exact_duplicates or redundant:
        anomalies.append(f"{exact_duplicates + redundant} duplicate row(s) collapsed")
    if conflicting:
        anomalies.append(f"{conflicting} same-asset/period/filing-date group(s) with conflicting weights averaged")
    if multi_version:
        anomalies.append(f"{multi_version} asset/period(s) had several filing dates although one version is "
                         "expected; the later-filed row is applied as a restatement once public")
    if filed_before_period:
        anomalies.append(f"{filed_before_period} row(s) dated before period_end kept "
                         "(their public date is still >= quarter end + 60 days)")

    if not events:
        note = (" Assumptions: " + "; ".join(anomalies) + ".") if anomalies else ""
        return insufficient(
            "No usable filing rows for the asset universe; every date sits at the equal-weight "
            "level, i.e. all cash." + note, cash)

    # ------------------------------------------------- sweep decision dates
    current = {}  # asset -> (period_end, weight_pct) of latest public period/version
    rows = [None] * len(dates)
    cache = {}
    pointer = 0
    carried = blank = 0
    for idx in sorted(range(len(dates)), key=lambda i: dates[i]):
        day = dates[idx]
        if day not in cache:
            while pointer < len(events) and events[pointer][0] <= day:
                _, _, period_end, asset, value = events[pointer]
                held = current.get(asset)
                if held is None or period_end >= held[0]:
                    current[asset] = (period_end, value)
                pointer += 1
            latest = max((p for p, _ in current.values()), default=None)
            levels = []
            for name in names:
                held = current.get(name)
                if held is None:
                    levels.append(equal_level)
                    if latest is not None:
                        blank += 1
                else:
                    levels.append(held[1])
                    if held[0] < latest:
                        carried += 1
            cache[day] = target_weights(levels)
        rows[idx] = list(cache[day])
    active = sum(1 for r in rows if any(v != 0.0 for v in r))

    # ------------------------------------------------------------------ report
    parts = [
        "Row t is decided at the end of dates[t] (columns in assets order) and held over the next "
        "session open-to-close; prices are not used.",
        "A filing row is usable on day t only if its public date <= dates[t] (same day allowed, since "
        "decisions are end-of-day and dates carry no times). Public date = later of filing_date and "
        "fiscal-quarter month-end + 60 calendar days, rolled to the next EDGAR business day: under the "
        "2022-23 regime the public third-month N-PORT data were released 60 days after quarter end even "
        "when filed earlier; period_end is only the holdings as-of date.",
        "Per asset: latest public report period, latest public version within it; none yet -> "
        "equal-weight level 100/N %.",
        "Weights = weight_pct minus cross-sectional mean, divided by the sum of absolute deviations "
        "(gross 1, net 0); cash when that vector is zero.",
        f"{deferred} of {accepted} rows became usable after their filing_date; "
        f"{active} of {len(dates)} dates hold positions.",
    ]
    if carried:
        parts.append(f"{carried} date-asset cells carried an asset's older period because it was absent "
                     "from the fund's latest public period.")
    if blank:
        parts.append(f"{blank} date-asset cells used the equal-weight level while other assets already "
                     "had public data.")
    if anomalies:
        parts.append("Assumptions: " + "; ".join(anomalies) + ".")
    if active == 0:
        parts.append("No public holdings differ from the cross-sectional mean on any date, so the "
                     "output is all cash.")

    if active == 0:
        status = "insufficient_data"
    elif anomalies:
        status = "assumption"
    else:
        status = "ok"
    return {"status": status, "reason": " ".join(parts), "weights": rows}
