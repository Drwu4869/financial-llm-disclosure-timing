from datetime import date
from math import fsum, isfinite
import re


def build_strategy(payload):
    """
    Construct a point-in-time, holdings-based, dollar-neutral signal.

    Information policy:
      - A filing becomes eligible only when filing_date < decision_date.
      - Same-day filings are excluded because intraday publication
        timestamps are unavailable.
      - For each asset, prefer the latest eligible report period.
      - Within that period, prefer the latest eligible filing version.
      - Revisions supersede earlier versions prospectively, never
        retroactively.
      - Missing asset observations retain the equal-weight baseline.
      - Missing observations do not imply zero holdings.

    Execution policy:
      - Weights are determined at the end of each decision date.
      - They apply to the next session's open-to-close trade.
      - Execution and returns are evaluated externally.
      - Prices are never used to construct or optimize the signal.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")

        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value) is None:
            raise ValueError("Dates must use ISO YYYY-MM-DD format.")

        return date.fromisoformat(value)

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        dates = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]

        if not isinstance(dates, list) or not dates:
            return insufficient("At least one decision date is required.")

        if not isinstance(assets, list) or not assets:
            return insufficient("At least one asset is required.")

        if not isinstance(filings, list):
            return insufficient("Filings must be a list.")

        if any(
            not isinstance(asset, str) or not asset
            for asset in assets
        ):
            return insufficient("Asset identifiers must be nonempty strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        decision_dates = [parse_date(d) for d in dates]

        if any(
            decision_dates[i] <= decision_dates[i - 1]
            for i in range(1, len(decision_dates))
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n = len(assets)
        asset_index = {
            asset: i for i, asset in enumerate(assets)
        }

        # All weights are represented in percentage-point units.
        # Centering makes the common baseline irrelevant once every
        # asset has an observation.
        baseline = 100.0 / n

        # A version is identified by:
        # (asset, period_end, filing_date).
        #
        # row_id is intentionally not used for chronological ordering:
        # it is an opaque identifier.
        versions = {}

        for record in filings:
            if not isinstance(record, dict):
                return insufficient(
                    "Each filing row must be a dictionary."
                )

            asset = record["asset"]

            # Restrict the signal to the supplied security universe.
            if asset not in asset_index:
                continue

            period_end = parse_date(record["period_end"])
            filing_date = parse_date(record["filing_date"])

            raw_weight = record["weight_pct"]

            if isinstance(raw_weight, bool):
                return insufficient(
                    "Filing weights must be finite numeric values."
                )

            weight = float(raw_weight)

            if not isfinite(weight):
                return insufficient(
                    "Filing weights must be finite numeric values."
                )

            key = (asset, period_end, filing_date)

            if key in versions:
                if versions[key] != weight:
                    return insufficient(
                        "Conflicting weights have the same asset, "
                        "report period, and filing date; their "
                        "chronological order cannot be determined."
                    )
            else:
                versions[key] = weight

        # Sort by actual public filing date, not report period.
        #
        # The asset's current selected observation is determined
        # separately using (period_end, filing_date).
        events = sorted(
            (
                filing_date,
                period_end,
                asset_index[asset],
                weight
            )
            for (asset, period_end, filing_date), weight
            in versions.items()
        )

        # Per-asset selected version:
        # (period_end, filing_date)
        selected_version = [None] * n

        # Per-asset most recently applicable holdings weight.
        levels = [baseline] * n

        weights = []
        event_index = 0
        event_count = len(events)

        for decision_day in decision_dates:

            # Conservative point-in-time availability:
            # filings dated on the decision day are NOT used.
            #
            # This prevents a filing released after the decision
            # cutoff from entering that decision's signal.
            while (
                event_index < event_count
                and events[event_index][0] < decision_day
            ):
                filing_day, period, j, weight = events[event_index]

                candidate = (period, filing_day)
                current = selected_version[j]

                # Latest report period takes priority.
                # For the same period, the latest filing wins.
                #
                # A later amendment of an older report must not
                # displace an already available newer report.
                if current is None or candidate > current:
                    selected_version[j] = candidate
                    levels[j] = weight

                event_index += 1

            # Cross-sectional demeaning.
            mean_level = fsum(levels) / n

            centered = [
                level - mean_level
                for level in levels
            ]

            # Gross exposure = sum(abs(weight)).
            gross = fsum(abs(x) for x in centered)

            if gross == 0.0:
                # No cross-sectional differentiation:
                # hold cash rather than manufacture a position.
                row = [0.0] * n
            else:
                row = [
                    x / gross
                    for x in centered
                ]

            weights.append(row)

        return {
            "status": "assumption",
            "reason": (
                "Point-in-time alignment uses filing_date strictly "
                "before each end-of-day decision because intraday "
                "filing timestamps are unavailable. Per asset, the "
                "latest eligible report period and then latest "
                "filing version are selected. Unobserved assets "
                "use the equal-weight baseline. Signals are "
                "cross-sectionally centered and gross-normalized; "
                "zero signals remain in cash. Each row applies "
                "to the next session's open-to-close trade. "
                "Prices are excluded from signal construction; "
                "the external evaluator determines session "
                "alignment, execution, and realized returns."
            ),
            "weights": weights
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            f"Invalid or incomplete input: {exc}"
        )
