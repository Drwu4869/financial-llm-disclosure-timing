import math
import re
from datetime import date, datetime

_ISO_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_ZERO_TOL = 1e-12


def _parse_date(value):
    """Strict ISO YYYY-MM-DD -> datetime.date; None if unusable."""
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        s = value.strip()
        if _ISO_DATE.match(s):
            try:
                return date.fromisoformat(s)
            except ValueError:
                return None
    return None


def _parse_weight(value):
    """Finite, non-negative portfolio percentage; None if unusable."""
    if value is None or isinstance(value, bool):
        return None
    try:
        if isinstance(value, str):
            value = value.strip().rstrip("%").strip()
        x = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(x) or x < 0.0:
        return None
    return x


def _center_and_scale(raw):
    """Subtract cross-sectional mean, scale to unit gross; zero vector -> cash."""
    n = len(raw)
    mean = math.fsum(raw) / n
    centered = [x - mean for x in raw]
    scale = max(1.0, max(abs(x) for x in raw))
    if max(abs(x) for x in centered) <= _ZERO_TOL * scale:
        return [0.0] * n
    gross = math.fsum(abs(x) for x in centered)
    w = [x / gross for x in centered]
    # Guard against floating-point rounding pushing gross exposure above 1.
    while math.fsum(abs(x) for x in w) > 1.0:
        w = [x * (1.0 - 1e-15) for x in w]
    return w


def build_strategy(payload):
    def result(status, reason, weights=None):
        out = {"status": status, "reason": reason}
        if weights is not None:
            out["weights"] = weights
        return out

    if not isinstance(payload, dict):
        return result("insufficient_data", "Payload is not a mapping.")
    dates_raw = payload.get("dates")
    assets_raw = payload.get("assets")
    filings_raw = payload.get("filings")
    if not isinstance(dates_raw, (list, tuple)) or not isinstance(assets_raw, (list, tuple)):
        return result("insufficient_data", "Missing or malformed 'dates' or 'assets'.")

    n_dates, n_assets = len(dates_raw), len(assets_raw)
    if n_dates == 0:
        return result("insufficient_data", "No decision dates supplied.", [])
    cash = [[0.0] * n_assets for _ in range(n_dates)]
    if n_assets < 2:
        return result(
            "insufficient_data",
            "Fewer than two assets: a demeaned cross-sectional signal is always zero; holding cash.",
            cash,
        )

    assumptions, notes = [], []

    # Asset columns (fixed order). Duplicate names map to every matching column.
    cols = {}
    for j, a in enumerate(assets_raw):
        cols.setdefault(str(a), []).append(j)
    dup_assets = sum(len(v) - 1 for v in cols.values())
    if dup_assets:
        assumptions.append(f"{dup_assets} duplicate asset name(s); duplicated columns share one value")

    # Decision dates: each row is computed independently, so input order is preserved.
    dec = [_parse_date(d) for d in dates_raw]
    bad_dates = sum(1 for d in dec if d is None)
    if bad_dates:
        assumptions.append(f"{bad_dates} unparseable decision date(s) held in cash")
    valid_idx = [i for i, d in enumerate(dec) if d is not None]
    if not valid_idx:
        return result("insufficient_data", "No parseable decision dates; holding cash.", cash)
    if any(dec[a] > dec[b] for a, b in zip(valid_idx, valid_idx[1:])):
        notes.append("decision dates not ascending; each evaluated independently")

    # Filing rows -> versions keyed by (asset, period_end, filing_date).
    if not isinstance(filings_raw, (list, tuple)):
        filings_raw = []
    unknown = malformed = no_filed = impossible = 0
    groups = {}
    for row in filings_raw:
        if not isinstance(row, dict):
            malformed += 1
            continue
        asset = row.get("asset")
        key = None if asset is None else str(asset)
        if key not in cols:
            unknown += 1
            continue
        period = _parse_date(row.get("period_end"))
        weight = _parse_weight(row.get("weight_pct"))
        if period is None or weight is None:
            malformed += 1
            continue
        filed = _parse_date(row.get("filing_date"))
        if filed is None:
            no_filed += 1  # availability unknowable -> cannot be used without look-ahead risk
            continue
        if filed < period:
            impossible += 1  # a quarterly 13F cannot be filed before its period ends
            continue
        groups.setdefault((key, period, filed), []).append(weight)

    if unknown:
        assumptions.append(f"{unknown} row(s) for assets outside the universe ignored")
    if malformed:
        assumptions.append(f"{malformed} malformed row(s) (bad asset/period_end/weight_pct) ignored")
    if no_filed:
        assumptions.append(f"{no_filed} row(s) without a valid filing_date excluded")
    if impossible:
        assumptions.append(f"{impossible} row(s) with filing_date before period_end excluded")

    events = []
    versions = {}
    conflicts = collapsed = 0
    for (key, period, filed), ws in groups.items():
        lo, hi = min(ws), max(ws)
        if hi - lo <= _ZERO_TOL * max(1.0, abs(hi)):
            collapsed += len(ws) - 1
        else:
            conflicts += 1
        value = math.fsum(ws) / len(ws)
        events.append((filed, key, period, value))
        versions[(key, period)] = versions.get((key, period), 0) + 1
    events.sort()

    if collapsed:
        notes.append(f"{collapsed} identical duplicate row(s) collapsed")
    if conflicts:
        assumptions.append(
            f"{conflicts} asset/period/filing_date group(s) with conflicting weights averaged"
        )
    revised = sum(1 for v in versions.values() if v > 1)
    if revised:
        notes.append(f"{revised} asset/period(s) have revisions; latest version filed before each decision used")

    core = (
        "Point-in-time 13F alignment: a row is usable for the end-of-day decision on date d only if "
        "filing_date < d (same-day filings excluded because intraday filing times are absent; "
        "period_end is never used for availability). Per asset: latest available period_end, then the "
        "latest-filed version for that period; equal-weight level 100/N before any usable row. "
        "Vector demeaned and scaled to unit gross (net zero); zero vector -> cash. Prices unused."
    )

    def compose(extra):
        parts = [core] + extra
        if assumptions:
            parts.append("Assumptions: " + "; ".join(assumptions) + ".")
        if notes:
            parts.append("Notes: " + "; ".join(notes) + ".")
        return " ".join(parts)

    if not events:
        return result("insufficient_data", compose(["No usable filing rows; holding cash."]), cash)

    # Sweep decision dates in chronological order, releasing filings strictly before each date.
    ew_level = 100.0 / n_assets
    order = sorted(valid_idx, key=lambda i: dec[i])
    state = {}  # asset key -> (period_end, filing_date, weight_pct)
    weights = [[0.0] * n_assets for _ in range(n_dates)]
    ptr = 0
    dates_with_obs = 0
    for i in order:
        d = dec[i]
        while ptr < len(events) and events[ptr][0] < d:
            filed, key, period, value = events[ptr]
            ptr += 1
            cur = state.get(key)
            # Events arrive in filing order, so for an equal period this is a later revision.
            if cur is None or period > cur[0] or (period == cur[0] and filed >= cur[1]):
                state[key] = (period, filed, value)
        raw = [ew_level] * n_assets
        for key, (_, _, value) in state.items():
            for c in cols[key]:
                raw[c] = value
        if state:
            dates_with_obs += 1
        weights[i] = _center_and_scale(raw)

    summary = (
        f"{len(events)} usable version(s); {dates_with_obs}/{n_dates} date(s) had at least one "
        "applicable observation."
    )
    if dates_with_obs == 0:
        return result(
            "insufficient_data",
            compose([summary, "No filing was public before any decision date; holding cash."]),
            weights,
        )
    status = "assumption" if assumptions else "ok"
    return result(status, compose([summary]), weights)
