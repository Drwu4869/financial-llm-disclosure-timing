import math
from datetime import date, datetime


def build_strategy(payload):
    """Point-in-time 13F holdings signal.

    For each decision date D, each asset uses the row with the latest period_end among
    rows whose SEC filing_date <= D. Within that period, the latest-filed version applies.
    An EDGAR filing dated D is public by the end of D. The decision is made at the end of D
    and traded at the next session's open.

    An asset with no public row yet sits at the equal-weight level 100/N. The cross-section
    is demeaned and scaled to unit gross exposure, giving net exposure of zero. Prices are
    never read.
    """

    # ---------- helpers ----------
    def parse_day(x):
        if isinstance(x, datetime):
            return x.date()
        if isinstance(x, date):
            return x
        if not isinstance(x, str) or not x.strip():
            return None
        s = x.strip()
        try:
            return date.fromisoformat(s)
        except ValueError:
            pass
        try:
            return datetime.fromisoformat(s.replace("Z", "+00:00")).date()
        except ValueError:
            return None

    def parse_weight(x):
        if x is None or isinstance(x, bool):
            return None
        try:
            f = float(x)
        except (TypeError, ValueError):
            return None
        return f if (math.isfinite(f) and f >= 0.0) else None

    def result(status, reason, weights=None):
        out = {"status": status, "reason": reason}
        if weights is not None:
            out["weights"] = weights
        return out

    # ---------- payload ----------
    if not isinstance(payload, dict):
        return result("insufficient_data", "Payload is not a mapping.")
    raw_dates = payload.get("dates")
    raw_assets = payload.get("assets")
    raw_filings = payload.get("filings")
    if not isinstance(raw_dates, (list, tuple)) or len(raw_dates) == 0:
        return result("insufficient_data", "No decision dates supplied.")
    if not isinstance(raw_assets, (list, tuple)) or len(raw_assets) == 0:
        return result("insufficient_data", "No assets supplied.")
    if not isinstance(raw_filings, (list, tuple)):
        raw_filings = []

    n_dates, n_assets = len(raw_dates), len(raw_assets)

    def cash():
        return [[0.0] * n_assets for _ in range(n_dates)]

    notes = []
    flagged = False

    columns = {}
    for j, a in enumerate(raw_assets):
        columns.setdefault(str(a), []).append(j)
    if any(len(v) > 1 for v in columns.values()):
        flagged = True
        notes.append("repeated asset names share one filing series")

    decision = [parse_day(d) for d in raw_dates]
    valid_days = [d for d in decision if d is not None]
    if not valid_days:
        return result("insufficient_data", "No decision date is a valid ISO date.", cash())
    n_bad_days = n_dates - len(valid_days)
    if n_bad_days:
        flagged = True
        notes.append(f"{n_bad_days} unparseable decision date(s) held in cash")
    if any(b <= a for a, b in zip(valid_days, valid_days[1:])):
        notes.append("dates not strictly increasing; each row is still computed point-in-time")

    if n_assets < 2:
        return result(
            "insufficient_data",
            "Fewer than two assets: the demeaned cross-section is identically zero, so every row is cash.",
            cash(),
        )

    # ---------- filing rows ----------
    records = []
    n_malformed = n_unknown = n_undated = n_bad_weight = n_early = 0
    for row in raw_filings:
        if not isinstance(row, dict):
            n_malformed += 1
            continue
        asset = row.get("asset")
        key = None if asset is None else str(asset)
        if key not in columns:
            n_unknown += 1
            continue
        period = parse_day(row.get("period_end"))
        filed = parse_day(row.get("filing_date"))
        if period is None or filed is None:
            n_undated += 1
            continue
        weight = parse_weight(row.get("weight_pct"))
        if weight is None:
            n_bad_weight += 1
            continue
        if filed < period:  # impossible for a real 13F; never treat as public before period_end
            filed = period
            n_early += 1
        records.append((filed, period, key, weight))

    if n_malformed:
        flagged = True
        notes.append(f"{n_malformed} non-record row(s) ignored")
    if n_unknown:
        flagged = True
        notes.append(f"{n_unknown} row(s) for assets outside the universe ignored")
    if n_undated:
        flagged = True
        notes.append(f"{n_undated} row(s) lacking a valid period_end or filing_date dropped (availability unknowable)")
    if n_bad_weight:
        flagged = True
        notes.append(f"{n_bad_weight} row(s) with invalid weight_pct dropped")
    if n_early:
        flagged = True
        notes.append(f"{n_early} row(s) filed before their period_end treated as public from period_end")

    # Collapse to one value per (asset, period, filing date); detect duplicates and conflicts.
    groups = {}
    for filed, period, key, weight in records:
        groups.setdefault((key, period, filed), []).append(weight)

    n_conflict = sum(1 for v in groups.values() if len(set(v)) > 1)
    n_dupe = sum(len(v) - 1 for v in groups.values() if len(set(v)) == 1)
    versions = {}
    for key, period, filed in groups:
        versions.setdefault((key, period), set()).add(filed)
    n_revised = sum(1 for v in versions.values() if len(v) > 1)

    if n_conflict:
        flagged = True
        notes.append(f"{n_conflict} asset/period version(s) with conflicting same-day values averaged")
    if n_dupe:
        notes.append(f"{n_dupe} identical duplicate row(s) collapsed")
    if n_revised:
        notes.append(f"{n_revised} asset/period(s) restated; each version applies only from its own filing date")

    def collapse(vals):
        return vals[0] if len(set(vals)) == 1 else math.fsum(vals) / len(vals)

    events = sorted(
        ((filed, period, key, collapse(v)) for (key, period, filed), v in groups.items()),
        key=lambda e: e[0],
    )

    if not events:
        return result(
            "insufficient_data",
            "No usable filing rows; every asset stays at the equal-weight level, so all rows are cash.",
            cash(),
        )
    if events[0][0] > max(valid_days):
        return result(
            "insufficient_data",
            "No filing was public (by filing_date) on or before the last decision date; all rows are cash.",
            cash(),
        )

    # ---------- signal ----------
    def signal(level):
        mean = math.fsum(level) / n_assets
        centered = [x - mean for x in level]
        scale = max(1.0, max(abs(x) for x in level))
        if max(abs(x) for x in centered) <= 1e-12 * scale:
            return [0.0] * n_assets
        gross = math.fsum(abs(x) for x in centered)
        w = [x / gross for x in centered]
        g = math.fsum(abs(x) for x in w)
        if g > 1.0:  # guard against float round-up past 1
            w = [x / g * (1.0 - 1e-12) for x in w]
        return [x + 0.0 for x in w]  # also clears -0.0

    level_eq = 100.0 / n_assets
    current = {}  # asset key -> (period_end, filing_date, value)
    weights = cash()
    order = sorted((i for i in range(n_dates) if decision[i] is not None), key=lambda i: decision[i])

    k = 0
    for i in order:
        day = decision[i]
        while k < len(events) and events[k][0] <= day:
            filed, period, key, value = events[k]
            k += 1
            prev = current.get(key)
            if prev is None or (period, filed) > (prev[0], prev[1]):
                current[key] = (period, filed, value)
        level = [level_eq] * n_assets
        for key, (_, _, value) in current.items():
            for j in columns[key]:
                level[j] = value
        weights[i] = signal(level)

    reason = (
        "Aligned on SEC filing_date, not period_end. A row enters the signal at the end of the "
        "first decision date on or after its filing date: an EDGAR filing dated D is public by "
        "the end of D, decisions are end-of-day, and trades happen at the next session's open. "
        "Per asset: latest public period_end, then the latest-filed version within it; "
        "equal-weight level 100/N until the asset's first public row. Cross-sectionally "
        "demeaned and scaled to gross 1 (net 0); cash when flat. Prices are not read."
    )
    if notes:
        reason += " Notes: " + "; ".join(notes) + "."
    return result("assumption" if flagged else "ok", reason, weights)
