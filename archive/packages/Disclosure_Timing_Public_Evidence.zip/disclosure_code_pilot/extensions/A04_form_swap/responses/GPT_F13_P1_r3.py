def build_strategy(payload):
    """
    Build a point-in-time, holdings-based, market-neutral portfolio signal.

    Python 3.11; standard library only.

    Alignment:
      - Each decision occurs at the end of its supplied date.
      - A filing becomes eligible only when filing_date < decision_date.
        This conservative one-day lag avoids assuming an unknown
        intraday SEC publication time.
      - For each asset, use the most recent eligible report period.
      - Within that period, use the latest eligible filing version.
      - An asset without an eligible observation receives 1 / N.
      - Cross-sectionally demean and normalize to unit gross exposure.
      - Return cash when all centered values are zero.

    Prices are never used to construct or select signals.
    The external evaluator handles next-session execution and returns.
    """

    from datetime import date
    import math

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Dates must use ISO YYYY-MM-DD format.")

        return parsed

    # ------------------------------------------------------------
    # 1. Validate the input schema.
    # ------------------------------------------------------------

    if not isinstance(payload, dict):
        return insufficient("Payload must be a dictionary.")

    try:
        assets = payload["assets"]
        decision_strings = payload["dates"]
        filings = payload["filings"]
    except KeyError as exc:
        return insufficient(f"Missing required field: {exc.args[0]}.")

    if not isinstance(assets, list) or not assets:
        return insufficient("Assets must be a nonempty list.")

    if not all(isinstance(a, str) and a for a in assets):
        return insufficient("Asset identifiers must be nonempty strings.")

    if len(set(assets)) != len(assets):
        return insufficient("Asset identifiers must be unique.")

    if not isinstance(decision_strings, list) or not decision_strings:
        return insufficient("Decision dates must be a nonempty list.")

    if not isinstance(filings, list):
        return insufficient("Filings must be a list.")

    try:
        decision_dates = [parse_date(d) for d in decision_strings]
    except (ValueError, TypeError) as exc:
        return insufficient(f"Invalid decision date: {exc}")

    if any(
        decision_dates[i] <= decision_dates[i - 1]
        for i in range(1, len(decision_dates))
    ):
        return insufficient(
            "Decision dates must be strictly increasing."
        )

    n_assets = len(assets)
    asset_index = {asset: i for i, asset in enumerate(assets)}

    # ------------------------------------------------------------
    # 2. Parse filings without using their input order.
    #
    # Events contain:
    #   (filing_date, period_end, asset_index, weight_fraction)
    #
    # row_id is an opaque identifier, never a chronological key.
    # ------------------------------------------------------------

    events = []
    seen_ids = set()
    seen_versions = {}

    for row in filings:
        if not isinstance(row, dict):
            return insufficient("Every filing must be a dictionary.")

        required = (
            "row_id",
            "asset",
            "period_end",
            "filing_date",
            "weight_pct",
        )

        if any(field not in row for field in required):
            return insufficient(
                "A filing is missing one or more required fields."
            )

        row_id = row["row_id"]
        asset = row["asset"]

        if not isinstance(row_id, str) or not row_id:
            return insufficient("Invalid filing row_id.")

        if row_id in seen_ids:
            return insufficient("Duplicate filing row_id.")

        seen_ids.add(row_id)

        if not isinstance(asset, str) or asset not in asset_index:
            return insufficient(
                "A filing references an asset outside the universe."
            )

        try:
            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])
        except (ValueError, TypeError) as exc:
            return insufficient(f"Invalid filing date: {exc}")

        if filing_date < period_end:
            return insufficient(
                "A filing_date precedes its report period_end."
            )

        weight_pct = row["weight_pct"]

        if (
            isinstance(weight_pct, bool)
            or not isinstance(weight_pct, (int, float))
        ):
            return insufficient("weight_pct must be numeric.")

        try:
            weight_pct = float(weight_pct)
        except (ValueError, OverflowError):
            return insufficient("Invalid weight_pct.")

        if not math.isfinite(weight_pct):
            return insufficient("weight_pct must be finite.")

        if not 0.0 <= weight_pct <= 100.0:
            return insufficient(
                "weight_pct must be between 0 and 100."
            )

        weight_fraction = weight_pct / 100.0
        idx = asset_index[asset]

        # If two versions have the same asset, report period and
        # filing date but conflicting weights, their order cannot
        # be determined from the provided schema.
        version_key = (idx, period_end, filing_date)

        if version_key in seen_versions:
            if seen_versions[version_key] != weight_fraction:
                return insufficient(
                    "Conflicting versions have identical filing dates; "
                    "intraday ordering is unavailable."
                )
            continue

        seen_versions[version_key] = weight_fraction

        events.append(
            (filing_date, period_end, idx, weight_fraction)
        )

    # Sorting is independent of opaque row_id and input order.
    events.sort(key=lambda x: (x[0], x[1], x[2]))

    # ------------------------------------------------------------
    # 3. Construct point-in-time holdings.
    #
    # latest[i] is either None or:
    #   (period_end, filing_date, weight_fraction)
    #
    # The report period has precedence over revision date:
    # a late revision to an older period cannot replace an
    # already available newer report period.
    # ------------------------------------------------------------

    latest = [None] * n_assets
    event_cursor = 0
    n_events = len(events)

    equal_weight = 1.0 / n_assets
    weights = []

    for decision_date in decision_dates:

        # Strict inequality prevents same-day publication
        # uncertainty from introducing look-ahead bias.
        while (
            event_cursor < n_events
            and events[event_cursor][0] < decision_date
        ):
            filing_date, period_end, idx, value = events[event_cursor]

            previous = latest[idx]

            if (
                previous is None
                or (period_end, filing_date)
                   > (previous[0], previous[1])
            ):
                latest[idx] = (
                    period_end,
                    filing_date,
                    value,
                )

            event_cursor += 1

        # Use the most recent applicable observation per asset.
        # Before the first applicable observation, use equal weight.
        holdings = [
            equal_weight if item is None else item[2]
            for item in latest
        ]

        # --------------------------------------------------------
        # 4. Cross-sectional centering and gross normalization.
        # --------------------------------------------------------

        if all(value == holdings[0] for value in holdings):
            weights.append([0.0] * n_assets)
            continue

        cross_sectional_mean = math.fsum(holdings) / n_assets

        centered = [
            value - cross_sectional_mean
            for value in holdings
        ]

        # Correct floating-point centering residual.
        # This preserves the zero-net-exposure constraint.
        centered[-1] = -math.fsum(centered[:-1])

        gross = math.fsum(abs(value) for value in centered)

        if gross == 0.0 or not math.isfinite(gross):
            weights.append([0.0] * n_assets)
            continue

        signal = [value / gross for value in centered]

        # Correct any floating-point net residual after scaling.
        signal[-1] = -math.fsum(signal[:-1])

        # Rescale if rounding produced gross exposure above one.
        final_gross = math.fsum(abs(value) for value in signal)

        if final_gross > 1.0:
            signal = [
                value / final_gross
                for value in signal
            ]

        # Convert negative zero to ordinary zero.
        signal = [
            0.0 if value == 0.0 else value
            for value in signal
        ]

        weights.append(signal)

    # ------------------------------------------------------------
    # 5. Return the signal matrix.
    #
    # Rows follow payload["dates"].
    # Columns follow payload["assets"].
    #
    # No price-based optimization, return calculation, or
    # exchange-calendar inference is performed.
    # ------------------------------------------------------------

    return {
        "status": "assumption",
        "reason": (
            "Point-in-time alignment uses each asset's latest "
            "report period publicly filed strictly before the "
            "end-of-day decision date, with its latest eligible "
            "revision. Same-day filings are excluded because "
            "intraday publication times are unavailable. "
            "Missing observations use equal-weight levels. "
            "Signals are demeaned and normalized to unit gross "
            "exposure with zero net exposure, or cash when flat. "
            "Prices are not used; the evaluator independently "
            "aligns decisions to next-session open-to-close trades "
            "using the supplied synthetic session calendar."
        ),
        "weights": weights,
    }
