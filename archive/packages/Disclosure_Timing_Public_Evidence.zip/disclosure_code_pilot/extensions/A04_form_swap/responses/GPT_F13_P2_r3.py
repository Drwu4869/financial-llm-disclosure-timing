from datetime import date
from math import fsum, isfinite


def build_strategy(payload):
    """
    Build a point-in-time holdings-based long/short portfolio signal.

    Input:
        payload = {
            "dates": ["YYYY-MM-DD", ...],
            "assets": ["Asset_01", ...],
            "filings": [
                {
                    "row_id": "...",
                    "asset": "...",
                    "period_end": "YYYY-MM-DD",
                    "filing_date": "YYYY-MM-DD",
                    "weight_pct": 10.5
                },
                ...
            ],
            "prices": [...]
        }

    Output:
        {
            "status": "ok" | "assumption" | "insufficient_data",
            "reason": str,
            "weights": [[float, ...], ...]
        }

    Rules:
      - Only information filed on or before the decision date is usable.
      - Filing-day records are available at that day's close.
      - Each asset uses its latest publicly available report period.
      - Later-filed revisions apply prospectively, never retroactively.
      - Previously unobserved assets receive an equal-weight level.
      - Cross-sectional signals are demeaned and gross-normalized.
      - Zero centered signals produce cash positions.
      - Prices are never used to construct or optimize signals.
      - Execution and return evaluation are external to this function.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Dates must use ISO YYYY-MM-DD format.")

        return parsed

    try:
        dates = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]

        if not isinstance(dates, (list, tuple)):
            return insufficient("dates must be an ordered sequence.")

        if not isinstance(assets, (list, tuple)) or not assets:
            return insufficient("A nonempty asset universe is required.")

        if not isinstance(filings, (list, tuple)):
            return insufficient("filings must be a sequence.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        decision_dates = [parse_date(d) for d in dates]

        if any(
            decision_dates[i] <= decision_dates[i - 1]
            for i in range(1, len(decision_dates))
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        universe = set(assets)
        n_assets = len(assets)

        # weight_pct is expressed in percentage points.
        # The corresponding equal-weight level is 100 / N,
        # not 1 / N.
        equal_level = 100.0 / n_assets

        # Events:
        # (filing_date, period_end, asset, weight_pct)
        events = []

        # Detect conflicting versions with indistinguishable
        # point-in-time priority.
        seen_versions = {}

        for row in filings:
            asset = row["asset"]

            # Holdings outside the fixed strategy universe
            # do not affect its signal.
            if asset not in universe:
                continue

            filing_date_value = row.get("filing_date")

            if filing_date_value is None or filing_date_value == "":
                return insufficient(
                    "Actual SEC filing_date is missing for at least "
                    "one relevant holding. Exact historical alignment "
                    "cannot be established without actual public "
                    "filing dates."
                )

            filing_day = parse_date(filing_date_value)
            period_end = parse_date(row["period_end"])

            raw_weight = row["weight_pct"]

            if isinstance(raw_weight, bool):
                return insufficient(
                    "Holding percentages must be numeric."
                )

            weight = float(raw_weight)

            if not isfinite(weight):
                return insufficient(
                    "Holding percentages must be finite numbers."
                )

            # row_id is opaque and is deliberately not used
            # to infer publication or revision chronology.
            version_key = (asset, period_end, filing_day)

            if version_key in seen_versions:
                previous_weight = seen_versions[version_key]

                if previous_weight != weight:
                    return insufficient(
                        "Conflicting versions exist for the same "
                        "asset, report period, and filing date. "
                        "Date-only records cannot establish their "
                        "ordering."
                    )

                # Identical duplicate observations are harmless.
                continue

            seen_versions[version_key] = weight

            events.append(
                (filing_day, period_end, asset, weight)
            )

        # Process disclosure events in actual filing-date order,
        # not report-period order or input-row order.
        events.sort(key=lambda event: event[0])

        # For each asset, retain:
        # (latest_period_end, version_filing_date, weight_pct)
        latest = {}

        weights = []
        event_index = 0
        event_count = len(events)

        for decision_day in decision_dates:

            # All filings publicly available by the end of
            # this decision day are eligible.
            while (
                event_index < event_count
                and events[event_index][0] <= decision_day
            ):
                filing_day, period_end, asset, weight = (
                    events[event_index]
                )

                current = latest.get(asset)

                candidate_priority = (period_end, filing_day)

                if current is None:
                    latest[asset] = (
                        period_end,
                        filing_day,
                        weight,
                    )
                else:
                    current_priority = (
                        current[0],
                        current[1],
                    )

                    # Prefer the newest report period.
                    # Within that period, prefer the latest
                    # version actually filed as of this day.
                    #
                    # An amendment to an older period must
                    # not replace a newer available period.
                    if candidate_priority > current_priority:
                        latest[asset] = (
                            period_end,
                            filing_day,
                            weight,
                        )

                event_index += 1

            # Construct levels in the exact supplied asset order.
            # Missing observations retain equal-weight levels.
            levels = [
                latest[asset][2]
                if asset in latest
                else equal_level
                for asset in assets
            ]

            # Remove the cross-sectional mean.
            cross_sectional_mean = fsum(levels) / n_assets

            centered = [
                level - cross_sectional_mean
                for level in levels
            ]

            # Gross L1 normalization.
            gross = fsum(abs(value) for value in centered)

            if gross == 0.0:
                # No cross-sectional information:
                # hold cash rather than invent positions.
                day_weights = [0.0] * n_assets
            else:
                day_weights = [
                    value / gross
                    for value in centered
                ]

                # Correct floating-point residuals in the
                # centered vector to maintain a numerically
                # market-neutral portfolio.
                #
                # The correction is limited to rounding error;
                # it does not change the intended signal.
                if n_assets > 1:
                    day_weights[-1] = -fsum(
                        day_weights[:-1]
                    )

                # Guard against floating-point gross exposure
                # exceeding one by a rounding increment.
                actual_gross = fsum(
                    abs(value) for value in day_weights
                )

                if actual_gross > 1.0:
                    day_weights = [
                        value / actual_gross
                        for value in day_weights
                    ]

                # A final conservative rounding guard.
                if fsum(abs(x) for x in day_weights) > 1.0:
                    day_weights = [
                        value * (1.0 - 1e-15)
                        for value in day_weights
                    ]

            weights.append(day_weights)

        return {
            "status": "ok",
            "reason": (
                "Point-in-time alignment uses supplied actual SEC "
                "filing dates, including disclosures available at "
                "filing-day close. Each asset uses its latest "
                "available report period and applicable filed "
                "version; revisions are prospective only. "
                "Unobserved assets use the equal-weight level. "
                "Signals are demeaned and gross-normalized, with "
                "cash when the centered vector is zero. "
                "Prices are excluded from signal construction. "
                "Decisions occur at date close; next-listed-session "
                "open-to-close execution and independent return "
                "evaluation are handled externally."
            ),
            "weights": weights,
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            "Invalid or incomplete input schema: "
            + str(exc)
        )
