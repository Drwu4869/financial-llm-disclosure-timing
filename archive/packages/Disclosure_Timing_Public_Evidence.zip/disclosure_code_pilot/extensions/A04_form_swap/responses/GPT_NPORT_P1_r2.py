from datetime import date
from math import fsum, isfinite


def build_strategy(payload):
    """
    Construct a point-in-time holdings-based long/short portfolio.

    Alignment:
      - Use SEC filing_date, not period_end, as the availability date.
      - Because intraday filing times are unavailable, a filing becomes
        eligible only on decision dates strictly after its filing_date.
      - For each asset, select the latest available report period.
      - Within that period, select the latest available revision.
      - Never use row_id to infer chronological order.

    Signal:
      - Use 100 / N as the initial equal-weight percentage for each asset.
      - Cross-sectionally demean the resulting holdings percentages.
      - Normalize absolute portfolio exposure to at most 1.
      - Maintain zero net exposure.
      - Return all-zero weights when the holdings vector is constant.

    Evaluation:
      - Decisions correspond to the ends of the supplied dates.
      - Execution is at the next synthetic session's open, followed by
        liquidation at that session's close.
      - Prices are deliberately excluded from signal construction.
      - The independent evaluator is responsible for realized returns.

    Returns:
      {
          "status": "ok" | "assumption" | "insufficient_data",
          "reason": str,
          "weights": list[list[float]]
      }
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": str(reason),
        }

    def parse_date(value):
        if (
            not isinstance(value, str)
            or len(value) != 10
            or value[4] != "-"
            or value[7] != "-"
        ):
            raise ValueError("Dates must use ISO YYYY-MM-DD format.")
        return date.fromisoformat(value)

    def normalize(levels):
        """
        Cross-sectionally demean and L1-normalize.

        Scaling before centering improves numerical stability when
        holdings contain large finite values.
        """
        n = len(levels)

        if n <= 1:
            return [0.0] * n

        scale = max(1.0, max(abs(x) for x in levels))
        scaled = [x / scale for x in levels]

        mean = fsum(scaled) / n
        centered = [x - mean for x in scaled]

        gross = fsum(abs(x) for x in centered)

        if gross == 0.0:
            return [0.0] * n

        weights = [x / gross for x in centered]

        # Correct floating-point residual net exposure.
        residual = fsum(weights)
        weights[-1] -= residual

        # Ensure gross exposure remains bounded by one.
        adjusted_gross = fsum(abs(x) for x in weights)

        if adjusted_gross > 1.0:
            weights = [x / adjusted_gross for x in weights]

        # Remove negative zero for consistent output.
        return [0.0 if x == 0.0 else float(x) for x in weights]

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        dates = payload.get("dates")
        assets = payload.get("assets")
        filings = payload.get("filings")

        if not isinstance(dates, list) or not dates:
            return insufficient("At least one decision date is required.")

        if not isinstance(assets, list) or not assets:
            return insufficient("At least one asset is required.")

        if not isinstance(filings, list):
            return insufficient("Filings must be a list.")

        if any(
            not isinstance(asset, str) or not asset
            for asset in assets
        ):
            return insufficient("Asset identifiers must be nonempty strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        decision_dates = [parse_date(d) for d in dates]

        if any(
            decision_dates[i] >= decision_dates[i + 1]
            for i in range(len(decision_dates) - 1)
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n_assets = len(assets)
        asset_index = {
            asset: i for i, asset in enumerate(assets)
        }

        equal_weight_level = 100.0 / n_assets

        # Deduplicate identical records and detect ambiguous versions.
        #
        # A version is identified by:
        #   (asset, period_end, filing_date)
        #
        # Two different weights for this same key cannot be ordered
        # using the supplied information.
        versions = {}

        for row in filings:
            if not isinstance(row, dict):
                return insufficient("Every filing must be a dictionary.")

            asset = row["asset"]

            if asset not in asset_index:
                return insufficient(
                    f"Filing references unknown asset: {asset!r}."
                )

            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])

            if period_end > filing_date:
                return insufficient(
                    "A filing cannot precede its holdings period_end."
                )

            raw_weight = row["weight_pct"]

            if (
                isinstance(raw_weight, bool)
                or not isinstance(raw_weight, (int, float))
            ):
                return insufficient(
                    "weight_pct must be a finite numeric value."
                )

            weight = float(raw_weight)

            if not isfinite(weight):
                return insufficient(
                    "weight_pct must be finite."
                )

            key = (
                asset_index[asset],
                period_end,
                filing_date,
            )

            if key in versions:
                if versions[key] != weight:
                    return insufficient(
                        "Conflicting weights exist for the same asset, "
                        "report period, and filing date; intraday "
                        "revision order cannot be determined."
                    )
            else:
                versions[key] = weight

        # Events are sorted by public filing date.
        #
        # Sorting by row_id would be incorrect: row_id is opaque.
        # Sorting by period_end alone would introduce look-ahead.
        events = [
            (filing_date, period_end, asset_idx, weight)
            for (asset_idx, period_end, filing_date), weight
            in versions.items()
        ]

        events.sort(key=lambda event: (
            event[0],
            event[1],
            event[2],
        ))

        # Latest applicable observation for each asset:
        #
        # (period_end, filing_date, weight_pct)
        #
        # Report period takes precedence over revision filing date.
        # Therefore a late amendment to an older period does not
        # overwrite an already available newer period.
        latest = [None] * n_assets

        weights = []
        event_pos = 0
        n_events = len(events)

        for decision_day in decision_dates:

            # Strict inequality prevents using a filing that might
            # have appeared after the market close on this day.
            while (
                event_pos < n_events
                and events[event_pos][0] < decision_day
            ):
                filing_day, period_end, asset_idx, weight = (
                    events[event_pos]
                )

                current = latest[asset_idx]

                if (
                    current is None
                    or (period_end, filing_day)
                    > (current[0], current[1])
                ):
                    latest[asset_idx] = (
                        period_end,
                        filing_day,
                        weight,
                    )

                event_pos += 1

            # Each asset independently uses its most recent
            # applicable report/version. Missing history receives
            # the equal-weight percentage level.
            levels = [
                (
                    latest[i][2]
                    if latest[i] is not None
                    else equal_weight_level
                )
                for i in range(n_assets)
            ]

            portfolio = normalize(levels)
            weights.append(portfolio)

        return {
            "status": "assumption",
            "reason": (
                "Used public SEC filing dates for point-in-time "
                "availability, conservatively excluding filings "
                "dated on the decision day because intraday "
                "publication times are unknown. For each asset, "
                "selected the newest available report period and "
                "then its newest available revision. Missing "
                "observations use the equal-weight percentage "
                "level. Signals are cross-sectionally demeaned "
                "and gross-normalized, with zero exposure for "
                "constant vectors. Prices were not used; "
                "independent evaluation executes at the next "
                "supplied session's open and exits at its close."
            ),
            "weights": weights,
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            f"Invalid or incomplete input data: {exc}"
        )
