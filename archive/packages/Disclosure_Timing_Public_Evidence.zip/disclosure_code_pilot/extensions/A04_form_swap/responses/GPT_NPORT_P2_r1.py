from datetime import date
from math import fsum, isfinite
import re


def build_strategy(payload):
    """
    Build a point-in-time, holdings-based, dollar-neutral portfolio signal.

    Rules:
      - Use actual SEC filing dates, never an estimated filing lag.
      - A filing becomes eligible at the end of its filing_date.
      - For each asset, select the latest eligible report period.
      - Within that period, use the latest eligible filed version.
      - Revisions never affect decisions preceding their filing dates.
      - Before an asset has an eligible observation, use 100 / N percent.
      - Cross-sectionally demean and normalize to unit gross exposure.
      - Return cash if the cross-sectional vector is constant.
      - Never use prices to select, optimize, or modify signals.

    Output weights correspond to decisions at the end of payload["dates"].
    Execution occurs at the next listed session's open, with liquidation
    at that session's close. The independent evaluator handles returns.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if (
            not isinstance(value, str)
            or re.fullmatch(r"\d{4}-\d{2}-\d{2}", value) is None
        ):
            raise ValueError("Dates must use ISO YYYY-MM-DD format.")
        return date.fromisoformat(value)

    # ---------------------------------------------------------------
    # 1. Validate the input universe and decision dates.
    # ---------------------------------------------------------------

    if not isinstance(payload, dict):
        return insufficient("Payload must be a dictionary.")

    try:
        assets = payload["assets"]
        decision_dates_raw = payload["dates"]
        filings = payload["filings"]
    except KeyError as exc:
        return insufficient(f"Missing required field: {exc.args[0]}.")

    if (
        not isinstance(assets, (list, tuple))
        or not assets
        or any(not isinstance(a, str) or not a for a in assets)
        or len(set(assets)) != len(assets)
    ):
        return insufficient("Assets must be a nonempty list of unique names.")

    if not isinstance(decision_dates_raw, (list, tuple)):
        return insufficient("Decision dates must be a list.")

    if not isinstance(filings, (list, tuple)):
        return insufficient("Filings must be a list.")

    try:
        decision_dates = [parse_date(d) for d in decision_dates_raw]
    except (ValueError, TypeError) as exc:
        return insufficient(f"Invalid decision date: {exc}")

    if any(
        decision_dates[i] >= decision_dates[i + 1]
        for i in range(len(decision_dates) - 1)
    ):
        return insufficient(
            "Decision dates must be strictly increasing."
        )

    n_assets = len(assets)
    asset_index = {asset: i for i, asset in enumerate(assets)}
    equal_weight_level = 100.0 / n_assets

    # ---------------------------------------------------------------
    # 2. Parse actual filing dates and check version ambiguity.
    #
    # Each event is:
    #   (filing_date, period_end, asset_index, weight_pct)
    #
    # row_id is opaque and must not be used to infer chronological order.
    # ---------------------------------------------------------------

    events = []
    version_values = {}

    for row_number, row in enumerate(filings):
        if not isinstance(row, dict):
            return insufficient(
                f"Filing row {row_number} must be a dictionary."
            )

        if "filing_date" not in row or row["filing_date"] is None:
            return insufficient(
                "Actual SEC filing_date is missing; exact historical "
                "alignment cannot be established from these inputs."
            )

        try:
            asset = row["asset"]
            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])
            raw_weight = row["weight_pct"]
        except (KeyError, ValueError, TypeError) as exc:
            return insufficient(
                f"Incomplete or invalid filing row {row_number}: {exc}"
            )

        if asset not in asset_index:
            return insufficient(
                f"Filing row {row_number} references an unknown asset."
            )

        if isinstance(raw_weight, bool):
            return insufficient(
                f"Invalid weight_pct in filing row {row_number}."
            )

        try:
            weight_pct = float(raw_weight)
        except (TypeError, ValueError, OverflowError):
            return insufficient(
                f"Invalid weight_pct in filing row {row_number}."
            )

        if not isfinite(weight_pct):
            return insufficient(
                f"Nonfinite weight_pct in filing row {row_number}."
            )

        # Two conflicting values for the same asset, report period,
        # and filing day cannot be ordered using opaque row IDs.
        version_key = (asset, period_end, filing_date)

        if version_key in version_values:
            if version_values[version_key] != weight_pct:
                return insufficient(
                    "Conflicting versions share the same asset, "
                    "report period, and filing date; their order "
                    "cannot be established without timestamps."
                )
            continue

        version_values[version_key] = weight_pct

        events.append(
            (
                filing_date,
                period_end,
                asset_index[asset],
                weight_pct,
            )
        )

    # Sort by actual filing date, never by row_id or an invented lag.
    # Other tuple fields provide deterministic ordering on the same day.
    events.sort()

    # ---------------------------------------------------------------
    # 3. Process filing events chronologically.
    #
    # Active state is independent for each asset.
    #
    # A newer report period supersedes an older report period.
    # A later-filed revision supersedes the earlier version only
    # when the report periods match.
    #
    # An older period revised after a newer period has become
    # applicable does not displace that newer period.
    # ---------------------------------------------------------------

    active_periods = [None] * n_assets
    active_weights = [equal_weight_level] * n_assets

    event_cursor = 0
    same_day_assumption_used = False

    output_weights = []

    for decision_day in decision_dates:

        while (
            event_cursor < len(events)
            and events[event_cursor][0] <= decision_day
        ):
            filing_day, period_end, idx, weight_pct = (
                events[event_cursor]
            )

            current_period = active_periods[idx]

            if (
                current_period is None
                or period_end >= current_period
            ):
                active_periods[idx] = period_end
                active_weights[idx] = weight_pct

                if filing_day == decision_day:
                    same_day_assumption_used = True

            event_cursor += 1

        # -----------------------------------------------------------
        # 4. Construct the signal from holdings only.
        # -----------------------------------------------------------

        levels = active_weights

        # Constant holdings levels imply a zero centered signal.
        # This explicit comparison also avoids floating-point noise
        # when all levels are equal.
        if all(value == levels[0] for value in levels):
            output_weights.append([0.0] * n_assets)
            continue

        cross_sectional_mean = fsum(levels) / n_assets

        centered = [
            value - cross_sectional_mean
            for value in levels
        ]

        gross = fsum(abs(value) for value in centered)

        if gross == 0.0:
            output_weights.append([0.0] * n_assets)
            continue

        # Standard L1 normalization of the demeaned holdings vector.
        signal = [
            value / gross
            for value in centered
        ]

        # Guard against a tiny floating-point overshoot of gross = 1.
        realized_gross = fsum(abs(value) for value in signal)

        if realized_gross > 1.0:
            signal = [
                value / realized_gross
                for value in signal
            ]

        # Net exposure is zero to floating-point precision because
        # each signal is constructed by cross-sectional demeaning.
        output_weights.append(signal)

    # ---------------------------------------------------------------
    # 5. Return signals for the independent historical evaluator.
    #
    # Prices are deliberately not consulted. Close-only price data
    # cannot establish next-session open-to-close execution returns.
    #
    # The evaluator is responsible for:
    #   - Matching each decision to the next listed session.
    #   - Executing at that next session's open.
    #   - Liquidating at that session's close.
    #   - Calculating realized returns independently.
    # ---------------------------------------------------------------

    if same_day_assumption_used:
        status = "assumption"
        reason = (
            "Aligned by actual SEC filing_date <= decision date; "
            "latest eligible report period and filed version per asset. "
            "Date-only records are assumed available at the end of "
            "their filing day. Execution and returns are evaluated "
            "independently in the next listed session."
        )
    else:
        status = "ok"
        reason = (
            "Aligned by actual SEC filing_date <= decision date; "
            "latest eligible report period and filed version per asset. "
            "No same-day filing assumption affected the signals. "
            "Execution and returns are evaluated independently "
            "in the next listed session."
        )

    return {
        "status": status,
        "reason": reason,
        "weights": output_weights,
    }
