from datetime import date
from math import fsum, isfinite, nextafter


def build_strategy(payload):
    """
    Construct point-in-time, dollar-neutral holdings signals.

    Rules:
    - Use actual SEC filing dates, never report-period dates as
      availability dates or an assumed reporting lag.
    - A filing is available at the end of its filing_date.
    - For each asset, select the newest available report period.
    - Within that period, select the latest available revision.
    - Before an asset's first applicable filing, use 100 / N percent.
    - Cross-sectionally demean and normalize to unit gross exposure.
    - Return zero weights when the centered signal is zero.
    - Signals are decided at each supplied date's close and are
      intended for execution at the next listed session's open,
      with liquidation at that session's close.
    - Do not use prices to construct or tune signals. The external
      evaluator is responsible for execution and return calculations.

    Returns:
        {
            "status": "ok" | "assumption" | "insufficient_data",
            "reason": str,
            "weights": list[list[float]]  # when available
        }
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Dates must use ISO YYYY-MM-DD format.")

        return parsed

    # ---------------------------------------------------------
    # 1. Validate the decision dates and fixed asset universe.
    # ---------------------------------------------------------

    if not isinstance(payload, dict):
        return insufficient("Payload must be a dictionary.")

    raw_dates = payload.get("dates")
    assets = payload.get("assets")
    filings = payload.get("filings")

    if not isinstance(raw_dates, (list, tuple)) or not raw_dates:
        return insufficient("At least one decision date is required.")

    if not isinstance(assets, (list, tuple)) or not assets:
        return insufficient("A nonempty asset universe is required.")

    if not all(isinstance(asset, str) and asset for asset in assets):
        return insufficient("Asset identifiers must be nonempty strings.")

    if len(set(assets)) != len(assets):
        return insufficient("Asset identifiers must be unique.")

    if not isinstance(filings, (list, tuple)):
        return insufficient("Filings must be a list of records.")

    try:
        decision_dates = [parse_date(value) for value in raw_dates]
    except (TypeError, ValueError) as exc:
        return insufficient(f"Invalid decision date: {exc}")

    if any(
        decision_dates[i] <= decision_dates[i - 1]
        for i in range(1, len(decision_dates))
    ):
        return insufficient(
            "Decision dates must be strictly increasing."
        )

    n_assets = len(assets)
    asset_set = set(assets)
    equal_weight_pct = 100.0 / n_assets

    # ---------------------------------------------------------
    # 2. Parse filings without using row_id as a time ordering.
    #
    # A version is identified by:
    #   asset, period_end, filing_date
    #
    # Distinct filing dates for the same asset and report period
    # represent successively available versions.
    #
    # Conflicting versions with the same filing date cannot be
    # chronologically ordered from date-only records.
    # ---------------------------------------------------------

    events = {asset: [] for asset in assets}
    seen_versions = {}

    for index, record in enumerate(filings):
        if not isinstance(record, dict):
            return insufficient(
                f"Filing row {index} must be a dictionary."
            )

        asset = record.get("asset")

        if not isinstance(asset, str) or not asset:
            return insufficient(
                f"Filing row {index} has an invalid asset."
            )

        # Rows outside the requested fixed universe do not
        # contribute to its signal.
        if asset not in asset_set:
            continue

        if record.get("filing_date") is None:
            return insufficient(
                "Actual SEC filing dates are missing. "
                "Exact historical point-in-time alignment cannot "
                "be established from these inputs; no filing "
                "dates or fixed reporting lags are inferred."
            )

        try:
            period_end = parse_date(record["period_end"])
            filing_date = parse_date(record["filing_date"])

            raw_weight = record["weight_pct"]

            if isinstance(raw_weight, bool):
                raise ValueError("Boolean weight is invalid.")

            weight_pct = float(raw_weight)

            if not isfinite(weight_pct):
                raise ValueError("Weight must be finite.")

        except (KeyError, TypeError, ValueError, OverflowError) as exc:
            return insufficient(
                f"Invalid filing row {index}: {exc}"
            )

        # One unambiguous weight per asset, period and filing day.
        version_key = (asset, period_end, filing_date)

        if version_key in seen_versions:
            if seen_versions[version_key] != weight_pct:
                return insufficient(
                    "Conflicting weights exist for the same asset, "
                    "report period and filing date. Date-only "
                    "records cannot determine which version was "
                    "available last."
                )

            # Identical duplicate observations change nothing.
            continue

        seen_versions[version_key] = weight_pct

        events[asset].append(
            (filing_date, period_end, weight_pct)
        )

    # Sort chronologically by actual public availability.
    # Report periods break same-day ties, not row identifiers.
    for asset in assets:
        events[asset].sort(key=lambda item: (item[0], item[1]))

    # ---------------------------------------------------------
    # 3. Maintain point-in-time holdings for each asset.
    #
    # The most recent report period has priority.
    # Revisions only replace the version of their own period.
    # A late revision to an older period must not replace an
    # already available newer report period.
    # ---------------------------------------------------------

    cursors = {asset: 0 for asset in assets}
    latest_period = {asset: None for asset in assets}
    latest_weight = {
        asset: equal_weight_pct for asset in assets
    }

    output_weights = []

    for decision_day in decision_dates:

        levels = []

        for asset in assets:
            asset_events = events[asset]
            cursor = cursors[asset]

            # Filing-day inclusion is intentional: decisions
            # occur at end of day, not before publication.
            while (
                cursor < len(asset_events)
                and asset_events[cursor][0] <= decision_day
            ):
                filing_date, period_end, weight_pct = (
                    asset_events[cursor]
                )

                current_period = latest_period[asset]

                if (
                    current_period is None
                    or period_end >= current_period
                ):
                    # If the period is newer, adopt it.
                    # If equal, adopt its later-filed revision.
                    latest_period[asset] = period_end
                    latest_weight[asset] = weight_pct

                cursor += 1

            cursors[asset] = cursor

            # Prior to the first applicable filing, this remains
            # the equal-weight percentage baseline.
            levels.append(latest_weight[asset])

        # -----------------------------------------------------
        # 4. Cross-sectional demeaning.
        # -----------------------------------------------------

        try:
            cross_sectional_mean = fsum(levels) / n_assets

            centered = [
                level - cross_sectional_mean
                for level in levels
            ]

            # Remove residual floating-point summation error.
            # This also handles the single-asset case.
            centered[-1] = -fsum(centered[:-1])

            gross = fsum(abs(value) for value in centered)

        except OverflowError:
            return insufficient(
                "Holdings values exceed stable numerical range."
            )

        if not isfinite(gross):
            return insufficient(
                "Holdings normalization is not numerically finite."
            )

        # No cross-sectional information => hold cash.
        if gross == 0.0:
            output_weights.append([0.0] * n_assets)
            continue

        # -----------------------------------------------------
        # 5. Normalize gross exposure to approximately one.
        # -----------------------------------------------------

        row = [
            value / gross
            for value in centered
        ]

        # Keep the final component dollar-neutral to floating-
        # point precision after division.
        row[-1] = -fsum(row[:-1])

        # Guard against a floating-point overshoot of unit gross.
        actual_gross = fsum(abs(value) for value in row)

        if actual_gross > 1.0:
            divisor = nextafter(actual_gross, float("inf"))
            row = [value / divisor for value in row]

        output_weights.append(row)

    # Prices are deliberately not used:
    # - no look-ahead from future closes;
    # - no price-based calibration;
    # - no invented next-session open prices;
    # - no assumption about a real exchange calendar.
    #
    # The external evaluator aligns each row to the next
    # authoritative synthetic session and independently
    # computes its open-to-close trading return.

    return {
        "status": "ok",
        "reason": (
            "Point-in-time alignment uses actual SEC filing dates, "
            "inclusive at each decision day's end. For each asset, "
            "the newest available report period and its latest "
            "filed version are selected independently; older-period "
            "revisions never supersede newer periods. Unobserved "
            "assets use the 100/N percentage baseline. Signals "
            "are demeaned, dollar-neutral and limited to unit "
            "gross exposure; zero signals hold cash. Decisions "
            "are intended for execution at the next listed "
            "session's open and liquidation at its close. "
            "Prices are not used; returns are evaluated separately."
        ),
        "weights": output_weights,
    }
