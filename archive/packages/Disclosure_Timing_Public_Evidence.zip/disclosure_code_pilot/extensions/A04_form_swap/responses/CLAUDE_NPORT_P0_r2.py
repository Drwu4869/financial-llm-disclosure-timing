import math
from datetime import date, datetime
from fractions import Fraction


def _parse_date(x):
    """Strict ISO YYYY-MM-DD (a trailing 'T...' / ' ...' time part is tolerated and dropped)."""
    if isinstance(x, datetime):
        return x.date()
    if isinstance(x, date):
        return x
    if not isinstance(x, str):
        return None
    s = x.strip()
    if len(s) < 10 or s[4] != "-" or s[7] != "-":
        return None
    if len(s) > 10 and s[10] not in "T ":
        return None
    try:
        return date.fromisoformat(s[:10])
    except ValueError:
        return None


def _parse_pct(x):
    """Exact rational from a finite numeric value (floats via their shortest decimal repr)."""
    if x is None or isinstance(x, bool):
        return None
    try:
        if isinstance(x, Fraction):
            return x
        if isinstance(x, int):
            return Fraction(x)
        if isinstance(x, float):
            return Fraction(repr(x)) if math.isfinite(x) else None
        s = str(x).strip()
        if not math.isfinite(float(s)):
            return None
        try:
            return Fraction(s)
        except (ValueError, ZeroDivisionError):
            return Fraction(repr(float(s)))
    except (TypeError, ValueError, OverflowError, ZeroDivisionError):
        return None


def _to_float(fr):
    """Float rounded toward zero, so the float gross never exceeds the exact gross of 1."""
    f = float(fr)
    if f != 0.0 and abs(Fraction(f)) > abs(fr):
        f = math.nextafter(f, 0.0)
    return f + 0.0  # normalise -0.0


def build_strategy(payload):
    def insufficient(msg, weights=None):
        out = {"status": "insufficient_data", "reason": msg}
        if weights is not None:
            out["weights"] = weights
        return out

    if not isinstance(payload, dict):
        return insufficient("Payload is not a mapping.")

    # ---- universe -------------------------------------------------------------
    raw_assets = payload.get("assets")
    if not isinstance(raw_assets, (list, tuple)) or not raw_assets:
        return insufficient("No assets supplied.")
    assets = [str(a).strip() for a in raw_assets]
    n = len(assets)

    # ---- decision dates (authoritative synthetic sessions) ---------------------
    raw_dates = payload.get("dates")
    if not isinstance(raw_dates, (list, tuple)) or not raw_dates:
        return insufficient("No decision dates supplied.")
    dec = []
    for d in raw_dates:
        pd = _parse_date(d)
        if pd is None:
            return insufficient(f"Unparseable decision date {d!r}.")
        dec.append(pd)
    cash = [[0.0] * n for _ in dec]

    notes = []
    if any(dec[i] >= dec[i + 1] for i in range(len(dec) - 1)):
        notes.append("dates not strictly increasing; each row still uses only data public before its own date")
    if len(set(assets)) != n:
        notes.append("duplicate asset names share one signal value")

    # ---- filings: validate, keep in-universe rows ------------------------------
    raw_filings = payload.get("filings")
    if not isinstance(raw_filings, (list, tuple)):
        raw_filings = []
    universe = set(assets)
    events, seen = [], set()
    n_bad = n_outside = n_incons = n_dup = 0
    for r in raw_filings:
        if not isinstance(r, dict):
            n_bad += 1
            continue
        a = r.get("asset")
        a = None if a is None else str(a).strip()
        pe = _parse_date(r.get("period_end"))
        fd = _parse_date(r.get("filing_date"))
        pct = _parse_pct(r.get("weight_pct"))
        if not a or pe is None or fd is None or pct is None:
            n_bad += 1
            continue
        if a not in universe:
            n_outside += 1
            continue
        if pe > fd:  # holdings cannot be reported before their as-of date
            n_incons += 1
            continue
        key = (str(r.get("row_id")), a, pe, fd, pct)
        if key in seen:
            n_dup += 1
            continue
        seen.add(key)
        events.append((fd, pe, a, pct))

    if n < 2:
        return insufficient("A cross-sectional signal needs at least two assets; holding cash.", cash)
    if not events:
        return insufficient("No valid in-universe filing rows; every centered vector is zero, so cash.", cash)

    # ---- point-in-time sweep ----------------------------------------------------
    events.sort(key=lambda e: (e[0], e[1]))  # by availability (filing_date)
    eq = Fraction(100, n)                    # equal-weight level in weight_pct units
    tol = Fraction(1, 10 ** 12)
    state = {}                               # asset -> [period_end, filing_date, [values]]
    conflicts = set()

    def signal():
        raw = []
        for a in assets:
            st = state.get(a)
            if st is None:
                raw.append(eq)
                continue
            vals = st[2]
            if any(v != vals[0] for v in vals):
                conflicts.add((a, st[0]))
            raw.append(sum(vals, Fraction(0)) / len(vals))
        mu = sum(raw, Fraction(0)) / n
        c = [v - mu for v in raw]
        gross = sum((abs(x) for x in c), Fraction(0))
        scale = max([Fraction(1)] + [abs(v) for v in raw])
        if gross == 0 or max(abs(x) for x in c) <= tol * scale:
            return [0.0] * n
        return [_to_float(x / gross) for x in c]

    out = [None] * len(dec)
    ptr, cached = 0, None
    for i in sorted(range(len(dec)), key=dec.__getitem__):
        d = dec[i]
        # A row is usable only if filed strictly before the decision date
        # (no intraday filing time, decision taken at the close of d).
        while ptr < len(events) and events[ptr][0] < d:
            fd, pe, a, pct = events[ptr]
            ptr += 1
            st = state.get(a)
            if st is None or pe > st[0] or (pe == st[0] and fd > st[1]):
                state[a] = [pe, fd, [pct]]  # newer period, or later-filed restatement
                cached = None
            elif pe == st[0] and fd == st[1]:
                st[2].append(pct)           # same-day duplicate version
                cached = None
            # older report periods never override a newer one
        if cached is None:
            cached = signal()
        out[i] = list(cached)

    # ---- reason ----------------------------------------------------------------
    if n_bad:
        notes.append(f"{n_bad} malformed rows dropped")
    if n_outside:
        notes.append(f"{n_outside} rows outside the asset universe ignored")
    if n_incons:
        notes.append(f"{n_incons} rows with period_end after filing_date dropped")
    if n_dup:
        notes.append(f"{n_dup} exact duplicate rows dropped")
    if conflicts:
        notes.append(f"conflicting same-day versions averaged for {len(conflicts)} asset-periods")
    if ptr < len(events):
        notes.append(f"{len(events) - ptr} rows filed on/after the last decision date are unused")

    reason = (
        "Assumption: public third-fiscal-month N-PORT rows (2022-23 regime, filed within 60 days of "
        "fiscal quarter end) are treated as public on filing_date; with no intraday time, a row is used "
        "only for decisions on dates strictly after its filing_date. Per asset: latest available "
        "period_end, latest-filed version of that period; 100/N % before any observation. Vector is "
        "demeaned and scaled to gross 1 (cash if flat), so net is 0. Row t is set at the close of "
        "dates[t] for the next session's open-to-close trade; prices are not used."
    )
    if notes:
        reason += " Notes: " + "; ".join(notes) + "."

    return {"status": "assumption", "reason": reason, "weights": out}
