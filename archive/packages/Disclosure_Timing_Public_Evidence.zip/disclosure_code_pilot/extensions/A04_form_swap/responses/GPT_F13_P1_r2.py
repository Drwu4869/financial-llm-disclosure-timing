from datetime import date
from math import fsum, isfinite
import re


def build_strategy(payload):
    """
    Build a point-in-time, holdings-based, market-neutral strategy.

    Information alignment:
      - period_end identifies the holdings report period.
      - filing_date identifies when a report version was filed.
      - A filing becomes eligible only on decision dates STRICTLY
        AFTER filing_date, because intraday publication times are unknown.
      - For each asset, select the latest eligible report period.
      - Within that period, select the latest eligible filing version.
      - A late amendment to an older period cannot supersede a newer
        report period.
      - Missing historical observations use an equal-weight baseline.
      - Observed weights persist until superseded.

    Portfolio construction:
      - Center holdings weights by their cross-sectional mean.
      - Normalize absolute exposures to one.
      - Return zero weights when the centered signal is zero.
      - Maintain approximately zero net exposure up to floating-point
        precision.

    Historical evaluation:
      - Signals use no price information.
      - A signal dated D is intended for execution at the next
        synthetic session's open and liquidation at that session's close.
      - This function does not calculate returns, since only closing
        prices are provided and evaluation is performed independently.

    Returns:
        {
            "status": "ok" | "assumption" | "insufficient_data",
            "reason": str,
            "weights": list[list[float]]
        }
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if (
            not isinstance(value, str)
            or re.fullmatch(r"\d{4}-\d{2}-\d{2}", value) is None
        ):
            raise ValueError("Dates must use YYYY-MM-DD format.")
        return date.fromisoformat(value)

    if not isinstance(payload, dict):
        return insufficient("Payload must be a dictionary.")

    raw_dates = payload.get("dates")
    assets = payload.get("assets")
    filings = payload.get("filings", [])

    if not isinstance(raw_dates, list) or not raw_dates:
        return insufficient("At least one decision date is required.")

    if not isinstance(assets, list) or not assets:
        return insufficient("At least one asset is required.")

    if not all(isinstance(a, str) and a for a in assets):
        return insufficient("Asset identifiers must be nonempty strings.")

    if len(set(assets)) != len(assets):
        return insufficient("Asset identifiers must be unique.")

    if not isinstance(filings, list):
        return insufficient("Filings must be a list.")

    try:
        decision_dates = [parse_date(d) for d in raw_dates]
    except ValueError as exc:
        return insufficient(str(exc))

    if any(
        decision_dates[i] <= decision_dates[i - 1]
        for i in range(1, len(decision_dates))
    ):
        return insufficient(
            "Decision dates must be strictly increasing."
        )

    n_assets = len(assets)
    asset_index = {asset: i for i, asset in enumerate(assets)}

    # Each event contains:
    # (filing_date, period_end, asset_index, weight_pct)
    #
    # row_id is deliberately NOT used to establish chronology.
    # It is an opaque identifier, not a publication timestamp.

    events = []
    versions = {}

    for row in filings:
        if not isinstance(row, dict):
            return insufficient("Each filing must be a dictionary.")

        asset = row.get("asset")

        # Only securities in the specified fixed universe contribute.
        if asset not in asset_index:
            continue

        try:
            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])

            raw_weight = row["weight_pct"]

            if isinstance(raw_weight, bool):
                raise ValueError("Boolean weights are invalid.")

            weight_pct = float(raw_weight)

            if not isfinite(weight_pct):
                raise ValueError("Filing weights must be finite.")

        except (KeyError, TypeError, ValueError, OverflowError) as exc:
            return insufficient(
                f"Invalid filing for {asset}: {exc}"
            )

        if filing_date < period_end:
            return insufficient(
                "A filing cannot precede its holdings period_end."
            )

        idx = asset_index[asset]

        # With only daily timestamps, conflicting versions filed on
        # the same day cannot be ordered without inventing information.
        version_key = (idx, period_end, filing_date)

        if version_key in versions:
            if versions[version_key] != weight_pct:
                return insufficient(
                    "Conflicting same-day versions for an asset and "
                    "report period cannot be ordered without timestamps."
                )
            continue

        versions[version_key] = weight_pct

        events.append(
            (filing_date, period_end, idx, weight_pct)
        )

    # Filing date controls public-information availability.
    # Sorting does not change the preference for newer report periods.
    events.sort(key=lambda e: (e[0], e[1], e[2]))

    # The baseline must use the same units as weight_pct.
    baseline = 100.0 / n_assets

    current_levels = [baseline] * n_assets

    # Track the most recent applicable (period_end, filing_date)
    # separately for each asset.
    latest_version = [
        (date.min, date.min)
        for _ in range(n_assets)
    ]

    weights = []
    event_pointer = 0

    for decision_day in decision_dates:

        # Strict inequality prevents same-day publication look-ahead.
        # Every event processed here was filed before the decision day.
        while (
            event_pointer < len(events)
            and events[event_pointer][0] < decision_day
        ):
            (
                filing_date,
                period_end,
                idx,
                weight_pct,
            ) = events[event_pointer]

            candidate_version = (period_end, filing_date)

            # First prefer the newer report period.
            # Then prefer the newer filing within that period.
            if candidate_version > latest_version[idx]:
                latest_version[idx] = candidate_version
                current_levels[idx] = weight_pct

            event_pointer += 1

        # Equal observations produce an exactly zero cash portfolio.
        if all(x == current_levels[0] for x in current_levels):
            weights.append([0.0] * n_assets)
            continue

        # Cross-sectional demeaning.
        cross_sectional_mean = fsum(current_levels) / n_assets

        centered = [
            x - cross_sectional_mean
            for x in current_levels
        ]

        # Correct residual floating-point centering error.
        centered[-1] = -fsum(centered[:-1])

        positive_total = fsum(
            x for x in centered if x > 0.0
        )
        negative_total = fsum(
            -x for x in centered if x < 0.0
        )

        if positive_total == 0.0 or negative_total == 0.0:
            weights.append([0.0] * n_assets)
            continue

        # The positive and negative books each receive 0.5 gross
        # exposure. This is mathematically equivalent to L1
        # normalization of a zero-mean vector.
        row_weights = []

        for x in centered:
            if x > 0.0:
                w = 0.5 * x / positive_total
            elif x < 0.0:
                w = 0.5 * x / negative_total
            else:
                w = 0.0

            row_weights.append(w)

        # Remove any remaining floating-point net-exposure residual.
        net = fsum(row_weights)

        if net != 0.0:
            adjustment_index = max(
                range(n_assets),
                key=lambda i: abs(row_weights[i])
            )
            row_weights[adjustment_index] -= net

        # Defensive gross-exposure bound against rounding errors.
        gross = fsum(abs(w) for w in row_weights)

        if gross > 1.0:
            row_weights = [
                w / gross for w in row_weights
            ]

            # If rounding still leaves gross marginally above one,
            # reduce by one representable floating-point step.
            if fsum(abs(w) for w in row_weights) > 1.0:
                from math import nextafter

                factor = nextafter(1.0, 0.0)
                row_weights = [
                    w * factor for w in row_weights
                ]

        weights.append(row_weights)

    return {
        "status": "assumption",
        "reason": (
            "Point-in-time alignment uses only filings dated strictly "
            "before each decision day because intraday SEC publication "
            "times are unavailable. For each asset, the newest eligible "
            "report period and its latest eligible revision are used; "
            "earlier missing observations receive a 100/N percent "
            "baseline. Signals are cross-sectionally centered and "
            "gross-normalized with zero net exposure up to floating-point "
            "precision. Prices are not used to construct or select "
            "signals. Each decision applies to the next synthetic "
            "session's open-to-close evaluation, performed independently."
        ),
        "weights": weights,
    }
