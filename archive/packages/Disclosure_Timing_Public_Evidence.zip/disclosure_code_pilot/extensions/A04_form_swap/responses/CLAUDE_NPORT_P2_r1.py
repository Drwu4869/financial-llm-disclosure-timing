import math
from bisect import bisect_right
from datetime import date, datetime


def build_strategy(payload):
    """Holdings-based cross-sectional signal from public Form N-PORT rows.

    Point-in-time rule: a row (asset, period_end, filing_date, weight_pct) can be
    used for the decision taken at the end of its actual SEC filing_date. The
    evaluator executes that decision at the next listed session. Prices are never
    read, so nothing is fitted or tuned on returns.
    """

    def fail(message):
        return {"status": "insufficient_data", "reason": message}

    def parse_day(value):
        if value is None or isinstance(value, bool):
            return None
        if isinstance(value, datetime):
            return value.date()
        if isinstance(value, date):
            return value
        if not isinstance(value, str) or not value.strip():
            return None
        text = value.strip()
        try:
            return date.fromisoformat(text)
        except ValueError:
            pass
        try:
            return datetime.fromisoformat(text).date()
        except ValueError:
            return None

    def parse_number(value):
        if value is None or isinstance(value, bool):
            return None
        try:
            if isinstance(value, str):
                number = float(value.strip().rstrip("%"))
            else:
                number = float(value)
        except (TypeError, ValueError):
            return None
        return number if math.isfinite(number) else None

    # ------------------------------------------------------------------ inputs
    if not isinstance(payload, dict):
        return fail("Payload is not a mapping with dates, assets, filings and prices.")

    raw_assets = payload.get("assets")
    if not isinstance(raw_assets, (list, tuple)) or not raw_assets:
        return fail("No asset universe was supplied.")
    assets = ["" if a is None else str(a).strip() for a in raw_assets]
    if any(not a for a in assets) or len(set(assets)) != len(assets):
        return fail("Asset list has blank or duplicate names, so columns cannot be mapped unambiguously.")
    n = len(assets)
    column = {a: j for j, a in enumerate(assets)}

    raw_dates = payload.get("dates")
    if not isinstance(raw_dates, (list, tuple)) or not raw_dates:
        return fail("No decision dates were supplied.")
    days = []
    for raw in raw_dates:
        day = parse_day(raw)
        if day is None:
            return fail(f"Decision date {raw!r} is not a valid ISO YYYY-MM-DD date.")
        days.append(day)
    strictly_increasing = all(a < b for a, b in zip(days, days[1:]))
    last_day = max(days)

    raw_filings = payload.get("filings")
    if raw_filings is None:
        raw_filings = []
    if not isinstance(raw_filings, (list, tuple)):
        return fail("Filings must be a list of rows.")

    # -------------------------------------------------------------- clean rows
    versions = {}             # (column, period_end, filing_date) -> [weight_pct, ...]
    malformed = 0
    unknown_assets = set()
    filed_before_period = 0
    undated_relevant = 0      # no filing date, and could have been public in-sample
    undated_irrelevant = 0    # no filing date, but period ends after the last decision date
    dated = 0

    for row in raw_filings:
        if not isinstance(row, dict):
            malformed += 1
            continue
        name = row.get("asset")
        name = "" if name is None else str(name).strip()
        if name not in column:
            if name:
                unknown_assets.add(name)
            else:
                malformed += 1
            continue
        period = parse_day(row.get("period_end"))
        weight = parse_number(row.get("weight_pct"))
        if period is None or weight is None:
            malformed += 1
            continue
        filed = parse_day(row.get("filing_date"))
        if filed is None:
            # A holdings report cannot be filed before its own period end, so an
            # undated row whose period ends after the last decision date can never
            # have been usable in-sample. Anything else blocks exact alignment.
            if period <= last_day:
                undated_relevant += 1
            else:
                undated_irrelevant += 1
            continue
        if filed < period:
            filed_before_period += 1
            continue
        dated += 1
        versions.setdefault((column[name], period, filed), []).append(weight)

    if undated_relevant or (undated_irrelevant and not dated):
        missing = undated_relevant + undated_irrelevant
        return fail(
            f"{missing} holdings row(s) lack an actual SEC filing_date. Exact historical alignment "
            "cannot be established from these inputs; no filing date or fixed reporting lag was "
            "invented, so no weights are returned."
        )

    # ------------------------------------------- per-asset point-in-time steps
    conflicting = 0
    per_asset = [[] for _ in range(n)]
    filings_per_period = {}
    for (j, period, filed), values in versions.items():
        if len(set(values)) > 1:
            conflicting += 1
        per_asset[j].append((filed, period, math.fsum(values) / len(values)))
        key = (j, period)
        filings_per_period[key] = filings_per_period.get(key, 0) + 1
    restated = sum(1 for count in filings_per_period.values() if count > 1)

    steps = []  # per asset: (effective dates, levels, report periods)
    for j in range(n):
        eff, val, per = [], [], []
        best_period = None
        # Sorted by filing date, then period: as filings arrive, the newest report
        # period wins; within a period the latest-filed version wins; a version of
        # an older period filed later never overrides a newer period. Each version
        # takes effect only from its own filing date (never carried backward).
        for filed, period, value in sorted(per_asset[j]):
            if best_period is None or period >= best_period:
                best_period = period
                if eff and eff[-1] == filed:
                    val[-1] = value
                    per[-1] = period
                else:
                    eff.append(filed)
                    val.append(value)
                    per.append(period)
        steps.append((eff, val, per))

    equal_level = 100.0 / n  # weight_pct is in percent

    def to_weights(levels):
        mean = math.fsum(levels) / n
        centred = [v - mean for v in levels]
        gross = math.fsum(abs(v) for v in centred)
        tolerance = 1e-12 * n * max(1.0, max(abs(v) for v in levels))
        if gross <= tolerance:
            return [0.0] * n
        w = [v / gross for v in centred]
        drift = math.fsum(w) / n
        if drift:
            w = [v - drift for v in w]
        total = math.fsum(abs(v) for v in w)
        for _ in range(8):
            if total <= 1.0:
                break
            factor = math.nextafter(1.0 / total, 0.0)
            w = [v * factor for v in w]
            total = math.fsum(abs(v) for v in w)
        return [v + 0.0 for v in w]

    # --------------------------------------------------------------- decisions
    weights = []
    cash_days = carried_days = mixed_days = 0
    for day in days:
        levels, periods = [], []
        for eff, val, per in steps:
            k = bisect_right(eff, day) - 1  # filing_date <= decision date
            if k >= 0:
                levels.append(val[k])
                periods.append(per[k])
            else:
                levels.append(equal_level)
                periods.append(None)
        observed = [p for p in periods if p is not None]
        if observed:
            if len(observed) < n:
                mixed_days += 1
            if min(observed) < max(observed):
                carried_days += 1
        row = to_weights(levels)
        if not any(row):
            cash_days += 1
        weights.append(row)

    # ------------------------------------------------------------------ report
    notes = []
    if malformed:
        notes.append(f"{malformed} row(s) with unusable asset/period_end/weight_pct were excluded")
    if unknown_assets:
        notes.append(f"rows for {len(unknown_assets)} asset(s) outside the universe were ignored")
    if filed_before_period:
        notes.append(f"{filed_before_period} row(s) with filing_date before period_end were excluded as inconsistent")
    if conflicting:
        notes.append(
            f"{conflicting} asset/period/filing-date group(s) with conflicting weights were averaged "
            "(row_id is opaque, so no tie-break exists)"
        )
    if undated_irrelevant:
        notes.append(
            f"{undated_irrelevant} undated row(s) with period_end after the last decision date were "
            "ignored since they could not have been public in-sample"
        )
    if not strictly_increasing:
        notes.append("dates were not strictly increasing; each row is still computed as of its own date in input order")
    status = "assumption" if notes else "ok"

    reason = (
        "Aligned on each row's actual SEC filing_date (public third-fiscal-month N-PORT portion, "
        "2022-2023 regime): a row is usable from the decision at the end of its filing day "
        "(filing_date <= decision date) and executes at the next listed session; no period_end "
        "timing or fixed lag is used. Per asset: newest report period public by that date, then that "
        "period's latest version filed by that date; assets with no public row yet sit at the "
        f"equal-weight level 100/N = {equal_level:.4g}%. Vector demeaned and scaled to unit gross, "
        "zero net, cash when flat; prices are not read. "
        f"{dated} dated row(s), {restated} restated asset-period(s), {cash_days}/{len(days)} cash day(s)."
    )
    if carried_days:
        reason += (
            f" On {carried_days} day(s) an asset missing from a newer public report kept its own "
            "latest public record (no zero inferred)."
        )
    if mixed_days:
        reason += f" On {mixed_days} day(s) some assets had no public row yet and used the equal-weight level."
    if notes:
        reason += " Assumptions: " + "; ".join(notes) + "."

    return {"status": status, "reason": reason, "weights": weights}
