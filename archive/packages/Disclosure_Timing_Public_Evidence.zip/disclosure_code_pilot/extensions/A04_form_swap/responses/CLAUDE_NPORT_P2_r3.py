import math
from datetime import date, datetime


def build_strategy(payload):
    """Point-in-time, holdings-based cross-sectional signal built from public
    third-fiscal-month N-PORT records, aligned on each record's filing date."""

    def insufficient(message):
        return {"status": "insufficient_data", "reason": message}

    def is_blank(value):
        return value is None or (isinstance(value, str) and not value.strip())

    def parse_day(value):
        if isinstance(value, datetime):
            return value.date()
        if isinstance(value, date):
            return value
        if isinstance(value, str):
            text = value.strip()
            if not text:
                return None
            try:
                return date.fromisoformat(text)
            except ValueError:
                pass
            try:
                # A stray time component is dropped. The record is still only
                # used from the end of that calendar day, which is conservative.
                return datetime.fromisoformat(text).date()
            except ValueError:
                return None
        return None

    def parse_number(value):
        if value is None or isinstance(value, bool):
            return None
        if isinstance(value, str):
            value = value.strip()
        try:
            x = float(value)
        except (TypeError, ValueError, OverflowError):
            return None
        return x if math.isfinite(x) else None

    # ---------------------------------------------------------------- inputs
    if not isinstance(payload, dict):
        return insufficient("Payload is not a dictionary with dates, assets, filings and prices.")

    raw_dates = payload.get("dates")
    raw_assets = payload.get("assets")
    raw_filings = payload.get("filings")

    if not isinstance(raw_dates, (list, tuple)) or len(raw_dates) == 0:
        return insufficient("No decision dates were supplied.")
    if not isinstance(raw_assets, (list, tuple)) or len(raw_assets) == 0:
        return insufficient("No assets were supplied, so there is no column order.")
    if raw_filings is None:
        return insufficient("No filings field was supplied, so no holdings records or public filing dates exist.")
    if not isinstance(raw_filings, (list, tuple)):
        return insufficient("Filings must be a list of row dictionaries.")

    assets = []
    for a in raw_assets:
        if is_blank(a):
            return insufficient("An asset name is missing, so the fixed column order cannot be established.")
        assets.append(str(a).strip())
    if len(set(assets)) != len(assets):
        return insufficient("Asset names are duplicated, so columns cannot be mapped unambiguously.")
    index = {name: i for i, name in enumerate(assets)}
    n = len(assets)

    decision_days = []
    for k, d in enumerate(raw_dates):
        parsed = parse_day(d)
        if parsed is None:
            return insufficient(f"Decision date at position {k} is not a valid ISO YYYY-MM-DD date.")
        decision_days.append(parsed)

    notes = []
    if any(b <= a for a, b in zip(decision_days, decision_days[1:])):
        notes.append("decision dates are not strictly increasing; each row still uses only "
                     "records filed on or before its own date")

    # --------------------------------------------------------- filing rows
    missing_filing_date = 0
    malformed = 0
    filed_before_period = 0
    unknown_assets = 0
    grouped = {}  # (asset index, period_end, filing_date) -> [weight_pct, ...]

    for row in raw_filings:
        if not isinstance(row, dict):
            malformed += 1
            continue
        name = row.get("asset")
        if is_blank(name):
            malformed += 1
            continue
        i = index.get(str(name).strip())
        if i is None:
            unknown_assets += 1
            continue
        filed = parse_day(row.get("filing_date"))
        if filed is None:
            missing_filing_date += 1
            continue
        period = parse_day(row.get("period_end"))
        weight = parse_number(row.get("weight_pct"))
        if period is None or weight is None:
            malformed += 1
            continue
        if filed < period:
            filed_before_period += 1
            continue
        grouped.setdefault((i, period, filed), []).append(weight)

    if missing_filing_date:
        return insufficient(
            f"Actual public filing dates are absent or unreadable for {missing_filing_date} of "
            f"{len(raw_filings)} filing rows; exact historical alignment cannot be established from "
            "these inputs, and no filing dates or fixed lags were invented."
        )
    if malformed:
        return insufficient(
            f"{malformed} filing rows lack a valid asset, period_end or weight_pct, so the "
            "point-in-time holdings vector cannot be reconstructed exactly."
        )
    if filed_before_period:
        return insufficient(
            f"{filed_before_period} filing rows have a filing_date earlier than their period_end, "
            "which is impossible for a holdings report; exact public-availability alignment "
            "cannot be established."
        )
    if unknown_assets:
        notes.append(f"ignored {unknown_assets} rows for assets outside the fixed universe")

    # ------------------------------------------- versions (one per filing)
    events = []
    filings_per_period = {}
    exact_duplicates = 0
    conflicting_duplicates = 0
    for (i, period, filed), values in grouped.items():
        if len(values) > 1:
            spread = max(values) - min(values)
            if spread <= 1e-12 * max(1.0, max(abs(v) for v in values)):
                exact_duplicates += 1
                value = values[0]
            else:
                conflicting_duplicates += 1
                value = math.fsum(values) / len(values)
        else:
            value = values[0]
        events.append((filed, period, i, value))
        filings_per_period.setdefault((i, period), set()).add(filed)

    revised_periods = sum(1 for s in filings_per_period.values() if len(s) > 1)
    if exact_duplicates:
        notes.append(f"collapsed {exact_duplicates} exact duplicate asset/period/filing-date records")
    if conflicting_duplicates:
        notes.append(f"averaged {conflicting_duplicates} asset/period groups with conflicting "
                     "weights filed on the same day")
    if revised_periods:
        notes.append(f"{revised_periods} asset/report periods had more than one filed version "
                     "although one is expected; each was treated as a revision used only from "
                     "its own filing date")

    events.sort(key=lambda e: (e[0], e[1], e[2]))

    # --------------------------------------------------------------- signal
    def to_weights(level):
        mean = math.fsum(level) / n
        centered = [x - mean for x in level]
        scale = max(1.0, max(abs(x) for x in level))
        if max(abs(x) for x in centered) <= 1e-12 * scale:
            return [0.0] * n  # cash
        gross = math.fsum(abs(x) for x in centered)
        w = [x / gross for x in centered]
        # Guard against a floating-point gross a hair above one.
        while math.fsum(abs(x) for x in w) > 1.0:
            w = [x * (1.0 - 2.0 ** -50) for x in w]
        return [x + 0.0 for x in w]  # normalise -0.0

    equal_level = 100.0 / n  # weight_pct units
    level = [equal_level] * n
    held = [None] * n  # per asset: (period_end, filing_date) currently applied
    weights_by_day = {}
    j = 0
    for day in sorted(set(decision_days)):
        # Records are usable at the end of their filing day (filing_date <= day).
        while j < len(events) and events[j][0] <= day:
            filed, period, i, value = events[j]
            current = held[i]
            if (current is None or period > current[0]
                    or (period == current[0] and filed >= current[1])):
                held[i] = (period, filed)
                level[i] = value
            j += 1
        weights_by_day[day] = to_weights(level)

    weights = [list(weights_by_day[d]) for d in decision_days]

    # --------------------------------------------------------------- result
    reason = (
        "Each row is the end-of-day decision for its listed date. For each asset it uses the most "
        "recent report period among public N-PORT records whose actual filing_date is on or before "
        "that date, and the latest version of that period filed by then, so later revisions are "
        "never carried backward. Records filed on unlisted days first count at the next listed "
        "date, and the evaluator trades at the following session's open. Assets with no applicable "
        f"record sit at the equal-weight level of {equal_level:.6g}%. The vector is demeaned across "
        "assets and scaled to unit gross with zero net, and an all-zero centered vector is cash. "
        "Prices are not used."
    )
    if len(raw_filings) == 0:
        reason += " No filing rows were supplied, so every row is cash."
    if notes:
        reason += " Assumptions: " + "; ".join(notes) + "."

    return {
        "status": "assumption" if notes else "ok",
        "reason": reason,
        "weights": weights,
    }
