import math
import numbers
import re
from datetime import date, datetime


def build_strategy(payload):
    """Point-in-time 13F holdings signal.

    For each decision date, every asset takes the weight_pct of its most recent
    report period among versions already filed (filing_date <= decision date),
    using the latest such version. Assets with no filed observation take the
    equal-weight level 100/N. The vector is demeaned and scaled so that its
    absolute weights sum to one (net zero). If the centered vector is zero,
    the row is cash. Prices are never used to form or tune the signal.
    """
    iso_re = re.compile(r"^\d{4}-\d{2}-\d{2}$")

    def parse_day(value):
        if isinstance(value, datetime):
            return value.date()
        if isinstance(value, date):
            return value
        if not isinstance(value, str):
            return None
        text = value.strip()
        if len(text) > 10 and text[10] in "T ":
            text = text[:10]
        if not iso_re.match(text):
            return None
        try:
            return date.fromisoformat(text)
        except ValueError:
            return None

    def parse_num(value):
        if isinstance(value, bool):
            return None
        if isinstance(value, numbers.Real):
            x = float(value)
        elif isinstance(value, str):
            try:
                x = float(value.strip())
            except ValueError:
                return None
        else:
            return None
        return x if math.isfinite(x) else None

    def insufficient(reason):
        return {"status": "insufficient_data", "reason": reason}

    # ---------- validate the frame ----------
    if not isinstance(payload, dict):
        return insufficient("Payload must be a mapping with dates, assets, filings and prices.")

    raw_dates = payload.get("dates")
    raw_assets = payload.get("assets")
    filings = payload.get("filings")

    if not isinstance(raw_dates, (list, tuple)) or len(raw_dates) == 0:
        return insufficient("No decision dates supplied.")
    if not isinstance(raw_assets, (list, tuple)) or len(raw_assets) == 0:
        return insufficient("No assets supplied.")
    if not isinstance(filings, (list, tuple)):
        return insufficient("No filings list supplied; holdings cannot be aligned to decision dates.")

    dates = []
    for d in raw_dates:
        parsed = parse_day(d)
        if parsed is None:
            return insufficient(f"Unparseable decision date {d!r}; expected ISO YYYY-MM-DD.")
        dates.append(parsed)

    assets = []
    for a in raw_assets:
        if a is None or str(a).strip() == "":
            return insufficient("Asset list contains an empty name.")
        assets.append(str(a))
    if len(set(assets)) != len(assets):
        return insufficient("Asset list contains duplicate names; column order is ambiguous.")

    n = len(assets)
    col = {a: j for j, a in enumerate(assets)}
    equal_level = 100.0 / n

    # ---------- parse filing rows ----------
    records = []                # (asset_idx, period_end, filing_date, weight_pct)
    seen_ids = {}
    out_of_universe = 0
    exact_duplicates = 0
    conflicting_ids = 0
    missing_filing_date = 0
    in_universe_rows = 0
    malformed = []

    for k, row in enumerate(filings):
        if not isinstance(row, dict):
            malformed.append(f"row {k} is not a mapping")
            continue
        raw_asset = row.get("asset")
        if raw_asset is None or str(raw_asset).strip() == "":
            malformed.append(f"row {k} has no asset")
            continue
        j = col.get(str(raw_asset))
        if j is None:
            out_of_universe += 1
            continue
        in_universe_rows += 1

        fd = parse_day(row.get("filing_date"))
        if fd is None:
            missing_filing_date += 1
            continue
        pe = parse_day(row.get("period_end"))
        w = parse_num(row.get("weight_pct"))
        if pe is None:
            malformed.append(f"row {k} has an invalid period_end")
            continue
        if w is None:
            malformed.append(f"row {k} has a non-numeric weight_pct")
            continue
        if fd < pe:
            malformed.append(f"row {k} is filed ({fd}) before its period end ({pe})")
            continue

        signature = (j, pe, fd, w)
        rid = row.get("row_id")
        if rid is not None:
            key = str(rid)
            if key in seen_ids:
                if seen_ids[key] == signature:
                    exact_duplicates += 1
                else:
                    conflicting_ids += 1
                continue
            seen_ids[key] = signature
        records.append(signature)

    if missing_filing_date:
        return insufficient(
            f"Actual SEC filing dates are absent or unparseable for {missing_filing_date} of "
            f"{in_universe_rows} in-universe filing rows; exact historical alignment cannot be "
            "established from these inputs, and no filing dates or reporting lags were invented."
        )
    if malformed:
        shown = "; ".join(malformed[:3]) + ("; ..." if len(malformed) > 3 else "")
        return insufficient(f"Malformed filing rows prevent point-in-time alignment: {shown}.")
    if conflicting_ids:
        return insufficient(
            f"{conflicting_ids} row_id(s) appear more than once with different contents; records are ambiguous."
        )

    # ---------- versions per asset / report period ----------
    groups = {}
    for j, pe, fd, w in records:
        groups.setdefault((j, pe, fd), []).append(w)

    same_day_conflicts = 0
    events = [[] for _ in range(n)]
    version_count = {}
    for (j, pe, fd), ws in groups.items():
        if len(set(ws)) > 1:
            same_day_conflicts += 1
            value = math.fsum(ws) / len(ws)
        else:
            value = ws[0]
        events[j].append((fd, pe, value))
        version_count[(j, pe)] = version_count.get((j, pe), 0) + 1
    for ev in events:
        ev.sort(key=lambda t: (t[0], t[1]))
    restated_periods = sum(1 for c in version_count.values() if c > 1)

    # ---------- point-in-time sweep over decision dates ----------
    order = sorted(range(len(dates)), key=lambda i: dates[i])
    ptr = [0] * n
    best_pe = [None] * n
    best_w = [equal_level] * n
    weights = [None] * len(dates)
    cash_days = 0

    for i in order:
        d = dates[i]
        for j in range(n):
            ev = events[j]
            p = ptr[j]
            while p < len(ev) and ev[p][0] <= d:      # usable at end of filing day
                fd, pe, value = ev[p]
                if best_pe[j] is None or pe >= best_pe[j]:
                    # newer period wins; same period -> later-filed version replaces
                    best_pe[j] = pe
                    best_w[j] = value
                p += 1
            ptr[j] = p

        raw = list(best_w)
        mean = math.fsum(raw) / n
        centered = [x - mean for x in raw]
        tol = 1e-12 * max(1.0, max(abs(x) for x in raw))
        if max(abs(x) for x in centered) <= tol:
            row = [0.0] * n
            cash_days += 1
        else:
            gross = math.fsum(abs(x) for x in centered)
            row = [x / gross for x in centered]
            g2 = math.fsum(abs(x) for x in row)
            if g2 > 1.0:
                f = (1.0 - 1e-15) / g2
                row = [x * f for x in row]
            row = [x + 0.0 for x in row]
        weights[i] = row

    # ---------- exposure checks ----------
    for row in weights:
        gross = math.fsum(abs(x) for x in row)
        net = math.fsum(row)
        if gross > 1.0 + 1e-12 or abs(net) > 1e-9:
            return insufficient("Internal exposure check failed; weights withheld.")

    # ---------- status and reason ----------
    assumptions = []
    if out_of_universe:
        assumptions.append(f"{out_of_universe} rows for assets outside the universe were ignored.")
    if exact_duplicates:
        assumptions.append(f"{exact_duplicates} exact duplicate rows (same row_id) were dropped.")
    if same_day_conflicts:
        assumptions.append(
            f"{same_day_conflicts} asset-periods had conflicting versions filed on the same day; "
            "their order is unknowable, so the values were averaged."
        )
    if any(dates[i] >= dates[i + 1] for i in range(len(dates) - 1)):
        assumptions.append("Dates are not strictly increasing; each row is computed as of its own date.")

    reason = " ".join(
        [
            "Point-in-time alignment on each row's actual SEC filing_date: a version enters the decision "
            "at the end of its filing day (filing_date <= decision date) and trades at the next listed "
            "session's open; filings dated on non-listed days enter at the next listed decision date.",
            "Per asset, the most recent report period already filed is used with its latest version "
            "filed by that date; later revisions are never carried backward, and neither period-end "
            "dates nor a fixed reporting lag are used.",
            f"Assets without a filed observation use the equal-weight level {equal_level:.6g}%; an asset "
            "absent from a newer report keeps its own latest filed weight.",
            "Each row is demeaned and scaled to unit gross exposure (net zero); rows without "
            "cross-sectional dispersion are cash. Prices are not used.",
            f"Used {len(records)} filing rows ({restated_periods} asset-periods restated); "
            f"{cash_days} of {len(dates)} dates in cash.",
        ]
        + assumptions
    )

    return {
        "status": "assumption" if assumptions else "ok",
        "reason": reason,
        "weights": weights,
    }
