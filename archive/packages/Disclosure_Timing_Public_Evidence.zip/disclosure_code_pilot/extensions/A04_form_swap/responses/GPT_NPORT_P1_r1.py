from datetime import date, timedelta
from math import fsum, isfinite


def build_strategy(payload):
    """
    Build a point-in-time, holdings-based, dollar-neutral portfolio signal.

    Historical alignment:
      - Use the public third-fiscal-month Form N-PORT disclosure regime
        applicable during 2022-2023.
      - A holding cannot become publicly available before both:
          (a) its SEC filing date; and
          (b) 60 calendar days after its report period ends.
      - Because intraday publication times are unavailable, a record
        becomes usable only on decision dates strictly later than its
        estimated public availability date.
      - Select the latest eligible report period independently for
        each asset.
      - Before an asset has an eligible observation, use 100 / N
        percent as its holdings level.
      - Center the holdings levels and normalize their L1 norm.
      - Return zero weights if the centered signal is zero.

    The returned weights belong to the supplied decision dates.
    The independent evaluator executes each decision at the next
    supplied session's open and liquidates at that session's close.

    Prices are deliberately excluded from signal construction.
    Close-only prices cannot establish open-to-close trade returns.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Dates must use ISO YYYY-MM-DD format.")

        return parsed

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        dates = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]

        if not isinstance(dates, list) or not dates:
            return insufficient("A nonempty decision-date list is required.")

        if not isinstance(assets, list) or not assets:
            return insufficient("A nonempty asset universe is required.")

        if not isinstance(filings, list):
            return insufficient("Filings must be a list.")

        if any(
            not isinstance(asset, str) or not asset
            for asset in assets
        ):
            return insufficient("Asset identifiers must be nonempty strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        decision_dates = [parse_date(d) for d in dates]

        if any(
            decision_dates[i] >= decision_dates[i + 1]
            for i in range(len(decision_dates) - 1)
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n_assets = len(assets)
        asset_index = {
            asset: i for i, asset in enumerate(assets)
        }

        # Each event contains:
        # (public_availability_date, report_period, asset_index, weight_pct)
        events = []

        seen_asset_periods = set()
        seen_row_ids = set()

        for row in filings:
            if not isinstance(row, dict):
                return insufficient("Every filing must be a dictionary.")

            asset = row["asset"]
            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])
            row_id = row["row_id"]
            value = row["weight_pct"]

            if asset not in asset_index:
                return insufficient(
                    "A filing references an asset outside the universe."
                )

            if not isinstance(row_id, str) or not row_id:
                return insufficient("Invalid filing row_id.")

            if row_id in seen_row_ids:
                return insufficient("Duplicate filing row_id.")

            seen_row_ids.add(row_id)

            if filing_date < period_end:
                return insufficient(
                    "A filing date precedes its report period."
                )

            if isinstance(value, bool) or not isinstance(
                value, (int, float)
            ):
                return insufficient(
                    "Holdings percentages must be numeric."
                )

            weight_pct = float(value)

            if not isfinite(weight_pct):
                return insufficient(
                    "Holdings percentages must be finite."
                )

            key = (asset, period_end)

            # The specified schema contains one version per
            # asset/report period. Do not infer revision order
            # from row_id or input-row order.
            if key in seen_asset_periods:
                return insufficient(
                    "Multiple versions of an asset/report period "
                    "cannot be ordered under this schema."
                )

            seen_asset_periods.add(key)

            public_date = max(
                filing_date,
                period_end + timedelta(days=60),
            )

            events.append(
                (
                    public_date,
                    period_end,
                    asset_index[asset],
                    weight_pct,
                )
            )

        # Filing input order has no significance.
        events.sort(key=lambda e: (e[0], e[1], e[2]))

        # Holdings levels are in percentage points.
        equal_weight_level = 100.0 / n_assets

        latest_levels = [
            equal_weight_level for _ in range(n_assets)
        ]

        latest_periods = [
            date.min for _ in range(n_assets)
        ]

        weights = []
        event_cursor = 0

        for decision_date in decision_dates:

            # Strict inequality prevents using an SEC filing or
            # public release whose time on the decision day
            # cannot be established.
            while (
                event_cursor < len(events)
                and events[event_cursor][0] < decision_date
            ):
                (
                    public_date,
                    period_end,
                    asset_idx,
                    weight_pct,
                ) = events[event_cursor]

                # A late-arriving older report must not overwrite
                # an already available newer report.
                if period_end > latest_periods[asset_idx]:
                    latest_periods[asset_idx] = period_end
                    latest_levels[asset_idx] = weight_pct

                event_cursor += 1

            # Scale before computing the mean to avoid overflow
            # for otherwise finite, unusually large input values.
            scale = max(abs(x) for x in latest_levels)

            if scale == 0.0:
                weights.append([0.0] * n_assets)
                continue

            scaled = [
                x / scale for x in latest_levels
            ]

            cross_sectional_mean = fsum(scaled) / n_assets

            centered = [
                x - cross_sectional_mean for x in scaled
            ]

            gross_signal = fsum(abs(x) for x in centered)

            if gross_signal == 0.0:
                # All holdings levels are equal: hold cash.
                weights.append([0.0] * n_assets)
                continue

            portfolio = [
                x / gross_signal for x in centered
            ]

            # Protect the gross-exposure ceiling against
            # floating-point rounding.
            computed_gross = sum(abs(x) for x in portfolio)

            if computed_gross > 1.0:
                portfolio = [
                    x / (computed_gross + 1e-15)
                    for x in portfolio
                ]

            weights.append(portfolio)

        return {
            "status": "assumption",
            "reason": (
                "Uses the latest publicly eligible report period "
                "independently for each asset. Public availability "
                "is no earlier than both SEC filing and 60 calendar "
                "days after period end. With no intraday timestamps, "
                "same-day disclosures are excluded conservatively. "
                "Signals are aligned to decision dates; prices and "
                "future session returns are not used."
            ),
            "weights": weights,
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            "Invalid or incomplete input: " + str(exc)
        )
