import math
from datetime import date, datetime


def build_strategy(payload):
    """
    Holdings-based cross-sectional signal built from public Form N-PORT rows, point in time.

    Alignment rules:
      * A row becomes known on its filing_date. Under the 2019-2024 quarterly-filing regime,
        the public NPORT-P (third fiscal month) report was posted on EDGAR when it was filed,
        and was due within 60 days of the fiscal-quarter end.
        period_end is only the holdings as-of date. It never makes a row available.
      * Filing times are absent, so a row filed on day D may appear after the decision taken
        at the end of D. It is therefore used only on decision dates strictly after D.
      * For each asset, take the latest usable period_end, then that period's latest usable
        version (a later filing_date restates the same period). An asset with no usable row
        gets the equal-weight level of 100/N percent.
      * Demean the vector across assets and scale it so absolute weights sum to one (net zero).
        Hold cash when the centered vector is zero.
      * Prices are never used. The evaluator trades each row at the next session's open and
        exits at that session's close.
    """

    # ---------- parsing helpers ----------
    def parse_day(x):
        if isinstance(x, datetime):
            return x.date()
        if isinstance(x, date):
            return x
        if isinstance(x, str):
            s = x.strip()
            if len(s) >= 10:
                s = s[:10]
            try:
                return date.fromisoformat(s)
            except ValueError:
                return None
        return None

    def parse_num(x):
        if x is None or isinstance(x, bool):
            return None
        try:
            v = float(x)
        except (TypeError, ValueError):
            return None
        return v if math.isfinite(v) else None

    base_reason = (
        "Point-in-time alignment: a row is usable only on decision dates strictly after its "
        "filing_date. Public NPORT-P portions were posted upon filing under the 2022-2023 regime, "
        "and filing times are absent, so same-day use could be look-ahead. period_end never makes "
        "a row available. Each asset uses its latest usable period_end and that period's latest "
        "usable version; assets with no usable row use the equal-weight level 100/N%. The vector "
        "is demeaned and scaled to unit gross exposure with zero net exposure, or held in cash if "
        "the centered vector is zero. Prices are not used; the evaluator trades each row at the "
        "next session's open and exits at its close."
    )

    # ---------- payload validation ----------
    if not isinstance(payload, dict):
        return {"status": "insufficient_data",
                "reason": "Payload must be a mapping with dates, assets, filings and prices."}

    raw_dates = payload.get("dates")
    raw_assets = payload.get("assets")
    raw_filings = payload.get("filings")

    if not isinstance(raw_dates, (list, tuple)) or not isinstance(raw_assets, (list, tuple)):
        return {"status": "insufficient_data",
                "reason": "Missing or malformed 'dates' or 'assets'."}

    notes = []
    data_flag = False

    if raw_filings is None:
        raw_filings = []
    elif not isinstance(raw_filings, (list, tuple)):
        notes.append("'filings' was not a list and was ignored.")
        data_flag = True
        raw_filings = []

    assets = [str(a) for a in raw_assets]
    n = len(assets)
    nd = len(raw_dates)

    if nd == 0 or n == 0:
        return {"status": "insufficient_data",
                "reason": "No decision dates or no assets supplied.",
                "weights": [[0.0] * n for _ in range(nd)]}

    if n < 2:
        return {"status": "insufficient_data",
                "reason": "Fewer than two assets: a demeaned (net-zero) cross-section is always "
                          "zero, so every day would be cash.",
                "weights": [[0.0] * n for _ in range(nd)]}

    # Map each asset name to its column(s), tolerating repeated labels.
    col = {}
    for j, a in enumerate(assets):
        col.setdefault(a, []).append(j)
    if len(col) < n:
        notes.append("Repeated asset labels share the same holdings value.")
        data_flag = True

    # ---------- decision dates ----------
    dec = [parse_day(d) for d in raw_dates]
    bad_dates = sum(1 for d in dec if d is None)
    if bad_dates:
        notes.append(f"{bad_dates} unparseable decision date(s) were set to cash.")
        data_flag = True

    valid_dec = [d for d in dec if d is not None]
    if any(valid_dec[i] > valid_dec[i + 1] for i in range(len(valid_dec) - 1)):
        notes.append("Decision dates were not ascending; each date was evaluated independently.")

    # ---------- clean filing rows ----------
    groups = {}  # (asset, period_end, filing_date) -> list of weight_pct values
    unknown_asset = bad_fields = filed_before_period = 0

    for r in raw_filings:
        if not isinstance(r, dict):
            bad_fields += 1
            continue

        a = r.get("asset")
        a = None if a is None else str(a)
        if a not in col:
            unknown_asset += 1
            continue

        p = parse_day(r.get("period_end"))
        f = parse_day(r.get("filing_date"))
        w = parse_num(r.get("weight_pct"))
        if p is None or f is None or w is None:
            bad_fields += 1
            continue
        if f < p:
            # A report cannot be public before its own as-of date.
            filed_before_period += 1
            continue

        groups.setdefault((a, p, f), []).append(w)

    if unknown_asset:
        notes.append(f"{unknown_asset} row(s) for assets outside the universe were ignored.")
    if bad_fields:
        notes.append(f"{bad_fields} row(s) with missing or invalid fields were dropped "
                     "(no availability date can be inferred without look-ahead).")
        data_flag = True
    if filed_before_period:
        notes.append(f"{filed_before_period} row(s) dated before their period_end were dropped.")
        data_flag = True

    # Collapse identical duplicates. Conflicting same-day rows are averaged and flagged.
    versions = {}
    conflicts = 0
    for key, vals in groups.items():
        uniq = sorted(set(vals))
        if len(uniq) > 1:
            conflicts += 1
        versions[key] = math.fsum(uniq) / len(uniq)
    if conflicts:
        notes.append(f"{conflicts} asset/period/filing-date group(s) had conflicting weights "
                     "and were averaged.")
        data_flag = True

    # Count asset/periods that were filed more than once (restatements).
    filings_per_pair = {}
    for (a, p, f) in versions:
        filings_per_pair[(a, p)] = filings_per_pair.get((a, p), 0) + 1
    restated = sum(1 for c in filings_per_pair.values() if c > 1)
    if restated:
        notes.append(f"{restated} asset/period(s) were restated; the latest usable filing applies.")

    # Events ordered by availability (filing_date).
    events = sorted(((f, a, p, v) for (a, p, f), v in versions.items()),
                    key=lambda e: (e[0], e[1], e[2]))

    decision_days = set(valid_dec)
    same_day = sum(1 for e in events if e[0] in decision_days)
    if same_day:
        notes.append(f"{same_day} version(s) filed on a decision day were first used on the "
                     "following decision day.")

    # ---------- signal construction ----------
    eq_level = 100.0 / n

    def normalize(vec):
        m = math.fsum(vec) / n
        c = [x - m for x in vec]
        scale = max(1.0, max(abs(x) for x in vec))
        if max(abs(x) for x in c) <= 1e-12 * scale:
            return [0.0] * n  # centered vector is zero -> cash
        g = math.fsum(abs(x) for x in c)
        w = [x / g for x in c]
        if math.fsum(abs(x) for x in w) > 1.0:
            # Guard against floating-point gross exposure slightly above one.
            w = [x * (1.0 - 1e-12) for x in w]
        return [x + 0.0 for x in w]  # turns -0.0 into 0.0

    weights = [[0.0] * n for _ in range(nd)]
    order = sorted((i for i in range(nd) if dec[i] is not None), key=lambda i: dec[i])

    state = {}  # asset -> [latest usable period_end, {period_end: latest usable value}]
    k = 0
    used_any = False

    for i in order:
        d = dec[i]

        # Add every version filed strictly before this decision date.
        while k < len(events) and events[k][0] < d:
            f, a, p, v = events[k]
            st = state.get(a)
            if st is None:
                state[a] = [p, {p: v}]
            else:
                st[1][p] = v  # events arrive in filing order, so a later version overwrites
                if p > st[0]:
                    st[0] = p
            k += 1

        vec = [eq_level] * n
        for a, st in state.items():
            val = st[1][st[0]]
            for j in col[a]:
                vec[j] = val
        if state:
            used_any = True

        weights[i] = normalize(vec)

    # ---------- status ----------
    if not used_any:
        status = "insufficient_data"
        reason = ("No filing becomes usable on any decision date, so the signal is cash "
                  "throughout. " + base_reason)
    else:
        status = "assumption" if (same_day or data_flag) else "ok"
        reason = base_reason

    if notes:
        reason = reason + " " + " ".join(notes)

    return {"status": status, "reason": reason, "weights": weights}
