def build_strategy(payload):
    """
    Build a point-in-time, holdings-based, dollar-neutral portfolio signal.

    Alignment assumptions:
    - For 2022-2023 third-fiscal-month Form N-PORT reports, public
      availability is no earlier than 60 calendar days after period_end.
    - A filing or revision cannot be used before filing_date.
    - Because intraday publication times are unavailable, an observation
      becomes usable only on decision dates strictly after its inferred
      public-availability date.
    - For each asset, select the latest available report period, then
      the latest applicable filing version within that period.
    - Before an asset has an applicable observation, use 100 / N percent.
    - Center the cross-section and normalize gross exposure to one.
    - If all levels are equal, hold cash.

    Prices are deliberately excluded from signal construction.
    The evaluator independently handles next-session execution and returns.
    Synthetic sessions need not follow a conventional exchange calendar.
    """
    from datetime import date, timedelta
    from math import fsum, isfinite, nextafter

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if (
            not isinstance(value, str)
            or len(value) != 10
            or value[4] != "-"
            or value[7] != "-"
        ):
            raise ValueError("Expected ISO date YYYY-MM-DD")
        return date.fromisoformat(value)

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        dates = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]

        # Prices belong to the independent execution/return evaluator.
        # Neither price values nor future price dates enter this signal.
        _prices = payload["prices"]

        if not isinstance(assets, (list, tuple)) or not assets:
            return insufficient("No assets supplied.")

        if any(not isinstance(a, str) or not a for a in assets):
            return insufficient("Asset identifiers must be nonempty strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        if not isinstance(dates, (list, tuple)) or not dates:
            return insufficient("No decision dates supplied.")

        if not isinstance(filings, (list, tuple)):
            return insufficient("Filings must be a sequence.")

        decision_days = [parse_date(d) for d in dates]

        if any(
            decision_days[i] <= decision_days[i - 1]
            for i in range(1, len(decision_days))
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n = len(assets)
        asset_index = {asset: i for i, asset in enumerate(assets)}
        baseline = 100.0 / n

        # Each event:
        # (public_availability_date, asset_index,
        #  report_period, filing_date, weight_pct)
        events = []

        # Detect ambiguous versions without treating opaque row_id
        # values as timestamps or precedence indicators.
        observed_versions = {}

        for row in filings:
            if not isinstance(row, dict):
                return insufficient("Each filing must be a dictionary.")

            asset = row["asset"]

            # Only securities in the specified fixed universe contribute.
            if asset not in asset_index:
                continue

            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])

            if filing_date < period_end:
                return insufficient(
                    "A filing date precedes its report period end."
                )

            raw_weight = row["weight_pct"]

            if isinstance(raw_weight, bool):
                return insufficient("Invalid filing weight.")

            weight = float(raw_weight)

            if not isfinite(weight):
                return insufficient("Non-finite filing weight.")

            idx = asset_index[asset]
            version_key = (idx, period_end, filing_date)

            if version_key in observed_versions:
                if observed_versions[version_key] != weight:
                    return insufficient(
                        "Conflicting same-day versions without "
                        "intraday ordering information."
                    )
                # Identical duplicate observations add no information.
                continue

            observed_versions[version_key] = weight

            # Public third-month N-PORT observations were subject
            # to a 60-calendar-day quarter-end publication lag.
            public_date = max(
                filing_date,
                period_end + timedelta(days=60),
            )

            events.append(
                (
                    public_date,
                    idx,
                    period_end,
                    filing_date,
                    weight,
                )
            )

        # Input filing order and row_id have no temporal significance.
        events.sort(key=lambda e: (e[0], e[2], e[3], e[1]))

        # Current point-in-time levels, one per asset.
        levels = [baseline] * n

        # Version precedence is report period first, filing date second.
        # This prevents a late revision to an older report from
        # superseding an already available newer report.
        selected_versions = [None] * n

        weights = []
        event_position = 0

        for decision_day in decision_days:

            # Strict inequality prevents same-day lookahead when
            # the time of SEC publication is unknown.
            while (
                event_position < len(events)
                and events[event_position][0] < decision_day
            ):
                (
                    public_date,
                    idx,
                    period_end,
                    filing_date,
                    weight,
                ) = events[event_position]

                candidate_version = (period_end, filing_date)
                previous_version = selected_versions[idx]

                if (
                    previous_version is None
                    or candidate_version > previous_version
                ):
                    selected_versions[idx] = candidate_version
                    levels[idx] = weight

                event_position += 1

            # Equal levels contain no cross-sectional signal.
            if all(value == levels[0] for value in levels):
                weights.append([0.0] * n)
                continue

            # Cross-sectional centering.
            cross_sectional_mean = fsum(levels) / n
            centered = [
                value - cross_sectional_mean
                for value in levels
            ]

            # Correct floating-point centering residual.
            centered[-1] = -fsum(centered[:-1])

            gross = fsum(abs(value) for value in centered)

            if gross == 0.0:
                weights.append([0.0] * n)
                continue

            # Unit gross exposure, zero net exposure.
            portfolio = [
                value / gross
                for value in centered
            ]

            # Explicitly remove floating-point net residual.
            portfolio[-1] = -fsum(portfolio[:-1])

            # Guard against rounding gross exposure slightly above 1.
            # nextafter provides a conservative scaling adjustment.
            for _ in range(4):
                actual_gross = fsum(
                    abs(value) for value in portfolio
                )

                if actual_gross <= 1.0:
                    break

                factor = nextafter(
                    1.0 / actual_gross,
                    0.0,
                )

                portfolio = [
                    value * factor
                    for value in portfolio
                ]

                portfolio[-1] = -fsum(portfolio[:-1])

            weights.append(portfolio)

        return {
            "status": "assumption",
            "reason": (
                "Third-month N-PORT holdings become eligible after "
                "max(filing_date, period_end + 60 calendar days). "
                "Unknown intraday publication times are handled "
                "conservatively by excluding same-day observations. "
                "Each asset uses its latest eligible report period "
                "and revision; missing observations use equal-weight "
                "levels. Prices are excluded from the signal; "
                "next-session execution and returns are evaluated "
                "independently."
            ),
            "weights": weights,
        }

    except (
        KeyError,
        TypeError,
        ValueError,
        OverflowError,
        ArithmeticError,
    ) as exc:
        return insufficient(
            f"Invalid or incomplete input: {exc}"
        )
