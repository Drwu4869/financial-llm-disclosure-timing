def build_strategy(payload):
    from bisect import bisect_right
    from datetime import date
    from fractions import Fraction
    import math

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Date must be a string.")
        parsed = date.fromisoformat(value)
        if parsed.isoformat() != value:
            raise ValueError("Date must use YYYY-MM-DD.")
        return parsed

    def parse_weight(value):
        if isinstance(value, bool):
            raise ValueError("Boolean weight is invalid.")
        result = Fraction(str(value))
        if not math.isfinite(float(result)):
            raise ValueError("Non-finite weight.")
        return result

    try:
        assets = payload["assets"]
        dates = payload["dates"]
        filings = payload["filings"]
        prices = payload["prices"]

        if not isinstance(assets, list) or not assets:
            return insufficient("No assets supplied.")

        if any(not isinstance(a, str) or not a for a in assets):
            return insufficient("Invalid asset identifiers.")

        if len(set(assets)) != len(assets):
            return insufficient("Duplicate assets.")

        if not isinstance(dates, list) or not dates:
            return insufficient("No decision dates supplied.")

        decision_dates = [parse_date(d) for d in dates]

        if any(
            decision_dates[i] >= decision_dates[i + 1]
            for i in range(len(decision_dates) - 1)
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        if not isinstance(prices, list) or not prices:
            return insufficient("No session calendar supplied.")

        # Prices define the authoritative synthetic session calendar.
        # Price VALUES are never used to construct or tune signals.
        sessions = sorted(parse_date(p["date"]) for p in prices)

        if len(set(sessions)) != len(sessions):
            return insufficient("Duplicate session dates.")

        # Every decision must have a subsequent execution session.
        # The evaluator independently computes that session's return.
        for d in decision_dates:
            if bisect_right(sessions, d) == len(sessions):
                return insufficient(
                    "No subsequent execution session for "
                    + d.isoformat()
                )

        if not isinstance(filings, list):
            return insufficient("Invalid filings collection.")

        universe = set(assets)

        # A version is identified by asset, report period, and
        # filing date. The opaque row_id is NOT chronological.
        versions = {}

        for record in filings:
            asset = record["asset"]

            if asset not in universe:
                continue

            period_end = parse_date(record["period_end"])
            filing_date = parse_date(record["filing_date"])
            weight = parse_weight(record["weight_pct"])

            if filing_date < period_end:
                return insufficient(
                    "Filing date precedes report period end."
                )

            key = (asset, period_end, filing_date)

            if key in versions:
                if versions[key] != weight:
                    return insufficient(
                        "Conflicting versions on the same filing "
                        "date cannot be ordered without timestamps."
                    )
            else:
                versions[key] = weight

        # Sort by actual publication date, not report period or row_id.
        observations = sorted(
            (
                (filing_date, period_end, asset, weight)
                for (asset, period_end, filing_date), weight
                in versions.items()
            ),
            key=lambda x: (x[0], x[1], x[2])
        )

        n = len(assets)
        equal_weight = Fraction(100, n)
        half = Fraction(1, 2)

        # Current selected observation per asset:
        # (period_end, filing_date, weight_pct)
        latest = {}
        cursor = 0
        weights = []

        for decision_day in decision_dates:

            # Conservative point-in-time rule:
            # Without intraday SEC timestamps, a filing dated on
            # the decision day is NOT presumed available by close.
            # Only strictly earlier filing dates are eligible.
            while (
                cursor < len(observations)
                and observations[cursor][0] < decision_day
            ):
                filing_date, period_end, asset, weight = (
                    observations[cursor]
                )
                cursor += 1

                if period_end > decision_day:
                    continue

                previous = latest.get(asset)

                # Prefer newest report period, then newest revision.
                candidate_key = (period_end, filing_date)

                if (
                    previous is None
                    or candidate_key > (previous[0], previous[1])
                ):
                    latest[asset] = (
                        period_end,
                        filing_date,
                        weight
                    )

            # Assets without an eligible public observation receive
            # the equal-weight level, expressed in percent.
            levels = [
                latest[asset][2]
                if asset in latest
                else equal_weight
                for asset in assets
            ]

            # Exact rational arithmetic avoids spurious nonzero
            # signals from equal levels.
            mean_level = sum(levels, Fraction(0)) / n
            centered = [x - mean_level for x in levels]

            gross = sum(
                (abs(x) for x in centered),
                Fraction(0)
            )

            if gross == 0:
                weights.append([0.0] * n)
                continue

            # Exact target:
            # w_i = (level_i - mean(level)) /
            #       sum_j(abs(level_j - mean(level)))
            #
            # Positive and negative exposures are each 0.5.
            positive_sum = sum(
                (x for x in centered if x > 0),
                Fraction(0)
            )
            negative_sum = -sum(
                (x for x in centered if x < 0),
                Fraction(0)
            )

            if positive_sum == 0 or negative_sum == 0:
                weights.append([0.0] * n)
                continue

            exact_weights = [
                half * x / positive_sum
                if x > 0
                else half * x / negative_sum
                if x < 0
                else Fraction(0)
                for x in centered
            ]

            row = [float(x) for x in exact_weights]

            # Leave negligible headroom for floating-point rounding.
            # This preserves unit gross exposure to numerical
            # precision while preventing accidental leverage > 1.
            scale = 1.0 - 1e-12
            row = [x * scale for x in row]

            # Correct accumulated floating-point net exposure.
            row[-1] = -sum(row[:-1])

            if (
                not all(math.isfinite(x) for x in row)
                or math.fsum(abs(x) for x in row) > 1.0
            ):
                return insufficient(
                    "Unable to represent normalized weights safely."
                )

            weights.append(row)

        return {
            "status": "assumption",
            "reason": (
                "Point-in-time alignment uses SEC filing_date, "
                "not holdings period_end, as the publication date. "
                "Because intraday filing times are unavailable, "
                "only filings dated strictly before each end-of-day "
                "decision are eligible. Per asset, the newest "
                "eligible report period and then its latest "
                "eligible revision are selected. Missing history "
                "uses the 100/N percent equal-weight level. "
                "Signals are cross-sectionally centered and "
                "gross-normalized, or held in cash if identical. "
                "Execution is at the next synthetic session's "
                "open with liquidation at its close. "
                "No price values or future filings influence "
                "the signals; returns are evaluated independently."
            ),
            "weights": weights
        }

    except (
        KeyError,
        TypeError,
        ValueError,
        OverflowError,
        ZeroDivisionError
    ) as exc:
        return insufficient(
            "Invalid or incomplete payload: " + str(exc)
        )

