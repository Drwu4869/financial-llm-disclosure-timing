"""Recompute A04 metrics from saved sandbox outputs, without running candidates."""
import datetime as dt
import gzip
import hashlib
import json
from collections import Counter
from study import ROOT, PILOT, SEEDS, POLICIES, policy, validate_output
from audit_full_horizon import jobs_for, compare, maxdiff

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    frozen=0
    for base,manifest in [(ROOT,'FREEZE.json'),(PILOT,'FREEZE.json'),(PILOT,'amendments/A01_runtime.json')]:
        for name,digest in json.loads((base/manifest).read_text())['files'].items():
            assert sha(base/name)==digest,(base,name)
            frozen+=1
    controls=[]
    for seed in SEEDS:
        f=json.loads((ROOT/'fixtures'/f'{seed}.json').read_text());jobs=jobs_for(f)
        for name in POLICIES:
            out=lambda p:{'status':'ok','reason':'Hand-written diagnostic control','weights':policy(p,name)}
            found=any(c['outcome']=='witness' for c in compare(out(f['payload']),[out(j['payload']) for j in jobs],f,jobs))
            expected=name in ('fixed45_inclusive','fixed60_inclusive','report_date')
            assert found==expected,('control',seed,name,found)
            controls.append({'seed':seed,'policy':name,'has_witness':found})
    rows=[];counts=Counter();executions=0;vectors=0
    for path in sorted((ROOT/'results').glob('*.json')):
        if not path.name.startswith(('GPT_','CLAUDE_')):continue
        r=json.loads(path.read_text());token=r['token']
        assert sha(ROOT/'responses'/(token+'.txt'))==r['raw_sha256']
        if r.get('outcome')!='evaluated':continue
        assert sha(ROOT/'responses'/(token+'.py'))==r['source_sha256']
        matches=[]
        for s in r['seeds']:
            if 'outputs_file' not in s:
                rows.append({'token':token,'seed':s['seed'],'status':'no_saved_outputs'})
                continue
            f=json.loads((ROOT/'fixtures'/f"{s['seed']}.json").read_text());p=f['payload']
            op=ROOT/'results'/s['outputs_file'];assert sha(op)==s['outputs_sha256']
            with gzip.open(op,'rt') as fp:outputs=json.load(fp)
            jobs=jobs_for(f);assert len(outputs)==len(jobs)+2
            executions+=len(outputs)
            bw=validate_output(outputs[0],p);rw=validate_output(outputs[1],p)
            stable=outputs[0]['status']==outputs[1]['status'] and maxdiff(bw,rw)<=1e-8
            assert stable==s['repeat_stable']
            checks=compare(outputs[0],outputs[2:],f,jobs);assert checks==s['checks']
            counts.update(c['outcome'] for c in checks)
            current=[]
            if outputs[0]['status']!='insufficient_data':
                assert len(bw)==len(p['dates'])==477
                current=[n for n in POLICIES if maxdiff(bw,policy(p,n))<=1e-8]
                assert current==s['matching_policies']
                oracle=policy(p,'filing_inclusive')
                assert s['oracle_mismatch_days']==sum(maxdiff([a],[b])>1e-8 for a,b in zip(bw,oracle))
                assert s['oracle_max_error']==maxdiff(bw,oracle)
                vectors+=len(bw)
            matches.append(current)
            rows.append({'token':token,'seed':s['seed'],'status':'verified',
                         'matching_policies':current,'interventions':len(checks)})
        assert r['matching_policy_all_seeds']==[n for n in POLICIES if len(matches)==len(SEEDS) and all(n in m for m in matches)]
    result={'audited_at':dt.datetime.now(dt.timezone.utc).isoformat(),'frozen_files_verified':frozen,
            'verified_program_seed_cases':sum(r['status']=='verified' for r in rows),
            'baseline_daily_vectors':vectors,'isolated_executions_in_saved_files':executions,
            'intervention_outcomes':dict(counts),'checks':rows,'controls':controls,
            'scope':'Saved-output recomputation and integrity check; no new model generation or candidate execution.'}
    (ROOT/'SAVED_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('checks','controls')},indent=2))

if __name__=='__main__':main()
