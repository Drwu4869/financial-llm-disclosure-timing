"""Build a self-contained progress package while preserving the old pilot."""
import datetime as dt
import hashlib
import json
import zipfile
from pathlib import Path
from study import ROOT, PILOT

def main():
    s=json.loads((ROOT/'SUMMARY.json').read_text())
    lines=['A04 paired N-PORT / 13F follow-up — live checkpoint',
           'Updated: '+dt.datetime.now(dt.timezone.utc).isoformat(),
           f"Planned 36; returned {s['returned']}; evaluated {s['evaluated']}; pending {s['pending']}; unattempted {s['unattempted']}.",
           'Claude sign-in was completed by the user. Collection uses Opus 5.5, Extra effort, fresh Incognito sessions; see CLAUDE_SETTINGS.json and attempts.json.',
           'The original nine-page report and its stopping decision remain unchanged.',
           '', 'Results by condition (three planned first answers per cell):']
    for c in s['cells']:
        p={k:v for k,v in c['all_seed_policy_counts'].items() if v}
        lines.append(f"{c['vendor']} {c['form']} {c['condition']}: evaluated {c['evaluated']}/3; policies={p}; refusals={c['refusals']}; invalid={c['invalid_or_incomplete']}; witnessed future-filing dependence={c['witness_programs']}")
    lines += ['', 'Policy labels: filing_inclusive = use assigned filing date at end of day; filing_strict = wait until a later decision date; floor60/floor45 = wait until BOTH filing date and period_end + 60/45 days.',
              'P0 task only; P1 generic avoid-look-ahead instruction; P2 explicit filing-date contract.',
              'All policy matches cover five synthetic seeds, six report periods, all 477 decision dates. Seeds are executions, not independent model samples.',
              'The filing date already accounts for after-17:30 ET transmissions and federal holidays. This does not test models converting raw timestamps.',
              'No Sharpe, realized-return, universal-habit, or causal-memory claim is supported by these fixtures.',
              'N-PORT-only lag is evidence of form-specific behavior here, not proof of recalling the 2016 rule.',
              'See README.txt, FREEZE.json, attempts.json, responses/, results/, SAVED_AUDIT.json and source_audit.json under extensions/A04_form_swap/.',
              'Captures preserve complete Copy-code payloads. Whole-message copies may be truncated by the website; they are saved separately and not used as executable code.']
    (ROOT/'CHECKPOINT.txt').write_text('\n'.join(lines)+'\n')
    files=[]
    for p in sorted(PILOT.rglob('*')):
        if not p.is_file() or '__pycache__' in p.parts or p.name=='evaluation_progress.log':continue
        files.append(p)
    manifest={'created_at':dt.datetime.now(dt.timezone.utc).isoformat(),
              'files':{str(p.relative_to(PILOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
              'summary':{k:v for k,v in s.items() if k!='cells'}}
    dest=PILOT.parent/'Disclosure_Form_Swap_A04_2026-11-08.zip'
    with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for p in files:z.write(p,'disclosure_code_pilot/'+str(p.relative_to(PILOT)))
        z.writestr('START_HERE.txt',(ROOT/'CHECKPOINT.txt').read_text())
        z.writestr('A04_package_manifest.json',json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(dest) as z:assert z.testzip() is None
    print(json.dumps({'path':str(dest),'bytes':dest.stat().st_size,'returned':s['returned'],'evaluated':s['evaluated'],'pending':s['pending']}))

if __name__=='__main__':main()
