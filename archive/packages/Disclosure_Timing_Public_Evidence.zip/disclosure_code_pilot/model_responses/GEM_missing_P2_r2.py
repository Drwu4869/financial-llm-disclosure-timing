def build_strategy(payload):
    dates = payload.get("dates", [])
    assets = payload.get("assets", [])
    filings = payload.get("filings", [])

    # The prompt explicitly notes that exact filing dates are not supplied in this schema
    # and strictly forbids inventing a fixed report lag (e.g., 60 days) to prevent lookahead bias.
    # We must assert this and return an insufficient_data status if they are missing.
    for row in filings:
        if "filing_date" not in row and "publication_timestamp" not in row:
            return {
                "status": "insufficient_data",
                "reason": "exact historical alignment cannot be established from these inputs",
                "weights": []
            }
            
    if not filings:
        return {
            "status": "insufficient_data",
            "reason": "exact historical alignment cannot be established from these inputs",
            "weights": []
        }

    # Signal logic mapping for datasets that do contain public filing dates
    asset_to_idx = {asset: idx for idx, asset in enumerate(assets)}
    num_assets = len(assets)
    
    # Identify filing date field properly and sort
    def get_fdate(x):
        return x.get("filing_date") or x.get("publication_timestamp", "")
        
    sorted_filings = sorted(filings, key=get_fdate)
    weights = []

    for current_date in dates:
        best_filings = {} # asset_idx -> (period_end, filing_date, weight_pct)
        
        for row in sorted_filings:
            f_date = get_fdate(row)
            # Only use a version on or after its own filing date 
            if f_date and f_date <= current_date:
                idx = asset_to_idx.get(row.get("asset"))
                if idx is not None:
                    p_end = row.get("period_end", "")
                    w_pct = row.get("weight_pct", 0.0)
                    
                    if idx not in best_filings:
                        best_filings[idx] = (p_end, f_date, w_pct)
                    else:
                        curr_p_end, curr_f_date, _ = best_filings[idx]
                        # Prioritize the most recent report period. 
                        # If tied on period_end, take the latest filing date (revision).
                        if p_end > curr_p_end or (p_end == curr_p_end and f_date >= curr_f_date):
                            best_filings[idx] = (p_end, f_date, w_pct)
                            
        raw_vector = []
        for i in range(num_assets):
            if i in best_filings:
                raw_vector.append(best_filings[i][2])
            else:
                # Default to equal weight level prior to any applicable observation
                raw_vector.append(100.0 / num_assets if num_assets > 0 else 0.0)
                
        if num_assets > 0:
            # Subtract cross-sectional mean
            mean_weight = sum(raw_vector) / num_assets
            centered = [w - mean_weight for w in raw_vector]
            
            # Normalize absolute weights to sum to one (Net=0, Gross=1)
            abs_sum = sum(abs(w) for w in centered)
            if abs_sum > 1e-9:
                norm_vector = [w / abs_sum for w in centered]
            else:
                # Return cash when the centered vector is entirely zero
                norm_vector = [0.0] * num_assets
        else:
            norm_vector = []
            
        weights.append(norm_vector)
        
    return {
        "status": "ok",
        "reason": "strategy built successfully",
        "weights": weights
    }

