from datetime import date
from math import fsum, isfinite


def build_strategy(payload):
    """
    Construct a point-in-time, holdings-based, dollar-neutral portfolio.

    Required payload fields:
        dates:    Ordered ISO decision dates.
        assets:   Fixed asset column order.
        filings:  Holdings observations.
        prices:   Price data (not used for signal construction).

    Each filing requires:
        row_id, asset, period_end, weight_pct

    Exact historical alignment additionally requires:
        filing_date: Actual public filing date for that observation.

    The supplied schema does not contain filing_date. Therefore, a
    payload using only that schema returns 'insufficient_data'.

    If actual filing dates are subsequently supplied, this function
    constructs the signal without using prices or estimating filing
    dates from report periods.

    Execution and return evaluation belong to the independent evaluator:
        Decision: end of supplied decision date.
        Entry:    next listed session's open.
        Exit:     same session's close.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Dates must use YYYY-MM-DD format.")

        return parsed

    try:
        assets = list(payload["assets"])
        dates = [parse_date(d) for d in payload["dates"]]
        filings = list(payload["filings"])

        if not assets or len(set(assets)) != len(assets):
            return insufficient(
                "The asset universe must be nonempty and unique."
            )

        if dates != sorted(dates):
            return insufficient(
                "Decision dates must be chronologically ordered."
            )

        # A report-period end is NOT a public filing date.
        # An opaque row_id cannot establish filing chronology.
        # No fixed reporting lag is a valid replacement.
        #
        # This check deliberately precedes signal construction.
        # Every observation needs its own actual availability date,
        # including any later amendment or revision.

        if any(
            not isinstance(row, dict)
            or not row.get("filing_date")
            for row in filings
        ):
            return insufficient(
                "Actual public filing dates are absent for one or more "
                "holdings observations. Period-end dates and row IDs "
                "cannot establish when each version became public. "
                "Exact point-in-time historical alignment and "
                "next-session evaluation therefore cannot be "
                "established from these inputs."
            )

        asset_index = {
            asset: i for i, asset in enumerate(assets)
        }

        # Events:
        # (actual filing date, report period, asset index, weight)
        events = []

        # Detect ambiguous versions whose chronology cannot be
        # established even when filing dates are available.
        versions = {}

        for row in filings:
            asset = row["asset"]

            if asset not in asset_index:
                return insufficient(
                    "A filing references an asset outside the "
                    "fixed security universe."
                )

            filing_day = parse_date(row["filing_date"])
            period_end = parse_date(row["period_end"])
            weight = float(row["weight_pct"])

            if not isfinite(weight):
                return insufficient(
                    "Holdings weights must be finite numbers."
                )

            if filing_day < period_end:
                return insufficient(
                    "A public filing date precedes its report period end."
                )

            key = (asset, period_end, filing_day)

            if key in versions:
                if versions[key] != weight:
                    return insufficient(
                        "Conflicting revisions for the same asset, "
                        "report period, and filing date have no "
                        "unambiguous version ordering."
                    )
                continue

            versions[key] = weight

            events.append((
                filing_day,
                period_end,
                asset_index[asset],
                weight
            ))

        # Chronology is determined exclusively by actual filing dates.
        events.sort(key=lambda event: event[0])

        n = len(assets)
        equal_weight_level = 100.0 / n

        # For each asset, retain:
        # (report period, filing date, weight_pct)
        #
        # Choose the newest report period that was publicly available
        # by the decision day. Within a report period, use the latest
        # publicly available version.
        latest = [None] * n

        result = []
        cursor = 0

        for decision_day in dates:

            # A date-only public filing is available at the END of
            # its filing date, never before.
            while (
                cursor < len(events)
                and events[cursor][0] <= decision_day
            ):
                filing_day, period_end, i, weight = events[cursor]

                candidate = (period_end, filing_day, weight)
                previous = latest[i]

                if (
                    previous is None
                    or (candidate[0], candidate[1])
                    > (previous[0], previous[1])
                ):
                    latest[i] = candidate

                cursor += 1

            # Before an asset's first available observation, use
            # the equal-weight level.
            holdings = [
                equal_weight_level
                if observation is None
                else observation[2]
                for observation in latest
            ]

            # Cross-sectional centering.
            mean_weight = fsum(holdings) / n

            centered = [
                value - mean_weight
                for value in holdings
            ]

            # Normalize absolute exposure to one.
            gross = fsum(abs(value) for value in centered)

            if gross == 0.0:
                # All holdings levels are equal: hold cash.
                portfolio = [0.0] * n
            else:
                portfolio = [
                    value / gross
                    for value in centered
                ]

                # Protect against floating-point rounding causing
                # gross exposure to marginally exceed one.
                realized_gross = fsum(abs(x) for x in portfolio)

                if realized_gross > 1.0:
                    portfolio = [
                        x / realized_gross
                        for x in portfolio
                    ]

            result.append(portfolio)

        return {
            "status": "ok",
            "reason": (
                "Each holding becomes eligible at the end of its "
                "actual public filing date. For each asset, the most "
                "recent publicly available report period and version "
                "are selected independently. Missing observations "
                "use the equal-weight level. Positions are "
                "cross-sectionally centered and gross-normalized, "
                "with zero positions when the signal is constant. "
                "Prices are not used; the independent evaluator "
                "applies positions from the next listed session's "
                "open through its close."
            ),
            "weights": result
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            "Invalid or incomplete input: " + str(exc)
        )
