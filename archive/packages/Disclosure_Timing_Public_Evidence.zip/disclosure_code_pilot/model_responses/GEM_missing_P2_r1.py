def build_strategy(payload: dict) -> dict:
    """
    Evaluates a holdings-based portfolio signal based on N-PORT filings.
    """
    dates = payload.get("dates", [])
    assets = payload.get("assets", [])
    filings = payload.get("filings", [])
    
    # Check for the presence of actual filing dates. 
    # N-PORT filings are historically published with a lag. Using period_end 
    # as the filing date introduces lookahead bias, and assuming a fixed lag 
    # ignores actual publication timestamps and revisions.
    if any("filing_date" not in f for f in filings):
        return {
            "status": "insufficient_data",
            "reason": "Exact historical alignment cannot be established from these inputs because actual public filing dates are absent."
        }
        
    weights = []
    n_assets = len(assets)
    
    for d in dates:
        v = []
        for a in assets:
            # Filter for point-in-time valid filings for this asset
            valid_filings = [
                f for f in filings 
                if f.get("asset") == a and f.get("filing_date", "") <= d
            ]
            
            if not valid_filings:
                # Before any applicable observation use the equal-weight level.
                # Assuming weight_pct is in percentage terms, equal weight is 100 / N.
                v.append(100.0 / n_assets if n_assets > 0 else 0.0)
            else:
                # Find the most recent report period. If there are revisions, 
                # use the most recent filing date (the latest version).
                valid_filings.sort(
                    key=lambda x: (x.get("period_end", ""), x.get("filing_date", "")), 
                    reverse=True
                )
                v.append(valid_filings[0].get("weight_pct", 0.0))
                
        # Subtract the cross-sectional mean (center) and normalize
        if n_assets > 0:
            mean_v = sum(v) / n_assets
            v_centered = [x - mean_v for x in v]
            abs_sum = sum(abs(x) for x in v_centered)
            
            if abs_sum > 1e-9:
                # Normalizing absolute weights to sum to one.
                # Gross exposure = 1, Net exposure = 0.
                w = [x / abs_sum for x in v_centered]
                weights.append(w)
            else:
                # Return cash when the centered vector is zero
                weights.append([0.0 for _ in assets])
        else:
            weights.append([])
            
    return {
        "status": "ok",
        "reason": "Aligned successfully using point-in-time public filing dates.",
        "weights": weights
    }

