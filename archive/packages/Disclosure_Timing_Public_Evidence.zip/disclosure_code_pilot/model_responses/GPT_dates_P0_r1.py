def build_strategy(payload):
    from datetime import date, timedelta
    from math import fsum, isfinite

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": str(reason)
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Invalid ISO date format.")

        return parsed

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        dates_raw = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]

        if not isinstance(dates_raw, list):
            return insufficient("dates must be a list.")

        if not isinstance(assets, list) or not assets:
            return insufficient("A nonempty asset universe is required.")

        if not isinstance(filings, list):
            return insufficient("filings must be a list.")

        if any(
            not isinstance(asset, str) or not asset
            for asset in assets
        ):
            return insufficient("Asset identifiers must be nonempty strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        decision_dates = [parse_date(d) for d in dates_raw]

        if any(
            decision_dates[i] >= decision_dates[i + 1]
            for i in range(len(decision_dates) - 1)
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n_assets = len(assets)
        asset_index = {
            asset: i for i, asset in enumerate(assets)
        }

        # A missing observation takes the equal-weight percentage level.
        equal_weight_pct = 100.0 / n_assets

        # Each event contains:
        # (public_date, period_end, filing_date, asset_index, weight_pct)
        events = []

        seen_row_ids = set()
        seen_versions = set()

        for row in filings:
            if not isinstance(row, dict):
                raise ValueError("Each filing must be a dictionary.")

            asset = row["asset"]

            # Only securities in the specified universe are traded.
            if asset not in asset_index:
                continue

            row_id = row["row_id"]

            if not isinstance(row_id, str) or not row_id:
                raise ValueError("Invalid row_id.")

            if row_id in seen_row_ids:
                raise ValueError("Duplicate row_id.")

            seen_row_ids.add(row_id)

            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])

            if filing_date < period_end:
                raise ValueError(
                    "A filing_date precedes its report period_end."
                )

            raw_weight = row["weight_pct"]

            if isinstance(raw_weight, bool):
                raise ValueError("Boolean portfolio weight is invalid.")

            weight_pct = float(raw_weight)

            if not isfinite(weight_pct):
                raise ValueError("Portfolio weights must be finite.")

            # A report may be amended, but distinct versions must
            # have distinguishable filing dates. An opaque row_id
            # cannot establish the chronology of same-day versions.
            version_key = (
                asset_index[asset],
                period_end,
                filing_date
            )

            if version_key in seen_versions:
                raise ValueError(
                    "Ambiguous versions for the same asset, "
                    "report period, and filing date."
                )

            seen_versions.add(version_key)

            # Under the specified historical Form N-PORT regime,
            # public third-fiscal-month information is subject
            # to the 60-calendar-day public-availability delay.
            #
            # An early SEC filing must not bypass that delay;
            # a late filing cannot become available before filing.
            public_date = max(
                period_end + timedelta(days=60),
                filing_date
            )

            events.append((
                public_date,
                period_end,
                filing_date,
                asset_index[asset],
                weight_pct
            ))

        # Input filing order and opaque row IDs have no temporal meaning.
        events.sort(key=lambda event: (
            event[0],
            event[1],
            event[2],
            event[3]
        ))

        # Current observation for each asset.
        current_weights = [equal_weight_pct] * n_assets

        # Latest applicable (report period, version filing date).
        latest_versions = [None] * n_assets

        result_weights = []
        event_pointer = 0

        for decision_date in decision_dates:

            # Intraday publication timestamps are unavailable.
            #
            # Conservatively exclude records first becoming public
            # on the decision date itself. Earlier public dates
            # are known before the decision-day close.
            while (
                event_pointer < len(events)
                and events[event_pointer][0] < decision_date
            ):
                (
                    public_date,
                    period_end,
                    filing_date,
                    asset_i,
                    weight_pct
                ) = events[event_pointer]

                candidate_version = (period_end, filing_date)
                previous_version = latest_versions[asset_i]

                # Most recent REPORT PERIOD wins first.
                # Within that period, the latest applicable
                # filing/revision wins.
                #
                # A late amendment to an older report must not
                # overwrite an already applicable newer report.
                if (
                    previous_version is None
                    or candidate_version > previous_version
                ):
                    latest_versions[asset_i] = candidate_version
                    current_weights[asset_i] = weight_pct

                event_pointer += 1

            # Cross-sectional centering.
            cross_sectional_mean = (
                fsum(current_weights) / n_assets
            )

            centered = [
                value - cross_sectional_mean
                for value in current_weights
            ]

            # Separate positive and negative totals to enforce
            # dollar neutrality despite floating-point rounding.
            positive_total = fsum(
                value for value in centered if value > 0.0
            )

            negative_total = -fsum(
                value for value in centered if value < 0.0
            )

            # Constant holdings vector (including the initial
            # all-equal-weight state) produces a cash position.
            if positive_total == 0.0 or negative_total == 0.0:
                result_weights.append([0.0] * n_assets)
                continue

            # Mathematically equivalent to centered / L1(centered),
            # with each side normalized to 0.5 gross exposure.
            #
            # Long exposure  = +0.5
            # Short exposure = -0.5
            # Net exposure   =  0
            # Gross exposure =  1
            row_weights = []

            for value in centered:
                if value > 0.0:
                    normalized = 0.5 * value / positive_total
                elif value < 0.0:
                    normalized = 0.5 * value / negative_total
                else:
                    normalized = 0.0

                row_weights.append(normalized)

            # Guard against a microscopic floating-point
            # overshoot of the gross-exposure limit.
            gross_exposure = max(
                fsum(abs(w) for w in row_weights),
                sum(abs(w) for w in row_weights)
            )

            if gross_exposure > 1.0:
                safety_scale = (1.0 - 1e-12) / gross_exposure
                row_weights = [
                    w * safety_scale for w in row_weights
                ]

            result_weights.append(row_weights)

        return {
            "status": "assumption",
            "reason": (
                "Each asset uses its latest applicable report period "
                "and filing-date version. Third-fiscal-month N-PORT "
                "records become eligible no earlier than 60 calendar "
                "days after period_end and no earlier than filing_date. "
                "Same-day disclosures are conservatively excluded "
                "because intraday timestamps are absent. "
                "Missing observations use the equal-weight level. "
                "Signals are centered, dollar-neutral, and "
                "L1-normalized; constant signals hold cash. "
                "Weights correspond to decision-day closes, with "
                "execution at the next synthetic session's open "
                "and liquidation at its close handled by the "
                "independent evaluator. Prices are not used "
                "to construct or optimize signals."
            ),
            "weights": result_weights
        }

    except (
        KeyError,
        TypeError,
        ValueError,
        OverflowError,
        ZeroDivisionError
    ) as exc:
        return insufficient(
            "Invalid or ambiguous input: " + str(exc)
        )
