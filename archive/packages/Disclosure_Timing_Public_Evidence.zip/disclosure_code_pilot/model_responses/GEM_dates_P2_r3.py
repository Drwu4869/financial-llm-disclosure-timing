def build_strategy(payload):
    dates = payload.get('dates', [])
    assets = payload.get('assets', [])
    filings = payload.get('filings', [])
    
    # Validation: Check for absent filing dates
    # If any filing is missing its filing_date, we cannot guarantee true point-in-time alignment
    for f in filings:
        if not f.get('filing_date'):
            return {
                "status": "insufficient_data",
                "reason": "exact historical alignment cannot be established from these inputs rather than inventing dates",
                "weights": []
            }
            
    # Group filings by asset for faster lookups
    asset_filings = {asset: [] for asset in assets}
    for f in filings:
        asset = f.get('asset')
        if asset in asset_filings:
            asset_filings[asset].append(f)
            
    N = len(assets)
    if N == 0:
        return {
            "status": "ok",
            "reason": "No assets provided in the universe.",
            "weights": []
        }
        
    # The baseline unadjusted equal-weight level (assuming weight_pct is out of 100)
    eq_weight = 100.0 / N
    weights_matrix = []
    
    for decision_date in dates:
        raw_weights = []
        
        # Determine the applicable weight for each asset as of the decision_date
        for asset in assets:
            # Filter filings available on or before this decision day
            valid_filings = [f for f in asset_filings[asset] if f.get('filing_date', '') <= decision_date]
            
            if not valid_filings:
                # Before any applicable observation use the equal-weight level
                raw_weights.append(eq_weight)
            else:
                # Select the most recent report period, and the latest filing date for that period
                best_filing = max(valid_filings, key=lambda x: (x.get('period_end', ''), x.get('filing_date', '')))
                raw_weights.append(float(best_filing.get('weight_pct', 0.0)))
                
        # Cross-sectional mean centering
        mean_w = sum(raw_weights) / N
        centered_w = [w - mean_w for w in raw_weights]
        
        # Normalize absolute weights so gross exposure == 1
        abs_sum = sum(abs(w) for w in centered_w)
        
        if abs_sum < 1e-9:
            # Return cash when the centered vector is zero
            weights_matrix.append([0.0] * N)
        else:
            normalized_w = [w / abs_sum for w in centered_w]
            weights_matrix.append(normalized_w)
            
    return {
        "status": "ok",
        "reason": "Successfully generated normalized zero-net portfolio weights fully aligned by actual filing dates.",
        "weights": weights_matrix
    }

