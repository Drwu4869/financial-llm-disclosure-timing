def build_strategy(payload: dict) -> dict:
    dates = payload.get('dates', [])
    assets = payload.get('assets', [])
    filings = payload.get('filings', [])
    
    # Verify the presence of actual filing dates to establish exact historical alignment
    for f in filings:
        if 'filing_date' not in f or not f['filing_date']:
            return {
                'status': 'insufficient_data',
                'reason': 'exact historical alignment cannot be established from these inputs; filing_date is absent.',
                'weights': []
            }
            
    num_assets = len(assets)
    if num_assets == 0:
        return {
            'status': 'ok',
            'reason': 'No assets provided.',
            'weights': [[] for _ in dates]
        }
        
    # Equal-weight level assumes percentages sum to 100
    equal_weight_pct = 100.0 / num_assets
    weights = []
    
    for date in dates:
        raw_weights = []
        for asset in assets:
            # Decisions occur at the end of the supplied date, so records filed on or before this date are usable
            valid_filings = [f for f in filings if f['asset'] == asset and f['filing_date'] <= date]
            
            if not valid_filings:
                # Use equal-weight level before any applicable observation
                raw_weights.append(equal_weight_pct)
            else:
                # Use the most recent report period, resolving revisions using the most recent filing date
                best_filing = max(valid_filings, key=lambda f: (f['period_end'], f['filing_date']))
                raw_weights.append(float(best_filing['weight_pct']))
                
        # Compute the cross-sectional mean
        mean_weight = sum(raw_weights) / num_assets
        
        # Center the vector by subtracting the mean
        centered = [w - mean_weight for w in raw_weights]
        
        # Normalize absolute weights to sum to one (gross exposure = 1.0)
        gross_exposure = sum(abs(w) for w in centered)
        
        if gross_exposure < 1e-9:
            # Return cash when the centered vector is zero
            final_weights = [0.0 for _ in assets]
        else:
            final_weights = [w / gross_exposure for w in centered]
            
        weights.append(final_weights)
        
    return {
        'status': 'ok',
        'reason': 'Successfully aligned latest available filings point-in-time using public filing dates.',
        'weights': weights
    }

