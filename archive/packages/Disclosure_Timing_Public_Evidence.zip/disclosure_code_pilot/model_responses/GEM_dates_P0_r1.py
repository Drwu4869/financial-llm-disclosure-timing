def build_strategy(payload: dict) -> dict:
    """
    Builds a holdings-based portfolio signal evaluating Form N-PORT filings.
    """
    dates = payload.get('dates', [])
    assets = payload.get('assets', [])
    filings = payload.get('filings', [])
    
    if not dates or not assets:
        return {
            'status': 'insufficient_data',
            'reason': 'Payload must contain non-empty dates and assets.'
        }
        
    N = len(assets)
    # Default to equal-weight level (1/N) when an asset lacks observations
    equal_weight = 1.0 / N
    
    # Group filings by asset for efficient querying
    asset_filings = {a: [] for a in assets}
    for f in filings:
        if f.get('asset') in asset_filings:
            asset_filings[f['asset']].append(f)
            
    # Sort filings for each asset to ensure point-in-time correctness:
    # 1. period_end descending (prioritize the most recent report period)
    # 2. filing_date descending (prioritize the latest revision for that period)
    for a in assets:
        asset_filings[a].sort(
            key=lambda x: (x.get('period_end', ''), x.get('filing_date', '')), 
            reverse=True
        )
        
    weights_matrix = []
    
    for d in dates:
        v = []
        for a in assets:
            val = equal_weight
            for f in asset_filings[a]:
                # Locate the first valid filing available on or before the decision day
                if f.get('filing_date', '') <= d:
                    val = f.get('weight_pct', 0.0) / 100.0
                    break
            v.append(val)
            
        # Cross-sectional mean calculation
        mu = sum(v) / N
        centered = [x - mu for x in v]
        
        # Absolute weights sum for L1 normalization
        l1_norm = sum(abs(x) for x in centered)
        
        if l1_norm > 1e-12:
            final_w = [x / l1_norm for x in centered]
        else:
            # Return cash (zero weights) when the centered vector is zero
            final_w = [0.0] * N
            
        weights_matrix.append(final_w)
        
    return {
        'status': 'ok',
        'reason': 'Successfully aligned most recent filings point-in-time and normalized weights to sum to one absolute gross exposure.',
        'weights': weights_matrix
    }

