def build_strategy(payload: dict) -> dict:
    dates = payload.get('dates', [])
    assets = payload.get('assets', [])
    filings = payload.get('filings', [])
    
    # Check for the point-in-time trap:
    # N-PORT filings cannot be aligned historically without their actual public filing dates.
    # We must not use period_end or invent fixed lags to look ahead.
    if filings and any('filing_date' not in row for row in filings):
        return {
            'status': 'insufficient_data',
            'reason': 'Exact historical alignment cannot be established from these inputs because actual public filing dates are absent.',
            'weights': []
        }

    n_assets = len(assets)
    if n_assets == 0:
        return {
            'status': 'ok',
            'reason': 'No assets to allocate.',
            'weights': [[0.0] * n_assets for _ in dates]
        }
        
    # Standard processing loop if filing dates *were* provided in the schema
    # Sort chronologically by filing date, then by period_end to handle revisions
    filings_sorted = sorted(filings, key=lambda x: (x['filing_date'], x['period_end']))
    
    weights = []
    filing_idx = 0
    n_filings = len(filings_sorted)
    
    # Tracks the most recent period_end and its associated weight per asset
    current_state = {}
    
    for date in dates:
        # Process any filings that became publicly available on or before this decision date
        while filing_idx < n_filings and filings_sorted[filing_idx]['filing_date'] <= date:
            f = filings_sorted[filing_idx]
            a = f['asset']
            # Update if it's a first observation or a newer/equal report period (revision)
            if a not in current_state or f['period_end'] >= current_state[a][0]:
                current_state[a] = (f['period_end'], f['weight_pct'])
            filing_idx += 1
            
        raw_weights = [0.0] * n_assets
        for i, a in enumerate(assets):
            if a in current_state:
                raw_weights[i] = current_state[a][1]
            else:
                # Before any applicable observation use the equal-weight level (scaled to match weight_pct)
                raw_weights[i] = 100.0 / n_assets
                
        # Subtract the cross-sectional mean to enforce zero net exposure
        mean_w = sum(raw_weights) / n_assets
        centered = [w - mean_w for w in raw_weights]
        
        # Normalize absolute weights to enforce a gross exposure of exactly one
        abs_sum = sum(abs(w) for w in centered)
        if abs_sum > 1e-9:
            weights.append([w / abs_sum for w in centered])
        else:
            # Return cash if the centered vector is zero
            weights.append([0.0] * n_assets)
            
    return {
        'status': 'ok',
        'reason': 'Strategy weights computed successfully using actual public filing dates.',
        'weights': weights
    }

