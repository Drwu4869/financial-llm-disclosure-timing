from bisect import bisect_right
from datetime import date, timedelta
from math import fsum, isfinite
import re


def build_strategy(payload):
    """
    Build a point-in-time, holdings-based, dollar-neutral portfolio signal.

    Assumptions
    -----------
    - Filings are public third-fiscal-month Form N-PORT observations
      under the 2022-2023 reporting regime.
    - Each observation is assumed publicly available 60 calendar days
      after its period_end.
    - Actual publication timestamps are unavailable, so this is an
      assumed availability date, not verified point-in-time information.
    - There is at most one distinct version per asset/report period.
    - An asset without an eligible observation receives the equal-weight
      baseline of 100 / number_of_assets.
    - Decisions occur at the end of each supplied decision date.
    - The external evaluator handles next-session execution and returns.
    - Prices are never used to construct or optimize the signal.

    Returns
    -------
    dict:
        status: "ok", "assumption", or "insufficient_data"
        reason: explanation of availability and alignment
        weights: list[list[float]], aligned to dates and assets
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if (
            not isinstance(value, str)
            or re.fullmatch(r"\d{4}-\d{2}-\d{2}", value) is None
        ):
            raise ValueError("Expected YYYY-MM-DD date.")
        return date.fromisoformat(value)

    # ------------------------------------------------------------
    # 1. Validate the fixed universe and decision dates.
    # ------------------------------------------------------------

    if not isinstance(payload, dict):
        return insufficient("Payload must be a dictionary.")

    assets = payload.get("assets")
    decision_dates_raw = payload.get("dates")
    filings = payload.get("filings")

    if not isinstance(assets, list) or not assets:
        return insufficient("A nonempty asset universe is required.")

    if any(not isinstance(a, str) or not a for a in assets):
        return insufficient("Asset identifiers must be nonempty strings.")

    if len(set(assets)) != len(assets):
        return insufficient("Asset identifiers must be unique.")

    if not isinstance(decision_dates_raw, list) or not decision_dates_raw:
        return insufficient("A nonempty decision-date list is required.")

    if not isinstance(filings, list):
        return insufficient("Filings must be a list.")

    try:
        decision_dates = [parse_date(d) for d in decision_dates_raw]
    except (ValueError, TypeError):
        return insufficient("Invalid decision date.")

    if any(
        decision_dates[i] >= decision_dates[i + 1]
        for i in range(len(decision_dates) - 1)
    ):
        return insufficient(
            "Decision dates must be strictly increasing."
        )

    n_assets = len(assets)
    asset_set = set(assets)

    # ------------------------------------------------------------
    # 2. Interpret report periods without using row ordering.
    #
    # No filing or publication timestamp is available.
    # The 60-day public-disclosure rule is used as a proxy.
    #
    # An opaque row_id must NEVER be treated as a timestamp.
    # Conflicting versions of the same asset/period cannot be
    # chronologically resolved and therefore cause rejection.
    # ------------------------------------------------------------

    disclosure_lag = timedelta(days=60)

    observations = {asset: {} for asset in assets}
    seen_row_ids = set()

    for row in filings:
        if not isinstance(row, dict):
            return insufficient("Each filing row must be a dictionary.")

        try:
            asset = row["asset"]
            period_end = parse_date(row["period_end"])
            raw_weight = row["weight_pct"]
            row_id = row["row_id"]
        except (KeyError, ValueError, TypeError):
            return insufficient("Invalid or incomplete filing row.")

        if not isinstance(asset, str) or asset not in asset_set:
            return insufficient("Filing refers to an unknown asset.")

        if not isinstance(row_id, str) or not row_id:
            return insufficient("Invalid filing row_id.")

        if row_id in seen_row_ids:
            return insufficient("Duplicate filing row_id.")

        seen_row_ids.add(row_id)

        if (
            isinstance(raw_weight, bool)
            or not isinstance(raw_weight, (int, float))
        ):
            return insufficient("Filing weight_pct must be numeric.")

        try:
            weight = float(raw_weight)
        except (ValueError, OverflowError):
            return insufficient("Invalid filing weight_pct.")

        if not isfinite(weight):
            return insufficient("Filing weights must be finite.")

        existing = observations[asset].get(period_end)

        if existing is not None and existing != weight:
            return insufficient(
                "Conflicting versions for an asset/report period; "
                "publication chronology is unavailable."
            )

        observations[asset][period_end] = weight

    # ------------------------------------------------------------
    # 3. Sort reports by period_end for each asset.
    #
    # This sort is independent of input order and row_id.
    # ------------------------------------------------------------

    report_periods = {}
    report_weights = {}

    for asset in assets:
        ordered = sorted(observations[asset].items())

        report_periods[asset] = [
            period for period, _ in ordered
        ]

        report_weights[asset] = [
            weight for _, weight in ordered
        ]

    # ------------------------------------------------------------
    # 4. Produce one signal row for every decision date.
    #
    # Eligibility:
    #
    #     period_end + 60 calendar days <= decision_date
    #
    # This additionally assumes the report is available by the
    # decision time on that date.
    #
    # The baseline applies separately to each asset until its
    # first eligible observation.
    # ------------------------------------------------------------

    baseline = 100.0 / n_assets
    result_weights = []

    for decision_day in decision_dates:
        latest_eligible_period = decision_day - disclosure_lag

        levels = []

        for asset in assets:
            periods = report_periods[asset]
            values = report_weights[asset]

            index = bisect_right(
                periods,
                latest_eligible_period
            ) - 1

            if index >= 0:
                level = values[index]
            else:
                level = baseline

            levels.append(level)

        # --------------------------------------------------------
        # 5. Cross-sectional demeaning.
        #
        # If all levels are identical, the signal is zero:
        # hold cash rather than manufacturing positions through
        # floating-point normalization.
        # --------------------------------------------------------

        if max(levels) == min(levels):
            result_weights.append([0.0] * n_assets)
            continue

        # Scaling first prevents numerical overflow for unusually
        # large but finite input weights. Scaling has no effect on
        # the theoretically normalized portfolio.
        scale = max(abs(x) for x in levels)

        if scale == 0.0:
            result_weights.append([0.0] * n_assets)
            continue

        scaled = [x / scale for x in levels]

        mean_level = fsum(scaled) / n_assets

        centered = [
            x - mean_level
            for x in scaled
        ]

        # --------------------------------------------------------
        # 6. Gross-one, dollar-neutral normalization.
        #
        # Positive and negative centered exposures each receive
        # half of the gross exposure. Their theoretical sums are
        # equal because the vector has been cross-sectionally
        # demeaned.
        # --------------------------------------------------------

        positive_total = fsum(
            x for x in centered if x > 0.0
        )

        negative_total = fsum(
            -x for x in centered if x < 0.0
        )

        if positive_total == 0.0 or negative_total == 0.0:
            result_weights.append([0.0] * n_assets)
            continue

        weights = []

        for x in centered:
            if x > 0.0:
                w = 0.5 * (x / positive_total)
            elif x < 0.0:
                w = -0.5 * (-x / negative_total)
            else:
                w = 0.0

            weights.append(w)

        # Protect against tiny floating-point gross-exposure
        # overshoots without increasing exposure.
        gross = fsum(abs(w) for w in weights)

        if gross > 1.0:
            weights = [w / gross for w in weights]

        result_weights.append(weights)

    # ------------------------------------------------------------
    # 7. Return decision-date weights.
    #
    # No shifting to the next session occurs here. The evaluator
    # independently maps decision-date positions to next-session
    # open-to-close trades using its authoritative session list.
    #
    # The price payload is deliberately unused to avoid leakage,
    # optimization, or accidental use of future returns.
    # ------------------------------------------------------------

    return {
        "status": "assumption",
        "reason": (
            "Assumes third-fiscal-month N-PORT observations become "
            "publicly usable 60 calendar days after period_end, "
            "including by that day's decision close. Actual "
            "publication timestamps are unavailable, so point-in-time "
            "availability cannot be verified. Per-asset latest "
            "eligible periods are used; missing observations receive "
            "equal-weight baselines. Conflicting revisions are "
            "rejected. Prices are unused, and execution/returns "
            "are delegated to the evaluator."
        ),
        "weights": result_weights,
    }
