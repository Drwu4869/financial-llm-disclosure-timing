from datetime import date, timedelta
from math import fsum, isfinite


def build_strategy(payload):
    """
    Construct a point-in-time, holdings-based, dollar-neutral portfolio.

    Rules:
      - Preserve the supplied asset and decision-date order.
      - Use only holdings publicly available before each decision day.
      - Apply the historical Form N-PORT 60-calendar-day public
        disclosure delay for third-fiscal-month reports.
      - Exclude same-day disclosures because intraday times are unknown.
      - Select the latest eligible report period independently per asset.
      - Within that period, select the highest eligible version.
      - Use 100 / number_of_assets as the level for an asset without
        an eligible observation.
      - Cross-sectionally demean and normalize to unit gross exposure.
      - Return cash if the centered vector is zero.
      - Never use prices to construct, tune, or evaluate the signal.

    The independent evaluator is responsible for mapping each decision
    to the next session in the supplied synthetic session calendar
    and calculating that session's open-to-close portfolio return.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason
        }

    try:
        decision_dates_raw = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]

        if not isinstance(assets, (list, tuple)) or not assets:
            return insufficient("A nonempty asset universe is required.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        if not isinstance(decision_dates_raw, (list, tuple)):
            return insufficient("Decision dates must be an ordered list.")

        if not decision_dates_raw:
            return insufficient("At least one decision date is required.")

        if not isinstance(filings, (list, tuple)):
            return insufficient("Filings must be a list of records.")

        decision_dates = [
            date.fromisoformat(d) for d in decision_dates_raw
        ]

        if any(
            decision_dates[i] <= decision_dates[i - 1]
            for i in range(1, len(decision_dates))
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n_assets = len(assets)
        asset_index = {
            asset: i for i, asset in enumerate(assets)
        }

        equal_weight_level = 100.0 / n_assets

        # Each event is:
        # (first_eligible_decision_date, period_end,
        #  version, asset_index, weight_pct)
        events = []

        # Detect conflicting observations with identical
        # asset/report-period/version identifiers.
        seen = {}

        for row in filings:
            asset = row["asset"]

            if asset not in asset_index:
                return insufficient(
                    "A filing references an asset outside the universe."
                )

            period_end = date.fromisoformat(row["period_end"])
            filing_date = date.fromisoformat(row["filing_date"])

            version = row["version"]

            if isinstance(version, bool) or not isinstance(
                version, int
            ) or version < 0:
                return insufficient(
                    "Filing versions must be nonnegative integers."
                )

            weight_pct = float(row["weight_pct"])

            if not isfinite(weight_pct):
                return insufficient(
                    "Filing weights must be finite numbers."
                )

            idx = asset_index[asset]
            observation_key = (idx, period_end, version)
            observation_value = (filing_date, weight_pct)

            if observation_key in seen:
                if seen[observation_key] != observation_value:
                    return insufficient(
                        "Conflicting records share an asset, "
                        "report period, and version."
                    )
                continue

            seen[observation_key] = observation_value

            # Under the historical third-fiscal-month N-PORT
            # disclosure regime, public holdings information was
            # subject to a 60-calendar-day delay after quarter end.
            statutory_public_date = (
                period_end + timedelta(days=60)
            )

            # A record cannot be used before both its SEC filing
            # and the applicable public disclosure threshold.
            earliest_public_date = max(
                filing_date,
                statutory_public_date
            )

            # Filing/publication timestamps are unavailable.
            # Conservatively exclude the entire disclosure date,
            # including end-of-day decisions on that date.
            first_eligible_date = (
                earliest_public_date + timedelta(days=1)
            )

            events.append((
                first_eligible_date,
                period_end,
                version,
                idx,
                weight_pct
            ))

        # Sort by eligibility, not by report period or row_id.
        # The row_id is opaque and has no temporal meaning.
        events.sort(key=lambda e: (e[0], e[1], e[2], e[3]))

        # Current eligible observation for each asset:
        # (period_end, version, weight_pct)
        latest = [None] * n_assets

        weights = []
        event_pointer = 0

        for decision_day in decision_dates:

            # Introduce only observations eligible at this decision.
            while (
                event_pointer < len(events)
                and events[event_pointer][0] <= decision_day
            ):
                (
                    eligible_day,
                    period_end,
                    version,
                    idx,
                    weight_pct
                ) = events[event_pointer]

                current = latest[idx]

                # Prefer the latest report period first, then
                # the highest eligible revision within that period.
                # A later-filed revision of an older report must
                # not replace a newer report period.
                if (
                    current is None
                    or (period_end, version)
                    > (current[0], current[1])
                ):
                    latest[idx] = (
                        period_end,
                        version,
                        weight_pct
                    )

                event_pointer += 1

            # Build the point-in-time holdings vector.
            # Missing observations retain the equal-weight level.
            levels = [
                equal_weight_level
                if latest[i] is None
                else latest[i][2]
                for i in range(n_assets)
            ]

            # Identical holdings levels contain no
            # cross-sectional information.
            if max(levels) == min(levels):
                weights.append([0.0] * n_assets)
                continue

            # Remove the cross-sectional mean.
            cross_sectional_mean = fsum(levels) / n_assets

            centered = [
                level - cross_sectional_mean
                for level in levels
            ]

            gross = fsum(abs(x) for x in centered)

            if gross == 0.0:
                weights.append([0.0] * n_assets)
                continue

            # Normalize absolute portfolio weights to one.
            portfolio_row = [
                x / gross for x in centered
            ]

            # Protect against tiny floating-point gross exposure
            # overshoots without changing the intended signal.
            realized_gross = fsum(
                abs(x) for x in portfolio_row
            )

            if realized_gross > 1.0:
                portfolio_row = [
                    x / realized_gross
                    for x in portfolio_row
                ]

            # The demeaned vector is dollar-neutral up to
            # floating-point precision.
            weights.append(portfolio_row)

        return {
            "status": "assumption",
            "reason": (
                "Assumes third-month N-PORT holdings become public "
                "no earlier than 60 calendar days after period end "
                "and their SEC filing date. Excludes same-day "
                "disclosures because intraday timestamps are absent. "
                "Uses the latest eligible period and version per asset. "
                "Prices are excluded from signal construction; "
                "next-session execution and returns are evaluated "
                "independently."
            ),
            "weights": weights
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            "Invalid or incomplete input: " + str(exc)
        )
