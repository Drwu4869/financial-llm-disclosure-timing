from typing import Any, Dict, List

def build_strategy(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Builds a holdings-based portfolio signal from SEC N-PORT data.
    
    Args:
        payload: Dictionary containing 'dates', 'assets', 'filings', and 'prices'.
                 Filings are expected to have 'asset', 'period_end', 'filing_date', 
                 and 'weight_pct'.
                 
    Returns:
        Dictionary with 'status', 'reason', and 'weights'.
    """
    dates: List[str] = payload.get('dates', [])
    assets: List[str] = payload.get('assets', [])
    filings: List[Dict[str, Any]] = payload.get('filings', [])
    
    if not dates or not assets:
        return {
            'status': 'insufficient_data',
            'reason': 'Missing dates or assets in the provided payload.',
            'weights': []
        }
        
    n_assets = len(assets)
    if n_assets == 0:
        return {
            'status': 'insufficient_data',
            'reason': 'Asset list is empty, cannot compute portfolio weights.',
            'weights': []
        }
        
    # Filter for well-formed filings and sort chronologically.
    # Sorting by filing_date (asc) ensures we process data as it becomes public.
    # Breaking ties with period_end (asc) ensures that if multiple reports 
    # are filed on the same day, the most recent period_end is evaluated last and kept.
    valid_filings = [
        f for f in filings 
        if 'filing_date' in f and 'period_end' in f and 'asset' in f and 'weight_pct' in f
    ]
    valid_filings.sort(key=lambda x: (x['filing_date'], x['period_end']))
    
    # State tracker for the most recent valid report period per asset
    asset_state = {a: {'period_end': '', 'weight': None} for a in assets}
    weights: List[List[float]] = []
    
    filing_idx = 0
    n_filings = len(valid_filings)
    
    for d in dates:
        # Advance the filing index to include all filings available on or before date 'd'
        while filing_idx < n_filings and valid_filings[filing_idx]['filing_date'] <= d:
            f = valid_filings[filing_idx]
            a = f['asset']
            if a in asset_state:
                # Keep the filing if it describes a period >= the one we currently hold.
                # The '>=' implicitly handles revisions (same period_end, filed later).
                if f['period_end'] >= asset_state[a]['period_end']:
                    asset_state[a]['period_end'] = f['period_end']
                    asset_state[a]['weight'] = f['weight_pct']
            filing_idx += 1
            
        # 1. Form raw asset vector for the current decision day
        raw_vec = []
        eq_weight = 1.0 / n_assets
        for a in assets:
            w = asset_state[a]['weight']
            if w is None:
                # Use equal-weight level before any applicable observation
                raw_vec.append(eq_weight)
            else:
                # Convert weight_pct to decimal to match the eq_weight scale
                raw_vec.append(float(w) / 100.0)
                
        # 2. Subtract the cross-sectional mean
        mean_val = sum(raw_vec) / n_assets
        centered = [v - mean_val for v in raw_vec]
        
        # 3. Normalize absolute weights to sum to one (or return cash if centered vector is zero)
        abs_sum = sum(abs(v) for v in centered)
        
        if abs_sum > 1e-9:
            normalized = [v / abs_sum for v in centered]
        else:
            # Vector is zero (e.g. all equal weight), return cash (all zeros)
            normalized = [0.0 for _ in range(n_assets)]
            
        weights.append(normalized)
        
    return {
        'status': 'ok',
        'reason': 'Successfully formed vectors and normalized gross exposure to 1 with 0 net exposure.',
        'weights': weights
    }

