from datetime import date
from math import fsum, isfinite


def build_strategy(payload):
    """
    Construct a dollar-neutral holdings-based signal without look-ahead.

    Historical alignment requires actual public filing dates.
    The specified payload does not supply them, so filings with
    unknown availability dates cause an insufficient_data result.

    If actual filing dates are explicitly supplied in an optional
    'filing_date' field, the calculation can proceed. No dates
    are inferred from period_end, row_id, or prices.

    Prices are intentionally unused: return evaluation is external.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")
        parsed = date.fromisoformat(value)
        if parsed.isoformat() != value:
            raise ValueError("Dates must use YYYY-MM-DD format.")
        return parsed

    try:
        dates = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]

        if not isinstance(dates, list):
            raise ValueError("dates must be a list.")
        if not isinstance(assets, list) or not assets:
            raise ValueError("assets must be a nonempty list.")
        if not isinstance(filings, list):
            raise ValueError("filings must be a list.")

        if any(not isinstance(a, str) for a in assets):
            raise ValueError("Asset identifiers must be strings.")
        if len(set(assets)) != len(assets):
            raise ValueError("Duplicate assets are not allowed.")

        decision_dates = [parse_date(d) for d in dates]

        if any(
            decision_dates[i] >= decision_dates[i + 1]
            for i in range(len(decision_dates) - 1)
        ):
            raise ValueError("Decision dates must be strictly increasing.")

        # With no filing observations, every asset remains at the
        # equal-weight baseline, giving a zero centered signal.
        if not filings:
            return {
                "status": "ok",
                "reason": (
                    "No filings supplied; equal-weight baseline "
                    "centers to zero. All decisions hold cash."
                ),
                "weights": [
                    [0.0] * len(assets)
                    for _ in decision_dates
                ]
            }

        # An actual public filing date is essential for each row.
        # The specified schema does not contain this information.
        # Neither period_end nor a regulatory reporting deadline
        # establishes the actual date of public availability.
        if any(
            not isinstance(row, dict)
            or not row.get("filing_date")
            for row in filings
        ):
            return insufficient(
                "Actual public filing dates are absent. Exact "
                "historical point-in-time alignment cannot be "
                "established from period_end, row_id, holdings, "
                "or prices. No filing dates or fixed lags "
                "have been invented."
            )

        asset_set = set(assets)
        observations = {asset: [] for asset in assets}
        seen_ids = set()
        seen_versions = set()

        for row in filings:
            row_id = row["row_id"]
            asset = row["asset"]

            if asset not in asset_set:
                raise ValueError("Filing references an unknown asset.")

            if row_id in seen_ids:
                raise ValueError("Duplicate row_id.")
            seen_ids.add(row_id)

            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])

            weight = row["weight_pct"]
            if (
                isinstance(weight, bool)
                or not isinstance(weight, (int, float))
                or not isfinite(weight)
            ):
                raise ValueError("weight_pct must be finite and numeric.")

            if filing_date < period_end:
                raise ValueError(
                    "Public filing date precedes report period end."
                )

            # Without intraday publication order, distinct versions
            # of the same observation on the same date are ambiguous.
            version_key = (asset, period_end, filing_date)
            if version_key in seen_versions:
                return insufficient(
                    "Multiple versions of the same asset/report "
                    "period have the same filing date; their "
                    "end-of-day order cannot be established."
                )
            seen_versions.add(version_key)

            observations[asset].append(
                (period_end, filing_date, float(weight))
            )

        # Sort by report period, then public filing date.
        # Later revisions cannot affect earlier decisions.
        for asset in assets:
            observations[asset].sort(
                key=lambda row: (row[0], row[1])
            )

        n_assets = len(assets)
        baseline = 100.0 / n_assets
        weights = []

        for decision_day in decision_dates:
            levels = []

            for asset in assets:
                latest_key = None
                latest_weight = baseline

                for period_end, filing_date, weight in observations[asset]:
                    # Public information only, available by the
                    # end of this decision day.
                    if (
                        period_end > decision_day
                        or filing_date > decision_day
                    ):
                        continue

                    key = (period_end, filing_date)

                    # Most recent applicable report period;
                    # most recent applicable version within it.
                    if latest_key is None or key > latest_key:
                        latest_key = key
                        latest_weight = weight

                levels.append(latest_weight)

            # Cross-sectional demeaning.
            mean_level = fsum(levels) / n_assets
            centered = [
                level - mean_level
                for level in levels
            ]

            gross = fsum(abs(value) for value in centered)

            # No cross-sectional dispersion means no positions.
            if gross == 0.0:
                weights.append([0.0] * n_assets)
                continue

            # Separately scale positive and negative centered
            # exposures to enforce dollar neutrality.
            positive_sum = fsum(
                value for value in centered if value > 0
            )
            negative_sum = fsum(
                -value for value in centered if value < 0
            )

            if positive_sum == 0.0 or negative_sum == 0.0:
                weights.append([0.0] * n_assets)
                continue

            vector = [
                (
                    0.5 * value / positive_sum
                    if value > 0
                    else 0.5 * value / negative_sum
                    if value < 0
                    else 0.0
                )
                for value in centered
            ]

            # Guard against floating-point gross exposure
            # marginally exceeding one.
            actual_gross = fsum(abs(x) for x in vector)

            if actual_gross > 1.0:
                vector = [
                    x / actual_gross
                    for x in vector
                ]

            weights.append(vector)

        return {
            "status": "ok",
            "reason": (
                "Each decision uses only holdings whose actual "
                "public filing date is on or before that decision "
                "day. Date-only filings become usable at that "
                "day's close. The newest applicable report period "
                "and version are selected independently per asset. "
                "Unobserved assets use the equal-weight baseline. "
                "Signals are centered and gross-normalized, with "
                "zero net exposure. Execution occurs at the next "
                "listed session's open, with liquidation at its "
                "close; returns are evaluated independently. "
                "Prices were not used to construct the signal."
            ),
            "weights": weights
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            "Invalid or incomplete input: " + str(exc)
        )
