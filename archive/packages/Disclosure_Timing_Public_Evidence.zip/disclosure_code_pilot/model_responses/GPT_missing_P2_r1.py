from datetime import date
from math import fsum, isfinite


def build_strategy(payload):
    """
    Construct a point-in-time, holdings-based, dollar-neutral signal.

    Required payload fields:
        dates:   Ordered ISO decision dates.
        assets:  Fixed asset column order.
        filings: Holdings observations containing:
                 row_id, asset, period_end, weight_pct.
        prices:  Price observations (not used for signal construction).

    Point-in-time requirement:
        Every filing observation must have its actual public filing date.
        The supplied schema does not include this information.

        Therefore, when filing dates are missing, return
        insufficient_data rather than inventing an availability date.

    If independently verified actual filing dates are subsequently
    supplied as an additional 'filing_date' field on each observation,
    the implementation can construct the signal.

    Signal construction:
        1. For each asset, select the latest publicly available
           report period as of the decision date.
        2. Within that period, use the latest available revision.
        3. Use the equal-weight percentage before an asset's first
           applicable observation.
        4. Subtract the cross-sectional mean.
        5. Normalize to unit gross exposure and zero net exposure.
        6. Return cash if all centered holdings are zero.

    Decisions are made at the end of their supplied dates.
    Positions apply to the next listed session's open-to-close
    interval, as handled by the independent evaluator.

    No price information is used to select or modify weights.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Dates must use ISO YYYY-MM-DD format.")

        return parsed

    # ------------------------------------------------------------
    # Validate the input structure.
    # ------------------------------------------------------------

    try:
        dates = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]

        if not isinstance(dates, list):
            return insufficient("dates must be a list.")

        if not isinstance(assets, list) or not assets:
            return insufficient("assets must be a nonempty list.")

        if not isinstance(filings, list):
            return insufficient("filings must be a list.")

        if any(
            not isinstance(asset, str) or not asset
            for asset in assets
        ):
            return insufficient("Asset identifiers must be strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        decision_dates = [parse_date(d) for d in dates]

        if any(
            decision_dates[i] >= decision_dates[i + 1]
            for i in range(len(decision_dates) - 1)
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

    except (KeyError, TypeError, ValueError) as exc:
        return insufficient(f"Invalid payload: {exc}")

    n_assets = len(assets)

    # ------------------------------------------------------------
    # No filing observations: the specified equal-weight fallback
    # is identical for all assets, so centering produces cash.
    # ------------------------------------------------------------

    if not filings:
        return {
            "status": "ok",
            "reason": (
                "No filing observations supplied; the equal-weight "
                "fallback centers to zero on every decision date."
            ),
            "weights": [
                [0.0] * n_assets
                for _ in decision_dates
            ],
        }

    # ------------------------------------------------------------
    # CRITICAL POINT-IN-TIME CHECK
    #
    # period_end is a holdings as-of date, NOT a public filing date.
    # row_id is opaque and cannot establish publication order.
    #
    # Form N-PORT reporting deadlines are not substitutes for
    # actual public filing dates.
    #
    # Without actual dates, report and revision availability
    # cannot be reconstructed without potential look-ahead bias.
    # ------------------------------------------------------------

    if any(
        not isinstance(row, dict)
        or not isinstance(row.get("filing_date"), str)
        or not row.get("filing_date")
        for row in filings
    ):
        return insufficient(
            "Actual public filing dates are absent. Report-period "
            "dates and opaque row IDs cannot establish when holdings "
            "or revisions became public; exact historical alignment "
            "cannot be established from these inputs."
        )

    # ------------------------------------------------------------
    # The remaining logic applies only if actual public filing
    # dates have been independently supplied.
    #
    # This does not infer or fabricate any missing dates.
    # ------------------------------------------------------------

    asset_set = set(assets)
    observations = []
    seen_versions = set()
    seen_row_ids = set()

    try:
        for row in filings:
            asset = row["asset"]
            row_id = row["row_id"]

            if asset not in asset_set:
                return insufficient(
                    "A filing references an unknown asset."
                )

            if not isinstance(row_id, str) or not row_id:
                return insufficient(
                    "Every filing must have a nonempty row_id."
                )

            if row_id in seen_row_ids:
                return insufficient(
                    "Duplicate row_id encountered."
                )

            seen_row_ids.add(row_id)

            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])

            weight = float(row["weight_pct"])

            if not isfinite(weight):
                return insufficient(
                    "Filing weights must be finite numbers."
                )

            if filing_date < period_end:
                return insufficient(
                    "A public filing date precedes its report period."
                )

            # Different revisions on the same public filing day
            # cannot be ordered using opaque row IDs.
            version_key = (asset, period_end, filing_date)

            if version_key in seen_versions:
                return insufficient(
                    "Multiple versions for an asset and report "
                    "period have the same filing date; their "
                    "public ordering cannot be established."
                )

            seen_versions.add(version_key)

            observations.append(
                {
                    "asset": asset,
                    "period_end": period_end,
                    "filing_date": filing_date,
                    "weight_pct": weight,
                }
            )

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            f"Invalid filing observation: {exc}"
        )

    # Sort only by economically meaningful, verified dates.
    # Opaque row IDs are never used as chronological information.

    observations.sort(
        key=lambda row: (
            row["filing_date"],
            row["period_end"],
        )
    )

    # ------------------------------------------------------------
    # Construct decision-day signals.
    # ------------------------------------------------------------

    equal_weight_pct = 100.0 / n_assets

    # Each asset's selected observation:
    # (report period, actual public filing date, portfolio weight)

    latest = {}

    weights = []
    observation_index = 0

    for decision_day in decision_dates:

        # Date-only public records become usable at the end of
        # their actual filing day, including equality here.

        while observation_index < len(observations):

            observation = observations[observation_index]

            if observation["filing_date"] > decision_day:
                break

            asset = observation["asset"]

            candidate = (
                observation["period_end"],
                observation["filing_date"],
                observation["weight_pct"],
            )

            previous = latest.get(asset)

            # Prefer the newest report period.
            # For that same period, prefer the newest public revision.
            #
            # A later revision never affects earlier decision dates.

            if (
                previous is None
                or candidate[:2] > previous[:2]
            ):
                latest[asset] = candidate

            observation_index += 1

        # Build the holdings-level vector in fixed asset order.

        levels = [
            (
                latest[asset][2]
                if asset in latest
                else equal_weight_pct
            )
            for asset in assets
        ]

        # Cross-sectional centering.

        mean_level = fsum(levels) / n_assets

        centered = [
            value - mean_level
            for value in levels
        ]

        # Separate positive and negative centered exposure.
        # Scaling each side to 0.5 produces a dollar-neutral
        # long/short portfolio with gross exposure of one.

        positive_total = fsum(
            x for x in centered if x > 0.0
        )

        negative_total = fsum(
            -x for x in centered if x < 0.0
        )

        # Identical levels imply no cross-sectional signal.

        if positive_total == 0.0 or negative_total == 0.0:
            row_weights = [0.0] * n_assets

        else:
            row_weights = []

            for value in centered:
                if value > 0.0:
                    position = 0.5 * value / positive_total

                elif value < 0.0:
                    position = 0.5 * value / negative_total

                else:
                    position = 0.0

                row_weights.append(float(position))

        # Numerically verify the portfolio constraints.
        # Floating-point arithmetic is allowed a small tolerance.

        gross_exposure = fsum(
            abs(w) for w in row_weights
        )

        net_exposure = fsum(row_weights)

        if (
            gross_exposure > 1.0 + 1e-12
            or abs(net_exposure) > 1e-12
        ):
            return insufficient(
                "Numerical portfolio exposure constraints failed."
            )

        weights.append(row_weights)

    # ------------------------------------------------------------
    # Return signal weights only.
    #
    # Prices are deliberately unused. Historical returns must
    # be calculated independently using the next listed session's
    # open and close, without shifting signals backward.
    #
    # Close-only price vectors cannot independently establish
    # the specified open-to-close execution returns.
    # ------------------------------------------------------------

    return {
        "status": "ok",
        "reason": (
            "Each observation uses its verified public filing date. "
            "On every decision day, the latest available report period "
            "and applicable revision are selected per asset. "
            "Signals are centered and dollar-neutral; execution "
            "belongs to the next listed session. "
            "Prices are excluded from signal construction."
        ),
        "weights": weights,
    }
