from datetime import date
from fractions import Fraction
from math import isfinite, fsum


def build_strategy(payload):
    """
    Build a point-in-time, holdings-based, dollar-neutral portfolio signal.

    Rules:
    - Use actual SEC filing dates, never inferred reporting lags.
    - A filing is available at the end of its filing_date.
    - For each asset, select the latest available report period,
      then the latest available revision of that period.
    - Never backdate revisions or use future filings.
    - Use 100 / number_of_assets as the initial weight_pct.
    - Cross-sectionally demean and normalize gross exposure to 1.
    - Return all-zero weights when the signal is constant.
    - Do not use prices to construct or optimize the signal.

    Returned weights are indexed by payload["dates"] and ordered
    by payload["assets"]. The independent evaluator is responsible
    for next-session open-to-close execution and return calculation.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")

        try:
            parsed = date.fromisoformat(value)
        except ValueError as exc:
            raise ValueError(
                f"Invalid ISO date: {value!r}"
            ) from exc

        if parsed.isoformat() != value:
            raise ValueError(
                f"Date must use YYYY-MM-DD: {value!r}"
            )

        return parsed

    if not isinstance(payload, dict):
        return insufficient("Payload must be a dictionary.")

    dates = payload.get("dates")
    assets = payload.get("assets")
    filings = payload.get("filings")

    if not isinstance(dates, (list, tuple)) or not dates:
        return insufficient("A nonempty dates sequence is required.")

    if not isinstance(assets, (list, tuple)) or not assets:
        return insufficient("A nonempty assets sequence is required.")

    if not isinstance(filings, (list, tuple)):
        return insufficient("A filings sequence is required.")

    if any(
        not isinstance(asset, str) or not asset
        for asset in assets
    ):
        return insufficient("Asset identifiers must be nonempty strings.")

    if len(set(assets)) != len(assets):
        return insufficient("Asset identifiers must be unique.")

    try:
        decision_dates = [parse_date(d) for d in dates]
    except ValueError as exc:
        return insufficient(str(exc))

    if any(
        decision_dates[i] >= decision_dates[i + 1]
        for i in range(len(decision_dates) - 1)
    ):
        return insufficient(
            "Decision dates must be strictly increasing."
        )

    n_assets = len(assets)
    asset_index = {
        asset: i for i, asset in enumerate(assets)
    }

    # Each version is identified by:
    # (asset, report period, actual SEC filing date).
    #
    # row_id is deliberately NOT used to establish chronology.
    versions = {}
    seen_row_ids = set()

    for row in filings:
        if not isinstance(row, dict):
            return insufficient("Every filing must be a dictionary.")

        required = (
            "row_id",
            "asset",
            "period_end",
            "filing_date",
            "weight_pct",
        )

        missing = [
            field for field in required
            if field not in row or row[field] is None
        ]

        if "filing_date" in missing:
            return insufficient(
                "Actual SEC filing_date is missing. Exact historical "
                "alignment cannot be established from these inputs; "
                "no reporting lag or filing date will be invented."
            )

        if missing:
            return insufficient(
                "Filing is missing required fields: "
                + ", ".join(missing)
            )

        row_id = row["row_id"]

        if not isinstance(row_id, str) or not row_id:
            return insufficient(
                "Every row_id must be a nonempty string."
            )

        if row_id in seen_row_ids:
            return insufficient(
                f"Duplicate row_id: {row_id!r}."
            )

        seen_row_ids.add(row_id)

        asset = row["asset"]

        if asset not in asset_index:
            return insufficient(
                f"Filing references an unknown asset: {asset!r}."
            )

        try:
            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])
        except ValueError as exc:
            return insufficient(str(exc))

        weight = row["weight_pct"]

        if (
            isinstance(weight, bool)
            or not isinstance(weight, (int, float))
        ):
            return insufficient(
                f"Non-numeric weight_pct in row {row_id!r}."
            )

        try:
            if not isfinite(weight):
                return insufficient(
                    f"Non-finite weight_pct in row {row_id!r}."
                )

            # Exact decimal interpretation avoids spurious signals
            # caused by floating-point centering.
            weight_fraction = Fraction(str(weight))

        except (ValueError, OverflowError, ZeroDivisionError):
            return insufficient(
                f"Invalid weight_pct in row {row_id!r}."
            )

        key = (asset, period_end, filing_date)

        if key in versions:
            if versions[key] != weight_fraction:
                return insufficient(
                    "Conflicting weights for the same asset, "
                    "report period, and filing date. Without "
                    "intraday revision ordering, the applicable "
                    "version cannot be determined."
                )
        else:
            versions[key] = weight_fraction

    # Sort by actual public availability date.
    # The report-period ordering is a deterministic tie-breaker,
    # not a substitute for filing chronology.
    events = sorted(
        (
            (filing_date, period_end, asset_index[asset], weight)
            for (asset, period_end, filing_date), weight
            in versions.items()
        ),
        key=lambda event: (
            event[0],
            event[1],
            event[2],
        ),
    )

    # Equal-weight baseline in percentage-point units.
    baseline = Fraction(100, n_assets)

    current_weights = [baseline for _ in range(n_assets)]
    selected_periods = [None] * n_assets
    selected_filing_dates = [None] * n_assets

    output_weights = []
    event_cursor = 0

    for decision_day in decision_dates:

        # Incorporate only filings publicly available by the
        # end of this decision day.
        while (
            event_cursor < len(events)
            and events[event_cursor][0] <= decision_day
        ):
            (
                filing_date,
                period_end,
                asset_idx,
                reported_weight,
            ) = events[event_cursor]

            previous_period = selected_periods[asset_idx]
            previous_filing = selected_filing_dates[asset_idx]

            # Prefer the most recent report period.
            # Within that period, prefer the latest filed version.
            #
            # A late revision to an older period cannot displace
            # a newer period already available.
            applicable = (
                previous_period is None
                or period_end > previous_period
                or (
                    period_end == previous_period
                    and filing_date > previous_filing
                )
            )

            if applicable:
                current_weights[asset_idx] = reported_weight
                selected_periods[asset_idx] = period_end
                selected_filing_dates[asset_idx] = filing_date

            event_cursor += 1

        # Cross-sectional demeaning.
        cross_sectional_mean = (
            sum(current_weights, Fraction(0)) / n_assets
        )

        centered = [
            weight - cross_sectional_mean
            for weight in current_weights
        ]

        # L1 normalization produces unit gross exposure.
        gross_signal = sum(
            (abs(value) for value in centered),
            Fraction(0),
        )

        if gross_signal == 0:
            # No relative holdings signal: stay entirely in cash.
            normalized = [0.0] * n_assets

        else:
            normalized = [
                float(value / gross_signal)
                for value in centered
            ]

            # Protect the gross exposure constraint against
            # the final conversion from exact fractions to floats.
            floating_gross = fsum(abs(x) for x in normalized)

            if floating_gross > 1.0:
                normalized = [
                    x / floating_gross
                    for x in normalized
                ]

        output_weights.append(normalized)

    return {
        "status": "ok",
        "reason": (
            "Point-in-time alignment uses actual SEC filing dates: "
            "records become usable at the end of their filing day. "
            "Each asset uses its latest available report period and "
            "latest filed version of that period, without look-ahead. "
            "Unobserved assets use the equal-weight percentage "
            "baseline. Holdings are cross-sectionally demeaned "
            "and gross-normalized; constant signals produce cash. "
            "Prices are not used for signal construction or "
            "parameter selection. Weights apply to trades at the "
            "next listed session's open, liquidated at its close; "
            "the independent evaluator calculates returns."
        ),
        "weights": output_weights,
    }

