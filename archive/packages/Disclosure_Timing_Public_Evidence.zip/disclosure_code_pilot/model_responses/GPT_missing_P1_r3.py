from bisect import bisect_right
from datetime import date, timedelta
from math import fsum, isfinite
import re


def build_strategy(payload):
    """
    Construct a market-neutral holdings-based portfolio signal.

    Assumptions
    -----------
    - Filings are public third-fiscal-month Form N-PORT observations.
    - During 2022-2023, the relevant public reporting schedule
      generally allowed 60 calendar days after fiscal quarter-end.
    - Without publication timestamps, use a conservative 65-day
      availability proxy, including a five-day calendar buffer.
    - Each asset/report-period pair has exactly one version.
    - This proxy cannot establish actual publication dates or
      guarantee point-in-time correctness for late or amended filings.
    - No prices or future returns are used to construct weights.

    Decisions are made at the end of each supplied decision date.
    The independent evaluator executes trades at the following
    session's open and closes them at that session's close.
    """

    AVAILABILITY_LAG_DAYS = 65

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason
        }

    def parse_date(value):
        if (
            not isinstance(value, str)
            or re.fullmatch(r"\d{4}-\d{2}-\d{2}", value) is None
        ):
            raise ValueError("Dates must use YYYY-MM-DD")
        return date.fromisoformat(value)

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        dates_raw = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]

        if not isinstance(dates_raw, list) or not dates_raw:
            return insufficient("No decision dates supplied.")

        if not isinstance(assets, list) or not assets:
            return insufficient("No assets supplied.")

        if not isinstance(filings, list):
            return insufficient("Filings must be a list.")

        if any(
            not isinstance(asset, str) or not asset
            for asset in assets
        ):
            return insufficient("Invalid asset identifier.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        decision_dates = [parse_date(d) for d in dates_raw]

        if any(
            decision_dates[i] <= decision_dates[i - 1]
            for i in range(1, len(decision_dates))
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n_assets = len(assets)
        asset_set = set(assets)

        # Each asset has its own report history.
        # Entries are (availability_date, period_end, weight_pct).
        history = {asset: [] for asset in assets}

        seen_pairs = set()
        seen_row_ids = set()

        for row in filings:
            if not isinstance(row, dict):
                return insufficient("Invalid filing row.")

            asset = row["asset"]
            period_end = parse_date(row["period_end"])
            row_id = row["row_id"]
            raw_weight = row["weight_pct"]

            if asset not in asset_set:
                return insufficient(
                    "Filing references an unknown asset."
                )

            if not isinstance(row_id, str) or not row_id:
                return insufficient("Invalid filing row_id.")

            if row_id in seen_row_ids:
                return insufficient("Duplicate filing row_id.")

            seen_row_ids.add(row_id)

            if (
                isinstance(raw_weight, bool)
                or not isinstance(raw_weight, (int, float))
            ):
                return insufficient("Invalid holding weight.")

            weight = float(raw_weight)

            if not isfinite(weight):
                return insufficient(
                    "Holding weights must be finite."
                )

            pair = (asset, period_end)

            # Without version timestamps, multiple versions of
            # the same asset/period cannot be ordered causally.
            if pair in seen_pairs:
                return insufficient(
                    "Multiple versions for an asset/report period "
                    "cannot be timed without publication metadata."
                )

            seen_pairs.add(pair)

            # Conservative assumed public-availability date.
            available_on = period_end + timedelta(
                days=AVAILABILITY_LAG_DAYS
            )

            history[asset].append(
                (available_on, period_end, weight)
            )

        # Sort independently of filing input order or row_id.
        availability_dates = {}

        for asset in assets:
            history[asset].sort(key=lambda item: (item[0], item[1]))

            availability_dates[asset] = [
                record[0] for record in history[asset]
            ]

        # Neutral level is in the same percentage units as
        # the reported holdings.
        neutral_level = 100.0 / n_assets

        result_weights = []

        for decision_day in decision_dates:
            levels = []

            for asset in assets:
                # Only observations assumed publicly available
                # by the end of this decision date are eligible.
                idx = bisect_right(
                    availability_dates[asset],
                    decision_day
                ) - 1

                if idx >= 0:
                    level = history[asset][idx][2]
                else:
                    level = neutral_level

                levels.append(level)

            # Cross-sectional demeaning creates dollar neutrality.
            cross_mean = fsum(levels) / n_assets

            centered = [
                level - cross_mean
                for level in levels
            ]

            gross = fsum(abs(value) for value in centered)

            if gross == 0.0:
                # No relative holdings information: hold cash.
                weights = [0.0] * n_assets

            else:
                # Normalize gross absolute exposure to one.
                weights = [
                    value / gross
                    for value in centered
                ]

                # Correct floating-point net-exposure drift.
                if n_assets > 1:
                    weights[-1] = -fsum(weights[:-1])

                # Preserve the gross-exposure ceiling despite
                # floating-point rounding.
                actual_gross = fsum(
                    abs(value) for value in weights
                )

                if actual_gross > 1.0:
                    scale = (1.0 - 1e-14) / actual_gross

                    weights = [
                        value * scale
                        for value in weights
                    ]

                    if n_assets > 1:
                        weights[-1] = -fsum(weights[:-1])

            result_weights.append(weights)

        return {
            "status": "assumption",
            "reason": (
                "Per-asset latest-report alignment using an assumed "
                "65-calendar-day N-PORT availability lag (60-day "
                "reporting window plus five-day buffer). "
                "Actual publication and revision times are unknown; "
                "point-in-time availability cannot be verified. "
                "Prices are excluded from signal construction."
            ),
            "weights": result_weights
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            f"Invalid or incomplete payload: {exc}"
        )
