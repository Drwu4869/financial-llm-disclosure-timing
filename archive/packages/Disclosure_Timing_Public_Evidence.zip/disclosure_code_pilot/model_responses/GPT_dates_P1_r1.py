from datetime import date
from math import fsum, isfinite


def build_strategy(payload):
    """
    Construct a point-in-time, holdings-based, dollar-neutral strategy.

    Inputs:
        payload["dates"]:
            Ordered ISO decision dates.

        payload["assets"]:
            Asset identifiers in fixed output-column order.

        payload["filings"]:
            Unordered records containing:
                row_id
                asset
                period_end
                filing_date
                weight_pct

        payload["prices"]:
            Session dates and close prices. Not used to construct
            signals or estimate returns.

    Alignment:
        A filing is eligible only when:
            filing_date < decision_date

        This conservative rule avoids assuming that a filing with
        an unknown intraday timestamp was available before the
        decision-day close.

        For each asset, select:
            1. The latest eligible report period.
            2. The latest eligible filing version within that period.

        Before the first eligible observation for an asset, use
        the equal-weight percentage level.

    Signal:
        Center the holdings percentages cross-sectionally and
        normalize gross absolute exposure to one.

        An all-equal holdings vector produces a zero portfolio.

    Execution:
        Decisions are made at the end of each decision date.
        The external evaluator handles next-session open-to-close
        execution using its authoritative synthetic session list.

    Returns:
        {
            "status": "ok" | "assumption" | "insufficient_data",
            "reason": str,
            "weights": list[list[float]]
        }
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO date strings.")

        if (
            len(value) != 10
            or value[4] != "-"
            or value[7] != "-"
        ):
            raise ValueError("Dates must use YYYY-MM-DD.")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Invalid ISO date.")

        return parsed

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        decision_dates = payload["dates"]
        assets = payload["assets"]
        filings = payload.get("filings", [])

        if not isinstance(decision_dates, (list, tuple)):
            return insufficient("dates must be an ordered sequence.")

        if not isinstance(assets, (list, tuple)) or not assets:
            return insufficient("A nonempty asset universe is required.")

        if not isinstance(filings, (list, tuple)):
            return insufficient("filings must be a sequence.")

        if any(not isinstance(a, str) for a in assets):
            return insufficient("Asset identifiers must be strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        parsed_dates = [parse_date(d) for d in decision_dates]

        if any(
            parsed_dates[i] >= parsed_dates[i + 1]
            for i in range(len(parsed_dates) - 1)
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n_assets = len(assets)
        asset_index = {
            asset: i for i, asset in enumerate(assets)
        }

        # Holdings are expressed in percentage points, not fractions.
        # This is important when observed and unobserved assets coexist.
        equal_weight_level = 100.0 / n_assets

        # Events:
        # (filing_date, period_end, asset_index, weight_pct)
        events = []

        # Detect contradictory records with indistinguishable
        # availability and report-period timestamps.
        observed_versions = {}

        seen_row_ids = set()

        for row in filings:
            if not isinstance(row, dict):
                return insufficient("Each filing must be a dictionary.")

            asset = row["asset"]

            if asset not in asset_index:
                return insufficient(
                    "A filing references an asset outside the universe."
                )

            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])

            if filing_date < period_end:
                return insufficient(
                    "A filing date precedes its report period end."
                )

            raw_weight = row["weight_pct"]

            if isinstance(raw_weight, bool):
                return insufficient("Invalid holding percentage.")

            weight = float(raw_weight)

            if not isfinite(weight):
                return insufficient(
                    "Holding percentages must be finite."
                )

            if "row_id" in row:
                row_id = row["row_id"]

                if not isinstance(row_id, str):
                    return insufficient("row_id must be a string.")

                if row_id in seen_row_ids:
                    return insufficient("Duplicate row_id detected.")

                seen_row_ids.add(row_id)

            version_key = (asset, period_end, filing_date)

            if version_key in observed_versions:
                if observed_versions[version_key] != weight:
                    return insufficient(
                        "Conflicting holdings share the same asset, "
                        "report period, and filing date."
                    )

                # An identical duplicate observation adds no information.
                continue

            observed_versions[version_key] = weight

            events.append(
                (
                    filing_date,
                    period_end,
                    asset_index[asset],
                    weight,
                )
            )

        # Sorting uses publication dates and report periods only.
        # Opaque row identifiers are never used as chronological keys.
        events.sort(key=lambda event: (event[0], event[1], event[2]))

        # Latest eligible observation for each asset.
        latest_key = [None] * n_assets

        # Current raw holdings percentage vector.
        current_holdings = [
            equal_weight_level
        ] * n_assets

        event_cursor = 0
        output_weights = []

        for decision_date in parsed_dates:

            # Filing timestamps are absent. Exclude filings dated on
            # the decision day itself, even though decisions occur
            # at the close.
            #
            # This is a conservative point-in-time availability rule.
            while (
                event_cursor < len(events)
                and events[event_cursor][0] < decision_date
            ):
                (
                    filing_date,
                    period_end,
                    asset_i,
                    weight,
                ) = events[event_cursor]

                candidate_key = (period_end, filing_date)
                previous_key = latest_key[asset_i]

                # Prefer the newest report period; within that period,
                # prefer the latest publicly available version.
                #
                # A late revision of an older report must not replace
                # a newer report that is already available.
                if (
                    previous_key is None
                    or candidate_key > previous_key
                ):
                    latest_key[asset_i] = candidate_key
                    current_holdings[asset_i] = weight

                event_cursor += 1

            # One asset produces no cross-sectional signal.
            if n_assets == 1:
                output_weights.append([0.0])
                continue

            holdings = current_holdings[:]

            # When all holdings are equal, the centered signal is zero.
            # This also handles the period before any public filings.
            if all(
                value == holdings[0]
                for value in holdings[1:]
            ):
                output_weights.append([0.0] * n_assets)
                continue

            # Cross-sectional centering.
            cross_sectional_mean = fsum(holdings) / n_assets

            centered = [
                value - cross_sectional_mean
                for value in holdings
            ]

            # Correct small floating-point residuals in the final
            # component so the centered vector sums to zero.
            centered[-1] = -fsum(centered[:-1])

            gross = fsum(abs(value) for value in centered)

            if not isfinite(gross):
                return insufficient(
                    "Numerical overflow while normalizing holdings."
                )

            if gross == 0.0:
                output_weights.append([0.0] * n_assets)
                continue

            # Unit gross exposure.
            weights = [
                value / gross
                for value in centered
            ]

            # Correct accumulated floating-point net exposure.
            weights[-1] = -sum(weights[:-1])

            # Protect against a tiny floating-point overshoot of
            # the gross-exposure limit.
            actual_gross = fsum(abs(w) for w in weights)

            if actual_gross > 1.0:
                # The tiny safety margin ensures gross <= 1,
                # while preserving effectively unit exposure.
                denominator = actual_gross * (1.0 + 1e-14)

                weights = [
                    w / denominator
                    for w in weights
                ]

                weights[-1] = -sum(weights[:-1])

            if (
                not all(isfinite(w) for w in weights)
                or fsum(abs(w) for w in weights) > 1.0 + 1e-12
                or abs(fsum(weights)) > 1e-12
            ):
                return insufficient(
                    "Unable to construct valid neutral exposures."
                )

            output_weights.append(weights)

        return {
            "status": "assumption",
            "reason": (
                "Point-in-time alignment uses only filings dated "
                "strictly before each end-of-day decision, because "
                "intraday filing times are unavailable. "
                "For each asset, the latest eligible report period "
                "and filing version are selected independently; "
                "unobserved assets use the equal-weight percentage "
                "level. Signals are cross-sectionally centered and "
                "gross-normalized, with zero exposure when all "
                "holdings are equal. Prices are not used to construct "
                "or optimize signals. The independent evaluator "
                "must execute each decision at the next session's "
                "open and liquidate at that session's close, using "
                "the supplied synthetic session chronology. "
                "Close-only prices cannot independently establish "
                "open-to-close execution returns."
            ),
            "weights": output_weights,
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            "Invalid or incomplete input: " + str(exc)
        )
