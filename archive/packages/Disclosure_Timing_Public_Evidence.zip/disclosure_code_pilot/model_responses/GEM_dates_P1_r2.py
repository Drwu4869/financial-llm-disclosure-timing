def build_strategy(payload: dict) -> dict:
    """
    Builds a holdings-based portfolio signal evaluating Form N-PORT data.
    
    Args:
        payload (dict): Contains 'dates', 'assets', 'filings', and 'prices'.
    
    Returns:
        dict: Evaluation results containing 'status', 'reason', and 'weights'.
    """
    dates = payload.get('dates', [])
    assets = payload.get('assets', [])
    filings = payload.get('filings', [])
    
    if not dates or not assets:
        return {
            'status': 'insufficient_data',
            'reason': 'Payload is missing required dates or assets.',
            'weights': []
        }
        
    n_assets = len(assets)
    # Default equal-weight level matching the weight_pct unit (percentages)
    equal_weight = 100.0 / n_assets 
    weights = []
    
    # Pre-process filings by asset for faster lookups
    asset_filings = {a: [] for a in assets}
    for f in filings:
        asset_name = f.get('asset')
        if asset_name in asset_filings:
            asset_filings[asset_name].append(f)
            
    for decision_date in dates:
        raw_vector = []
        
        for asset in assets:
            # Filter filings available on or before the decision date to avoid look-ahead bias
            valid_filings = [f for f in asset_filings[asset] if f['filing_date'] <= decision_date]
            
            if not valid_filings:
                # Use equal-weight level before any applicable observation
                raw_vector.append(equal_weight)
            else:
                # Find the most recent report period (period_end)
                max_period_end = max(f['period_end'] for f in valid_filings)
                
                # If there are revisions, find the most recently filed version for that report period
                latest_filing = max(
                    (f for f in valid_filings if f['period_end'] == max_period_end),
                    key=lambda x: x['filing_date']
                )
                
                raw_vector.append(latest_filing['weight_pct'])
                
        # Subtract the cross-sectional mean
        cross_sectional_mean = sum(raw_vector) / n_assets
        centered_vector = [v - cross_sectional_mean for v in raw_vector]
        
        # Normalize absolute weights to sum to one
        sum_abs = sum(abs(v) for v in centered_vector)
        
        # Return cash (vector of zeros) when the centered vector is zero
        if sum_abs < 1e-12:
            weights.append([0.0] * n_assets)
        else:
            normalized_vector = [v / sum_abs for v in centered_vector]
            weights.append(normalized_vector)
            
    return {
        'status': 'ok',
        'reason': 'Signal aligned with most recent applicable filings; avoided look-ahead bias.',
        'weights': weights
    }

