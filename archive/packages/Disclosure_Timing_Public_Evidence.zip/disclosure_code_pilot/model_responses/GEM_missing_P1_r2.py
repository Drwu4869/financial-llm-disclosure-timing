import datetime

def build_strategy(payload: dict) -> dict:
    """
    Constructs a cross-sectionally mean-centered and normalized portfolio signal
    based on N-PORT holdings data.
    """
    dates = payload.get('dates', [])
    assets = payload.get('assets', [])
    filings = payload.get('filings', [])

    if not dates or not assets:
        return {
            'status': 'insufficient_data',
            'reason': 'Payload is missing required dates or assets.',
            'weights': []
        }

    N = len(assets)
    # Using 100.0 / N since input weights are represented as percentages (e.g., 14.5)
    eq_weight = 100.0 / N

    # Consolidate filings to handle only the single version per asset/report period provided
    filings_dict = {}
    for row in filings:
        asset = row.get('asset')
        if asset not in assets:
            continue
        
        period_end_str = row.get('period_end')
        if not period_end_str:
            continue
            
        period_end = datetime.date.fromisoformat(period_end_str)
        filings_dict[(asset, period_end)] = row.get('weight_pct', eq_weight)

    # Under SEC rules during 2022-2023, public parts of N-PORT for the third fiscal month
    # are filed and made public 60 days after the report period ends.
    # We apply this 60-day lag to strictly avoid look-ahead bias.
    asset_filings = {a: [] for a in assets}
    for (asset, period_end), w_pct in filings_dict.items():
        avail_date = period_end + datetime.timedelta(days=60)
        asset_filings[asset].append((period_end, avail_date, w_pct))

    # Sort each asset's history chronologically by period_end to identify the most recent observation
    for a in assets:
        asset_filings[a].sort(key=lambda x: x[0])

    weights = []

    for dt_str in dates:
        dt = datetime.date.fromisoformat(dt_str)
        raw_vector = []
        
        for a in assets:
            applicable_weight = eq_weight
            # Use the most recent report period available strictly on or before this decision day
            for period_end, avail_date, w_pct in asset_filings[a]:
                if avail_date <= dt:
                    applicable_weight = w_pct
            raw_vector.append(applicable_weight)
            
        # Subtract the cross-sectional mean
        cross_sectional_mean = sum(raw_vector) / N
        centered = [x - cross_sectional_mean for x in raw_vector]
        
        # Normalize absolute weights to sum to one (Net = 0.0, Gross = 1.0)
        sum_abs = sum(abs(x) for x in centered)
        
        if sum_abs > 1e-12:
            normalized = [x / sum_abs for x in centered]
        else:
            # Return cash (zero weights) when the centered vector is zero
            normalized = [0.0] * N
            
        weights.append(normalized)

    return {
        'status': 'assumption',
        'reason': 'Assumed a strict 60-day lag from period_end to public availability for N-PORT filings to prevent look-ahead bias, as publication timestamps were omitted.',
        'weights': weights
    }

