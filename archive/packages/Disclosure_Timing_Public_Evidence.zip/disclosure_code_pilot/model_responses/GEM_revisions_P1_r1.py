def build_strategy(payload):
    dates = payload.get("dates", [])
    assets = payload.get("assets", [])
    filings = payload.get("filings", [])

    if not dates or not assets:
        return {
            "status": "insufficient_data",
            "reason": "Payload is missing required dates or assets for evaluation.",
            "weights": []
        }

    num_assets = len(assets)
    # The prompt requests the equal-weight level prior to applicable observations.
    # Because weight_pct represents a percentage, equal weight in fractional terms is 1.0 / num_assets.
    equal_weight = 1.0 / num_assets

    # Group and sort filings by asset.
    # Sorting primarily by period_end (descending) and then version (descending)
    # allows us to confidently take the first filing we iterate over that is legally
    # known as-of the decision date (filing_date <= decision_date), preventing look-ahead bias.
    filings_by_asset = {asset: [] for asset in assets}
    for f in filings:
        asset = f.get("asset")
        if asset in filings_by_asset:
            filings_by_asset[asset].append(f)

    for asset in assets:
        filings_by_asset[asset].sort(
            key=lambda x: (x.get("period_end", ""), x.get("version", -1)),
            reverse=True
        )

    weights = []
    
    for date in dates:
        raw_weights = []
        for asset in assets:
            current_weight = equal_weight
            for f in filings_by_asset[asset]:
                # Observation is permitted if the public filing was made on or before the decision date
                if f.get("filing_date", "9999-99-99") <= date:
                    # Convert percentage format to a standard fraction
                    current_weight = f.get("weight_pct", 0.0) / 100.0
                    break
            raw_weights.append(current_weight)

        # Subtract the cross-sectional mean
        mean_weight = sum(raw_weights) / num_assets
        centered_weights = [w - mean_weight for w in raw_weights]

        # Normalize absolute weights to sum to one (Net exposure = 0, Gross exposure <= 1)
        abs_sum = sum(abs(w) for w in centered_weights)
        
        if abs_sum > 1e-9:
            final_weights = [w / abs_sum for w in centered_weights]
        else:
            # Return cash (zero weights) when the centered vector is virtually zero
            final_weights = [0.0 for _ in assets]

        weights.append(final_weights)

    return {
        "status": "ok",
        "reason": "Weights determined using the latest known filing_date <= decision date. Unobserved assets default to equal-weight. Vector is zero-centered and absolute sum is normalized to 1.",
        "weights": weights
    }

