def build_strategy(payload: dict) -> dict:
    """
    Builds a holdings-based portfolio signal evaluating filings point-in-time.
    
    Args:
        payload (dict): Expected to contain 'dates', 'assets', 'filings', and optionally 'prices'.
        
    Returns:
        dict: A dictionary containing 'status', 'reason', and 'weights'.
    """
    dates = payload.get('dates', [])
    assets = payload.get('assets', [])
    filings = payload.get('filings', [])
    
    if not assets:
        return {
            'status': 'insufficient_data',
            'reason': 'No assets provided in the payload to form a cross-section.',
            'weights': []
        }
        
    if not dates:
        return {
            'status': 'ok',
            'reason': 'No evaluation dates provided.',
            'weights': []
        }

    N = len(assets)
    
    # Pre-group filings by asset for faster point-in-time traversal.
    # We convert weight_pct to a decimal here to match the 1/N equal-weight default.
    asset_filings = {a: [] for a in assets}
    for f in filings:
        asset = f.get('asset')
        if asset in asset_filings:
            asset_filings[asset].append({
                'filing_date': f.get('filing_date', ''),
                'period_end': f.get('period_end', ''),
                'weight': f.get('weight_pct', 0.0) / 100.0
            })
            
    # Sort filings strictly by filing_date ascending, then period_end ascending.
    # ISO date strings (YYYY-MM-DD) sort chronologically.
    for a in assets:
        asset_filings[a].sort(key=lambda x: (x['filing_date'], x['period_end']))
        
    # Maintain state pointers across ordered dates to avoid O(N^2) lookups
    pointers = {a: 0 for a in assets}
    current_best = {a: None for a in assets}
    
    weights_matrix = []
    
    for d in dates:
        raw_w = []
        for a in assets:
            flist = asset_filings[a]
            p = pointers[a]
            
            # Consume any filings that are observable on or before date 'd'
            while p < len(flist) and flist[p]['filing_date'] <= d:
                new_f = flist[p]
                if current_best[a] is None:
                    current_best[a] = new_f
                else:
                    # We want the most recent report period.
                    # Because we process chronologically by filing_date, if the new filing
                    # has a period_end >= the current best's period_end, it's either
                    # a newer report or a revision for the same report, making it the new valid observation.
                    if new_f['period_end'] >= current_best[a]['period_end']:
                        current_best[a] = new_f
                p += 1
            
            pointers[a] = p
            
            # Apply equal weight (1/N) if no valid observation is found prior to decision day
            if current_best[a] is None:
                raw_w.append(1.0 / N)
            else:
                raw_w.append(current_best[a]['weight'])
                
        # Center the vector cross-sectionally
        mean_w = sum(raw_w) / N
        centered = [w - mean_w for w in raw_w]
        
        # Normalize absolute weights so gross exposure == 1
        sum_abs = sum(abs(c) for c in centered)
        
        if sum_abs == 0:
            # Fallback to zero vector (cash) when centered vector is uniformly zero
            norm_w = [0.0] * N
        else:
            norm_w = [c / sum_abs for c in centered]
            
        weights_matrix.append(norm_w)
        
    return {
        'status': 'ok',
        'reason': 'Successfully evaluated point-in-time constraints, centering, and net-zero normalization.',
        'weights': weights_matrix
    }

