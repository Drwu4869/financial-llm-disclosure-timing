import math

def build_strategy(payload):
    """
    Builds a holdings-based portfolio signal based on N-PORT filings.
    
    Args:
        payload (dict): Dictionary containing 'dates', 'assets', 'filings', and 'prices'.
    
    Returns:
        dict: A dictionary containing the status, reason, and computed weights.
    """
    dates = payload.get('dates', [])
    assets = payload.get('assets', [])
    filings = payload.get('filings', [])

    # Validate essential inputs
    if not dates or not assets:
        return {
            "status": "insufficient_data",
            "reason": "Missing 'dates' or 'assets' in the payload to form the portfolio space.",
            "weights": []
        }

    num_assets = len(assets)
    # Equal weight level before any applicable observations (assuming percentage scale matches weight_pct)
    equal_weight = 100.0 / num_assets

    # Group filings by asset to optimize point-in-time filtering
    filings_by_asset = {asset: [] for asset in assets}
    for filing in filings:
        asset = filing.get('asset')
        if asset in filings_by_asset:
            filings_by_asset[asset].append(filing)

    weights = []

    for decision_date in dates:
        day_raw_weights = []
        
        for asset in assets:
            # Step 1: Filter filings that are observable on or before the decision date
            applicable_filings = [
                f for f in filings_by_asset[asset] 
                if f['filing_date'] <= decision_date
            ]
            
            if not applicable_filings:
                # Use the equal-weight level before any applicable observation
                day_raw_weights.append(equal_weight)
            else:
                # Step 2: Find the most recent report period (period_end)
                # ISO date strings can be compared lexicographically
                max_period_end = max(f['period_end'] for f in applicable_filings)
                
                # Step 3: Find the highest version for that specific report period
                latest_period_filings = [
                    f for f in applicable_filings 
                    if f['period_end'] == max_period_end
                ]
                best_filing = max(latest_period_filings, key=lambda x: x['version'])
                
                day_raw_weights.append(best_filing['weight_pct'])

        # Step 4: Subtract cross-sectional mean
        mean_w = sum(day_raw_weights) / num_assets
        centered = [w - mean_w for w in day_raw_weights]

        # Step 5: Normalize absolute weights to sum to one, ensuring gross <= 1 and net == 0
        sum_abs = sum(abs(c) for c in centered)
        
        # If the centered vector is entirely zero, return cash (vector of zeros)
        if math.isclose(sum_abs, 0.0, abs_tol=1e-9):
            weights.append([0.0] * num_assets)
        else:
            weights.append([c / sum_abs for c in centered])

    return {
        "status": "ok",
        "reason": (
            "Successfully aligned filings strictly point-in-time. Assumed equal weight for assets "
            "prior to their first applicable observation as requested. Used the highest version of the "
            "most recent report period. Centered and normalized absolute exposure to 1 (0 net)."
        ),
        "weights": weights
    }

