from datetime import date
import math
import re


def build_strategy(payload):
    """
    Build point-in-time, holdings-based portfolio signals.

    Alignment:
      - filing_date is the public availability date.
      - A filing is usable at the end of its filing_date.
      - For each asset, select the latest publicly available
        report period and the highest eligible version.
      - Revisions never affect decisions before their filing_date.
      - Before an asset's first eligible observation, use 100/N.
      - Center holdings cross-sectionally and normalize gross
        exposure to at most 1, with zero net exposure.
      - Return cash when the centered signal is zero.

    The evaluator independently applies each decision to the
    next listed session's open-to-close return.

    Prices are intentionally not used to construct the signal.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if (
            not isinstance(value, str)
            or re.fullmatch(r"\d{4}-\d{2}-\d{2}", value) is None
        ):
            raise ValueError("Expected ISO date YYYY-MM-DD")
        return date.fromisoformat(value)

    # ---------------------------------------------------------
    # 1. Validate the input universe and decision dates.
    # ---------------------------------------------------------

    if not isinstance(payload, dict):
        return insufficient("Payload must be a dictionary.")

    assets = payload.get("assets")
    dates = payload.get("dates")
    filings = payload.get("filings")

    if (
        not isinstance(assets, list)
        or not assets
        or any(not isinstance(a, str) or not a for a in assets)
        or len(set(assets)) != len(assets)
    ):
        return insufficient(
            "Assets must be a nonempty list of unique names."
        )

    if not isinstance(dates, list) or not dates:
        return insufficient(
            "At least one decision date is required."
        )

    try:
        decision_dates = [parse_date(d) for d in dates]
    except (TypeError, ValueError):
        return insufficient(
            "Decision dates must be valid ISO YYYY-MM-DD dates."
        )

    if any(
        decision_dates[i] <= decision_dates[i - 1]
        for i in range(1, len(decision_dates))
    ):
        return insufficient(
            "Decision dates must be strictly increasing."
        )

    if not isinstance(filings, list):
        return insufficient("Filings must be a list.")

    # ---------------------------------------------------------
    # 2. Validate point-in-time filing information.
    #
    # Missing actual public filing dates cannot be replaced
    # with report-period dates or an assumed publication lag.
    # ---------------------------------------------------------

    asset_set = set(assets)
    seen_row_ids = set()
    seen_versions = set()
    records = []

    for index, row in enumerate(filings):
        if not isinstance(row, dict):
            return insufficient(
                f"Filing row {index} is not a dictionary."
            )

        if (
            "filing_date" not in row
            or row["filing_date"] is None
            or row["filing_date"] == ""
        ):
            return insufficient(
                "Actual public filing dates are missing; "
                "exact historical alignment cannot be established "
                "without them."
            )

        required = (
            "row_id",
            "asset",
            "period_end",
            "filing_date",
            "version",
            "weight_pct",
        )

        missing = [key for key in required if key not in row]

        if missing:
            return insufficient(
                f"Filing row {index} is missing: "
                + ", ".join(missing)
            )

        asset = row["asset"]
        row_id = row["row_id"]
        version = row["version"]

        if asset not in asset_set:
            return insufficient(
                f"Filing row {index} references an unknown asset."
            )

        if (
            not isinstance(row_id, str)
            or not row_id
            or row_id in seen_row_ids
        ):
            return insufficient(
                "Filing row IDs must be nonempty and unique."
            )

        seen_row_ids.add(row_id)

        try:
            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])
        except (TypeError, ValueError):
            return insufficient(
                f"Filing row {index} contains an invalid date."
            )

        if (
            not isinstance(version, int)
            or isinstance(version, bool)
            or version < 0
        ):
            return insufficient(
                f"Filing row {index} has an invalid version."
            )

        version_key = (asset, period_end, version)

        if version_key in seen_versions:
            return insufficient(
                "Duplicate versions for the same asset and "
                "report period make the filing history ambiguous."
            )

        seen_versions.add(version_key)

        raw_weight = row["weight_pct"]

        if (
            isinstance(raw_weight, bool)
            or not isinstance(raw_weight, (int, float))
        ):
            return insufficient(
                f"Filing row {index} has a nonnumeric weight."
            )

        try:
            weight = float(raw_weight)
        except (TypeError, ValueError, OverflowError):
            return insufficient(
                f"Filing row {index} has an invalid weight."
            )

        if not math.isfinite(weight):
            return insufficient(
                f"Filing row {index} has a nonfinite weight."
            )

        records.append(
            {
                "asset": asset,
                "period_end": period_end,
                "filing_date": filing_date,
                "version": version,
                "weight_pct": weight,
            }
        )

    # ---------------------------------------------------------
    # 3. Sort by actual public filing date, not period_end.
    #
    # Processing records only when filing_date <= decision
    # date prevents any use of future filings or revisions.
    # ---------------------------------------------------------

    records.sort(
        key=lambda r: (
            r["filing_date"],
            r["period_end"],
            r["version"],
        )
    )

    n_assets = len(assets)

    # Holdings are expressed in percentage points.
    equal_weight_pct = 100.0 / n_assets

    # State maps each asset to:
    # (report_period, version, reported_weight_pct)
    #
    # Lexicographic (period, version) ordering ensures:
    #   1. Newer report periods supersede older periods.
    #   2. Higher eligible versions supersede earlier versions.
    #   3. A late revision of an older period cannot override
    #      an already-public newer report period.

    latest = {}
    record_cursor = 0
    n_records = len(records)

    output_weights = []

    # ---------------------------------------------------------
    # 4. Construct the signal for each decision day.
    # ---------------------------------------------------------

    for decision_day in decision_dates:

        # Activate all filings publicly available by the
        # end of the current decision day, inclusive.

        while (
            record_cursor < n_records
            and records[record_cursor]["filing_date"]
            <= decision_day
        ):
            record = records[record_cursor]

            asset = record["asset"]

            candidate_key = (
                record["period_end"],
                record["version"],
            )

            incumbent = latest.get(asset)

            if (
                incumbent is None
                or candidate_key
                > (incumbent[0], incumbent[1])
            ):
                latest[asset] = (
                    record["period_end"],
                    record["version"],
                    record["weight_pct"],
                )

            record_cursor += 1

        # Use the latest eligible reported holding for each
        # asset. Assets not yet observed receive the equal-
        # weight percentage level, not an assumed zero.

        holdings = [
            latest[asset][2]
            if asset in latest
            else equal_weight_pct
            for asset in assets
        ]

        # -----------------------------------------------------
        # 5. Cross-sectional demeaning.
        # -----------------------------------------------------

        try:
            mean_weight = math.fsum(holdings) / n_assets

            centered = [
                weight - mean_weight
                for weight in holdings
            ]

            # Correct floating-point centering residual.
            # This preserves a zero-net signal to numerical
            # precision without changing the intended model.

            if n_assets > 1:
                residual = math.fsum(centered)
                centered[-1] -= residual

            gross = math.fsum(
                abs(value) for value in centered
            )

        except (OverflowError, ValueError):
            return insufficient(
                "Holding magnitudes exceed stable numerical "
                "evaluation limits."
            )

        # -----------------------------------------------------
        # 6. Gross normalization and cash fallback.
        # -----------------------------------------------------

        if gross == 0.0:
            signal = [0.0] * n_assets

        else:
            # Scale the centered positions to unit gross
            # exposure, with a small rounding safeguard.

            denominator = math.nextafter(
                gross, math.inf
            )

            signal = [
                value / denominator
                for value in centered
            ]

            # Defend against floating-point rounding that
            # could otherwise produce gross > 1.

            for _ in range(4):
                realized_gross = math.fsum(
                    abs(value) for value in signal
                )

                if realized_gross <= 1.0:
                    break

                signal = [
                    math.nextafter(value, 0.0)
                    for value in signal
                ]

            # Avoid negative-zero representations.
            signal = [
                0.0 if value == 0.0 else value
                for value in signal
            ]

        output_weights.append(signal)

    # ---------------------------------------------------------
    # 7. Return one asset-ordered weight vector per date.
    #
    # No price-based selection, fitting, optimization,
    # lookahead, or return calculation is performed.
    # ---------------------------------------------------------

    return {
        "status": "ok",
        "reason": (
            "Point-in-time alignment uses actual SEC filing "
            "dates, inclusive at decision-day close. For each "
            "asset, the latest publicly available report period "
            "and highest eligible version determine its holding. "
            "Unobserved assets receive the 100/N percent "
            "equal-weight level. Holdings are cross-sectionally "
            "centered and gross-normalized; zero signals remain "
            "in cash. Decisions precede next-session execution. "
            "Prices are excluded from signal construction and "
            "returns are evaluated independently."
        ),
        "weights": output_weights,
    }
