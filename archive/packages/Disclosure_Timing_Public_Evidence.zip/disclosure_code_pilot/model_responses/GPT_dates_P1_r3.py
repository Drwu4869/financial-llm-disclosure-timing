def build_strategy(payload):
    from datetime import date, timedelta
    from math import fsum, isfinite, ulp

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Date must be an ISO YYYY-MM-DD string.")
        parsed = date.fromisoformat(value)
        if parsed.isoformat() != value:
            raise ValueError("Date must use YYYY-MM-DD format.")
        return parsed

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        dates_raw = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]

        if not isinstance(dates_raw, list) or not dates_raw:
            return insufficient("No decision dates supplied.")

        if not isinstance(assets, list) or not assets:
            return insufficient("No assets supplied.")

        if (
            any(not isinstance(a, str) or not a for a in assets)
            or len(set(assets)) != len(assets)
        ):
            return insufficient("Asset names must be unique strings.")

        if not isinstance(filings, list):
            return insufficient("Filings must be a list.")

        decisions = [parse_date(d) for d in dates_raw]

        if any(
            decisions[i] <= decisions[i - 1]
            for i in range(1, len(decisions))
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n_assets = len(assets)
        asset_index = {a: i for i, a in enumerate(assets)}
        equal_weight_pct = 100.0 / n_assets

        # Historical Form N-PORT third-fiscal-month reports:
        # public disclosure is subject to a 60-calendar-day
        # delay after the fiscal quarter's end.
        #
        # The effective public date cannot precede either
        # the filing date or the end of that disclosure delay.
        #
        # Because intraday publication times are unavailable,
        # a record is conservatively eligible only when:
        #
        #     effective_public_date < decision_date
        #
        # This prevents using a same-day filing or release
        # that might have occurred after the decision close.

        events = []
        seen_row_ids = set()
        seen_versions = {}

        for row in filings:
            if not isinstance(row, dict):
                return insufficient("Each filing must be a dictionary.")

            row_id = row["row_id"]
            asset = row["asset"]
            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])
            raw_weight = row["weight_pct"]

            if not isinstance(row_id, str) or not row_id:
                return insufficient("Invalid filing row_id.")

            if row_id in seen_row_ids:
                return insufficient("Duplicate filing row_id.")

            seen_row_ids.add(row_id)

            if asset not in asset_index:
                return insufficient(
                    "A filing references an unknown asset."
                )

            if isinstance(raw_weight, bool) or not isinstance(
                raw_weight, (int, float)
            ):
                return insufficient(
                    "Filing weight_pct must be numeric."
                )

            weight_pct = float(raw_weight)

            if not isfinite(weight_pct):
                return insufficient(
                    "Filing weights must be finite numbers."
                )

            if filing_date < period_end:
                return insufficient(
                    "A filing date precedes its report period."
                )

            # Different filing dates can represent revisions.
            # Same asset, period and filing date with conflicting
            # values cannot be chronologically disambiguated.
            version_key = (asset, period_end, filing_date)

            if version_key in seen_versions:
                if seen_versions[version_key] != weight_pct:
                    return insufficient(
                        "Conflicting versions have the same "
                        "asset, period and filing date."
                    )
                continue

            seen_versions[version_key] = weight_pct

            public_date = max(
                filing_date,
                period_end + timedelta(days=60)
            )

            events.append((
                public_date,
                period_end,
                filing_date,
                asset_index[asset],
                weight_pct
            ))

        # Filings are unordered in the input.
        #
        # Sort by effective public date, then report period
        # and filing date. Never use row_id to infer chronology.
        events.sort(key=lambda e: (e[0], e[1], e[2]))

        # Per-asset state:
        # (period_end, filing_date, weight_pct)
        #
        # State is updated only using eligible observations.
        latest = [None] * n_assets

        result_weights = []
        event_pos = 0

        for decision_date in decisions:

            # Incorporate only information that was already
            # publicly available before this decision day.
            while (
                event_pos < len(events)
                and events[event_pos][0] < decision_date
            ):
                (
                    public_date,
                    period_end,
                    filing_date,
                    idx,
                    weight_pct
                ) = events[event_pos]

                current = latest[idx]

                # Report-period recency takes precedence over
                # filing-date recency.
                #
                # Within the same report period, the later
                # eligible filing replaces the earlier version.
                #
                # Thus, a late revision of an older period
                # cannot overwrite a newer report period.
                if (
                    current is None
                    or (period_end, filing_date)
                    > (current[0], current[1])
                ):
                    latest[idx] = (
                        period_end,
                        filing_date,
                        weight_pct
                    )

                event_pos += 1

            # Construct the raw holdings vector in the fixed
            # asset order. Missing observations receive the
            # equal-weight baseline, expressed in percentages.
            holdings = [
                equal_weight_pct
                if latest[i] is None
                else latest[i][2]
                for i in range(n_assets)
            ]

            # If every holding has the same level, the
            # cross-sectionally centered signal is zero.
            if all(x == holdings[0] for x in holdings):
                result_weights.append([0.0] * n_assets)
                continue

            # Cross-sectional demeaning.
            mean_weight = fsum(holdings) / n_assets

            centered = [
                x - mean_weight
                for x in holdings
            ]

            gross = fsum(abs(x) for x in centered)

            if gross == 0.0:
                result_weights.append([0.0] * n_assets)
                continue

            if not isfinite(gross):
                return insufficient(
                    "Numerical overflow while normalizing holdings."
                )

            # Normalize absolute exposures to one.
            portfolio = [
                x / gross
                for x in centered
            ]

            # Correct floating-point summation residuals
            # so the returned portfolio is dollar-neutral
            # to floating-point precision.
            portfolio[-1] = -fsum(portfolio[:-1])

            # Ensure gross exposure cannot exceed one due
            # to floating-point rounding. Retain a tiny
            # numerical safety margin.
            actual_gross = fsum(abs(x) for x in portfolio)

            if actual_gross == 0.0:
                result_weights.append([0.0] * n_assets)
                continue

            safety_target = 1.0 - 8.0 * ulp(1.0)

            if actual_gross > safety_target:
                scale = safety_target / actual_gross
                portfolio = [
                    x * scale
                    for x in portfolio
                ]

            # Explicitly reject invalid numerical output.
            if any(not isfinite(x) for x in portfolio):
                return insufficient(
                    "Non-finite portfolio weight produced."
                )

            if fsum(abs(x) for x in portfolio) > 1.0:
                return insufficient(
                    "Gross exposure exceeds one."
                )

            if abs(fsum(portfolio)) > 1e-12:
                return insufficient(
                    "Portfolio is not dollar-neutral."
                )

            result_weights.append(portfolio)

        # Prices are deliberately not used.
        #
        # Signals are determined at each supplied decision
        # day's close using only previously public holdings.
        # The independent evaluator maps each decision to
        # the next session in its authoritative session list,
        # executes at that session's open, and liquidates
        # at its close.
        #
        # Close-only prices cannot determine open-to-close
        # execution returns, so no performance is fabricated.

        return {
            "status": "assumption",
            "reason": (
                "Uses the later of SEC filing_date and "
                "period_end + 60 calendar days as the public "
                "availability date for third-month N-PORT reports. "
                "Because intraday release times are unavailable, "
                "records become eligible only on decision dates "
                "strictly after that date. For each asset, selects "
                "the newest eligible report period and then its "
                "latest eligible revision. Missing observations "
                "use the equal-weight baseline. Signals are "
                "demeaned, gross-normalized and dollar-neutral. "
                "Prices are excluded from signal construction; "
                "next-session execution and returns belong to "
                "the independent evaluator."
            ),
            "weights": result_weights
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            "Invalid or incomplete payload: " + str(exc)
        )
