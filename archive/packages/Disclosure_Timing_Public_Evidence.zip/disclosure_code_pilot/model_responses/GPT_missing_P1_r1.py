from bisect import bisect_right
from collections import defaultdict
from datetime import date, timedelta
import math


def build_strategy(payload):
    """
    Build a dollar-neutral holdings-based portfolio signal.

    Historical alignment
    --------------------
    Under the 2022-2023 Form N-PORT regime, third-fiscal-month
    reports were generally required within 60 calendar days
    after the fiscal quarter ended and became public upon filing.

    Actual publication timestamps are unavailable. Therefore,
    this implementation ASSUMES that ordinary reports were
    publicly available 70 calendar days after period_end.

    The additional 10 days provide a conservative buffer for
    non-business-day deadlines and end-of-day publication.

    This is an explicit assumption, not proof of point-in-time
    availability. Late filings and subsequent amendments could
    invalidate the assumed availability dates.

    Rules
    -----
    1. Never use a report before its assumed availability date.
    2. For each asset, select its latest eligible report period.
    3. Before an asset has an eligible observation, assign the
       equal-weight baseline of 100 / number_of_assets.
    4. Subtract the cross-sectional mean.
    5. Normalize absolute exposure to one.
    6. Return zero weights when the centered vector is zero.
    7. Never use prices to construct or calibrate signals.
    8. Output one weight vector per supplied decision date.

    Decisions are formed at the close of each supplied date.
    The evaluator is responsible for executing at the next
    supplied session's open and liquidating at that session's
    close.

    Returns
    -------
    dict:
        status: "ok", "assumption", or "insufficient_data"
        reason: explanation of alignment or missing information
        weights: list[list[float]], when data is sufficient
    """

    DISCLOSURE_LAG_DAYS = 70

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Date must be an ISO YYYY-MM-DD string.")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Date must use YYYY-MM-DD format.")

        return parsed

    def normalize_neutral(levels):
        """
        Center and gross-normalize a vector.

        Apply a small floating-point correction so that
        numerical rounding does not create net exposure
        or gross leverage above one.
        """
        n = len(levels)

        if n == 0:
            return []

        if all(value == levels[0] for value in levels):
            return [0.0] * n

        mean = math.fsum(levels) / n

        centered = [
            value - mean
            for value in levels
        ]

        gross = math.fsum(
            abs(value)
            for value in centered
        )

        if gross == 0.0:
            return [0.0] * n

        weights = [
            value / gross
            for value in centered
        ]

        # Remove floating-point net-exposure drift.
        weights[-1] = -math.fsum(weights[:-1])

        # Enforce the gross-exposure ceiling.
        actual_gross = math.fsum(
            abs(value)
            for value in weights
        )

        if actual_gross > 1.0:
            scale = (1.0 - 2e-15) / actual_gross

            weights = [
                value * scale
                for value in weights
            ]

            weights[-1] = -math.fsum(weights[:-1])

        return [
            0.0 if value == 0.0 else float(value)
            for value in weights
        ]

    # --------------------------------------------------
    # Validate payload
    # --------------------------------------------------

    if not isinstance(payload, dict):
        return insufficient("Payload must be a dictionary.")

    try:
        raw_dates = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]
    except (KeyError, TypeError):
        return insufficient(
            "Payload requires dates, assets, and filings."
        )

    if not isinstance(raw_dates, (list, tuple)):
        return insufficient("dates must be a sequence.")

    if not isinstance(assets, (list, tuple)) or not assets:
        return insufficient("assets must be nonempty.")

    if not isinstance(filings, (list, tuple)):
        return insufficient("filings must be a sequence.")

    if (
        any(not isinstance(a, str) or not a for a in assets)
        or len(set(assets)) != len(assets)
    ):
        return insufficient(
            "Asset identifiers must be unique, nonempty strings."
        )

    try:
        decision_dates = [
            parse_date(value)
            for value in raw_dates
        ]
    except (ValueError, TypeError):
        return insufficient("Invalid decision date.")

    if any(
        decision_dates[i] <= decision_dates[i - 1]
        for i in range(1, len(decision_dates))
    ):
        return insufficient(
            "Decision dates must be strictly increasing."
        )

    n_assets = len(assets)
    baseline = 100.0 / n_assets
    asset_set = set(assets)

    # --------------------------------------------------
    # Index observations by asset.
    #
    # row_id is opaque and must never be interpreted as
    # a filing timestamp, amendment order, or sort key.
    #
    # One version per asset/report period is assumed,
    # as specified by the input contract.
    # --------------------------------------------------

    observations = defaultdict(list)
    seen_row_ids = set()
    seen_asset_periods = set()

    for row in filings:

        if not isinstance(row, dict):
            return insufficient(
                "Each filing row must be a dictionary."
            )

        try:
            row_id = row["row_id"]
            asset = row["asset"]
            period_end = parse_date(row["period_end"])
            raw_weight = row["weight_pct"]
        except (KeyError, ValueError, TypeError):
            return insufficient(
                "A filing row has missing or invalid fields."
            )

        if not isinstance(row_id, str) or not row_id:
            return insufficient("Invalid row_id.")

        if row_id in seen_row_ids:
            return insufficient("Duplicate row_id.")

        seen_row_ids.add(row_id)

        if asset not in asset_set:
            return insufficient(
                "Filing references an asset outside the universe."
            )

        if (
            isinstance(raw_weight, bool)
            or not isinstance(raw_weight, (int, float))
        ):
            return insufficient(
                "weight_pct must be numeric."
            )

        try:
            weight = float(raw_weight)
        except (ValueError, OverflowError):
            return insufficient(
                "Invalid weight_pct value."
            )

        if not math.isfinite(weight):
            return insufficient(
                "weight_pct must be finite."
            )

        key = (asset, period_end)

        if key in seen_asset_periods:
            return insufficient(
                "Multiple rows exist for the same asset and "
                "report period. Without version/publication "
                "timestamps, their historical precedence "
                "cannot be determined."
            )

        seen_asset_periods.add(key)

        try:
            available_on = period_end + timedelta(
                days=DISCLOSURE_LAG_DAYS
            )
        except OverflowError:
            return insufficient(
                "Report availability date is out of range."
            )

        observations[asset].append(
            (available_on, period_end, weight)
        )

    # --------------------------------------------------
    # Prepare per-asset chronological indexes.
    #
    # Sorting depends on report dates, never row order,
    # opaque identifiers, or future prices.
    # --------------------------------------------------

    available_dates = {}
    observed_weights = {}

    for asset in assets:

        rows = sorted(
            observations[asset],
            key=lambda item: (item[0], item[1])
        )

        available_dates[asset] = [
            item[0]
            for item in rows
        ]

        observed_weights[asset] = [
            item[2]
            for item in rows
        ]

    # --------------------------------------------------
    # Construct signals at each decision-day close.
    #
    # Price vectors are deliberately not accessed.
    # The evaluator independently handles next-session
    # execution and realized returns.
    # --------------------------------------------------

    result_weights = []
    used_assumed_publication = False

    for decision_day in decision_dates:

        levels = []

        for asset in assets:

            idx = bisect_right(
                available_dates[asset],
                decision_day
            ) - 1

            if idx >= 0:
                level = observed_weights[asset][idx]
                used_assumed_publication = True
            else:
                level = baseline

            levels.append(level)

        result_weights.append(
            normalize_neutral(levels)
        )

    # --------------------------------------------------
    # Report the unavoidable information limitation.
    # --------------------------------------------------

    if used_assumed_publication:
        status = "assumption"
        reason = (
            "Uses each asset's latest report period assumed "
            "public by the decision-day close, with a "
            "conservative 70-calendar-day lag after period_end "
            "(60-day N-PORT filing rule plus 10-day buffer). "
            "Missing observations use the equal-weight "
            "baseline. Actual publication and amendment "
            "timestamps are unavailable, so point-in-time "
            "accuracy cannot be guaranteed for late or "
            "revised filings. Prices are not used."
        )
    else:
        status = "ok"
        reason = (
            "No filing observation is eligible under the "
            "70-calendar-day disclosure-lag convention. "
            "All assets use the equal-weight baseline, "
            "which centers to cash. Prices are not used."
        )

    return {
        "status": status,
        "reason": reason,
        "weights": result_weights,
    }
