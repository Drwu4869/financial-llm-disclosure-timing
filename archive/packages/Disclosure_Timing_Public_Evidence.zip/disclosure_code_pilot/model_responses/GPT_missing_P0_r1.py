from datetime import date, timedelta
from collections import defaultdict
import bisect
import math


def build_strategy(payload):
    """
    Build a holdings-based, market-neutral portfolio signal.

    Historical alignment:
      - Uses only the fund's reported holdings.
      - Assumes third-fiscal-month Form N-PORT holdings become
        publicly available 60 calendar days after period_end.
      - Because actual publication timestamps are unavailable,
        observations become eligible only on decision dates
        strictly later than the assumed publication date.
      - Carries forward each asset's latest eligible observation.
      - Uses an equal-weight baseline before an asset's first
        eligible observation.
      - Centers cross-sectionally and normalizes gross exposure
        to one, unless the signal is zero.

    Decision weights apply to the next session's open-to-close
    trade, not to the decision day's return.

    Prices are intentionally not used. The independent evaluator
    handles execution, session alignment, and realized returns.

    Returns:
        {
            "status": "assumption" | "insufficient_data",
            "reason": str,
            "weights": list[list[float]]  # when available
        }
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO strings.")

        result = date.fromisoformat(value)

        if result.isoformat() != value:
            raise ValueError("Dates must use YYYY-MM-DD.")

        return result

    if not isinstance(payload, dict):
        return insufficient("Payload must be a dictionary.")

    try:
        assets = payload["assets"]
        decision_dates_raw = payload["dates"]
        filings = payload["filings"]

        if not isinstance(assets, list) or not assets:
            return insufficient("A nonempty asset universe is required.")

        if any(
            not isinstance(asset, str) or not asset
            for asset in assets
        ):
            return insufficient("Asset identifiers must be nonempty strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        if not isinstance(decision_dates_raw, list):
            return insufficient("Decision dates must be a list.")

        if not decision_dates_raw:
            return insufficient("At least one decision date is required.")

        if not isinstance(filings, list):
            return insufficient("Filings must be a list.")

        decision_dates = [
            parse_date(value)
            for value in decision_dates_raw
        ]

        if any(
            decision_dates[i] <= decision_dates[i - 1]
            for i in range(1, len(decision_dates))
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        asset_index = {
            asset: i
            for i, asset in enumerate(assets)
        }

        n_assets = len(assets)

        # weight_pct is expressed in percentage points.
        equal_weight_level = 100.0 / n_assets

        # In the 2022-2023 reporting regime, public third-month
        # Form N-PORT reports had a 60-day public-availability lag.
        #
        # This is an assumed alignment, not a verified publication
        # timestamp. The extra strict-date condition prevents use
        # on the assumed publication day itself.
        public_lag = timedelta(days=60)

        # Each key represents one asset/report-period observation.
        #
        # row_id is opaque and must not be interpreted as a
        # chronological or revision-ordering field.
        observations = {}

        for row in filings:
            if not isinstance(row, dict):
                return insufficient("Invalid filing row.")

            asset = row["asset"]

            if asset not in asset_index:
                return insufficient(
                    "A filing references an unknown asset."
                )

            period_end = parse_date(row["period_end"])

            raw_weight = row["weight_pct"]

            if isinstance(raw_weight, bool):
                return insufficient("Invalid filing weight.")

            weight = float(raw_weight)

            if not math.isfinite(weight):
                return insufficient(
                    "Filing weights must be finite."
                )

            key = (asset, period_end)

            if key in observations:
                if observations[key] != weight:
                    return insufficient(
                        "Conflicting observations for the same "
                        "asset and report period cannot be ordered "
                        "without version or publication timestamps."
                    )

                # Identical duplicate observations carry no
                # additional information.
                continue

            observations[key] = weight

        # Group observations in the supplied asset order.
        #
        # Each tuple is:
        #   (report_period_end, reported_weight)
        #
        # Sorting by report period is valid because each
        # asset/report-period pair has only one version.
        histories = defaultdict(list)

        for (asset, period_end), weight in observations.items():
            histories[asset_index[asset]].append(
                (period_end, weight)
            )

        for history in histories.values():
            history.sort(key=lambda item: item[0])

        # Maintain one pointer and one latest eligible level
        # per asset. This avoids revisiting historical observations
        # for every decision date.
        positions = [0] * n_assets
        current_levels = [equal_weight_level] * n_assets

        weights = []

        for decision_day in decision_dates:

            # Only reports whose assumed publication day has
            # already passed can influence this decision.
            #
            # This condition does not rely on the synthetic
            # exchange calendar or any price observations.
            eligibility_cutoff = decision_day - public_lag

            for asset_i in range(n_assets):
                history = histories[asset_i]
                position = positions[asset_i]

                while (
                    position < len(history)
                    and history[position][0] < eligibility_cutoff
                ):
                    _, reported_weight = history[position]

                    current_levels[asset_i] = reported_weight

                    position += 1

                positions[asset_i] = position

            # Cross-sectional demeaning.
            cross_sectional_mean = (
                math.fsum(current_levels) / n_assets
            )

            centered = [
                level - cross_sectional_mean
                for level in current_levels
            ]

            # Remove accumulated floating-point net drift.
            # The last component is determined by the others.
            if n_assets > 1:
                centered[-1] = -math.fsum(centered[:-1])

            gross = math.fsum(
                abs(value)
                for value in centered
            )

            if gross == 0.0:
                # An equal cross-sectional holdings vector
                # contains no relative signal.
                portfolio = [0.0] * n_assets

            else:
                portfolio = [
                    value / gross
                    for value in centered
                ]

                # Enforce numerical neutrality.
                if n_assets > 1:
                    portfolio[-1] = -math.fsum(
                        portfolio[:-1]
                    )

                # Guard against floating-point gross exposure
                # exceeding one by a rounding error.
                realized_gross = math.fsum(
                    abs(value)
                    for value in portfolio
                )

                if realized_gross > 1.0:
                    portfolio = [
                        value / realized_gross
                        for value in portfolio
                    ]

            weights.append(portfolio)

        return {
            "status": "assumption",
            "reason": (
                "Actual filing and publication timestamps are "
                "unavailable. Assumes public third-fiscal-month "
                "Form N-PORT observations become available "
                "60 calendar days after period_end; uses each "
                "observation only on decision dates strictly "
                "after that assumed date. Carries forward each "
                "asset's latest eligible reported weight and "
                "uses an equal-weight level before its first "
                "observation. Cross-sectionally demeans and "
                "normalizes to unit gross exposure, or cash "
                "when the signal is zero. Weights are formed "
                "at decision-day close for next-session "
                "open-to-close evaluation. Prices are not used "
                "to construct or select the signal. Actual "
                "historical publication timing cannot be "
                "verified from the supplied data."
            ),
            "weights": weights
        }

    except (
        KeyError,
        TypeError,
        ValueError,
        OverflowError
    ) as exc:
        return insufficient(
            f"Invalid or incomplete input: {exc}"
        )
