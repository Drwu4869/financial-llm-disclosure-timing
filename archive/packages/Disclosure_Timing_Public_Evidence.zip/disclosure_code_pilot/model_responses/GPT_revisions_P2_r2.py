from datetime import date
from math import fsum, isfinite


def build_strategy(payload):
    """
    Build a point-in-time, holdings-based long/short portfolio signal.

    Returns:
        {
            "status": "ok" | "assumption" | "insufficient_data",
            "reason": str,
            "weights": list[list[float]]  # omitted if insufficient
        }

    Weight rows follow payload["dates"].
    Weight columns follow payload["assets"].

    Filing-day observations are available at that day's close.
    Positions are intended for the next listed session's open-to-close
    trade. Prices are never used to construct the signal.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Dates must use ISO YYYY-MM-DD format.")

        return parsed

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        dates = payload.get("dates")
        assets = payload.get("assets")
        filings = payload.get("filings")

        if not isinstance(dates, list):
            return insufficient("Missing or invalid decision dates.")

        if not isinstance(assets, list) or not assets:
            return insufficient("A nonempty asset list is required.")

        if not isinstance(filings, list):
            return insufficient("Missing or invalid filing records.")

        if (
            any(not isinstance(asset, str) for asset in assets)
            or len(set(assets)) != len(assets)
        ):
            return insufficient("Asset identifiers must be unique strings.")

        decision_dates = [parse_date(d) for d in dates]

        if any(
            decision_dates[i] <= decision_dates[i - 1]
            for i in range(1, len(decision_dates))
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n_assets = len(assets)
        asset_index = {
            asset: i for i, asset in enumerate(assets)
        }

        # Each event:
        # (public_filing_date, report_period, version, asset_index, weight)
        events = []

        seen_row_ids = set()
        seen_versions = set()

        for row in filings:
            if not isinstance(row, dict):
                return insufficient("Filing rows must be dictionaries.")

            # Never manufacture availability dates from report periods
            # or assumed regulatory filing delays.
            if not row.get("filing_date"):
                return insufficient(
                    "Actual public filing dates are absent; exact "
                    "historical alignment cannot be established."
                )

            required = (
                "row_id",
                "asset",
                "period_end",
                "filing_date",
                "version",
                "weight_pct",
            )

            if any(field not in row for field in required):
                return insufficient(
                    "A filing record is missing required fields."
                )

            asset = row["asset"]

            if asset not in asset_index:
                return insufficient(
                    "A filing references an unknown asset."
                )

            row_id = row["row_id"]

            if not isinstance(row_id, str):
                return insufficient(
                    "Filing row identifiers must be strings."
                )

            if row_id in seen_row_ids:
                return insufficient(
                    "Duplicate filing row identifier."
                )

            seen_row_ids.add(row_id)

            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])

            if filing_date < period_end:
                return insufficient(
                    "A filing date precedes its holdings report period."
                )

            version = row["version"]

            if (
                isinstance(version, bool)
                or not isinstance(version, int)
                or version < 0
            ):
                return insufficient(
                    "Filing versions must be nonnegative integers."
                )

            version_key = (asset, period_end, version)

            if version_key in seen_versions:
                return insufficient(
                    "Duplicate version for an asset and report period."
                )

            seen_versions.add(version_key)

            raw_weight = row["weight_pct"]

            if (
                isinstance(raw_weight, bool)
                or not isinstance(raw_weight, (int, float))
            ):
                return insufficient(
                    "Holdings percentages must be numeric."
                )

            weight = float(raw_weight)

            if not isfinite(weight):
                return insufficient(
                    "Holdings percentages must be finite."
                )

            events.append(
                (
                    filing_date,
                    period_end,
                    version,
                    asset_index[asset],
                    weight,
                )
            )

        # Input filing order and opaque row_id values have no
        # influence on historical availability or precedence.
        events.sort(key=lambda event: event[0])

        # A holding not yet publicly observed receives the equal-
        # weight percentage level, not a zero holding percentage.
        equal_level = 100.0 / n_assets
        levels = [equal_level] * n_assets

        # Per asset, retain the latest eligible (period_end, version).
        # Report-period precedence comes before revision precedence.
        latest_keys = [None] * n_assets

        output_weights = []
        event_cursor = 0

        for decision_day in decision_dates:

            # Inclusive comparison: date-only public filings can be
            # used for decisions at the end of their filing day.
            while (
                event_cursor < len(events)
                and events[event_cursor][0] <= decision_day
            ):
                (
                    filing_day,
                    period_end,
                    version,
                    idx,
                    weight,
                ) = events[event_cursor]

                candidate_key = (period_end, version)
                current_key = latest_keys[idx]

                if (
                    current_key is None
                    or candidate_key > current_key
                ):
                    latest_keys[idx] = candidate_key
                    levels[idx] = weight

                event_cursor += 1

            # A single-asset universe cannot support a nonzero,
            # dollar-neutral cross-sectional portfolio.
            if n_assets == 1:
                output_weights.append([0.0])
                continue

            # Identical holdings levels imply an exactly zero signal.
            if all(x == levels[0] for x in levels):
                output_weights.append([0.0] * n_assets)
                continue

            # Center the cross section. Subtracting a common reference
            # first improves floating-point accuracy when holdings
            # levels are close together.
            reference = levels[0]
            differences = [x - reference for x in levels]

            mean_difference = fsum(differences) / n_assets

            centered = [
                x - mean_difference
                for x in differences
            ]

            # Normalize absolute exposures to gross leverage one.
            gross = fsum(abs(x) for x in centered)

            if gross == 0.0:
                weights = [0.0] * n_assets
            else:
                weights = [x / gross for x in centered]

                # Guard against a tiny floating-point overshoot of
                # the gross-exposure limit.
                observed_gross = fsum(abs(x) for x in weights)

                if observed_gross > 1.0:
                    scale = 1.0 / observed_gross
                    weights = [x * scale for x in weights]

                    # One-ULP corrections preserve the intended
                    # normalization while enforcing gross <= 1.
                    from math import nextafter

                    while fsum(abs(x) for x in weights) > 1.0:
                        weights = [
                            nextafter(x, 0.0) if x != 0.0 else 0.0
                            for x in weights
                        ]

            output_weights.append(weights)

        return {
            "status": "ok",
            "reason": (
                "At each decision close, uses only records with actual "
                "public filing_date on or before that day. For each asset, "
                "selects the newest eligible report period and highest "
                "eligible version, without backdating revisions. "
                "Unobserved assets use the equal-weight level. "
                "Cross-sectional deviations are gross-normalized and "
                "dollar-neutral (up to floating-point precision), "
                "with zero signals held in cash. Weights are intended "
                "for execution at the next listed session's open and "
                "liquidation at its close. The independent evaluator "
                "handles session alignment and returns; no prices "
                "are used in signal construction."
            ),
            "weights": output_weights,
        }

    except (ValueError, TypeError, OverflowError, KeyError) as exc:
        return insufficient(
            "Cannot construct a reliable point-in-time signal: "
            + str(exc)
        )
