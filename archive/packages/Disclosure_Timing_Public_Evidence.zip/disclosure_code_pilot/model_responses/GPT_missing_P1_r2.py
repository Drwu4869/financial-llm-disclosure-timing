from bisect import bisect_left
from datetime import date
from math import fsum, isfinite


def build_strategy(payload):
    """
    Construct a holdings-based, market-neutral portfolio signal.

    Point-in-time assumption:
        Third-fiscal-month Form N-PORT holdings are assumed publicly
        available by 60 calendar days after their report period ends,
        consistent with the historical quarterly filing regime.

        To avoid using information on its assumed publication day,
        observations become eligible only on decision dates strictly
        later than period_end + 60 calendar days.

        Actual publication dates and revision histories cannot be
        established from the supplied schema. Consequently, results
        are marked 'assumption', not 'ok'.

    Signal:
        1. Obtain each asset's latest eligible reported weight.
        2. Use 100 / N before an asset has an eligible observation.
        3. Subtract the cross-sectional mean.
        4. Normalize absolute exposure to one.
        5. Hold cash if all centered holdings are zero.

    Execution:
        Weights are determined at the end of each decision date.
        The external evaluator is responsible for executing them
        at the next session's open and closing them that session.

        Prices are deliberately excluded from signal construction.
        The provided close prices alone cannot determine
        next-session open-to-close returns.
    """

    PUBLICATION_LAG_DAYS = 60

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason
        }

    def parse_iso_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")

        try:
            parsed = date.fromisoformat(value)
        except ValueError:
            raise ValueError("Invalid ISO date: {!r}".format(value))

        if parsed.isoformat() != value:
            raise ValueError("Date must use YYYY-MM-DD: {!r}".format(value))

        return parsed

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        dates = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]

        if not isinstance(dates, list) or not dates:
            return insufficient("A nonempty decision-date list is required.")

        if not isinstance(assets, list) or not assets:
            return insufficient("A nonempty asset list is required.")

        if not isinstance(filings, list):
            return insufficient("Filings must be a list.")

        if any(
            not isinstance(asset, str) or not asset
            for asset in assets
        ):
            return insufficient("Asset identifiers must be nonempty strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        decision_dates = [parse_iso_date(d) for d in dates]

        if any(
            decision_dates[i] >= decision_dates[i + 1]
            for i in range(len(decision_dates) - 1)
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n_assets = len(assets)
        equal_weight_pct = 100.0 / n_assets

        # Store observations independently for each asset.
        # Each entry is (period_end_ordinal, weight_pct).
        history = {asset: [] for asset in assets}

        seen_row_ids = set()
        seen_asset_periods = set()

        for row in filings:
            if not isinstance(row, dict):
                return insufficient("Each filing must be a dictionary.")

            row_id = row["row_id"]
            asset = row["asset"]
            period_end = parse_iso_date(row["period_end"])
            raw_weight = row["weight_pct"]

            if not isinstance(row_id, str) or not row_id:
                return insufficient("Invalid filing row_id.")

            if row_id in seen_row_ids:
                return insufficient("Duplicate filing row_id.")

            seen_row_ids.add(row_id)

            if asset not in history:
                return insufficient(
                    "Filing contains an asset outside the fixed universe."
                )

            if isinstance(raw_weight, bool) or not isinstance(
                raw_weight, (int, float)
            ):
                return insufficient("Filing weight_pct must be numeric.")

            weight_pct = float(raw_weight)

            if not isfinite(weight_pct):
                return insufficient(
                    "Filing weights must be finite numbers."
                )

            period_ordinal = period_end.toordinal()
            pair = (asset, period_ordinal)

            # row_id is opaque and cannot establish revision order.
            # Without timestamps, multiple versions for the same
            # asset and period cannot be ordered point-in-time.
            if pair in seen_asset_periods:
                return insufficient(
                    "Multiple versions for an asset/report period "
                    "cannot be aligned without publication timestamps."
                )

            seen_asset_periods.add(pair)

            history[asset].append(
                (period_ordinal, weight_pct)
            )

        # Filings are unordered. Sort chronologically, never by row_id.
        # Separate period ordinals and values for efficient lookup.
        indexed_history = {}

        for asset in assets:
            observations = sorted(history[asset])

            indexed_history[asset] = (
                [item[0] for item in observations],
                [item[1] for item in observations]
            )

        output_weights = []

        for decision_day in decision_dates:
            decision_ordinal = decision_day.toordinal()

            # An observation is usable only if:
            #
            #     period_end + 60 days < decision_day
            #
            # This deliberately excludes the assumed publication day.
            cutoff = decision_ordinal - PUBLICATION_LAG_DAYS

            levels = []

            for asset in assets:
                periods, values = indexed_history[asset]

                # Find the most recent period strictly before cutoff.
                index = bisect_left(periods, cutoff) - 1

                if index >= 0:
                    level = values[index]
                else:
                    level = equal_weight_pct

                levels.append(level)

            # Identical holdings levels produce a zero signal.
            # Handle this explicitly to avoid floating-point artifacts.
            if all(level == levels[0] for level in levels):
                output_weights.append([0.0] * n_assets)
                continue

            # Cross-sectional demeaning.
            mean_level = fsum(levels) / n_assets

            centered = [
                level - mean_level
                for level in levels
            ]

            # Correct accumulated floating-point error so that
            # the centered vector has approximately zero net exposure.
            centered[-1] = -fsum(centered[:-1])

            gross = fsum(abs(value) for value in centered)

            if gross == 0.0:
                output_weights.append([0.0] * n_assets)
                continue

            # Normalize gross absolute exposure to one.
            weights = [
                value / gross
                for value in centered
            ]

            # Eliminate residual net exposure from division rounding.
            weights[-1] = -fsum(weights[:-1])

            # Protect against gross exposure marginally exceeding
            # one because of floating-point rounding.
            realized_gross = fsum(abs(w) for w in weights)

            if realized_gross > 1.0:
                weights = [
                    w / realized_gross
                    for w in weights
                ]

            output_weights.append(weights)

        return {
            "status": "assumption",
            "reason": (
                "Assumes third-month N-PORT holdings were public "
                "by period_end + 60 calendar days; first uses them "
                "on later decision dates. Actual publication and "
                "revision times are unavailable, so point-in-time "
                "accuracy cannot be guaranteed. Signals use no "
                "prices; next-session execution and returns are "
                "handled independently by the evaluator."
            ),
            "weights": output_weights
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            "Invalid or incomplete payload: {}".format(exc)
        )
