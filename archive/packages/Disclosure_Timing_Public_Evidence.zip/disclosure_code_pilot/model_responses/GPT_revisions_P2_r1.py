def build_strategy(payload):
    from datetime import date
    from math import fsum, isfinite, nextafter

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")
        parsed = date.fromisoformat(value)
        if parsed.isoformat() != value:
            raise ValueError("Dates must use ISO YYYY-MM-DD format.")
        return parsed

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        assets = payload["assets"]
        dates = payload["dates"]
        filings = payload["filings"]

        if not isinstance(assets, list) or not assets:
            return insufficient("A nonempty asset list is required.")

        if any(not isinstance(a, str) or not a for a in assets):
            return insufficient("Asset identifiers must be nonempty strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        if not isinstance(dates, list) or not dates:
            return insufficient("At least one decision date is required.")

        if not isinstance(filings, list):
            return insufficient("Filings must be a list.")

        # Actual filing dates are essential for point-in-time alignment.
        # Never infer them from period_end or a fixed reporting lag.
        for row in filings:
            if not isinstance(row, dict):
                return insufficient("Each filing must be a dictionary.")

            if not row.get("filing_date"):
                return insufficient(
                    "Exact historical alignment cannot be established "
                    "because actual SEC filing dates are absent. "
                    "No reporting lag has been inferred."
                )

        decision_dates = [parse_date(d) for d in dates]

        if any(
            decision_dates[i] <= decision_dates[i - 1]
            for i in range(1, len(decision_dates))
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n = len(assets)
        asset_index = {asset: i for i, asset in enumerate(assets)}
        equal_weight_level = 100.0 / n

        # Events become observable at the END of their filing date.
        # Each event is:
        # (filing_date, asset_index, period_end, version, weight_pct)
        events = []
        seen_ids = set()
        seen_versions = set()

        for row in filings:
            asset = row["asset"]

            if asset not in asset_index:
                return insufficient(
                    "A filing references an asset outside the fixed universe."
                )

            row_id = row["row_id"]
            if not isinstance(row_id, str) or not row_id:
                return insufficient("Each filing needs a valid row_id.")

            if row_id in seen_ids:
                return insufficient("Duplicate filing row_id.")
            seen_ids.add(row_id)

            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])

            version = row["version"]
            if type(version) is not int:
                return insufficient(
                    "Filing versions must be integers."
                )

            version_key = (asset, period_end, version)
            if version_key in seen_versions:
                return insufficient(
                    "Duplicate asset/report-period/version combination."
                )
            seen_versions.add(version_key)

            value = row["weight_pct"]
            if isinstance(value, bool) or not isinstance(
                value, (int, float)
            ):
                return insufficient("Filing weights must be numeric.")

            weight_pct = float(value)
            if not isfinite(weight_pct):
                return insufficient("Filing weights must be finite.")

            events.append(
                (
                    filing_date,
                    asset_index[asset],
                    period_end,
                    version,
                    weight_pct,
                )
            )

        # Filing rows are unordered; establish actual availability order.
        events.sort(key=lambda e: (e[0], e[1], e[2], e[3]))

        # For each asset, retain the best publicly available observation.
        # Selection priority:
        #   1. Latest eligible report period.
        #   2. Highest eligible version within that period.
        #
        # A subsequently filed revision cannot affect earlier decisions.
        latest_key = [None] * n
        latest_value = [equal_weight_level] * n

        weights = []
        event_index = 0

        for decision_date in decision_dates:

            # Incorporate only records filed by this decision day's end.
            while (
                event_index < len(events)
                and events[event_index][0] <= decision_date
            ):
                (
                    filing_date,
                    asset_idx,
                    period_end,
                    version,
                    weight_pct,
                ) = events[event_index]

                candidate_key = (period_end, version)
                current_key = latest_key[asset_idx]

                if (
                    current_key is None
                    or candidate_key > current_key
                ):
                    latest_key[asset_idx] = candidate_key
                    latest_value[asset_idx] = weight_pct

                event_index += 1

            # Current holdings vector; unobserved assets retain
            # the equal-weight percentage level.
            levels = latest_value[:]

            # Cross-sectional demeaning.
            mean_level = fsum(levels) / n
            centered = [v - mean_level for v in levels]

            # Gross exposure before normalization.
            gross = fsum(abs(x) for x in centered)

            if gross == 0.0:
                # No cross-sectional information: hold cash.
                weights.append([0.0] * n)
                continue

            # Normalize absolute exposure to one.
            signal = [x / gross for x in centered]

            # Correct negligible floating-point net-exposure drift.
            # Adjust the largest-magnitude component to minimize
            # relative numerical error.
            if n > 1:
                correction_index = max(
                    range(n), key=lambda i: abs(signal[i])
                )
                other_sum = fsum(
                    signal[i]
                    for i in range(n)
                    if i != correction_index
                )
                signal[correction_index] = -other_sum

            # Guard against gross exposure exceeding one because
            # of floating-point rounding.
            actual_gross = fsum(abs(x) for x in signal)

            if actual_gross > 1.0:
                target = nextafter(1.0, 0.0)
                factor = target / actual_gross
                signal = [x * factor for x in signal]

            weights.append(signal)

        return {
            "status": "ok",
            "reason": (
                "Point-in-time alignment uses actual SEC filing dates. "
                "For each asset, the latest publicly available report "
                "period and highest available version are selected. "
                "Date-only filings are assumed available at the end "
                "of their filing day, including same-day decisions. "
                "Unobserved assets use the equal-weight level. "
                "Signals are cross-sectionally demeaned and normalized "
                "to unit gross exposure, or zero when degenerate. "
                "Prices are not used to construct signals or select "
                "parameters. Execution is deferred to the next listed "
                "session's open, with liquidation at that session's "
                "close; return evaluation is performed independently "
                "using the authoritative synthetic session list."
            ),
            "weights": weights,
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            "Invalid or incomplete payload: " + str(exc)
        )
