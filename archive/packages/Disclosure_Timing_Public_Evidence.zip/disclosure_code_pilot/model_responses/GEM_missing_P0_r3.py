import datetime

def build_strategy(payload: dict) -> dict:
    """
    Implements a holdings-based portfolio signal using N-PORT filings.
    Assumes a 60-day lag from period_end to publication date based on 
    the SEC N-PORT third-fiscal-month public availability rules for 2022-2023.
    """
    dates_str = payload.get('dates', [])
    assets = payload.get('assets', [])
    filings = payload.get('filings', [])
    
    if not assets or not dates_str:
        return {
            'status': 'insufficient_data',
            'reason': 'Missing dates or assets in the payload.',
            'weights': []
        }
        
    N = len(assets)
    
    def parse_date(d_str: str) -> datetime.date:
        y, m, d = map(int, d_str.split('-'))
        return datetime.date(y, m, d)
        
    # Group filings by asset
    asset_filings = {a: [] for a in assets}
    
    for f in filings:
        a = f.get('asset')
        pe_str = f.get('period_end')
        w = f.get('weight_pct')
        
        if a in asset_filings and pe_str and w is not None:
            pe = parse_date(pe_str)
            # N-PORT data for the third month of a fiscal quarter is made public 
            # 60 days after the end of the reporting period.
            pub_date = pe + datetime.timedelta(days=60)
            asset_filings[a].append({
                'period_end': pe,
                'pub_date': pub_date,
                'weight': float(w)
            })
            
    # Sort each asset's filings by period_end to ensure chronological application
    for a in assets:
        asset_filings[a].sort(key=lambda x: x['period_end'])
        
    weights = []
    
    for d_str in dates_str:
        decision_date = parse_date(d_str)
        raw_vec = []
        
        # 1. Form the asset vector using the most recent report period available
        for a in assets:
            best_w = None
            for filing in asset_filings[a]:
                # Filing must be available on or before the decision day
                if filing['pub_date'] <= decision_date:
                    best_w = filing['weight']
                    
            if best_w is None:
                # Before any applicable observation, use equal-weight level
                # Since weights are percentages, equal-weight is 100 / N
                raw_vec.append(100.0 / N)
            else:
                raw_vec.append(best_w)
                
        # 2. Subtract cross-sectional mean
        mean_w = sum(raw_vec) / N
        centered_vec = [w - mean_w for w in raw_vec]
        
        # 3. Normalize absolute weights to sum to one
        abs_sum = sum(abs(w) for w in centered_vec)
        
        if abs_sum < 1e-9:
            # Return cash (zero weights) when the centered vector is zero
            weights.append([0.0] * N)
        else:
            # Enforces gross exposure <= 1 and net exposure == 0
            norm_vec = [w / abs_sum for w in centered_vec]
            weights.append(norm_vec)
            
    return {
        'status': 'assumption',
        'reason': 'Inferred public availability by adding a statutory 60-day lag to period_end for Form N-PORT third-fiscal-month filings.',
        'weights': weights
    }

