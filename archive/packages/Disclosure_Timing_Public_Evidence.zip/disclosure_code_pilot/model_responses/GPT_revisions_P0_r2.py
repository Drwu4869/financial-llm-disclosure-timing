from datetime import date, timedelta
from math import fsum, isfinite, nextafter, inf


def build_strategy(payload):
    """
    Build a point-in-time, holdings-based, market-neutral portfolio signal.

    Public availability assumptions:
      - Third-fiscal-month Form N-PORT information under the 2022-2023
        regime becomes public no earlier than 60 calendar days after
        the report period ends.
      - A record cannot be used before its actual SEC filing date.
      - Because intraday publication times are unavailable, a record
        is usable only on decision dates strictly after its inferred
        public availability date.
      - Revisions replace earlier versions only when publicly available.

    Signal:
      - For each asset, select the latest publicly available report
        period, then its highest publicly available version.
      - Before an asset's first applicable observation, use 100/N.
      - Subtract the cross-sectional mean.
      - Normalize gross absolute exposure to at most one.
      - Return all-zero weights when the centered signal is zero.

    Timing:
      - Each returned row is decided at the end of its input date.
      - The independent evaluator executes it at the next session's
        open and liquidates at that session's close.
      - Prices are never used to construct or optimize the signal.

    Returns:
        {
            "status": "ok" | "assumption" | "insufficient_data",
            "reason": str,
            "weights": list[list[float]]
        }
    """

    def insufficient(message):
        return {
            "status": "insufficient_data",
            "reason": str(message)[:200]
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Dates must use canonical YYYY-MM-DD format.")

        return parsed

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        dates_input = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]

        if not isinstance(dates_input, list) or not dates_input:
            return insufficient("At least one decision date is required.")

        if not isinstance(assets, list) or not assets:
            return insufficient("At least one asset is required.")

        if not isinstance(filings, list):
            return insufficient("Filings must be a list.")

        if (
            any(not isinstance(a, str) or not a for a in assets)
            or len(set(assets)) != len(assets)
        ):
            return insufficient("Assets must be unique, nonempty strings.")

        decision_dates = [parse_date(d) for d in dates_input]

        if any(
            decision_dates[i] <= decision_dates[i - 1]
            for i in range(1, len(decision_dates))
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n_assets = len(assets)
        asset_index = {asset: i for i, asset in enumerate(assets)}

        # Each event contains:
        # (inferred_public_date, report_period, version,
        #  asset_index, weight_pct)
        events = []

        seen_row_ids = set()
        seen_versions = set()

        for row in filings:
            if not isinstance(row, dict):
                raise ValueError("Each filing must be a dictionary.")

            row_id = row["row_id"]
            asset = row["asset"]
            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])
            version = row["version"]
            weight_pct = row["weight_pct"]

            if not isinstance(row_id, str) or not row_id:
                raise ValueError("Invalid filing row_id.")

            if row_id in seen_row_ids:
                raise ValueError("Duplicate filing row_id.")

            seen_row_ids.add(row_id)

            if asset not in asset_index:
                raise ValueError("Filing references an unknown asset.")

            if (
                isinstance(version, bool)
                or not isinstance(version, int)
                or version < 0
            ):
                raise ValueError(
                    "Filing versions must be nonnegative integers."
                )

            if (
                isinstance(weight_pct, bool)
                or not isinstance(weight_pct, (int, float))
            ):
                raise ValueError("weight_pct must be numeric.")

            weight_pct = float(weight_pct)

            if not isfinite(weight_pct):
                raise ValueError("weight_pct must be finite.")

            if filing_date < period_end:
                raise ValueError(
                    "A filing cannot precede its report period."
                )

            version_key = (asset, period_end, version)

            if version_key in seen_versions:
                raise ValueError(
                    "Ambiguous duplicate asset/period/version."
                )

            seen_versions.add(version_key)

            # Form N-PORT's historical public-disclosure delay:
            # third-month information is public no earlier than
            # 60 calendar days after the fiscal quarter ends.
            regulatory_public_date = period_end + timedelta(days=60)

            # A late filing cannot be observed before it is filed.
            inferred_public_date = max(
                regulatory_public_date,
                filing_date
            )

            events.append((
                inferred_public_date,
                period_end,
                version,
                asset_index[asset],
                weight_pct
            ))

        # Filings are unordered. Sort by inferred availability,
        # not by row_id, report period alone, or version alone.
        events.sort()

        # Before any applicable observation, use equal-weight holdings.
        equal_weight_pct = 100.0 / n_assets

        current_levels = [equal_weight_pct] * n_assets

        # The state key prioritizes report period, then version.
        # Therefore a late amendment to an older report cannot
        # overwrite an already available newer report.
        current_keys = [(date.min, -1)] * n_assets

        weights = []
        event_position = 0

        for decision_day in decision_dates:

            # Strict inequality prevents using filings/publications
            # dated on the decision day when their intraday
            # availability is unknown.
            while (
                event_position < len(events)
                and events[event_position][0] < decision_day
            ):
                (
                    public_date,
                    period_end,
                    version,
                    index,
                    weight_pct
                ) = events[event_position]

                candidate_key = (period_end, version)

                if candidate_key > current_keys[index]:
                    current_keys[index] = candidate_key
                    current_levels[index] = weight_pct

                event_position += 1

            # Cross-sectional centering.
            mean_level = fsum(current_levels) / n_assets

            centered = [
                level - mean_level
                for level in current_levels
            ]

            # Correct floating-point summation residual so that
            # the unnormalized signal is market-neutral.
            if n_assets > 1:
                centered[-1] = -fsum(centered[:-1])

            gross = fsum(abs(value) for value in centered)

            if gross == 0.0:
                row_weights = [0.0] * n_assets

            else:
                # A slightly upward-rounded denominator avoids
                # accidental gross exposure above one.
                denominator = nextafter(gross, inf)

                row_weights = [
                    float(value / denominator)
                    for value in centered
                ]

                # Remove floating-point net-exposure residual.
                if n_assets > 1:
                    row_weights[-1] = -fsum(row_weights[:-1])

                # Guard the gross-exposure limit after correction.
                actual_gross = fsum(
                    abs(value) for value in row_weights
                )

                if actual_gross > 1.0:
                    scale = nextafter(actual_gross, inf)

                    row_weights = [
                        float(value / scale)
                        for value in row_weights
                    ]

            weights.append(row_weights)

        return {
            "status": "assumption",
            "reason": (
                "Point-in-time alignment uses the later of SEC filing "
                "date and report period end plus 60 calendar days. "
                "Same-day records are excluded because publication "
                "times are unknown. For each asset, the newest "
                "available period and highest available version apply. "
                "Missing observations use equal-weight levels. "
                "Weights are decided at date-end for next-session "
                "open-to-close execution by the independent evaluator; "
                "close prices are not used in the signal."
            ),
            "weights": weights
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(f"Invalid or insufficient input: {exc}")
