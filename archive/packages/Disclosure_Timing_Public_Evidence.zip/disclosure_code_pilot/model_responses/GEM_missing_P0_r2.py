import datetime

def build_strategy(payload):
    """
    Constructs a holdings-based portfolio signal evaluating N-PORT data.
    """
    dates = payload.get("dates", [])
    assets = payload.get("assets", [])
    filings = payload.get("filings", [])

    if not dates or not assets:
        return {
            "status": "insufficient_data",
            "reason": "Missing required dates or assets arrays.",
            "weights": []
        }

    # Group filings by asset
    filings_by_asset = {asset: [] for asset in assets}

    for f in filings:
        asset = f.get("asset")
        if asset not in filings_by_asset:
            continue
            
        period_end_str = f.get("period_end")
        weight_pct = f.get("weight_pct")
        
        if period_end_str and weight_pct is not None:
            period_end = datetime.date.fromisoformat(period_end_str)
            # Under the SEC regime for 2022-2023, public portions of third-month 
            # N-PORT filings are subjected to a 60-day delay post period-end.
            observable_date = period_end + datetime.timedelta(days=60)
            filings_by_asset[asset].append((period_end, observable_date, weight_pct))

    # Sort each asset's filings chronologically by period_end to ensure we 
    # iterate and overwrite with the most recent applicable version.
    for asset in assets:
        filings_by_asset[asset].sort(key=lambda x: x[0])

    n_assets = len(assets)
    # The default weight before any applicable observation is the equal-weight 
    # level in percentage points, matching the `weight_pct` scale.
    equal_weight_pct = 100.0 / n_assets
    weights = []

    for date_str in dates:
        d_date = datetime.date.fromisoformat(date_str)
        raw_w = []

        # 1. Form the asset vector point-in-time
        for asset in assets:
            current_weight = equal_weight_pct
            for period_end, observable_date, w in filings_by_asset[asset]:
                if observable_date <= d_date:
                    current_weight = w
            raw_w.append(current_weight)

        # 2. Subtract the cross-sectional mean (Net exposure = 0)
        mean_w = sum(raw_w) / n_assets
        centered_w = [w - mean_w for w in raw_w]

        # 3. Normalize absolute weights to sum to one (Gross exposure = 1)
        abs_sum = sum(abs(w) for w in centered_w)
        
        if abs_sum > 1e-9:
            final_w = [w / abs_sum for w in centered_w]
        else:
            # Return cash if the centered vector is practically zero
            final_w = [0.0] * n_assets

        weights.append(final_w)

    return {
        "status": "assumption",
        "reason": "Applied a standard 60-day SEC reporting lag to period_end to model public N-PORT availability and avoid look-ahead bias.",
        "weights": weights
    }

