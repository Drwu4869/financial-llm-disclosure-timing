import datetime

def build_strategy(payload: dict) -> dict:
    """
    Builds a holdings-based portfolio signal from historical N-PORT filings.
    """
    dates = payload.get('dates', [])
    assets = payload.get('assets', [])
    filings = payload.get('filings', [])
    
    if not dates or not assets:
        return {
            'status': 'insufficient_data',
            'reason': 'Missing dates or assets in the payload.',
            'weights': []
        }
        
    n_assets = len(assets)
    # Assume equal weight is scaled to percentage points like the filing weights (e.g., 100% / N)
    equal_weight = 100.0 / n_assets
    
    # Pre-process filings
    # Assumption: Form N-PORT data becomes publicly available 60 days after the period_end 
    # (consistent with the 2022-2023 SEC reporting regime for the third-fiscal-month).
    asset_filings = {a: [] for a in assets}
    
    for f in filings:
        asset = f.get('asset')
        if asset in asset_filings:
            p_end = datetime.datetime.strptime(f['period_end'], '%Y-%m-%d').date()
            # Calculate the date the filing is public and usable
            pub_date = p_end + datetime.timedelta(days=60)
            asset_filings[asset].append({
                'pub_date': pub_date,
                'period_end': p_end,
                'weight': f['weight_pct']
            })
            
    # Sort filings chronologically by period_end to always find the most recent
    for a in assets:
        asset_filings[a].sort(key=lambda x: x['period_end'])
        
    weights_matrix = []
    
    for d_str in dates:
        d = datetime.datetime.strptime(d_str, '%Y-%m-%d').date()
        raw_vector = []
        
        for a in assets:
            applicable_weight = equal_weight
            best_p_end = None
            
            # Find the most recent report period available on or before the decision date
            for filing in asset_filings[a]:
                if filing['pub_date'] <= d:
                    if best_p_end is None or filing['period_end'] > best_p_end:
                        best_p_end = filing['period_end']
                        applicable_weight = filing['weight']
                        
            raw_vector.append(applicable_weight)
            
        # Cross-sectional demean
        mean_weight = sum(raw_vector) / n_assets
        centered_vector = [w - mean_weight for w in raw_vector]
        
        # Normalize absolute weights to sum to one (L1 normalization)
        abs_sum = sum(abs(w) for w in centered_vector)
        
        if abs_sum > 1e-9:
            final_weights = [w / abs_sum for w in centered_vector]
        else:
            # Return cash (all zeros) when the centered vector is zero
            final_weights = [0.0] * n_assets
            
        weights_matrix.append(final_weights)
        
    return {
        'status': 'ok',
        'reason': 'Assumed a 60-day lag from period_end to account for the Form N-PORT public publication delay under the 2022-2023 SEC regime.',
        'weights': weights_matrix
    }

