from typing import Any, Dict, List

def build_strategy(payload: Dict[str, Any]) -> Dict[str, Any]:
    dates: List[str] = payload.get('dates', [])
    assets: List[str] = payload.get('assets', [])
    filings: List[Dict[str, Any]] = payload.get('filings', [])

    # Check for missing filing dates to prevent lookahead / leakage
    for f in filings:
        if 'filing_date' not in f or not f['filing_date']:
            return {
                'status': 'insufficient_data',
                'reason': 'Exact historical alignment cannot be established from these inputs due to absent filing dates.',
                'weights': []
            }

    num_assets = len(assets)
    weights: List[List[float]] = []

    if num_assets == 0:
        return {
            'status': 'ok',
            'reason': 'No assets provided in the universe to form a portfolio.',
            'weights': [[] for _ in dates]
        }

    equal_weight = 1.0 / num_assets
    
    # Pre-group filings by asset to optimize point-in-time lookups
    filings_by_asset: Dict[str, List[Dict[str, Any]]] = {a: [] for a in assets}
    for f in filings:
        if f.get('asset') in filings_by_asset:
            filings_by_asset[f['asset']].append(f)

    # Process each decision day
    for date in dates:
        raw_weights: List[float] = []
        
        for asset in assets:
            # Filter filings available strictly on or before the decision day
            valid_filings = [f for f in filings_by_asset[asset] if f['filing_date'] <= date]
            
            if not valid_filings:
                # Before any applicable observation, use the equal-weight level
                raw_weights.append(equal_weight)
            else:
                # Most recent report period first, then applicable max version
                valid_filings.sort(key=lambda x: (x['period_end'], x.get('version', 0)), reverse=True)
                best_filing = valid_filings[0]
                # Convert percentage to decimal format
                raw_weights.append(best_filing['weight_pct'] / 100.0)

        # Subtract the cross-sectional mean (Net exposure = 0)
        mean_weight = sum(raw_weights) / num_assets
        centered = [w - mean_weight for w in raw_weights]
        
        # Normalize absolute weights to sum to one (Gross exposure = 1.0)
        abs_sum = sum(abs(c) for c in centered)
        
        # Return cash (all zeros) if the centered vector is zero
        if abs_sum < 1e-12:
            final_weights = [0.0] * num_assets
        else:
            final_weights = [c / abs_sum for c in centered]
            
        weights.append(final_weights)

    return {
        'status': 'ok',
        'reason': 'Point-in-time weights successfully constructed using applicable filing dates and versions.',
        'weights': weights
    }

