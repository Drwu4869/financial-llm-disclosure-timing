def build_strategy(payload: dict) -> dict:
    dates = payload.get('dates', [])
    assets = payload.get('assets', [])
    filings = payload.get('filings', [])
    
    if not dates or not assets:
        return {
            'status': 'insufficient_data',
            'reason': 'Missing dates or assets in the payload.',
            'weights': []
        }
        
    num_assets = len(assets)
    # Using 100.0 / num_assets because weight_pct is generally on a 0-100 scale.
    # The scale is ultimately irrelevant due to mean-centering and L1 normalization,
    # but aligning with the percentage scale avoids relative distortion.
    equal_weight = 100.0 / num_assets
    
    # Pre-group filings by asset for faster lookup
    filings_by_asset = {asset: [] for asset in assets}
    for f in filings:
        asset_name = f.get('asset')
        if asset_name in filings_by_asset:
            filings_by_asset[asset_name].append({
                'period_end': f['period_end'],
                'filing_date': f['filing_date'],
                'weight_pct': float(f['weight_pct'])
            })
            
    weights_out = []
    
    for d in dates:
        raw_vector = []
        
        for asset in assets:
            # Filter filings available on or before the decision date
            valid_filings = [
                f for f in filings_by_asset[asset] 
                if f['filing_date'] <= d
            ]
            
            if not valid_filings:
                # Before any applicable observation, use the equal-weight level
                raw_vector.append(equal_weight)
            else:
                # Most recent report period and applicable version (latest filing_date for that period)
                best_filing = max(
                    valid_filings, 
                    key=lambda x: (x['period_end'], x['filing_date'])
                )
                raw_vector.append(best_filing['weight_pct'])
                
        # Subtract the cross-sectional mean
        cross_sectional_mean = sum(raw_vector) / num_assets
        centered_vector = [val - cross_sectional_mean for val in raw_vector]
        
        # Normalize absolute weights to sum to one (L1 normalization)
        sum_abs_weights = sum(abs(val) for val in centered_vector)
        
        if sum_abs_weights > 1e-12:
            normalized_vector = [val / sum_abs_weights for val in centered_vector]
        else:
            # Return cash (vector of zeros) when the centered vector is zero
            normalized_vector = [0.0 for _ in range(num_assets)]
            
        weights_out.append(normalized_vector)
        
    return {
        'status': 'ok',
        'reason': 'Cross-sectional mean-reverting weights successfully built using Point-in-Time N-PORT filings.',
        'weights': weights_out
    }

