from datetime import date
from bisect import bisect_right
from math import fsum, isfinite


def build_strategy(payload):
    """
    Construct a point-in-time, holdings-based, market-neutral portfolio.

    Rules
    -----
    1. Use only publicly filed third-fiscal-month N-PORT observations.
    2. Because filing times are unavailable, a filing becomes eligible
       on decision dates strictly after its filing_date.
    3. For each asset, select the latest eligible report period.
       Within that period, select the latest eligible revision.
    4. Before an asset has any eligible observation, use 100 / N
       as its weight_pct level.
    5. Center the cross-sectional holdings vector and normalize it
       to unit gross exposure with zero net exposure.
    6. Return cash (all-zero weights) when the vector is constant.
    7. Use synthetic price dates only to verify session alignment.
       Never use price values to construct or optimize the signal.

    Returns
    -------
    {
        "status": "ok" | "assumption" | "insufficient_data",
        "reason": str,
        "weights": list[list[float]]
    }

    Weights correspond to input decision dates and asset order.
    Each decision is made at the end of its date and is intended
    for execution at the next synthetic session's open, followed
    by liquidation at that session's close.

    The independent evaluator is responsible for trade returns.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Date must be an ISO YYYY-MM-DD string.")

        try:
            result = date.fromisoformat(value)
        except (ValueError, TypeError):
            raise ValueError("Invalid date: {!r}".format(value))

        if result.isoformat() != value:
            raise ValueError("Noncanonical ISO date: {!r}".format(value))

        return result

    def finite_number(value):
        if isinstance(value, bool) or not isinstance(
            value, (int, float)
        ):
            raise ValueError("Expected a finite numeric value.")

        try:
            number = float(value)
        except (OverflowError, ValueError):
            raise ValueError("Numeric value cannot be represented.")

        if not isfinite(number):
            raise ValueError("Nonfinite numeric value.")

        return number

    def neutralize(levels):
        """
        Construct a dollar-neutral, unit-gross vector.

        Separately normalizing the positive and negative sides
        to 0.5 improves numerical neutrality.

        Scaling before centering avoids overflow for very large
        but finite input values.
        """
        n = len(levels)

        if n == 0:
            return []

        if all(x == levels[0] for x in levels):
            return [0.0] * n

        scale = max(abs(x) for x in levels)

        if scale == 0.0:
            return [0.0] * n

        scaled = [x / scale for x in levels]
        mean = fsum(scaled) / n

        centered = [x - mean for x in scaled]

        positive_sum = fsum(
            x for x in centered if x > 0.0
        )

        negative_sum = fsum(
            -x for x in centered if x < 0.0
        )

        if positive_sum <= 0.0 or negative_sum <= 0.0:
            return [0.0] * n

        weights = []

        for x in centered:
            if x > 0.0:
                weights.append(0.5 * x / positive_sum)
            elif x < 0.0:
                weights.append(0.5 * x / negative_sum)
            else:
                weights.append(0.0)

        # Correct any residual floating-point net exposure.
        residual = fsum(weights)

        if residual != 0.0:
            index = max(
                range(n),
                key=lambda i: abs(weights[i])
            )
            weights[index] -= residual

        # Protect the gross-exposure constraint against rounding.
        gross = fsum(abs(x) for x in weights)

        if gross > 1.0:
            weights = [x / gross for x in weights]

        return weights

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        assets = payload.get("assets")
        dates_raw = payload.get("dates")
        filings = payload.get("filings")
        prices = payload.get("prices")

        if not isinstance(assets, (list, tuple)) or not assets:
            return insufficient("A nonempty asset universe is required.")

        if any(
            not isinstance(a, str) or not a
            for a in assets
        ):
            return insufficient("Asset identifiers must be strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        if not isinstance(dates_raw, (list, tuple)) or not dates_raw:
            return insufficient("Decision dates are required.")

        if not isinstance(filings, (list, tuple)):
            return insufficient("Filings must be a list.")

        if not isinstance(prices, (list, tuple)) or not prices:
            return insufficient("Synthetic session prices are required.")

        n_assets = len(assets)
        asset_index = {
            asset: i for i, asset in enumerate(assets)
        }

        # ----------------------------------------------------------
        # Validate decision dates.
        # ----------------------------------------------------------

        decision_dates = [
            parse_date(value) for value in dates_raw
        ]

        if any(
            decision_dates[i] >= decision_dates[i + 1]
            for i in range(len(decision_dates) - 1)
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        # ----------------------------------------------------------
        # Validate the synthetic session list.
        #
        # No weekday, holiday, or exchange-calendar assumptions.
        # Price magnitudes never influence portfolio construction.
        # ----------------------------------------------------------

        session_dates = []
        seen_sessions = set()

        for record in prices:
            if not isinstance(record, dict):
                return insufficient("Invalid price record.")

            session = parse_date(record.get("date"))

            if session in seen_sessions:
                return insufficient(
                    "Duplicate synthetic session date."
                )

            seen_sessions.add(session)
            session_dates.append(session)

            closes = record.get("close")

            if closes is None:
                closes = record.get("closes")

            if closes is None:
                closes = record.get("close_prices")

            if not isinstance(closes, (list, tuple)):
                return insufficient(
                    "Each price record requires a close-price vector."
                )

            if len(closes) != n_assets:
                return insufficient(
                    "Close-price vector length does not match assets."
                )

            for value in closes:
                if finite_number(value) <= 0.0:
                    return insufficient(
                        "Close prices must be finite and positive."
                    )

        session_dates.sort()

        # Every decision must occur on a supplied session and
        # must have a subsequent synthetic execution session.
        for decision in decision_dates:
            if decision not in seen_sessions:
                return insufficient(
                    "A decision date is absent from the synthetic "
                    "session list."
                )

            next_index = bisect_right(session_dates, decision)

            if next_index >= len(session_dates):
                return insufficient(
                    "A decision has no subsequent execution session."
                )

        # ----------------------------------------------------------
        # Validate and consolidate filing versions.
        #
        # Key = (asset, report period, filing date).
        #
        # row_id is an opaque identifier, not a chronological key.
        # Conflicting same-date versions cannot be ordered without
        # intraday timestamps, so they are rejected.
        # ----------------------------------------------------------

        versions = {}
        seen_row_ids = set()

        for record in filings:
            if not isinstance(record, dict):
                return insufficient("Invalid filing record.")

            row_id = record.get("row_id")
            asset = record.get("asset")

            if not isinstance(row_id, str) or not row_id:
                return insufficient("Invalid filing row_id.")

            if row_id in seen_row_ids:
                return insufficient("Duplicate filing row_id.")

            seen_row_ids.add(row_id)

            if asset not in asset_index:
                return insufficient(
                    "A filing references an unknown asset."
                )

            period_end = parse_date(record.get("period_end"))
            filing_date = parse_date(record.get("filing_date"))
            weight_pct = finite_number(record.get("weight_pct"))

            if filing_date < period_end:
                return insufficient(
                    "A filing date precedes its holdings period."
                )

            key = (asset, period_end, filing_date)

            if key in versions:
                if versions[key] != weight_pct:
                    return insufficient(
                        "Conflicting versions for the same asset, "
                        "period, and filing date cannot be ordered."
                    )
            else:
                versions[key] = weight_pct

        # ----------------------------------------------------------
        # Create chronological public-availability events.
        #
        # Third-fiscal-month N-PORT records under the specified
        # reporting regime are public upon SEC filing.
        #
        # The filing date, not the holdings period end, is the
        # information-availability boundary.
        #
        # With no intraday filing timestamps, records filed on
        # the decision date are conservatively excluded.
        # ----------------------------------------------------------

        events = sorted(
            (
                filing_date,
                period_end,
                asset_index[asset],
                weight_pct
            )
            for (asset, period_end, filing_date), weight_pct
            in versions.items()
        )

        # Detect whether the missing intraday times produce an
        # actual same-day information-timing assumption.
        decision_date_set = set(decision_dates)

        same_day_ambiguity = any(
            filing_date in decision_date_set
            for filing_date, _, _, _ in events
        )

        # ----------------------------------------------------------
        # Walk decision dates and availability events once.
        #
        # latest[i] = (period_end, filing_date, weight_pct)
        #
        # Comparing (period_end, filing_date) ensures that an
        # amendment to an older period never supersedes a newer
        # eligible period for the same asset.
        # ----------------------------------------------------------

        latest = [None] * n_assets

        baseline = 100.0 / n_assets
        weights_by_date = []

        event_index = 0
        event_count = len(events)

        for decision in decision_dates:

            while (
                event_index < event_count
                and events[event_index][0] < decision
            ):
                filing_date, period_end, i, weight_pct = (
                    events[event_index]
                )

                current = latest[i]
                candidate_key = (period_end, filing_date)

                if (
                    current is None
                    or candidate_key > (current[0], current[1])
                ):
                    latest[i] = (
                        period_end,
                        filing_date,
                        weight_pct
                    )

                event_index += 1

            # Construct asset levels in the original column order.
            levels = [
                baseline if observation is None else observation[2]
                for observation in latest
            ]

            # Center and normalize, or use cash.
            row = neutralize(levels)

            # Defensive numerical checks.
            if len(row) != n_assets:
                return insufficient("Invalid output vector length.")

            if not all(isfinite(x) for x in row):
                return insufficient("Nonfinite portfolio weight.")

            gross = fsum(abs(x) for x in row)
            net = fsum(row)

            if gross > 1.0 + 1e-12:
                return insufficient(
                    "Portfolio gross exposure exceeds one."
                )

            if abs(net) > 1e-12:
                return insufficient(
                    "Portfolio is not sufficiently dollar-neutral."
                )

            weights_by_date.append(row)

        # ----------------------------------------------------------
        # Output.
        #
        # No trading returns are calculated. In particular,
        # previous close-to-close returns are not substitutes for
        # the next-session open-to-close returns required by the
        # independent evaluator.
        # ----------------------------------------------------------

        if same_day_ambiguity:
            status = "assumption"
            timing_reason = (
                "Same-day SEC filings are excluded because "
                "intraday publication times are unavailable."
            )
        else:
            status = "ok"
            timing_reason = (
                "No decision requires resolving an intraday "
                "SEC filing-time ambiguity."
            )

        reason = (
            "Point-in-time holdings alignment uses filing_date "
            "strictly before each end-of-day decision, selecting "
            "the latest eligible report period and revision for "
            "each asset. Missing observations use the equal-weight "
            "percentage level. Centered holdings are normalized "
            "to zero net and at most unit gross exposure; constant "
            "vectors produce cash. Synthetic price dates establish "
            "next-session execution alignment only; the independent "
            "evaluator computes next-open-to-close returns. "
            + timing_reason
        )

        return {
            "status": status,
            "reason": reason,
            "weights": weights_by_date
        }

    except (ValueError, TypeError, KeyError, OverflowError) as exc:
        return insufficient(str(exc))
