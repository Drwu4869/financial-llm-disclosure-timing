def build_strategy(payload: dict) -> dict:
    """
    Evaluates a holdings-based portfolio signal using Form N-PORT filings.
    """
    dates = payload.get('dates', [])
    assets = payload.get('assets', [])
    filings = payload.get('filings', [])
    
    # Check for the existence of filing_date to ensure point-in-time accuracy
    if any('filing_date' not in f for f in filings):
        return {
            'status': 'insufficient_data',
            'reason': 'exact historical alignment cannot be established from these inputs'
        }
        
    # Pre-group filings by asset to optimize the daily lookups
    filings_by_asset = {asset: [] for asset in assets}
    for f in filings:
        asset_name = f.get('asset')
        if asset_name in filings_by_asset:
            filings_by_asset[asset_name].append(f)
            
    n_assets = len(assets)
    if n_assets == 0:
        return {
            'status': 'ok',
            'reason': 'No assets in universe',
            'weights': [[] for _ in dates]
        }
        
    default_weight = 1.0 / n_assets
    weights_matrix = []
    
    for decision_date in dates:
        row_weights = []
        
        # 1. Determine point-in-time pre-centered weights
        for asset in assets:
            # Only consider filings publicly available on or before the decision date
            known_filings = [f for f in filings_by_asset[asset] if f['filing_date'] <= decision_date]
            
            if not known_filings:
                # Before any applicable observation use the equal-weight level
                row_weights.append(default_weight)
            else:
                # Most recent report period
                max_period_end = max(f['period_end'] for f in known_filings)
                recent_period_filings = [f for f in known_filings if f['period_end'] == max_period_end]
                
                # Most applicable version within that report period
                best_filing = max(recent_period_filings, key=lambda x: x.get('version', 0))
                
                # Convert weight_pct to a decimal fraction
                row_weights.append(best_filing.get('weight_pct', 0.0) / 100.0)
                
        # 2. Subtract cross-sectional mean
        mean_w = sum(row_weights) / n_assets
        centered = [w - mean_w for w in row_weights]
        
        # 3. Normalize absolute weights to sum to one
        sum_abs = sum(abs(c) for c in centered)
        
        if sum_abs < 1e-9:
            # Return cash (vector of zeros) when the centered vector is zero
            weights_matrix.append([0.0] * n_assets)
        else:
            weights_matrix.append([c / sum_abs for c in centered])
            
    return {
        'status': 'ok',
        'reason': 'Successfully calculated point-in-time normalized weights.',
        'weights': weights_matrix
    }

