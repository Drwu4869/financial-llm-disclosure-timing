from typing import Dict, Any, List

def build_strategy(payload: Dict[str, Any]) -> Dict[str, Any]:
    dates: List[str] = payload.get('dates', [])
    assets: List[str] = payload.get('assets', [])
    filings: List[Dict[str, Any]] = payload.get('filings', [])

    # Ensure all filings have an actual filing date; do not invent dates if missing
    for f in filings:
        if not f.get('filing_date'):
            return {
                'status': 'insufficient_data',
                'reason': 'exact historical alignment cannot be established from these inputs',
                'weights': []
            }

    num_assets = len(assets)
    if num_assets == 0:
        return {
            'status': 'ok',
            'reason': 'No assets provided.',
            'weights': [[0.0] * 0 for _ in dates]
        }

    # Before any applicable observation, use equal-weight level natively scaled to percentages
    ew_level = 100.0 / num_assets
    
    # Pre-group filings by asset for efficient temporal lookup
    filings_by_asset: Dict[str, List[Dict[str, Any]]] = {a: [] for a in assets}
    for f in filings:
        asset_id = f.get('asset')
        if asset_id in filings_by_asset:
            filings_by_asset[asset_id].append(f)

    weights: List[List[float]] = []
    
    for d in dates:
        day_vector: List[float] = []
        
        for a in assets:
            # Filter to filings available on or before the decision date
            available = [f for f in filings_by_asset[a] if f['filing_date'] <= d]
            
            if not available:
                day_vector.append(ew_level)
            else:
                # Best filing matches the most recent report period.
                # In case of revisions for the same period, pick the one with the latest filing date.
                # ISO dates allow for direct lexicographical string comparison.
                best_filing = max(available, key=lambda x: (x['period_end'], x['filing_date']))
                day_vector.append(best_filing.get('weight_pct', ew_level))

        # 1. Subtract the cross-sectional mean (guarantees net exposure is zero)
        mu = sum(day_vector) / num_assets
        centered = [v - mu for v in day_vector]
        
        # 2. Normalize absolute weights to sum to one (guarantees gross exposure is exactly one)
        abs_sum = sum(abs(c) for c in centered)
        
        if abs_sum < 1e-12:
            # Return cash (zeros) when the centered vector is zero
            weights.append([0.0] * num_assets)
        else:
            weights.append([c / abs_sum for c in centered])

    return {
        'status': 'ok',
        'reason': 'Successfully aligned point-in-time filing dates with decision days.',
        'weights': weights
    }

