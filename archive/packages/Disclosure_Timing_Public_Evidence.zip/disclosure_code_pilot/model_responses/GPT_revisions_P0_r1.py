from datetime import date, timedelta
from math import fsum, isfinite
import re


def build_strategy(payload):
    """
    Construct point-in-time, market-neutral portfolio weights from
    public third-fiscal-month Form N-PORT holdings.

    Disclosure convention (2022-2023 regime):
      - Third-fiscal-month reports become publicly available no earlier
        than 60 calendar days after the report period ends.
      - A filing or revision cannot be used before its SEC filing date.
      - With date-only timestamps, assume information is available by
        the end of its public-availability date.

    For each asset and decision date:
      - Select the latest publicly applicable report period.
      - Within that period, select the highest applicable version.
      - Use 100 / number_of_assets when no observation is applicable.

    Center the resulting vector and normalize to unit gross exposure.
    A zero centered vector produces an all-cash portfolio.

    Returned rows correspond to decision dates, NOT execution dates.
    The independent evaluator applies each row to the next session's
    open-to-close return. Prices are never used to construct signals.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO date strings.")
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value) is None:
            raise ValueError("Dates must use YYYY-MM-DD.")
        return date.fromisoformat(value)

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        assets = payload["assets"]
        dates = payload["dates"]
        filings = payload["filings"]

        if not isinstance(assets, (list, tuple)) or not assets:
            return insufficient("At least one asset is required.")

        if any(
            not isinstance(asset, str) or not asset
            for asset in assets
        ):
            return insufficient("Asset identifiers must be nonempty strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        if not isinstance(dates, (list, tuple)) or not dates:
            return insufficient("At least one decision date is required.")

        if not isinstance(filings, (list, tuple)):
            return insufficient("Filings must be a sequence.")

        decision_dates = [parse_date(d) for d in dates]

        if any(
            decision_dates[i] >= decision_dates[i + 1]
            for i in range(len(decision_dates) - 1)
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n = len(assets)
        asset_index = {
            asset: i for i, asset in enumerate(assets)
        }

        equal_weight_pct = 100.0 / n

        # Each event:
        # (public_availability_date, report_period, version,
        #  asset_column, weight_pct)
        events = []

        seen_row_ids = set()
        seen_versions = set()

        for row in filings:
            if not isinstance(row, dict):
                return insufficient("Each filing must be a dictionary.")

            asset = row["asset"]
            row_id = row["row_id"]
            period = parse_date(row["period_end"])
            filed = parse_date(row["filing_date"])
            version = row["version"]
            raw_weight = row["weight_pct"]

            if asset not in asset_index:
                return insufficient(
                    "A filing references an asset outside the universe."
                )

            if not isinstance(row_id, str) or not row_id:
                return insufficient("Invalid filing row_id.")

            if row_id in seen_row_ids:
                return insufficient("Duplicate filing row_id.")

            seen_row_ids.add(row_id)

            if (
                isinstance(version, bool)
                or not isinstance(version, int)
                or version < 0
            ):
                return insufficient(
                    "Filing versions must be nonnegative integers."
                )

            if isinstance(raw_weight, bool):
                return insufficient("Invalid holdings percentage.")

            weight = float(raw_weight)

            if not isfinite(weight):
                return insufficient(
                    "Holdings percentages must be finite."
                )

            version_key = (asset, period, version)

            if version_key in seen_versions:
                return insufficient(
                    "Ambiguous duplicate version for an asset/report period."
                )

            seen_versions.add(version_key)

            if filed < period:
                return insufficient(
                    "A filing date precedes its holdings period."
                )

            # N-PORT third-fiscal-month public-disclosure rule.
            # The 60-day restriction is measured in calendar days,
            # not exchange sessions or from the filing date.
            public_date = max(
                filed,
                period + timedelta(days=60),
            )

            events.append((
                public_date,
                period,
                version,
                asset_index[asset],
                weight,
            ))

        # Filing input order and row_id never determine precedence.
        events.sort()

        # Maintain the best currently applicable observation per asset.
        # Report period has precedence over version:
        # a revision to an old period cannot replace a newer period.
        best_keys = [None] * n
        current_levels = [equal_weight_pct] * n

        weights = []
        event_index = 0
        same_day_availability_used = False

        for decision_day in decision_dates:

            # Decisions are at the end of the specified date.
            # The inclusive comparison assumes date-only public
            # disclosures are usable by that day's end.
            while (
                event_index < len(events)
                and events[event_index][0] <= decision_day
            ):
                public_day, period, version, col, value = (
                    events[event_index]
                )

                if public_day == decision_day:
                    same_day_availability_used = True

                candidate_key = (period, version)
                existing_key = best_keys[col]

                if (
                    existing_key is None
                    or candidate_key > existing_key
                ):
                    best_keys[col] = candidate_key
                    current_levels[col] = value

                event_index += 1

            # Cross-sectional demean.
            mean_level = fsum(current_levels) / n

            centered = [
                value - mean_level
                for value in current_levels
            ]

            gross = fsum(abs(value) for value in centered)

            if gross == 0.0:
                # Equal holdings levels imply no long/short signal.
                portfolio = [0.0] * n

            else:
                # Normalize centered holdings to unit gross exposure.
                portfolio = [
                    value / gross
                    for value in centered
                ]

                # Correct floating-point rounding in net exposure.
                residual = fsum(portfolio)

                if residual != 0.0:
                    largest = max(
                        range(n),
                        key=lambda i: abs(portfolio[i]),
                    )
                    portfolio[largest] -= residual

                # Guard against gross exposure exceeding one because
                # of floating-point rounding.
                actual_gross = fsum(
                    abs(value) for value in portfolio
                )

                if actual_gross > 1.0:
                    portfolio = [
                        value / actual_gross
                        for value in portfolio
                    ]

            weights.append(portfolio)

        if same_day_availability_used:
            status = "assumption"
            timing_note = (
                "Date-only disclosures are assumed available "
                "by the end of their public-availability date."
            )
        else:
            status = "ok"
            timing_note = (
                "No decision relies on a disclosure becoming "
                "available on that same date."
            )

        return {
            "status": status,
            "reason": (
                "Third-fiscal-month N-PORT holdings are eligible "
                "no earlier than the later of SEC filing date and "
                "60 calendar days after period end. "
                "Each asset uses its latest eligible report period "
                "and highest eligible version; unavailable assets "
                "use the equal-weight percentage. "
                "Weights are demeaned and gross-normalized, with "
                "zero exposure for a flat signal. "
                "Each row is formed at decision-day end for "
                "execution at the next synthetic session's open "
                "and liquidation at its close. "
                "Prices are not used to estimate signals or returns. "
                + timing_note
            ),
            "weights": weights,
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            f"Invalid or incomplete input: {exc}"
        )
