from datetime import date, timedelta
from math import fsum, isfinite, nextafter


def build_strategy(payload):
    """
    Build a point-in-time, holdings-based long/short portfolio signal.

    Assumptions
    -----------
    Under the 2022-2023 Form N-PORT reporting regime, third-fiscal-month
    reports were generally due 60 calendar days after fiscal quarter-end.

    Because actual filing/publication timestamps are unavailable, assume
    each report was publicly available by the end of that 60-day period.

    To avoid relying on an unknown intraday publication time, a report
    becomes eligible only on decision dates strictly later than
    period_end + 60 calendar days.

    This is an assumption, not proof of historical availability.
    Late filings, deadline extensions, and publication delays cannot
    be reconstructed from the supplied data.

    There is exactly one version per asset/report period. row_id is
    treated as an opaque identifier, never as a chronological key.

    Decisions are made at each supplied date's close. The independent
    evaluator handles execution at the next synthetic session's open
    and liquidation at that session's close.

    Prices are deliberately not used for signal construction.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")
        parsed = date.fromisoformat(value)
        if parsed.isoformat() != value:
            raise ValueError("Dates must use YYYY-MM-DD format.")
        return parsed

    if not isinstance(payload, dict):
        return insufficient("Payload must be a dictionary.")

    assets = payload.get("assets")
    dates = payload.get("dates")
    filings = payload.get("filings")

    if not isinstance(assets, (list, tuple)) or not assets:
        return insufficient("A nonempty asset list is required.")

    if any(not isinstance(a, str) or not a for a in assets):
        return insufficient("Asset identifiers must be nonempty strings.")

    if len(set(assets)) != len(assets):
        return insufficient("Asset identifiers must be unique.")

    if not isinstance(dates, (list, tuple)) or not dates:
        return insufficient("A nonempty decision-date list is required.")

    if not isinstance(filings, (list, tuple)):
        return insufficient("Filings must be a list of records.")

    try:
        decision_dates = [parse_date(d) for d in dates]
    except (ValueError, TypeError) as exc:
        return insufficient(f"Invalid decision date: {exc}")

    if any(
        decision_dates[i] <= decision_dates[i - 1]
        for i in range(1, len(decision_dates))
    ):
        return insufficient(
            "Decision dates must be strictly increasing."
        )

    n_assets = len(assets)
    asset_index = {asset: i for i, asset in enumerate(assets)}

    # Each entry is (eligibility_cutoff, period_end, weight_pct).
    reports = [[] for _ in assets]

    seen_row_ids = set()
    seen_asset_periods = set()

    try:
        for record in filings:
            if not isinstance(record, dict):
                raise ValueError("Each filing row must be a dictionary.")

            row_id = record["row_id"]
            asset = record["asset"]
            period_end = parse_date(record["period_end"])
            raw_weight = record["weight_pct"]

            if not isinstance(row_id, str) or not row_id:
                raise ValueError("row_id must be a nonempty string.")

            if row_id in seen_row_ids:
                raise ValueError("Duplicate row_id encountered.")
            seen_row_ids.add(row_id)

            if asset not in asset_index:
                raise ValueError(
                    f"Filing references an unknown asset: {asset!r}"
                )

            key = (asset, period_end)

            if key in seen_asset_periods:
                raise ValueError(
                    "Multiple versions for an asset/report period "
                    "cannot be ordered without publication timestamps."
                )
            seen_asset_periods.add(key)

            if (
                isinstance(raw_weight, bool)
                or not isinstance(raw_weight, (int, float))
            ):
                raise ValueError("weight_pct must be numeric.")

            weight_pct = float(raw_weight)

            if not isfinite(weight_pct):
                raise ValueError("weight_pct must be finite.")

            cutoff = period_end + timedelta(days=60)

            reports[asset_index[asset]].append(
                (cutoff, period_end, weight_pct)
            )

    except (KeyError, ValueError, TypeError, OverflowError) as exc:
        return insufficient(f"Invalid filing data: {exc}")

    # Filing input order and opaque row IDs have no chronological role.
    # Since every period uses the same 60-day lag, ordering by period_end
    # also orders the assumed eligibility cutoffs.
    for asset_reports in reports:
        asset_reports.sort(key=lambda item: item[1])

    # Before the first eligible observation, use equal-weight holdings
    # levels, expressed in percentage points.
    baseline = 100.0 / n_assets
    current_levels = [baseline] * n_assets

    # Each asset maintains its own latest eligible report period.
    cursors = [0] * n_assets
    output_weights = []

    for decision_day in decision_dates:

        # Update only from reports assumed public before this decision.
        # The cutoff day itself is excluded conservatively.
        for j in range(n_assets):
            asset_reports = reports[j]
            cursor = cursors[j]

            while (
                cursor < len(asset_reports)
                and asset_reports[cursor][0] < decision_day
            ):
                _, _, reported_weight = asset_reports[cursor]
                current_levels[j] = reported_weight
                cursor += 1

            cursors[j] = cursor

        # Equal holdings levels imply a zero cross-sectional signal.
        # This also handles the single-asset case.
        if all(
            level == current_levels[0]
            for level in current_levels
        ):
            output_weights.append([0.0] * n_assets)
            continue

        # Cross-sectional demeaning.
        mean_level = fsum(current_levels) / n_assets

        centered = [
            level - mean_level
            for level in current_levels
        ]

        gross_signal = fsum(abs(x) for x in centered)

        if gross_signal == 0.0:
            output_weights.append([0.0] * n_assets)
            continue

        # Normalize the absolute weights to unit gross exposure.
        weights = [
            x / gross_signal
            for x in centered
        ]

        # Correct floating-point net-exposure residuals.
        residual = fsum(weights)
        weights[-1] -= residual

        # Guard against floating-point gross exposure slightly above 1.
        gross = fsum(abs(w) for w in weights)

        if gross > 1.0:
            scale = nextafter(1.0 / gross, 0.0)
            weights = [w * scale for w in weights]

        output_weights.append(weights)

    return {
        "status": "assumption",
        "reason": (
            "Assumes timely public availability of third-month "
            "Form N-PORT reports within 60 calendar days after "
            "period_end; eligibility starts on decision dates "
            "strictly after that cutoff. Each asset uses its latest "
            "eligible report, or the equal-weight baseline if none "
            "exists. Actual publication dates cannot be verified; "
            "late filings and deadline extensions may invalidate "
            "point-in-time alignment. Prices are not used, and "
            "next-session execution and returns belong to the "
            "independent evaluator."
        ),
        "weights": output_weights,
    }
