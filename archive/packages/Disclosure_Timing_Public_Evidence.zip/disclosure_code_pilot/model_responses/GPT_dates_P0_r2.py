from datetime import date, timedelta
from math import fsum, isfinite


def build_strategy(payload):
    """
    Construct a point-in-time, holdings-based, dollar-neutral strategy.

    Information availability:
      - Third-fiscal-month Form N-PORT holdings become publicly
        available no earlier than 60 calendar days after period_end.
      - A record cannot be used before its SEC filing_date.
      - Because intraday publication times are unavailable, a record
        becomes eligible only on decision dates strictly later than
        both dates.

    Selection:
      - Select the latest eligible report period independently
        for each asset.
      - Within that period, select the latest eligible filing version.
      - Carry observations forward until superseded.
      - Use 100 / number_of_assets as the fallback level.

    Portfolio construction:
      - Subtract the cross-sectional mean.
      - Normalize gross absolute exposure to one.
      - Return all cash when the centered vector is zero.

    Prices are deliberately excluded from signal construction.
    Decisions are made at the end of each supplied decision date.
    Execution at the next synthetic session's open and liquidation
    at its close are responsibilities of the independent evaluator.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Dates must use YYYY-MM-DD format.")

        return parsed

    try:
        assets = payload["assets"]
        decision_dates_raw = payload["dates"]
        filings = payload["filings"]

        if not isinstance(assets, list) or not assets:
            return insufficient("Assets must be a nonempty list.")

        if any(not isinstance(a, str) for a in assets):
            return insufficient("Asset identifiers must be strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        if not isinstance(decision_dates_raw, list):
            return insufficient("Decision dates must be a list.")

        if not isinstance(filings, list):
            return insufficient("Filings must be a list.")

        decision_dates = [
            parse_date(d) for d in decision_dates_raw
        ]

        if any(
            decision_dates[i] >= decision_dates[i + 1]
            for i in range(len(decision_dates) - 1)
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        n_assets = len(assets)
        asset_index = {
            asset: i for i, asset in enumerate(assets)
        }

        fallback_level = 100.0 / n_assets

        # Each event is:
        # (earliest_public_date, period_end, filing_date,
        #  asset_index, weight_pct)
        #
        # row_id is intentionally not used for ordering:
        # it is an opaque identifier, not a timestamp.

        events = []
        seen_versions = {}

        for row in filings:
            if not isinstance(row, dict):
                return insufficient(
                    "Each filing must be a dictionary."
                )

            asset = row["asset"]

            if asset not in asset_index:
                return insufficient(
                    "A filing refers to an unknown asset."
                )

            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])

            raw_weight = row["weight_pct"]

            if (
                isinstance(raw_weight, bool)
                or not isinstance(raw_weight, (int, float))
            ):
                return insufficient(
                    "Filing weights must be numeric."
                )

            weight = float(raw_weight)

            if not isfinite(weight):
                return insufficient(
                    "Filing weights must be finite."
                )

            # Under the 2022-2023 third-month N-PORT regime,
            # public disclosure cannot precede the end of the
            # 60-calendar-day period following the report period.
            disclosure_date = period_end + timedelta(days=60)

            earliest_public_date = max(
                filing_date,
                disclosure_date,
            )

            idx = asset_index[asset]

            # Without intraday timestamps, conflicting versions
            # for the same asset, report period and filing date
            # cannot be chronologically resolved.
            version_key = (idx, period_end, filing_date)

            if version_key in seen_versions:
                if seen_versions[version_key] != weight:
                    return insufficient(
                        "Conflicting same-day filing versions "
                        "cannot be ordered without timestamps."
                    )
                continue

            seen_versions[version_key] = weight

            events.append(
                (
                    earliest_public_date,
                    period_end,
                    filing_date,
                    idx,
                    weight,
                )
            )

        # Sorting is independent of the original filing-row order.
        events.sort()

        # Current point-in-time observation for each asset.
        current_levels = [fallback_level] * n_assets

        # Track (period_end, filing_date) separately per asset.
        # A late amendment to an older period must not replace
        # a newer report period already available.
        current_versions = [None] * n_assets

        weights = []
        event_cursor = 0

        for decision_day in decision_dates:

            # Strict inequality excludes records becoming public
            # on the decision date itself. This prevents assuming
            # knowledge of their unknown intraday release times.
            while (
                event_cursor < len(events)
                and events[event_cursor][0] < decision_day
            ):
                (
                    public_date,
                    period_end,
                    filing_date,
                    idx,
                    weight,
                ) = events[event_cursor]

                candidate_version = (
                    period_end,
                    filing_date,
                )

                existing_version = current_versions[idx]

                if (
                    existing_version is None
                    or candidate_version > existing_version
                ):
                    current_versions[idx] = candidate_version
                    current_levels[idx] = weight

                event_cursor += 1

            # Cross-sectional centering.
            #
            # Scaling first improves numerical stability when
            # filing weights differ substantially in magnitude.
            max_abs_level = max(
                abs(x) for x in current_levels
            )

            if max_abs_level == 0.0:
                weights.append([0.0] * n_assets)
                continue

            scaled_levels = [
                x / max_abs_level
                for x in current_levels
            ]

            # Explicitly handle identical observations, including
            # the all-fallback case, as an all-cash position.
            if all(
                x == scaled_levels[0]
                for x in scaled_levels
            ):
                weights.append([0.0] * n_assets)
                continue

            cross_sectional_mean = (
                fsum(scaled_levels) / n_assets
            )

            centered = [
                x - cross_sectional_mean
                for x in scaled_levels
            ]

            # Correct residual floating-point centering error.
            residual = fsum(centered) / n_assets

            centered = [
                x - residual for x in centered
            ]

            gross = fsum(
                abs(x) for x in centered
            )

            if gross == 0.0:
                weights.append([0.0] * n_assets)
                continue

            portfolio = [
                x / gross for x in centered
            ]

            # Enforce dollar neutrality to floating-point precision.
            # The final component absorbs accumulated roundoff.
            if n_assets > 1:
                portfolio[-1] = -fsum(portfolio[:-1])

            # Recheck gross exposure after numerical correction.
            actual_gross = fsum(
                abs(x) for x in portfolio
            )

            if actual_gross > 1.0:
                portfolio = [
                    x / actual_gross
                    for x in portfolio
                ]

            # Convert negative zero to ordinary zero.
            portfolio = [
                0.0 if x == 0.0 else x
                for x in portfolio
            ]

            weights.append(portfolio)

        return {
            "status": "assumption",
            "reason": (
                "Uses the later of filing_date and period_end "
                "+ 60 calendar days for N-PORT public availability. "
                "Because intraday times are unknown, filings are "
                "eligible only on later decision dates. "
                "The latest eligible report period and revision "
                "are selected independently per asset, with "
                "equal-weight fallback and forward filling. "
                "Prices do not enter the signal; next-session "
                "execution and returns are evaluated separately."
            ),
            "weights": weights,
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            "Invalid or incomplete payload: " + str(exc)
        )
