from datetime import date, timedelta
import math


def build_strategy(payload):
    """
    Construct a point-in-time, holdings-based, dollar-neutral signal.

    Inputs
    ------
    payload = {
        "dates": ["YYYY-MM-DD", ...],
        "assets": ["Asset_01", ...],
        "filings": [
            {
                "row_id": str,
                "asset": str,
                "period_end": "YYYY-MM-DD",
                "filing_date": "YYYY-MM-DD",
                "version": int,
                "weight_pct": float
            },
            ...
        ],
        "prices": ...
    }

    Returns
    -------
    {
        "status": "ok" | "assumption" | "insufficient_data",
        "reason": str,
        "weights": [[float, ...], ...]
    }

    Alignment rules
    ---------------
    1. Treat third-fiscal-month Form N-PORT holdings as publicly
       available no earlier than 60 calendar days after period_end.

    2. A row's conservative availability date is the later of its
       filing_date and the 60-day disclosure date.

    3. Because intraday publication times are unavailable, a row
       becomes eligible only on decision dates strictly AFTER its
       availability date.

    4. For each asset, select the most recent eligible report period.
       Within that period, select the highest eligible version.

    5. Before an asset has an eligible observation, use the
       equal-weight holdings level of 100 / number_of_assets percent.

    6. Cross-sectionally demean holdings percentages and normalize
       by the sum of their absolute deviations. Return cash if all
       holdings levels are equal.

    7. Signal decisions occur at the end of each supplied decision
       date. The independent evaluator applies a decision's weights
       to the next synthetic session's open-to-close returns.

    8. Prices are deliberately not used to construct the signal.
       Close-only prices cannot establish next-session open-to-close
       returns, and those returns belong to the independent evaluator.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Date must be an ISO YYYY-MM-DD string.")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Date must use YYYY-MM-DD format.")

        return parsed

    # ------------------------------------------------------------
    # 1. Validate the input structure.
    # ------------------------------------------------------------

    if not isinstance(payload, dict):
        return insufficient("Payload must be a dictionary.")

    raw_dates = payload.get("dates")
    assets = payload.get("assets")
    filings = payload.get("filings")

    if not isinstance(raw_dates, (list, tuple)) or not raw_dates:
        return insufficient("At least one decision date is required.")

    if not isinstance(assets, (list, tuple)) or not assets:
        return insufficient("At least one asset is required.")

    if not isinstance(filings, (list, tuple)):
        return insufficient("Filings must be a list of records.")

    if any(not isinstance(a, str) or not a for a in assets):
        return insufficient("Asset identifiers must be nonempty strings.")

    if len(set(assets)) != len(assets):
        return insufficient("Asset identifiers must be unique.")

    try:
        decision_dates = [parse_date(d) for d in raw_dates]
    except (TypeError, ValueError) as exc:
        return insufficient(f"Invalid decision date: {exc}")

    if any(
        decision_dates[i] <= decision_dates[i - 1]
        for i in range(1, len(decision_dates))
    ):
        return insufficient(
            "Decision dates must be strictly increasing."
        )

    n_assets = len(assets)
    asset_index = {asset: i for i, asset in enumerate(assets)}

    # Holdings are percentages, so the neutral baseline is 100/n,
    # not 1/n.
    baseline = 100.0 / n_assets

    # ------------------------------------------------------------
    # 2. Validate and index filing observations.
    #
    # Each indexed record contains:
    # (availability_date, asset_index, period_end, version, weight_pct)
    #
    # row_id is validated for uniqueness but never used as a
    # chronological ordering key.
    # ------------------------------------------------------------

    observations = []
    seen_row_ids = set()
    seen_versions = set()

    required_fields = (
        "row_id",
        "asset",
        "period_end",
        "filing_date",
        "version",
        "weight_pct"
    )

    for row in filings:
        if not isinstance(row, dict):
            return insufficient("Every filing must be a dictionary.")

        if any(field not in row for field in required_fields):
            return insufficient("A filing is missing required fields.")

        row_id = row["row_id"]
        asset = row["asset"]
        version = row["version"]
        weight = row["weight_pct"]

        if not isinstance(row_id, str) or not row_id:
            return insufficient("Invalid filing row_id.")

        if row_id in seen_row_ids:
            return insufficient("Duplicate filing row_id.")

        seen_row_ids.add(row_id)

        if asset not in asset_index:
            return insufficient(
                "A filing references an asset outside the universe."
            )

        if (
            isinstance(version, bool)
            or not isinstance(version, int)
            or version < 0
        ):
            return insufficient(
                "Filing versions must be nonnegative integers."
            )

        if (
            isinstance(weight, bool)
            or not isinstance(weight, (int, float))
        ):
            return insufficient("Filing weight_pct must be numeric.")

        try:
            weight = float(weight)
        except (ValueError, OverflowError):
            return insufficient("Invalid filing weight_pct.")

        if not math.isfinite(weight):
            return insufficient("Filing weights must be finite.")

        try:
            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])
        except (TypeError, ValueError) as exc:
            return insufficient(f"Invalid filing date: {exc}")

        if filing_date < period_end:
            return insufficient(
                "A filing date cannot precede its report period."
            )

        version_key = (asset, period_end, version)

        if version_key in seen_versions:
            return insufficient(
                "Duplicate asset/report-period/version combination."
            )

        seen_versions.add(version_key)

        # Under the specified historical Form N-PORT regime, the
        # ordinary third-month report has a 60-calendar-day
        # public-disclosure floor.
        disclosure_date = period_end + timedelta(days=60)

        # Filing and public availability are distinct concepts.
        # Do not treat a record as public before either date.
        availability_date = max(filing_date, disclosure_date)

        observations.append(
            (
                availability_date,
                asset_index[asset],
                period_end,
                version,
                weight
            )
        )

    # ------------------------------------------------------------
    # 3. Sort by point-in-time availability, NOT report period.
    #
    # This permits an efficient chronological sweep of the filings
    # while preventing future revisions from overwriting history.
    # ------------------------------------------------------------

    observations.sort(key=lambda record: record[0])

    # Current holdings levels in fixed asset order.
    levels = [baseline] * n_assets

    # For each asset, the selected (period_end, version).
    # None means that no publicly eligible observation exists.
    selected_keys = [None] * n_assets

    next_observation = 0
    total_observations = len(observations)

    weights = []

    # ------------------------------------------------------------
    # 4. Construct a signal independently at each decision date.
    # ------------------------------------------------------------

    for decision_date in decision_dates:

        # A record becoming public on the decision date itself is
        # excluded. Without an intraday timestamp, its availability
        # before the decision cutoff cannot be established.
        while (
            next_observation < total_observations
            and observations[next_observation][0] < decision_date
        ):
            (
                availability_date,
                column,
                period_end,
                version,
                weight
            ) = observations[next_observation]

            candidate_key = (period_end, version)
            current_key = selected_keys[column]

            # Lexicographic comparison implements:
            #   - Most recent eligible report period first.
            #   - Highest eligible version within that period.
            #
            # An amendment to an older report cannot replace an
            # already eligible, more recent report period.
            if current_key is None or candidate_key > current_key:
                selected_keys[column] = candidate_key
                levels[column] = weight

            next_observation += 1

        # --------------------------------------------------------
        # 5. Cross-sectional centering.
        #
        # Subtracting a common reference level before calculating
        # the mean reduces floating-point cancellation. This is
        # algebraically equivalent to levels[i] - mean(levels).
        # --------------------------------------------------------

        reference_level = levels[0]

        deviations = [
            value - reference_level
            for value in levels
        ]

        mean_deviation = math.fsum(deviations) / n_assets

        centered = [
            value - mean_deviation
            for value in deviations
        ]

        # Exactly uniform holdings imply no long-short signal.
        if all(value == reference_level for value in levels):
            weights.append([0.0] * n_assets)
            continue

        gross = math.fsum(abs(value) for value in centered)

        if gross == 0.0:
            weights.append([0.0] * n_assets)
            continue

        # --------------------------------------------------------
        # 6. Gross-exposure normalization.
        #
        # The theoretical properties are:
        #   sum(abs(w)) = 1
        #   sum(w) = 0
        #
        # Floating-point results satisfy these to numerical
        # precision. A small safety correction prevents gross
        # exposure from exceeding 1 through rounding.
        # --------------------------------------------------------

        signal = [
            value / gross
            for value in centered
        ]

        realized_gross = math.fsum(abs(w) for w in signal)

        if realized_gross > 1.0:
            correction = math.nextafter(1.0, 0.0) / realized_gross

            signal = [
                w * correction
                for w in signal
            ]

        weights.append(signal)

    # ------------------------------------------------------------
    # 7. Return signal weights only.
    #
    # Do not calculate returns from payload["prices"].
    #
    # In particular:
    # - The decision at dates[t] is not traded on dates[t].
    # - The evaluator uses the NEXT session's open-to-close return.
    # - The supplied synthetic session order is authoritative.
    # - No exchange-calendar inference is performed here.
    # - No prices are used for parameter selection or optimization.
    # ------------------------------------------------------------

    return {
        "status": "assumption",
        "reason": (
            "Point-in-time alignment uses the later of filing_date "
            "and period_end + 60 calendar days as the public-"
            "availability date. Because publication times are "
            "unknown, records are eligible only on strictly later "
            "decision dates. Each asset uses its latest eligible "
            "report period and highest eligible version, with "
            "100/N percent as its pre-observation baseline. "
            "Weights are demeaned, gross-normalized and "
            "dollar-neutral; uniform holdings produce cash. "
            "Signals are for next-session open-to-close execution "
            "by the independent evaluator. Prices are not used."
        ),
        "weights": weights
    }
