def build_strategy(payload: dict) -> dict:
    """
    Constructs a holdings-based portfolio signal and historical weights 
    using point-in-time SEC Form N-PORT filings.
    """
    dates = payload.get("dates", [])
    assets = payload.get("assets", [])
    filings = payload.get("filings", [])

    if not dates or not assets:
        return {
            "status": "insufficient_data",
            "reason": "Payload is missing 'dates' or 'assets'.",
            "weights": []
        }

    N = len(assets)
    
    # Pre-process filings by asset for faster point-in-time resolution
    asset_filings = {a: [] for a in assets}
    for f in filings:
        a = f.get("asset")
        if a in asset_filings:
            asset_filings[a].append(f)
            
    # Sort each asset's filings by period_end (descending) then filing_date (descending).
    # This ensures that when we filter by filing_date <= decision_date, the first
    # matching record is the most recent report period and its latest applicable revision.
    for a in assets:
        asset_filings[a].sort(
            key=lambda x: (x.get("period_end", ""), x.get("filing_date", "")), 
            reverse=True
        )

    weights = []
    # weight_pct is in percentages (0-100), so the equal-weight level is 100 / N
    equal_weight_pct = 100.0 / N if N > 0 else 0.0

    for d in dates:
        v = []
        for a in assets:
            # Find the latest filing available strictly on or before the decision date
            applicable = [f for f in asset_filings[a] if f.get("filing_date", "") <= d]
            if applicable:
                v.append(float(applicable[0].get("weight_pct", 0.0)))
            else:
                # Before any applicable observation, use the equal-weight level
                v.append(equal_weight_pct)
                
        # Subtract cross-sectional mean to center the vector
        mean_v = sum(v) / N
        centered_v = [val - mean_v for val in v]
        
        # Calculate sum of absolute centered weights to evaluate gross exposure
        sum_abs = sum(abs(val) for val in centered_v)
        
        # Return cash (vector of zeros) if the centered vector is zero (e.g., all equal weight)
        if sum_abs < 1e-9:
            weights.append([0.0] * N)
        else:
            # Normalize absolute weights to sum to one (Gross exposure = 1.0, Net exposure = 0.0)
            normalized_v = [val / sum_abs for val in centered_v]
            weights.append(normalized_v)
            
    return {
        "status": "ok",
        "reason": "Successfully generated aligned portfolio weights without look-ahead bias.",
        "weights": weights
    }

