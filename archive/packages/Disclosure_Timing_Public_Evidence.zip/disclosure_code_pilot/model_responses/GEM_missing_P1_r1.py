import datetime

def build_strategy(payload: dict) -> dict:
    """
    Build a holdings-based portfolio signal from N-PORT filings.
    
    Args:
        payload (dict): Contains 'dates', 'assets', 'filings', and optionally 'prices'.
    Returns:
        dict: Status, reason, and computed weights.
    """
    dates = payload.get('dates', [])
    assets = payload.get('assets', [])
    filings = payload.get('filings', [])
    
    if not dates or not assets:
        return {
            'status': 'insufficient_data',
            'reason': 'Missing dates or assets in the payload.',
            'weights': []
        }
        
    N = len(assets)
    asset_to_idx = {a: i for i, a in enumerate(assets)}
    
    # Track filings per asset: list of (publication_date, period_end_date, weight_pct)
    asset_filings = {a: [] for a in assets}
    
    for f in filings:
        a = f.get('asset')
        if a not in asset_to_idx:
            continue
            
        period_end_str = f.get('period_end')
        if not period_end_str:
            continue
            
        period_end = datetime.date.fromisoformat(period_end_str)
        
        # To avoid look-ahead bias, we must assume a publication lag. 
        # Under the SEC regime for 2022-2023, public portions of third-fiscal-month 
        # Form N-PORT reports are filed/public within 60 days after the period end.
        pub_date = period_end + datetime.timedelta(days=60)
        
        # If weight is missing, fall back to equal weight percentage
        weight = f.get('weight_pct', 100.0 / N)
        
        asset_filings[a].append((pub_date, period_end, weight))
        
    # Sort filings so that we can easily find the most recent period_end
    for a in assets:
        asset_filings[a].sort(key=lambda x: x[1])
        
    weights_out = []
    
    for d_str in dates:
        d = datetime.date.fromisoformat(d_str)
        
        # Start with the equal-weight level (in percentage)
        raw_w = [100.0 / N] * N
        
        # Determine the most recently available report for each asset
        for i, a in enumerate(assets):
            best_w = None
            best_period = None
            
            for pub, pend, w in asset_filings[a]:
                # Observation is only applicable if it was published on or before the decision date
                if pub <= d:
                    if best_period is None or pend > best_period:
                        best_period = pend
                        best_w = w
            
            if best_w is not None:
                raw_w[i] = best_w
                
        # Centering step: subtract the cross-sectional mean
        mean_w = sum(raw_w) / N
        centered_w = [w - mean_w for w in raw_w]
        
        # Normalization step: absolute weights sum to one (Gross exposure = 1)
        sum_abs = sum(abs(w) for w in centered_w)
        
        if sum_abs > 1e-9:
            final_w = [w / sum_abs for w in centered_w]
        else:
            # If the centered vector is zero, return cash (all zeros)
            final_w = [0.0] * N
            
        weights_out.append(final_w)
        
    return {
        'status': 'assumption',
        'reason': 'Assumed a strict 60-day lag from period_end to publication date for Form N-PORT filings to prevent look-ahead bias.',
        'weights': weights_out
    }

