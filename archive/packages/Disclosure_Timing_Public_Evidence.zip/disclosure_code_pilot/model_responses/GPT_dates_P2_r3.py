from datetime import date
from math import fsum, isfinite


def build_strategy(payload):
    """
    Build a point-in-time, holdings-based long/short portfolio signal.

    Rules:
      - Use actual SEC filing dates, never estimated filing lags.
      - A filing is available at the end of its filing date.
      - For each asset, select the latest available report period.
      - Within that period, select the latest available filed version.
      - Never apply a later revision retroactively.
      - Use 100 / number_of_assets as the pre-observation baseline.
      - Cross-sectionally demean and L1-normalize the holdings.
      - Return cash when all centered holdings are zero.
      - Do not use prices to construct or optimize signals.
      - Return decision-day weights without shifting them.
        The independent evaluator executes each decision at the
        next listed session's open and closes at that session's close.

    Returns:
        {
            "status": "ok" | "assumption" | "insufficient_data",
            "reason": str,
            "weights": list[list[float]]
        }

    On insufficient data, weights may be omitted.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value, field):
        if not isinstance(value, str):
            raise ValueError(f"{field} must be an ISO date string")

        try:
            parsed = date.fromisoformat(value)
        except (ValueError, TypeError):
            raise ValueError(f"Invalid {field}: {value!r}")

        if parsed.isoformat() != value:
            raise ValueError(
                f"{field} must use YYYY-MM-DD format: {value!r}"
            )

        return parsed

    def normalize_holdings(levels):
        """
        Subtract the cross-sectional mean, then normalize
        absolute exposures to one.

        If the holdings are identical, return an all-cash portfolio.
        """
        n = len(levels)

        if n == 0:
            return []

        if max(levels) == min(levels):
            return [0.0] * n

        mean = fsum(levels) / n

        centered = [value - mean for value in levels]

        gross = fsum(abs(value) for value in centered)

        if not isfinite(gross) or gross == 0.0:
            return [0.0] * n

        weights = [value / gross for value in centered]

        # Protect against floating-point rounding causing gross
        # exposure to exceed one.
        measured_gross = max(
            sum(abs(w) for w in weights),
            fsum(abs(w) for w in weights),
        )

        if measured_gross > 1.0:
            scale = (1.0 - 1e-14) / measured_gross
            weights = [w * scale for w in weights]

        return weights

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        dates = payload.get("dates")
        assets = payload.get("assets")
        filings = payload.get("filings")

        if not isinstance(dates, list) or not dates:
            return insufficient(
                "A nonempty list of decision dates is required."
            )

        if not isinstance(assets, list) or not assets:
            return insufficient(
                "A nonempty list of assets is required."
            )

        if not isinstance(filings, list):
            return insufficient(
                "Filings must be supplied as a list."
            )

        if any(
            not isinstance(asset, str) or not asset
            for asset in assets
        ):
            return insufficient(
                "Asset identifiers must be nonempty strings."
            )

        if len(set(assets)) != len(assets):
            return insufficient(
                "Assets must be unique."
            )

        decision_dates = [
            parse_date(value, "decision date")
            for value in dates
        ]

        if any(
            decision_dates[i] > decision_dates[i + 1]
            for i in range(len(decision_dates) - 1)
        ):
            return insufficient(
                "Decision dates must be in chronological order."
            )

        n_assets = len(assets)

        asset_index = {
            asset: index
            for index, asset in enumerate(assets)
        }

        baseline = 100.0 / n_assets

        # Each event:
        # (filing_date, period_end, asset_index, weight_pct)
        events = []

        # Detect contradictory records with indistinguishable
        # point-in-time ordering.
        seen_versions = {}

        for row_number, row in enumerate(filings):
            if not isinstance(row, dict):
                return insufficient(
                    f"Filing row {row_number} is not a dictionary."
                )

            required = (
                "asset",
                "period_end",
                "filing_date",
                "weight_pct",
            )

            missing = [
                field
                for field in required
                if field not in row or row[field] is None
            ]

            if missing:
                if "filing_date" in missing:
                    return insufficient(
                        "Actual SEC filing dates are missing. "
                        "Exact historical alignment cannot be "
                        "established from these inputs; report-period "
                        "dates or assumed filing lags are insufficient."
                    )

                return insufficient(
                    f"Filing row {row_number} is missing: "
                    + ", ".join(missing)
                )

            asset = row["asset"]

            if asset not in asset_index:
                return insufficient(
                    f"Unknown asset in filing row {row_number}: "
                    f"{asset!r}"
                )

            period_end = parse_date(
                row["period_end"],
                "period_end",
            )

            filing_date = parse_date(
                row["filing_date"],
                "filing_date",
            )

            raw_weight = row["weight_pct"]

            if isinstance(raw_weight, bool):
                return insufficient(
                    f"Invalid weight_pct in filing row {row_number}."
                )

            try:
                weight = float(raw_weight)
            except (TypeError, ValueError, OverflowError):
                return insufficient(
                    f"Invalid weight_pct in filing row {row_number}."
                )

            if not isfinite(weight):
                return insufficient(
                    f"Non-finite weight_pct in filing row {row_number}."
                )

            version_key = (
                asset,
                period_end,
                filing_date,
            )

            if version_key in seen_versions:
                if seen_versions[version_key] != weight:
                    return insufficient(
                        "Conflicting weights exist for the same "
                        "asset, report period, and filing date. "
                        "The available dates cannot determine "
                        "which version was applicable."
                    )

                # Identical duplicate observations are harmless.
                continue

            seen_versions[version_key] = weight

            events.append(
                (
                    filing_date,
                    period_end,
                    asset_index[asset],
                    weight,
                )
            )

        # Filing rows arrive unordered.
        #
        # Sorting by actual filing date prevents look-ahead.
        # row_id is deliberately excluded: it is an opaque
        # identifier, not a temporal ordering variable.
        events.sort(key=lambda event: (event[0], event[1]))

        # Current applicable holdings for each asset.
        current_levels = [baseline] * n_assets

        # Highest available (period_end, filing_date) per asset.
        # A newer report period takes precedence over an older one.
        # Within the same period, the later filing takes precedence.
        latest_keys = [None] * n_assets

        weights = []
        event_cursor = 0
        n_events = len(events)

        for decision_date in decision_dates:

            # A date-only public filing is eligible at the end
            # of its filing day, including that day itself.
            while (
                event_cursor < n_events
                and events[event_cursor][0] <= decision_date
            ):
                (
                    filing_date,
                    period_end,
                    index,
                    reported_weight,
                ) = events[event_cursor]

                candidate_key = (
                    period_end,
                    filing_date,
                )

                existing_key = latest_keys[index]

                if (
                    existing_key is None
                    or candidate_key > existing_key
                ):
                    latest_keys[index] = candidate_key
                    current_levels[index] = reported_weight

                event_cursor += 1

            # Construct the signal using only holdings
            # publicly available by this decision day's close.
            #
            # Each asset without an applicable observation
            # retains its equal-weight baseline.
            daily_weights = normalize_holdings(current_levels)

            if not all(isfinite(w) for w in daily_weights):
                return insufficient(
                    "Unable to construct finite portfolio weights."
                )

            weights.append(daily_weights)

        return {
            "status": "ok",
            "reason": (
                "Point-in-time alignment uses actual SEC filing_date "
                "for each asset and report period, inclusive at the "
                "decision-day close. The latest publicly available "
                "report period and its latest filed version are used "
                "per asset; revisions are never backfilled. "
                "Unobserved assets use the equal-weight baseline. "
                "Holdings are cross-sectionally demeaned and "
                "L1-normalized, with cash when the signal is zero. "
                "Weights remain aligned to input decision dates; "
                "the independent evaluator executes them at the "
                "next listed session's open and liquidates at its "
                "close. Prices are not used in signal construction. "
                "The specified end-of-filing-day availability "
                "convention is applied because intraday filing "
                "timestamps are unavailable."
            ),
            "weights": weights,
        }

    except (ValueError, TypeError, KeyError, OverflowError) as exc:
        return insufficient(
            f"Unable to establish valid historical alignment: {exc}"
        )
