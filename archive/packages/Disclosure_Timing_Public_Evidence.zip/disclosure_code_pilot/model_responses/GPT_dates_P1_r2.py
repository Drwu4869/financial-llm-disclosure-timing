from bisect import bisect_right
from datetime import date, timedelta
from math import fsum, isfinite
import re


def build_strategy(payload):
    """
    Construct a point-in-time, holdings-based, dollar-neutral strategy.

    Historical alignment:
      - Use only information publicly available before decision day.
      - For third-fiscal-month Form N-PORT reports under the 2022-2023
        regime, assume public availability no earlier than 60 calendar
        days after the reporting period ends.
      - Also respect the actual SEC filing_date.
      - Because intraday publication times are unknown, exclude a record
        from decisions made on its assumed availability date.
      - Select the newest eligible report period independently per asset.
      - Within a report period, select the latest eligible revision.
      - Before an eligible observation, use the equal-weight level.

    Signal:
      - Cross-sectionally demean the latest holdings percentages.
      - Normalize absolute exposures to one.
      - Return all-zero weights when the signal is constant.
      - Maintain zero net exposure.

    Execution and evaluation:
      - Weights are decisions made at the close of each input date.
      - An independent evaluator executes at the next session's open
        and liquidates at that session's close.
      - Prices are deliberately excluded from signal construction.
      - No real-world exchange calendar is inferred.

    Returns:
        {
            "status": "ok" | "assumption" | "insufficient_data",
            "reason": str,
            "weights": list[list[float]]
        }

    On insufficient_data, weights may be omitted.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason
        }

    def parse_date(value):
        if (
            not isinstance(value, str)
            or re.fullmatch(r"\d{4}-\d{2}-\d{2}", value) is None
        ):
            raise ValueError("Expected ISO date YYYY-MM-DD")

        return date.fromisoformat(value)

    def normalize(levels):
        """
        Subtract the cross-sectional mean and normalize gross exposure.

        Scaling before centering protects against numerical overflow.
        Separately normalizing positive and negative centered exposures
        minimizes floating-point drift from dollar neutrality.
        """
        n = len(levels)
        zero = [0.0] * n

        scale = max(abs(x) for x in levels)

        if scale == 0.0:
            return zero

        scaled = [x / scale for x in levels]

        mean = fsum(scaled) / n
        centered = [x - mean for x in scaled]

        positive_sum = fsum(
            x for x in centered if x > 0.0
        )
        negative_sum = fsum(
            -x for x in centered if x < 0.0
        )

        if positive_sum == 0.0 or negative_sum == 0.0:
            return zero

        result = []

        for x in centered:
            if x > 0.0:
                result.append(0.5 * x / positive_sum)
            elif x < 0.0:
                result.append(0.5 * x / negative_sum)
            else:
                result.append(0.0)

        return result

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        raw_dates = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]

        if not isinstance(raw_dates, (list, tuple)):
            return insufficient("dates must be a sequence.")

        if not raw_dates:
            return insufficient("No decision dates supplied.")

        decision_dates = [parse_date(x) for x in raw_dates]

        if any(
            decision_dates[i] >= decision_dates[i + 1]
            for i in range(len(decision_dates) - 1)
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        if not isinstance(assets, (list, tuple)) or not assets:
            return insufficient("A nonempty asset universe is required.")

        if any(
            not isinstance(asset, str) or not asset
            for asset in assets
        ):
            return insufficient("Asset identifiers must be nonempty strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        if not isinstance(filings, (list, tuple)):
            return insufficient("filings must be a sequence.")

        n_assets = len(assets)
        asset_index = {
            asset: i for i, asset in enumerate(assets)
        }

        equal_weight_level = 100.0 / n_assets

        # Each event is:
        # (first_eligible_decision_index,
        #  report_period, filing_date, asset_index, weight_pct)
        #
        # bisect_right ensures an observation is not used on the
        # same calendar day as its assumed public availability.

        events = []
        seen_ids = set()
        seen_versions = {}

        for row in filings:
            if not isinstance(row, dict):
                return insufficient("Each filing must be a dictionary.")

            row_id = row["row_id"]
            asset = row["asset"]
            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])

            if not isinstance(row_id, str) or not row_id:
                return insufficient("Invalid filing row_id.")

            if row_id in seen_ids:
                return insufficient("Duplicate filing row_id.")

            seen_ids.add(row_id)

            if filing_date < period_end:
                return insufficient(
                    "A filing date precedes its reporting period end."
                )

            raw_weight = row["weight_pct"]

            if isinstance(raw_weight, bool):
                return insufficient("Invalid holdings percentage.")

            try:
                weight_pct = float(raw_weight)
            except (TypeError, ValueError, OverflowError):
                return insufficient("Invalid holdings percentage.")

            if not isfinite(weight_pct):
                return insufficient(
                    "Holdings percentages must be finite numbers."
                )

            # Only the requested fixed security universe is traded.
            if asset not in asset_index:
                continue

            # Distinct revisions may have different filing dates.
            # Conflicting versions with identical dates cannot be
            # chronologically ordered without intraday timestamps.
            version_key = (asset, period_end, filing_date)

            if version_key in seen_versions:
                if seen_versions[version_key] != weight_pct:
                    return insufficient(
                        "Conflicting same-day versions cannot be ordered."
                    )
                continue

            seen_versions[version_key] = weight_pct

            # Historical Form N-PORT public-disclosure convention.
            assumed_public_date = max(
                filing_date,
                period_end + timedelta(days=60)
            )

            first_eligible = bisect_right(
                decision_dates,
                assumed_public_date
            )

            if first_eligible >= len(decision_dates):
                continue

            events.append((
                first_eligible,
                period_end,
                filing_date,
                asset_index[asset],
                weight_pct
            ))

        # Process eligibility events in decision-date order.
        # No price information participates in this ordering.
        events.sort(key=lambda event: event[0])

        current_levels = [equal_weight_level] * n_assets

        # Most recent (report period, revision filing date) per asset.
        current_versions = [None] * n_assets

        weights = []
        event_cursor = 0
        total_events = len(events)

        for decision_index in range(len(decision_dates)):

            # Incorporate every observation known before this close.
            while (
                event_cursor < total_events
                and events[event_cursor][0] <= decision_index
            ):
                (
                    _,
                    report_period,
                    revision_date,
                    column,
                    weight_pct
                ) = events[event_cursor]

                candidate_version = (
                    report_period,
                    revision_date
                )

                previous_version = current_versions[column]

                # Report period takes priority over revision date.
                # A late revision of an older report must not replace
                # an already-available newer reporting period.
                if (
                    previous_version is None
                    or candidate_version > previous_version
                ):
                    current_versions[column] = candidate_version
                    current_levels[column] = weight_pct

                event_cursor += 1

            # Cross-sectional centering and exposure normalization.
            signal = normalize(current_levels)

            weights.append(signal)

        return {
            "status": "assumption",
            "reason": (
                "Point-in-time alignment uses the later of SEC filing "
                "date and 60 calendar days after report period end as "
                "the earliest assumed public date. Date-only records "
                "become eligible on strictly later decision dates. "
                "The newest eligible report and revision are selected "
                "independently per asset; missing observations use "
                "equal-weight levels. Signals are centered, gross "
                "normalized and dollar neutral. Prices are excluded "
                "from signal construction; next-session execution "
                "and returns belong to the independent evaluator."
            ),
            "weights": weights
        }

    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return insufficient(
            f"Invalid or incomplete input: {exc}"
        )
