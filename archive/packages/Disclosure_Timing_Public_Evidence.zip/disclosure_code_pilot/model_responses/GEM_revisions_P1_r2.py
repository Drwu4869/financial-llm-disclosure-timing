def build_strategy(payload):
    """
    Builds a holdings-based portfolio signal using Form N-PORT filing data,
    evaluating available information at each decision date to avoid look-ahead bias.
    """
    # Extract components from payload
    dates = payload.get('dates')
    assets = payload.get('assets')
    filings = payload.get('filings')
    
    if not dates or not assets:
        return {
            'status': 'insufficient_data',
            'reason': 'Missing dates or assets in the payload.',
            'weights': []
        }
        
    num_assets = len(assets)
    if num_assets == 0:
        return {
            'status': 'insufficient_data',
            'reason': 'Asset list is empty.',
            'weights': []
        }
        
    # Baseline observation is the equal-weight level (assuming weight_pct is out of 100)
    equal_weight_pct = 100.0 / num_assets
    
    # Pre-group filings by asset for faster lookup per date
    filings_by_asset = {a: [] for a in assets}
    if filings:
        for f in filings:
            asset = f.get('asset')
            if asset in filings_by_asset:
                filings_by_asset[asset].append(f)
                
    weights_out = []
    
    # Evaluate at the end of each decision day
    for d in dates:
        raw_weights = []
        
        for asset in assets:
            # Filter filings available on or before the current decision date
            available = [f for f in filings_by_asset[asset] if f.get('filing_date', '') <= d]
            
            if not available:
                # Fallback to equal-weight level before any applicable observation
                raw_weights.append(equal_weight_pct)
            else:
                # Most recent report period, then max version
                best_filing = max(available, key=lambda x: (x.get('period_end', ''), x.get('version', -1)))
                raw_weights.append(float(best_filing.get('weight_pct', 0.0)))
        
        # 1. Cross-sectional mean centering (ensures net exposure is zero)
        mean_w = sum(raw_weights) / num_assets
        centered = [w - mean_w for w in raw_weights]
        
        # 2. Normalize absolute weights (ensures gross exposure <= 1)
        sum_abs = sum(abs(w) for w in centered)
        
        # 3. Return cash (all zeros) when the centered vector is zero
        if sum_abs < 1e-12:
            weights_out.append([0.0 for _ in range(num_assets)])
        else:
            weights_out.append([w / sum_abs for w in centered])
            
    return {
        'status': 'ok',
        'reason': 'Processed strictly on point-in-time filing_date alignment. Unobserved assets default to equal weight.',
        'weights': weights_out
    }

