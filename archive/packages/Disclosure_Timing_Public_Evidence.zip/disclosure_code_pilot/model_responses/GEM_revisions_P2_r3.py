def build_strategy(payload: dict) -> dict:
    dates = payload.get('dates', [])
    assets = payload.get('assets', [])
    filings = payload.get('filings', [])

    # Check that actual filing dates are present across all provided filings
    for f in filings:
        if not f.get('filing_date'):
            return {
                'status': 'insufficient_data',
                'reason': 'Exact historical alignment cannot be established from these inputs rather than inventing dates.'
            }

    num_assets = len(assets)
    if num_assets == 0:
        return {
            'status': 'ok',
            'reason': 'No assets to allocate.',
            'weights': [[] for _ in dates]
        }

    # Organize filings by asset for faster lookup
    filings_by_asset = {a: [] for a in assets}
    for f in filings:
        asset = f.get('asset')
        if asset in filings_by_asset:
            filings_by_asset[asset].append(f)

    equal_weight = 1.0 / num_assets
    weights = []

    for d in dates:
        raw_weights = []
        for a in assets:
            # Filter filings available by the end of the decision day
            valid_filings = [f for f in filings_by_asset[a] if f['filing_date'] <= d]
            
            if not valid_filings:
                # Before any applicable observation, use equal-weight level
                raw_weights.append(equal_weight)
            else:
                # Most recent report period for this asset
                max_period = max(f['period_end'] for f in valid_filings)
                best_period_filings = [f for f in valid_filings if f['period_end'] == max_period]
                
                # Applicable version (highest version for that report period)
                max_version = max(f['version'] for f in best_period_filings)
                best_filing = next(f for f in best_period_filings if f['version'] == max_version)
                
                # Convert percentage to a fraction
                raw_weights.append(best_filing['weight_pct'] / 100.0)
        
        # Subtract the cross-sectional mean
        mean_weight = sum(raw_weights) / num_assets
        centered = [w - mean_weight for w in raw_weights]
        
        # Normalize absolute weights to sum to one
        abs_sum = sum(abs(w) for w in centered)
        
        if abs_sum < 1e-12:
            # Return cash (zeros) when the centered vector is zero
            weights.append([0.0] * num_assets)
        else:
            weights.append([w / abs_sum for w in centered])

    return {
        'status': 'ok',
        'reason': 'Successfully formed signal using strictly point-in-time filing dates and max versions.',
        'weights': weights
    }

