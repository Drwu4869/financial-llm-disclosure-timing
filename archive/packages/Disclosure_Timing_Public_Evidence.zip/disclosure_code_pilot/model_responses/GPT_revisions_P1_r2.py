from datetime import date, timedelta
import math


def build_strategy(payload):
    """
    Construct a point-in-time, holdings-based, market-neutral strategy.

    Information policy:
      - Form N-PORT third-fiscal-month holdings during 2022-2023
        are subject to a 60-calendar-day public-disclosure delay.
      - A filing cannot be used before its actual filing date.
      - Because intraday disclosure timestamps are unavailable,
        a record is used only on decision dates strictly after
        its earliest possible public-availability date.
      - Revisions replace earlier versions of the same asset and
        report period, but only after becoming publicly available.
      - For each asset, the latest available report period wins;
        within that period, the highest available version wins.
      - Missing asset observations receive the equal-weight level.

    Signal construction:
      1. Assemble the latest available holdings percentages.
      2. Subtract their cross-sectional mean.
      3. Normalize absolute exposures to approximately one.
      4. Return all-zero weights when the centered vector is zero.

    Weights are decided at the close of each decision date and are
    intended for execution at the following session's open and
    liquidation at that session's close.

    Prices are deliberately excluded from signal construction.
    The external evaluator independently handles session alignment,
    execution prices, realized returns, and performance statistics.

    Returns:
        {
            "status": "ok" | "assumption" | "insufficient_data",
            "reason": str,
            "weights": list[list[float]]
        }
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Dates must be ISO YYYY-MM-DD strings.")

        try:
            parsed = date.fromisoformat(value)
        except ValueError:
            raise ValueError(f"Invalid date: {value!r}") from None

        if parsed.isoformat() != value:
            raise ValueError(f"Noncanonical date: {value!r}")

        return parsed

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        assets = payload.get("assets")
        decision_dates = payload.get("dates")
        filings = payload.get("filings")

        if not isinstance(assets, list) or not assets:
            return insufficient("A nonempty asset list is required.")

        if any(
            not isinstance(asset, str) or not asset
            for asset in assets
        ):
            return insufficient("Asset identifiers must be nonempty strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        if not isinstance(decision_dates, list) or not decision_dates:
            return insufficient("A nonempty decision-date list is required.")

        if not isinstance(filings, list):
            return insufficient("Filings must be a list.")

        days = [parse_date(value) for value in decision_dates]

        if any(
            days[i] >= days[i + 1]
            for i in range(len(days) - 1)
        ):
            return insufficient(
                "Decision dates must be strictly increasing."
            )

        asset_index = {
            asset: i
            for i, asset in enumerate(assets)
        }

        n_assets = len(assets)
        equal_level = 100.0 / n_assets

        # Events contain:
        # (earliest_public_date, period_end, version,
        #  asset_index, weight_pct)
        events = []

        seen_ids = set()
        seen_versions = set()

        for row in filings:
            if not isinstance(row, dict):
                return insufficient("Each filing must be a dictionary.")

            row_id = row.get("row_id")
            asset = row.get("asset")
            version = row.get("version")
            weight = row.get("weight_pct")

            if not isinstance(row_id, str) or not row_id:
                return insufficient("Each filing requires a valid row_id.")

            if row_id in seen_ids:
                return insufficient("Duplicate filing row_id.")

            seen_ids.add(row_id)

            if asset not in asset_index:
                return insufficient(
                    f"Filing references an unknown asset: {asset!r}."
                )

            if type(version) is not int or version < 0:
                return insufficient(
                    "Filing versions must be nonnegative integers."
                )

            if isinstance(weight, bool) or not isinstance(
                weight, (int, float)
            ):
                return insufficient("weight_pct must be numeric.")

            try:
                weight = float(weight)
            except (ValueError, OverflowError):
                return insufficient("Invalid weight_pct value.")

            if not math.isfinite(weight):
                return insufficient("weight_pct must be finite.")

            period_end = parse_date(row.get("period_end"))
            filing_date = parse_date(row.get("filing_date"))

            if filing_date < period_end:
                return insufficient(
                    "A filing date cannot precede its report period."
                )

            identity = (asset, period_end, version)

            if identity in seen_versions:
                return insufficient(
                    "Duplicate asset/report-period/version combination."
                )

            seen_versions.add(identity)

            # Historical Form N-PORT disclosure rule:
            # Third-fiscal-month information becomes public no
            # earlier than 60 calendar days after period end.
            #
            # A later actual filing date takes precedence.
            public_date = max(
                filing_date,
                period_end + timedelta(days=60)
            )

            events.append(
                (
                    public_date,
                    period_end,
                    version,
                    asset_index[asset],
                    weight
                )
            )

        # Unordered filings are processed chronologically.
        # Sorting is independent of row_id and input row order.
        events.sort(key=lambda event: (
            event[0],
            event[1],
            event[2],
            event[3]
        ))

        # One state entry per asset:
        # (period_end, version, weight_pct)
        #
        # None means no publicly applicable observation.
        current = [None] * n_assets

        weights = []
        event_cursor = 0

        for decision_day in days:

            # Strict inequality is intentional.
            #
            # With only filing dates, not filing timestamps,
            # same-day publication cannot safely be assumed
            # available at the decision close.
            while (
                event_cursor < len(events)
                and events[event_cursor][0] < decision_day
            ):
                (
                    public_date,
                    period_end,
                    version,
                    index,
                    weight
                ) = events[event_cursor]

                previous = current[index]

                # Prefer the newest publicly available report
                # period, then its highest available version.
                if (
                    previous is None
                    or (period_end, version)
                    > (previous[0], previous[1])
                ):
                    current[index] = (
                        period_end,
                        version,
                        weight
                    )

                event_cursor += 1

            # Build the holdings vector in fixed asset order.
            levels = [
                equal_level if observation is None
                else observation[2]
                for observation in current
            ]

            # An identical holdings vector has no
            # cross-sectional signal: remain entirely in cash.
            if all(value == levels[0] for value in levels):
                weights.append([0.0] * n_assets)
                continue

            # Positive rescaling before centering improves
            # numerical stability without changing the
            # normalized strategy.
            magnitude = max(abs(value) for value in levels)

            if magnitude == 0.0:
                weights.append([0.0] * n_assets)
                continue

            scaled = [
                value / magnitude
                for value in levels
            ]

            cross_sectional_mean = (
                math.fsum(scaled) / n_assets
            )

            centered = [
                value - cross_sectional_mean
                for value in scaled
            ]

            # Correct floating-point centering residuals
            # to maintain a zero-net-exposure portfolio.
            centered[-1] = -math.fsum(centered[:-1])

            gross = math.fsum(
                abs(value) for value in centered
            )

            if gross == 0.0:
                weights.append([0.0] * n_assets)
                continue

            # Normalize by L1 exposure.
            signal = [
                value / gross
                for value in centered
            ]

            # Remove any residual numerical net exposure.
            signal[-1] = -math.fsum(signal[:-1])

            # Guard against floating-point roundoff causing
            # gross exposure to exceed one.
            actual_gross = math.fsum(
                abs(value) for value in signal
            )

            if actual_gross > 1.0:
                # Tiny downward adjustment only when necessary.
                # This preserves unit gross exposure to
                # floating-point precision.
                adjustment = (
                    (1.0 - 8.0 * math.ulp(1.0))
                    / actual_gross
                )

                signal = [
                    value * adjustment
                    for value in signal
                ]

            # Avoid negative zero in the output.
            signal = [
                0.0 if value == 0.0 else float(value)
                for value in signal
            ]

            weights.append(signal)

        return {
            "status": "assumption",
            "reason": (
                "Each asset uses its newest publicly applicable "
                "Form N-PORT report period and highest available "
                "revision. Public availability is no earlier than "
                "60 calendar days after period end or the actual "
                "filing date, whichever is later. Because intraday "
                "filing times are absent, observations become "
                "eligible only on subsequent decision dates. "
                "Missing holdings use the equal-weight level. "
                "Signals are centered, dollar-neutral and "
                "L1-normalized, with cash for zero signals. "
                "Weights are determined at decision close for "
                "next-session open-to-close evaluation. "
                "No prices, future filings, or return information "
                "are used to construct or tune the signal."
            ),
            "weights": weights
        }

    except (ValueError, TypeError, OverflowError) as exc:
        return insufficient(str(exc))
