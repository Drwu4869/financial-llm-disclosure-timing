from datetime import date, timedelta
from math import fsum, isfinite
from collections import defaultdict
import re


def build_strategy(payload):
    """
    Construct a point-in-time, dollar-neutral holdings signal.

    Disclosure alignment:
      - Under the 2022-2023 Form N-PORT regime, third-fiscal-month
        holdings become public no earlier than 60 calendar days
        after the report period ends.
      - A row cannot be used before its SEC filing date.
      - Because intraday publication times are unavailable, a
        disclosure is eligible only on subsequent decision dates.
      - For each asset, select the newest eligible report period,
        then its highest eligible revision version.

    Signal:
      - Missing observations receive the equal-weight percentage.
      - Subtract the cross-sectional mean.
      - Normalize absolute exposure to one.
      - Return cash when all levels are equal.

    Execution:
      - Each row represents a decision made at that date's close.
      - The evaluator independently handles next-session open-to-close
        execution and returns.
      - Prices are never used for signal construction or calibration.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason,
        }

    def parse_date(value):
        if (
            not isinstance(value, str)
            or re.fullmatch(r"\d{4}-\d{2}-\d{2}", value) is None
        ):
            raise ValueError("Expected ISO YYYY-MM-DD date")
        return date.fromisoformat(value)

    if not isinstance(payload, dict):
        return insufficient("Payload must be a dictionary.")

    dates = payload.get("dates")
    assets = payload.get("assets")
    filings = payload.get("filings")

    if not isinstance(dates, list) or not dates:
        return insufficient("Missing decision dates.")

    if not isinstance(assets, list) or not assets:
        return insufficient("Missing asset universe.")

    if not isinstance(filings, list):
        return insufficient("Filings must be a list.")

    if (
        any(not isinstance(a, str) or not a for a in assets)
        or len(set(assets)) != len(assets)
    ):
        return insufficient("Asset identifiers must be unique strings.")

    try:
        decision_dates = [parse_date(d) for d in dates]
    except (ValueError, TypeError):
        return insufficient("Invalid decision date.")

    if any(
        decision_dates[i] <= decision_dates[i - 1]
        for i in range(1, len(decision_dates))
    ):
        return insufficient("Decision dates must be strictly increasing.")

    n = len(assets)
    asset_index = {asset: i for i, asset in enumerate(assets)}

    # Each event is:
    # (first_public_date, period_end, version, asset_index, weight_pct)
    events = []

    seen_ids = set()
    seen_versions = set()

    try:
        for row in filings:
            if not isinstance(row, dict):
                raise ValueError("Invalid filing row")

            row_id = row["row_id"]
            asset = row["asset"]
            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])
            version = row["version"]
            weight = row["weight_pct"]

            if not isinstance(row_id, str) or not row_id:
                raise ValueError("Invalid row identifier")

            if row_id in seen_ids:
                raise ValueError("Duplicate row identifier")
            seen_ids.add(row_id)

            if asset not in asset_index:
                raise ValueError("Filing contains an unknown asset")

            if (
                isinstance(version, bool)
                or not isinstance(version, int)
                or version < 0
            ):
                raise ValueError("Invalid revision version")

            if (
                isinstance(weight, bool)
                or not isinstance(weight, (int, float))
            ):
                raise ValueError("Invalid portfolio weight")

            weight = float(weight)

            if not isfinite(weight):
                raise ValueError("Non-finite portfolio weight")

            if filing_date < period_end:
                raise ValueError("Filing precedes its report period")

            revision_key = (asset, period_end, version)

            if revision_key in seen_versions:
                raise ValueError("Ambiguous duplicate revision")
            seen_versions.add(revision_key)

            # The public-disclosure delay is measured in calendar days,
            # not in synthetic or exchange trading sessions.
            public_date = max(
                filing_date,
                period_end + timedelta(days=60),
            )

            events.append(
                (
                    public_date,
                    period_end,
                    version,
                    asset_index[asset],
                    weight,
                )
            )

    except (KeyError, ValueError, TypeError, OverflowError) as exc:
        return insufficient(f"Invalid filing data: {exc}")

    # Sort by actual availability, not by report period or row_id.
    events.sort(key=lambda event: event[0])

    # Equal-weight fallback is expressed in portfolio percentage units.
    equal_level = 100.0 / n
    levels = [equal_level] * n

    # Track the best eligible (period_end, version) for each asset.
    best_key = [None] * n

    result = []
    event_pointer = 0

    for decision_day in decision_dates:

        # Strict inequality avoids assuming that an SEC record filed
        # or released on this date was observable before the close.
        while (
            event_pointer < len(events)
            and events[event_pointer][0] < decision_day
        ):
            (
                public_date,
                period_end,
                version,
                j,
                weight,
            ) = events[event_pointer]

            candidate_key = (period_end, version)

            # Most recent report period takes precedence.
            # Within that period, the highest eligible version wins.
            if (
                best_key[j] is None
                or candidate_key > best_key[j]
            ):
                best_key[j] = candidate_key
                levels[j] = weight

            event_pointer += 1

        # A constant cross-section has no relative holdings signal.
        if all(value == levels[0] for value in levels):
            result.append([0.0] * n)
            continue

        # Cross-sectional demeaning.
        mean_level = fsum(levels) / n
        centered = [value - mean_level for value in levels]

        # Correct floating-point centering residual.
        centered[-1] = -fsum(centered[:-1])

        gross = fsum(abs(value) for value in centered)

        if gross == 0.0:
            result.append([0.0] * n)
            continue

        # Unit gross exposure, zero net exposure.
        weights = [value / gross for value in centered]

        # Remove residual numerical net exposure.
        weights[-1] = -sum(weights[:-1])

        # Guard against floating-point gross exposure exceeding one.
        actual_gross = fsum(abs(value) for value in weights)

        if actual_gross > 1.0:
            scale = (1.0 - 1e-14) / actual_gross
            weights = [value * scale for value in weights]
            weights[-1] = -sum(weights[:-1])

        result.append(weights)

    return {
        "status": "assumption",
        "reason": (
            "Uses the later of SEC filing and the 60-calendar-day "
            "Form N-PORT public-release date. Same-day disclosures "
            "are excluded because intraday publication times are "
            "unknown. Each asset uses its newest eligible report "
            "period and highest eligible version. Missing observations "
            "use equal-weight levels. Signals are determined at "
            "decision-day close; the evaluator independently maps "
            "them to next-session open-to-close trades. Prices are "
            "not used to construct the signal."
        ),
        "weights": result,
    }
