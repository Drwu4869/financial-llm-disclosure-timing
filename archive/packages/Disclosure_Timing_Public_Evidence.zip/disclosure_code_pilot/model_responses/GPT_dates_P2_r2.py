from datetime import date
from fractions import Fraction
import math


def build_strategy(payload):
    """
    Construct point-in-time holdings-based portfolio weights.

    Rules
    -----
    1. Use only filings with filing_date <= decision date.
    2. For each asset, select the latest available report period.
    3. Within that period, use the latest publicly filed revision.
    4. Before an asset's first eligible filing, use 100 / N percent.
    5. Cross-sectionally center the holdings percentages.
    6. Normalize absolute exposures to one, or hold cash if flat.
    7. Do not use prices to construct or optimize the signal.

    Returned weights correspond to decisions made at the close
    of each input date. Execution and return calculation belong
    to the independent evaluator, using the next listed session.

    No exchange calendar, reporting lag, or intraday filing time
    is inferred.
    """

    def insufficient(reason):
        return {
            "status": "insufficient_data",
            "reason": reason
        }

    def parse_date(value):
        if not isinstance(value, str):
            raise ValueError("Date must be an ISO date string.")

        parsed = date.fromisoformat(value)

        if parsed.isoformat() != value:
            raise ValueError("Date must have YYYY-MM-DD format.")

        return parsed

    try:
        if not isinstance(payload, dict):
            return insufficient("Payload must be a dictionary.")

        dates = payload["dates"]
        assets = payload["assets"]
        filings = payload["filings"]

        if not isinstance(dates, (list, tuple)):
            return insufficient("dates must be an ordered sequence.")

        if not isinstance(assets, (list, tuple)) or not assets:
            return insufficient("A nonempty asset universe is required.")

        if not isinstance(filings, (list, tuple)):
            return insufficient("filings must be a sequence.")

        if any(
            not isinstance(asset, str) or not asset
            for asset in assets
        ):
            return insufficient("Asset identifiers must be nonempty strings.")

        if len(set(assets)) != len(assets):
            return insufficient("Asset identifiers must be unique.")

        decision_dates = [parse_date(d) for d in dates]

        if any(
            decision_dates[i] > decision_dates[i + 1]
            for i in range(len(decision_dates) - 1)
        ):
            return insufficient("Decision dates must be chronological.")

        n_assets = len(assets)
        asset_index = {
            asset: i for i, asset in enumerate(assets)
        }

        # A revision is identified by its own SEC filing date.
        # row_id is opaque and must not determine chronology.
        #
        # Key:
        #   (asset index, report period, filing date)
        #
        # Value:
        #   exact reported percentage
        versions = {}

        for row in filings:
            if not isinstance(row, dict):
                return insufficient("Every filing must be a dictionary.")

            if "filing_date" not in row or row["filing_date"] in (
                None, ""
            ):
                return insufficient(
                    "Actual SEC filing_date is missing; "
                    "exact historical point-in-time alignment "
                    "cannot be established."
                )

            asset = row["asset"]

            if asset not in asset_index:
                return insufficient(
                    "A filing references an asset outside the universe."
                )

            period_end = parse_date(row["period_end"])
            filing_date = parse_date(row["filing_date"])

            raw_weight = row["weight_pct"]

            if isinstance(raw_weight, bool) or not isinstance(
                raw_weight, (int, float, Fraction)
            ):
                return insufficient(
                    "weight_pct must be a finite numeric value."
                )

            # Fractions avoid rounding errors when testing whether
            # cross-sectionally centered holdings are exactly zero.
            weight = Fraction(str(raw_weight))

            key = (
                asset_index[asset],
                period_end,
                filing_date
            )

            if key in versions:
                if versions[key] != weight:
                    return insufficient(
                        "Conflicting versions for the same asset, "
                        "report period and filing date cannot be "
                        "ordered without intraday timestamps."
                    )
            else:
                versions[key] = weight

        # Process filings in the order they became public.
        # Period_end is not an availability timestamp.
        events = sorted(
            (
                filing_date,
                period_end,
                asset_i,
                weight
            )
            for (asset_i, period_end, filing_date), weight
            in versions.items()
        )

        # Baseline holding percentage before the first public
        # observation for an asset.
        baseline = Fraction(100, n_assets)

        current_levels = [baseline for _ in range(n_assets)]
        current_periods = [None for _ in range(n_assets)]

        weights = []
        event_index = 0

        for decision_date in decision_dates:

            # A date-only SEC filing is usable at the close of
            # its filing day, not before that day.
            while (
                event_index < len(events)
                and events[event_index][0] <= decision_date
            ):
                (
                    filing_date,
                    period_end,
                    asset_i,
                    weight
                ) = events[event_index]

                existing_period = current_periods[asset_i]

                if (
                    existing_period is None
                    or period_end > existing_period
                ):
                    # Newer eligible report period.
                    current_periods[asset_i] = period_end
                    current_levels[asset_i] = weight

                elif period_end == existing_period:
                    # Later-filed revision of the current period.
                    # Events are processed chronologically, so the
                    # revision cannot affect earlier decisions.
                    current_levels[asset_i] = weight

                # A late amendment of an older report period does
                # not replace an already available newer period.

                event_index += 1

            # Center holdings across the fixed asset universe.
            #
            # centered_i = level_i - mean(levels)
            #
            # Multiplying every centered value by N preserves
            # the final L1-normalized portfolio and avoids
            # unnecessary fractional division.
            total_level = sum(current_levels, Fraction(0))

            centered = [
                n_assets * level - total_level
                for level in current_levels
            ]

            gross = sum(
                (abs(value) for value in centered),
                Fraction(0)
            )

            if gross == 0:
                # Equal holdings imply no active signal.
                portfolio = [0.0] * n_assets

            else:
                # Exact rational normalization before converting
                # the portfolio to ordinary Python floats.
                portfolio = [
                    float(value / gross)
                    for value in centered
                ]

                # Correct only possible floating-point exposure
                # overshoot. The adjustment is at machine precision.
                floating_gross = math.fsum(
                    abs(value) for value in portfolio
                )

                if floating_gross > 1.0:
                    portfolio = [
                        value * (1.0 - 1e-15)
                        for value in portfolio
                    ]

            weights.append(portfolio)

        return {
            "status": "ok",
            "reason": (
                "Point-in-time SEC filing dates determine availability, "
                "inclusive at each decision-day close. Each asset uses "
                "its latest eligible report period and latest eligible "
                "revision within that period. Assets without observations "
                "use equal-weight baseline holdings. Centered signals "
                "are L1-normalized or held in cash when zero. "
                "Prices are excluded from signal construction; "
                "next-session execution and returns are evaluated "
                "independently using the supplied session calendar."
            ),
            "weights": weights
        }

    except (
        KeyError,
        ValueError,
        TypeError,
        OverflowError,
        ZeroDivisionError
    ) as exc:
        return insufficient(
            "Invalid or incomplete input: " + str(exc)
        )
