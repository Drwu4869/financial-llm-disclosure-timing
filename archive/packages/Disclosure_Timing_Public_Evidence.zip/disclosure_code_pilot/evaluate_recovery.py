"""A03 supplemental transport recoveries; never overwrite primary missing slots."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
from engine import make_fixture, interventions, score
from sandbox_bwrap import run_candidate

ROOT=Path(__file__).resolve().parent
DEST=ROOT/'technical_recovery'
EXCHANGE=Path('/workspace/shared/disclosure_code_recovery')
for manifest in ['FREEZE.json','amendments/A01_runtime.json']:
 for name,digest in json.loads((ROOT/manifest).read_text())['files'].items():
  assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
plan=json.loads((ROOT/'amendments/A03_technical_recovery.json').read_text())
attempts=json.loads((EXCHANGE/'attempts.json').read_text())
assert [a['trial_id'] for a in attempts]==plan['order'][:len(attempts)]
assert len({a['trial_id'] for a in attempts})==len(attempts)
(DEST/'attempts.json').write_text(json.dumps(attempts,indent=2)+'\n')
for a in attempts:
 if a['status']!='returned':continue
 token='GEM_'+a['trial_id']; target=DEST/(token+'.json')
 if target.exists():continue
 raw=(EXCHANGE/'raw'/(token+'.txt')).read_text()
 (DEST/(token+'.txt')).write_text(raw)
 blocks=re.findall(r'```(?:python|py)?\s*\n(.*?)```',raw,re.S)
 out={**a,'raw_sha256':hashlib.sha256(raw.encode()).hexdigest(),'scored_at':dt.datetime.now(dt.timezone.utc).isoformat(),
      'source_group':'A03 supplemental technical recovery','seeds':[],'outcome':'format_failure'}
 if len(blocks)==1:
  source=blocks[0];(DEST/(token+'.py')).write_text(source)
  out.update(code_sha256=hashlib.sha256(source.encode()).hexdigest(),outcome='evaluated')
  for seed in json.loads((ROOT/'study_config.json').read_text())['evaluation_seeds']:
   fixture=make_fixture(seed,a['trial_id'].split('_')[0]);jobs=interventions(fixture);item={'seed':seed}
   try:
    outputs,metadata=run_candidate(source,[fixture['payload']]+[j['payload'] for j in jobs])
    name=token+'_'+str(seed)+'_outputs.json';(DEST/name).write_text(json.dumps(outputs,indent=2)+'\n')
    item.update(outputs_file=name,environment=metadata)
    item['score']=score(fixture,outputs,jobs)
   except Exception as exc:item['execution_or_scoring_error']=type(exc).__name__+': '+str(exc)
   out['seeds'].append(item)
 out['valid_seeds']=sum('score' in s for s in out['seeds'])
 out['has_numerical_witness']=any(s.get('score',{}).get('numerical_leakage_witness') for s in out['seeds'])
 target.write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({'token':token,'valid_seeds':out['valid_seeds'],'witness':out['has_numerical_witness']}),flush=True)
results=[json.loads((DEST/('GEM_'+a['trial_id']+'.json')).read_text()) for a in attempts if (DEST/('GEM_'+a['trial_id']+'.json')).exists()]
summary={'amendment':'A03','planned':4,'attempted':len(attempts),'returned':sum(a['status']=='returned' for a in attempts),
         'evaluated':sum(r['outcome']=='evaluated' for r in results),'valid_seed_evaluations':sum(r['valid_seeds'] for r in results),
         'witness_programs':sum(r['has_numerical_witness'] for r in results),
         'dated_witness_programs':sum(r['has_numerical_witness'] for r in results if not r['trial_id'].startswith('missing_')),
         'scope':'Supplemental only. Four primary technical missing slots remain missing in the primary analysis.'}
(DEST/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
