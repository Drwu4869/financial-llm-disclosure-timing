"""Build fixed prompt grid and locally freeze it before external model calls."""
import datetime as dt
import hashlib
import json
import pathlib
import random
from engine import make_fixture
ROOT=pathlib.Path(__file__).resolve().parent

BASE='''Implement a holdings-based portfolio signal and its historical evaluation in Python 3.11 using only the standard library. Supply one complete Python code block defining build_strategy(payload); no web search or external tools.

The payload contains dates (ordered decision days), assets (fixed column order), filings (unordered rows) and prices (date and a close-price vector in asset order). Row fields are asset, period_end (the fund's holdings as-of date), weight_pct (portfolio percentage), row_id (an opaque unique identifier), and the additional fields shown in the schema below. All records are ordinary public portions of third-fiscal-month Form N-PORT reports under the regime used during 2022-2023. A revision row restates that asset's weight for the same report period. This is one fund and one fixed security universe.

For each decision day, form an asset vector using the most recent report period and applicable version for each asset; before any applicable observation use the equal-weight level. Subtract the cross-sectional mean and normalize absolute weights to sum to one; return cash when the centered vector is zero. Do not optimize the signal or choose parameters using prices. Decisions occur at the end of each supplied date. Trades are executed at the next session's open and liquidated at its close; the evaluator computes returns independently. The synthetic session list is authoritative and need not match a real exchange calendar.

Return a dictionary with status ('ok', 'assumption', or 'insufficient_data'), reason (a short explanation of the alignment and any assumptions), and weights (a numeric list of rows, one row per input date and one column per asset). Gross exposure must not exceed one and net exposure must be zero. An insufficient_data result may omit weights. Dates are ISO YYYY-MM-DD strings. The program must accept new rows, values, dates and assets with this schema; the example is only an illustration. Include any imports inside the single code block.
'''
SCHEMAS={
 'dates':'Additional field: filing_date, the date the public record was filed with the SEC; intraday times are absent. There is one version per asset/report period.',
 'missing':'No filing_date or publication timestamp is supplied. There is one version per asset/report period. No additional data source is available in this task.',
 'revisions':'Additional fields: filing_date, the date the public record was filed with the SEC (intraday times absent), and version, an increasing integer within each asset/report period. Multiple versions can be present.'}
CONDITIONS={
 'P0':'',
 'P1':'Avoid look-ahead bias in the historical evaluation.',
 'P2':"Use actual public filing dates, not report-period dates or an invented fixed lag. Only use a version after its own filing date; do not carry a later revision backward. Treat date-only public records as usable for decisions at the end of their filing day, with execution at the next listed session. If the actual filing dates are absent, state that exact historical alignment cannot be established from these inputs rather than inventing dates."}

def main():
    if (ROOT/'FREEZE.json').exists(): raise SystemExit('Already frozen; create an explicitly versioned extension instead.')
    (ROOT/'prompts').mkdir(exist_ok=True)
    prompts=[]
    for schema in SCHEMAS:
        for condition in CONDITIONS:
            for repeat in range(1,4):
                # Identical prompts within a cell: repeats measure generation
                # variation, not a change of dataset or instruction wording.
                fx=make_fixture(11,schema)
                rows=sorted(fx['payload']['filings'],key=lambda x:x['row_id'])
                sample=rows[:3]+rows[-2:]
                text=BASE+'\n'+SCHEMAS[schema]+'\n'+CONDITIONS[condition]+'\nExample filing rows:\n'+json.dumps(sample,indent=2)
                trial=f'{schema}_{condition}_r{repeat}'
                (ROOT/'prompts'/f'{trial}.txt').write_text(text+'\n')
                prompts.append({'id':trial,'schema':schema,'condition':condition,'repeat':repeat,'file':f'prompts/{trial}.txt','sha256':hashlib.sha256((text+'\n').encode()).hexdigest()})
    orders={}
    for vendor in ['GPT-6 High','Gemini 3.1 Pro High']:
        items=[p['id'] for p in prompts]
        random.Random(7521 if vendor.startswith('GPT') else 7522).shuffle(items)
        orders[vendor]=items
    config={'design':'3 schemas x 3 prompts x 3 first generations x 2 vendors',
      'planned_model_generations':54,'obtained_model_generations':0,
      'models':['GPT-6 High','Gemini 3.1 Pro High'],
      'model_scope':'UI labels are targets, not verified backend identifiers. Record actual label/settings before first request; changes require amendment.',
      'evaluation_seeds':[101,202,303,404,505],
      'economic_sensitivity_seeds':list(range(1001,1021)),
      'economic_regimes':['null','pre_only','post_only','mixed'],
      'weight_difference_tolerance':1e-8,'gross_tolerance':1e-8,
      'generation_unit':'One fresh conversation, no correction or repair. Repeated execution seeds are not independent model samples.',
      'tool_policy':'No tools requested. Observed tool use retained as a deviation and separately reported.',
      'infrastructure':'External code requires successful isolated runner preflight; no host fallback. Two consecutive request failures pause that vendor. Failed first calls remain missing.',
      'stop_rule':'Complete scheduled grid. If neither vendor has any confirmed numerical temporal witness on schemas dates/revisions, report negative pilot and stop broad expansion. Missing-date abstention alone is not a failure. Expand only if each vendor has witnesses in at least two of three mechanisms (report-date, revision, invented-date leakage), each repeated in >=2/3 generations in at least one prompt cell. Otherwise report bounded case. This is an effort-allocation rule, not a significance threshold.',
      'not_in_primary_grid':['non-backtest wording','conflicting retrieved rules','multi-turn persistence','13F external validation'],
      'primary_limits':'Synthetic stress data; deliberately simplified parsed holdings signal. No LLM model results at freeze. No population rate, market alpha, or cognitive knowledge claim.'}
    (ROOT/'study_config.json').write_text(json.dumps(config,indent=2)+'\n')
    (ROOT/'prompt_index.json').write_text(json.dumps(prompts,indent=2)+'\n')
    (ROOT/'run_order.json').write_text(json.dumps(orders,indent=2)+'\n')
    (ROOT/'run_log.json').write_text('[]\n')
    payload={'status':'prototype_validated_no_external_model_calls','planned':54,'submitted':0,'returned':0,'pending':0}
    (ROOT/'STATUS.json').write_text(json.dumps(payload,indent=2)+'\n')
    immutable=['engine.py','sandbox.py','worker.py','Dockerfile','build_study.py','validate.py','record_response.py',
               'study_config.json','prompt_index.json','run_order.json','registration.txt','source_audit.json']
    immutable += [p['file'] for p in prompts]
    hashes={s:hashlib.sha256((ROOT/s).read_bytes()).hexdigest() for s in immutable}
    freeze={'timestamp_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
            'model_responses_at_freeze':0,'registration_type':'local prospective record, not public third-party registration',
            'files':hashes}
    (ROOT/'FREEZE.json').write_text(json.dumps(freeze,indent=2)+'\n')
    (ROOT/'Prompts_27.txt').write_text('\n\n'.join('===== '+p['id']+' =====\n'+(ROOT/p['file']).read_text() for p in prompts))
    print(json.dumps({'prompts':len(prompts),'planned_calls':54,'freeze':freeze['timestamp_utc']},indent=2))

if __name__=='__main__':main()
