"""Import verified UI code copies; keep capture provenance beside raw answers."""
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
EXCHANGE=Path('/workspace/shared/disclosure_code_run')
attempts=json.loads((EXCHANGE/'attempts.json').read_text())
records=json.loads((ROOT/'run_log.json').read_text())
destination=ROOT/'capture_metadata'
destination.mkdir(exist_ok=True)
for a in attempts:
    if a['status'] not in ('returned','missing') or any(r['model']==a['model'] and r['trial']==a['trial_id'] for r in records):
        continue
    token=('GPT' if a['model'].startswith('GPT') else 'GEM')+'_'+a['trial_id']
    if a['status']=='missing':
        subprocess.run([sys.executable,str(ROOT/'record_response.py'),'--trial',a['trial_id'],
                        '--model',a['model'],'--outcome','missing','--failure-reason',a['failure_reason'],
                        '--submitted-at',a['submitted_at'],'--returned-at',a['returned_at'],
                        '--settings',a['settings']],check=True,stdout=subprocess.DEVNULL)
        (destination/(token+'.json')).write_text(json.dumps(a,indent=2)+'\n')
        for source in (EXCHANGE/'raw').glob(token+'.*'):
            shutil.copyfile(source,destination/source.name)
        print('Recorded technical missing '+token,flush=True)
        continue
    subprocess.run([sys.executable,str(ROOT/'record_response.py'),'--trial',a['trial_id'],
                    '--model',a['model'],'--raw',str(EXCHANGE/'raw'/(token+'.txt')),
                    '--submitted-at',a['submitted_at'],'--returned-at',a['returned_at'],
                    '--settings',a['settings']],check=True,stdout=subprocess.DEVNULL)
    (destination/(token+'.json')).write_text(json.dumps(a,indent=2)+'\n')
    for source in (EXCHANGE/'raw').glob(token+'.*'):
        if source.name!=token+'.txt':shutil.copyfile(source,destination/source.name)
    print('Recorded '+token,flush=True)
