DISCLOSURE CODE PILOT — 7 NOVEMBER 2026

Observed answers: 54 total = 50 primary + 4 A03 technical recoveries.
Primary design: 54 slots; 54 attempted, 4 technical missing,
0 pending, 0 unattempted.
Primary evaluated programs: 50; valid seed scores: 240.
A03 evaluated programs: 4; valid seed scores: 20.
Seed runs are not independent model generations. No answer was regenerated or repaired.

Primary evidence
- Dated programs: 33; temporal witnesses: 0.
- Oracle matches on every seed: 21; genuine dated information abstentions: 0.
- Whole-output interface refusals: 1; these are not successful timing judgments.
- Missing-date programs: 17; stress witnesses: 9.
- Malformed-output programs: 2; they are not timing failures.
- A03 stress witnesses: 1; dated witnesses: 0.
- Primary integrity audit: 450/450; A03 audit: 45/45.

Read first
report/Disclosure_Code_Pilot_2026-11-07.pdf and .tex: English report and LaTeX.
results/interim_findings.json: exact primary cell counts and witness provenance.
technical_recovery/SUMMARY.json: separate recovery counts.
results/full_horizon/SUMMARY.json: D01 post-hoc all-period diagnostic.
results/full_horizon/rule_classification.json: per-program timing rules with source anchors.
STATUS.json and operational_blockers.json: exact current state.

Main descriptive finding, corrected 8 November 2026
Among 12 GPT dated P0/P1 answers, 10 implement max(filing_date, period_end+60).
P0 and P1 each have 5/6 such floors. This is NOT filing_date+60.
Nine of the ten also exclude the eligibility day. The other two programs are
one strict filing-date boundary and GPT_dates_P0_r3's interface refusal.
The latter rejects the whole output because the final decision has no next
execution session; its code uses filing dates, with no sixty-day floor.
All six GPT P2 dated programs match the oracle. All 18 Gemini dated programs
match it (15 primary + 3 A03). This is a bounded observed vendor contrast.

D01 diagnostic, explicitly post-hoc
The frozen perturbation generator covers the first two report periods.
D01 checks all 477 decision days and six report periods on the same five seeds.
35 portfolio-producing programs give 175/175 all-day policy matches (83,475
daily vectors). Matching a delayed policy is not matching the oracle.
3,360 assessable distinct future-filing interventions have no numerical witness.
60 interventions for the single refusing program are unassessable.
There are 3,600 isolated executions, zero new model generations. Dated refusal
is excluded from success. Full calendars remain unchanged; identical filing
interventions are deduplicated exactly. Daily future-price tests were not added.
Original scores, raw statuses, sources, prompts and stopping rule are unchanged.
The full-horizon result is bounded to the fixed synthetic fixtures.

Reproduction and provenance
FREEZE.json, registration.txt and run_order.json preserve the original design.
Amendments A01/A02 cover validated isolation and concurrency. A03 prospectively
permits one recovery for each of four draft-only technical failures. The primary
missing records remain unchanged; recovery-inclusive views are explicitly labelled.
model_responses/ and technical_recovery/ retain raw answers and unmodified source.
results/model_evaluation/ and technical_recovery/ retain complete seed outputs.
capture_metadata/ records UI settings, transport recovery and capture method.
GPT long code uses the code-block Copy control; Gemini uses whole-response Copy.
Unneeded authentication query strings and account labels were removed from
capture metadata, never from raw model code or scoring evidence.

Audit commands, run from this directory
  python audit_saved_results.py
  python audit_recovery.py
  python audit_full_horizon_saved.py
These re-score saved outputs; they do not request models or execute candidates.
evaluate_recorded.py and evaluate_recovery.py use the A01 isolated runner for
unevaluated answers only. Never execute candidate code directly on the host.
Runtime: bubblewrap plus default-deny seccomp; no network, host workspace,
credentials or subprocess access. Requested Python 3.11-compatible source runs
under CPython 3.13.5, a disclosed environment deviation.

Limits and stopping
This is a synthetic parsed-holdings implementation pilot, not market alpha,
financial loss estimation, general model safety, or publication-ready novelty.
An assumed release lag can fail under late-report stress without pretending
to know true missing dates. A conservative delay is not look-ahead. An abstaining
or cash-only program is not automatically useful task completion.
No dated witnesses across both vendors calls for stopping broad expansion under
the original effort-allocation rule; missing-date witnesses alone do not meet
the two-mechanism criterion. Do not choose harder cases merely to force failures.
Observation timestamps include collection/login delays and are not model latency.

Earlier manuscripts are not replaced. archive/README_at_freeze.txt and
archive/operational_blockers_at_30.json preserve earlier protocol/collection state.
