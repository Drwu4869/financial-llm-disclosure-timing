def build_strategy(payload):
    """
    Constructs a holdings-based cross-sectional mean-reversion portfolio 
    signal from SEC Form N-PORT filings.
    """
    dates = payload.get("dates", [])
    assets = payload.get("assets", [])
    filings = payload.get("filings", [])

    if not dates or not assets:
        return {
            "status": "insufficient_data",
            "reason": "Missing dates or assets in the payload.",
            "weights": []
        }

    N = len(assets)
    # The payload uses weight_pct (percentages), so the equal-weight level is 100/N.
    equal_weight_pct = 100.0 / N

    # Sort filings chronologically by filing_date
    sorted_filings = sorted(filings, key=lambda x: x["filing_date"])
    num_filings = len(sorted_filings)

    # State trackers
    # current_best tracks the latest valid filing dict for each asset
    current_best = {a: None for a in assets}
    # active_weights tracks the applied weight_pct for each asset
    active_weights = {a: equal_weight_pct for a in assets}

    weights_out = []
    filing_idx = 0

    for decision_date in dates:
        # Decisions occur at the end of the day, so filings filed <= decision_date are known
        while filing_idx < num_filings and sorted_filings[filing_idx]["filing_date"] <= decision_date:
            f = sorted_filings[filing_idx]
            a = f.get("asset")

            # Process only assets within the defined fixed universe
            if a in current_best:
                best_f = current_best[a]

                # A filing applies if it has the highest period_end seen so far,
                # or if the period_end matches but it has a higher version (revision).
                is_better = False
                if best_f is None:
                    is_better = True
                else:
                    if f["period_end"] > best_f["period_end"]:
                        is_better = True
                    elif f["period_end"] == best_f["period_end"] and f["version"] > best_f["version"]:
                        is_better = True

                if is_better:
                    current_best[a] = f
                    active_weights[a] = f.get("weight_pct", 0.0)

            filing_idx += 1

        # Construct the asset vector
        raw_w = [active_weights[a] for a in assets]
        
        # Subtract the cross-sectional mean
        mean_w = sum(raw_w) / N
        centered_w = [w - mean_w for w in raw_w]

        # Normalize absolute weights to sum to one (gross exposure == 1.0)
        sum_abs = sum(abs(w) for w in centered_w)

        # Handle zero-exposure vectors cleanly by returning cash (zeros)
        if sum_abs < 1e-12:
            final_w = [0.0] * N
        else:
            final_w = [w / sum_abs for w in centered_w]

        weights_out.append(final_w)

    return {
        "status": "ok",
        "reason": "Applied latest known N-PORT weights per decision date; defaulted to equal-weight percentage before first observation.",
        "weights": weights_out
    }

