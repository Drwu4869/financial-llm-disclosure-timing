from typing import Dict, Any, List

def build_strategy(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Builds a mean-reverting holdings-based portfolio signal using point-in-time N-PORT filings.
    """
    dates: List[str] = payload.get('dates', [])
    assets: List[str] = payload.get('assets', [])
    filings: List[Dict[str, Any]] = payload.get('filings', [])
    
    # Check for sufficient data to operate
    if not dates or not assets:
        return {
            'status': 'insufficient_data',
            'reason': 'Payload is missing required dates or assets for evaluation.',
        }
        
    num_assets = len(assets)
    equal_weight = 100.0 / num_assets
    weights: List[List[float]] = []
    
    # Pre-group filings by asset to optimize the point-in-time lookup
    filings_by_asset: Dict[str, List[Dict[str, Any]]] = {asset: [] for asset in assets}
    for filing in filings:
        asset = filing.get('asset')
        if asset in filings_by_asset:
            filings_by_asset[asset].append(filing)
            
    for current_date in dates:
        row_raw_weights: List[float] = []
        
        for asset in assets:
            # Filter filings available on or before the decision date
            available_filings = [
                f for f in filings_by_asset[asset] 
                if f.get('filing_date', '9999-99-99') <= current_date
            ]
            
            if not available_filings:
                # Before any applicable observation use the equal-weight level
                row_raw_weights.append(equal_weight)
            else:
                # Find the most recent report period
                max_period_end = max(f['period_end'] for f in available_filings)
                latest_period_filings = [f for f in available_filings if f['period_end'] == max_period_end]
                
                # Find the highest version for that specific report period
                max_version = max(f['version'] for f in latest_period_filings)
                target_filing = next(f for f in latest_period_filings if f['version'] == max_version)
                
                row_raw_weights.append(target_filing.get('weight_pct', 0.0))
                
        # 1. Subtract the cross-sectional mean
        cross_sectional_mean = sum(row_raw_weights) / num_assets
        centered_weights = [w - cross_sectional_mean for w in row_raw_weights]
        
        # 2. Normalize absolute weights to sum to one
        absolute_sum = sum(abs(w) for w in centered_weights)
        
        if absolute_sum > 1e-9:
            normalized_weights = [w / absolute_sum for w in centered_weights]
        else:
            # Return cash (zero weights) when the centered vector is zero
            normalized_weights = [0.0 for _ in range(num_assets)]
            
        weights.append(normalized_weights)

    return {
        'status': 'ok',
        'reason': 'Point-in-time alignment successful. Used filing_date to prevent lookahead. Missing pre-filing values defaulted to 1/N. Demeaned and normalized gross exposure to 1.0 (net 0.0).',
        'weights': weights
    }

