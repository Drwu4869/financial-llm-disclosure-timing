def build_strategy(payload: dict) -> dict:
    """
    Builds a market-neutral portfolio signal based on historical fund holdings
    without look-ahead bias.
    """
    dates = payload.get('dates', [])
    assets = payload.get('assets', [])
    filings = payload.get('filings', [])
    
    if not dates or not assets:
        return {
            "status": "insufficient_data",
            "reason": "Missing dates or assets in the payload.",
            "weights": []
        }
        
    num_assets = len(assets)
    # The default assumption for an asset before any filings is its equal-weight percentage.
    # We use 100.0 / N because Form N-PORT weight_pct is reported in percentages.
    equal_weight_pct = 100.0 / num_assets
    
    # Pre-group filings by asset for faster O(1) key lookup
    filings_by_asset = {asset: [] for asset in assets}
    for filing in filings:
        asset_name = filing.get('asset')
        if asset_name in filings_by_asset:
            filings_by_asset[asset_name].append(filing)
            
    # Sort filings for each asset by period_end (DESC), then version (DESC).
    # This guarantees that as we iterate through the list for a specific decision date, 
    # the first filing we encounter with a filing_date <= decision_date will inherently 
    # be the most recent applicable report period and the highest known version.
    for asset_name in assets:
        filings_by_asset[asset_name].sort(
            key=lambda x: (x.get('period_end', ''), x.get('version', 0)), 
            reverse=True
        )

    weights_matrix = []
    
    for decision_date in dates:
        raw_weights = []
        
        for asset in assets:
            # Find the applicable filing: filed on or before the decision date
            applicable_filing = None
            for filing in filings_by_asset[asset]:
                if filing.get('filing_date', '') <= decision_date:
                    applicable_filing = filing
                    break
            
            # If an observation is available, use its weight, otherwise use the equal-weight level
            if applicable_filing is not None:
                raw_weights.append(applicable_filing.get('weight_pct', equal_weight_pct))
            else:
                raw_weights.append(equal_weight_pct)
                
        # 1. Centering: Subtract the cross-sectional mean (Ensures net exposure = 0)
        cross_sectional_mean = sum(raw_weights) / num_assets
        centered_weights = [w - cross_sectional_mean for w in raw_weights]
        
        # 2. Normalization: Absolute weights sum to 1 (Ensures gross exposure <= 1)
        abs_sum = sum(abs(w) for w in centered_weights)
        
        if abs_sum < 1e-9:
            # The centered vector is essentially zero; return cash (all 0s)
            weights_matrix.append([0.0] * num_assets)
        else:
            weights_matrix.append([w / abs_sum for w in centered_weights])
            
    return {
        "status": "ok",
        "reason": "Successfully aligned filings with decision dates avoiding look-ahead bias, prioritizing max period_end and version.",
        "weights": weights_matrix
    }

