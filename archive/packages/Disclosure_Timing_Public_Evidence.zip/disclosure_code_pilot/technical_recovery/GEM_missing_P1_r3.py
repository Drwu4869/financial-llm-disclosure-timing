import datetime

def build_strategy(payload):
    """
    Builds a holdings-based portfolio signal without look-ahead bias.
    """
    dates = payload.get('dates', [])
    assets = payload.get('assets', [])
    filings = payload.get('filings', [])
    
    if not dates or not assets:
        return {
            'status': 'insufficient_data',
            'reason': 'Missing dates or assets in the provided payload.',
            'weights': []
        }
    
    # Process filings and enforce a publication lag to avoid look-ahead bias.
    # Assumption: Public portions of 3rd-fiscal-month Form N-PORT reports are filed 
    # and made public no later than 60 days after the report period_end.
    # Without specific filing_date timestamps, we add 60 days to period_end.
    asset_history = {asset: [] for asset in assets}
    
    for row in filings:
        asset = row.get('asset')
        if asset not in asset_history:
            continue
        
        period_end = datetime.date.fromisoformat(row['period_end'])
        pub_date = period_end + datetime.timedelta(days=60)
        
        # Convert weight_pct to decimal
        weight = float(row['weight_pct']) / 100.0 
        
        asset_history[asset].append({
            'period_end': period_end,
            'pub_date': pub_date,
            'weight': weight
        })
        
    weights_matrix = []
    
    for dt_str in dates:
        current_date = datetime.date.fromisoformat(dt_str)
        raw_weights = []
        
        for asset in assets:
            # Equal-weight level before any applicable observation
            current_weight = 1.0 / len(assets)
            
            # Find all filings available on or before the decision date
            available_filings = [f for f in asset_history[asset] if f['pub_date'] <= current_date]
            
            if available_filings:
                # Use the filing with the most recent report period available
                best_filing = max(available_filings, key=lambda x: x['period_end'])
                current_weight = best_filing['weight']
                
            raw_weights.append(current_weight)
            
        # Cross-sectional mean centering
        mean_weight = sum(raw_weights) / len(assets)
        centered_weights = [w - mean_weight for w in raw_weights]
        
        # Normalize absolute weights to sum to one
        sum_abs = sum(abs(w) for w in centered_weights)
        
        if sum_abs > 1e-12:
            final_weights = [w / sum_abs for w in centered_weights]
        else:
            # Return cash (all zeros) when the centered vector is zero
            final_weights = [0.0 for _ in assets]
            
        weights_matrix.append(final_weights)
        
    return {
        'status': 'assumption',
        'reason': 'Assumed a 60-day SEC publication lag for N-PORT period_end to avoid look-ahead bias.',
        'weights': weights_matrix
    }

