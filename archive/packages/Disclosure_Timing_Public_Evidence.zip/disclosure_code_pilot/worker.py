"""Container-only worker. Never run external candidate code directly on host."""
import contextlib
import copy
import importlib.util
import io
import json
import resource
import sys

resource.setrlimit(resource.RLIMIT_CPU,(70,70))
resource.setrlimit(resource.RLIMIT_FSIZE,(32_000_000,32_000_000))
request=json.load(sys.stdin)
outputs=[]
for payload in request['payloads']:
    # Reload candidate for each intervention to prevent module-state carryover.
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            spec=importlib.util.spec_from_file_location('candidate','/candidate.py')
            module=importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            answer=module.build_strategy(copy.deepcopy(payload))
        outputs.append(answer)
    except Exception as exc:
        outputs.append({'status':'execution_error','error':type(exc).__name__+': '+str(exc)[:1000]})
json.dump(outputs,sys.stdout,allow_nan=False)
