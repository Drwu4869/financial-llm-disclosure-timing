"""Re-score A03 outputs and verify separation from primary missing slots."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
from engine import make_fixture, interventions, score

ROOT=Path(__file__).resolve().parent;D=ROOT/'technical_recovery'
checks=[]
def check(label,value):checks.append({'check':label,'passed':bool(value)})
plan=json.loads((ROOT/'amendments/A03_technical_recovery.json').read_text())
attempts=json.loads((D/'attempts.json').read_text())
log=json.loads((ROOT/'run_log.json').read_text())
check('recovery order',[a['trial_id'] for a in attempts]==plan['order'][:len(attempts)])
for a in attempts:
 t=a['trial_id'];token='GEM_'+t
 check(token+': registered before request',dt.datetime.fromisoformat(a['submitted_at'])>dt.datetime.fromisoformat(plan['registered_at']))
 check(token+': frozen prompt hash',hashlib.sha256((ROOT/'prompts'/(t+'.txt')).read_bytes()).hexdigest()==plan['prompt_sha256'][t])
 check(token+': primary remains missing',any(x['model']==a['model'] and x['trial']==t and x['outcome']=='missing' for x in log))
 if a['status']!='returned':continue
 r=json.loads((D/(token+'.json')).read_text());raw=(D/(token+'.txt')).read_text();source=(D/(token+'.py')).read_text()
 check(token+': raw hash',hashlib.sha256(raw.encode()).hexdigest()==r['raw_sha256'])
 blocks=re.findall(r'```(?:python|py)?\s*\n(.*?)```',raw,re.S)
 check(token+': unchanged code extraction',len(blocks)==1 and blocks[0]==source)
 check(token+': executed code hash',hashlib.sha256(source.encode()).hexdigest()==r['code_sha256'])
 for s in r['seeds']:
  f=make_fixture(s['seed'],t.split('_')[0]);outputs=json.loads((D/s['outputs_file']).read_text())
  try:check(token+': score '+str(s['seed']),score(f,outputs,interventions(f))==s.get('score'))
  except Exception as exc:check(token+': format '+str(s['seed']),type(exc).__name__+': '+str(exc)==s.get('execution_or_scoring_error'))
out={'audited_at':dt.datetime.now(dt.timezone.utc).isoformat(),'passed':sum(c['passed'] for c in checks),'total':len(checks),'checks':checks,
     'scope':'Identity and saved-score audit; no model generation or candidate re-execution.'}
(D/'AUDIT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='checks'},indent=2))
assert out['passed']==out['total']
