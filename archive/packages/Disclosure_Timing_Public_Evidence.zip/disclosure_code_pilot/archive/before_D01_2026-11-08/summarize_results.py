"""Summarize retained first responses without changing frozen scoring rules."""
import datetime as dt
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
status=json.loads((ROOT/'STATUS.json').read_text())
records=json.loads((ROOT/'run_log.json').read_text())
results=[json.loads(p.read_text()) for p in sorted((ROOT/'results/model_evaluation').glob('*.json')) if not p.name.endswith('_outputs.json')]
previous=json.loads((ROOT/'results/interim_findings.json').read_text()) if (ROOT/'results/interim_findings.json').exists() else {}
reviews={x['token']:x.get('mechanism_review') for x in previous.get('witness_provenance',[])}
returned=[r for r in results if r['outcome']=='evaluated']
dated=[r for r in returned if not r['trial'].startswith('missing_')]
undated=[r for r in returned if r['trial'].startswith('missing_')]
def token(r):return ('GPT' if r['model'].startswith('GPT') else 'GEM')+'_'+r['trial']
def scores(r):return [s['score'] for s in r['seeds'] if 'score' in s]
def abstains(r):return r['valid_seeds']==5 and all(s['status']=='insufficient_data' for s in scores(r))
def matches(r):return r['valid_seeds']==5 and all(s.get('oracle_weight_mae') is not None and s['oracle_weight_mae']<=1e-8 for s in scores(r))
cells=[]
for model in ['GPT-6 High','Gemini 3.1 Pro High']:
 for schema in ['dates','missing','revisions']:
  for prompt in ['P0','P1','P2']:
   rs=[r for r in results if r['model']==model and r['trial'].startswith(schema+'_'+prompt+'_')]
   cells.append({'model':model,'schema':schema,'prompt':prompt,'planned':3,
      'closed_attempts':len(rs),'returned':sum(r['outcome']!='missing' for r in rs),
      'technical_missing':sum(r['outcome']=='missing' for r in rs),
      'valid_programs':sum(r['valid_seeds']==5 for r in rs),
      'invalid_programs':sum(r['outcome']!='missing' and r['valid_seeds']==0 for r in rs),
      'witness_programs':sum(r['has_numerical_witness'] for r in rs),
      'valid_abstentions':sum(abstains(r) for r in rs),
      'oracle_matches':sum(matches(r) for r in rs) if schema!='missing' else None})
witnesses=[]
for r in returned:
 if not r['has_numerical_witness']:continue
 item=next(s for s in r['seeds'] if s.get('score',{}).get('numerical_leakage_witness'))
 s=item['score']
 witnesses.append({'token':token(r),'seed':item['seed'],'status':s['status'],'reason':s['reason'],
                   'witness_example':s['witnesses'][0],
                   'mechanism_review':reviews.get(token(r),'Pending source inspection; numerical witness alone does not identify a cognitive mechanism.')})
out={'created_at':dt.datetime.now(dt.timezone.utc).isoformat(),'interim':status['submitted']<54 or bool(status['pending']),
     'planned':54,'attempted':status['submitted'],'returned':status['returned'],'technical_missing':status['missing'],
     'unsubmitted':54-status['submitted'],'pending':len(status['pending']),'evaluated':status['evaluated_answers'],
     'seed_execution_attempts':sum(len(r['seeds']) for r in results),'valid_seed_scores':status['valid_seed_evaluations'],
     'dated_programs':len(dated),'dated_numerical_witnesses':sum(r['has_numerical_witness'] for r in dated),
     'dated_valid_abstentions':sum(abstains(r) for r in dated),'dated_oracle_matches':sum(matches(r) for r in dated),
     'missing_date_programs':len(undated),'missing_date_numerical_witnesses':sum(r['has_numerical_witness'] for r in undated),
     'missing_date_valid_abstentions':sum(abstains(r) for r in undated),
     'programs_with_no_valid_seed':[token(r) for r in returned if r['valid_seeds']==0],
     'technical_missing_trials':[token(r) for r in results if r['outcome']=='missing'],
     'witness_provenance':witnesses,'cells':cells,
     'limits':['First generations, not execution seeds, are the sampling units.',
               'Missing requests and malformed abstentions are not timing errors.',
               'Declared lag assumptions are stress-tested; they do not identify actual missing release dates.',
               'Synthetic return effects are not market alpha or economic materiality.']}
(ROOT/'results/interim_findings.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('cells','witness_provenance','limits')},indent=2))
