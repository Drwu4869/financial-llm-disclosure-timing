"""Render an English LaTeX protocol and a labelled control-calibration figure."""
import json
import os
import pathlib
import shutil
import subprocess
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT/'report';OUT.mkdir(exist_ok=True)
v=json.loads((ROOT/'results/baseline_validation.json').read_text())
f=json.loads((ROOT/'FREEZE.json').read_text())
b=json.loads((ROOT/'data/real_metadata_bridge.json').read_text())
status=json.loads((ROOT/'STATUS.json').read_text())
findings=json.loads((ROOT/'results/interim_findings.json').read_text())
recovery_path=ROOT/'technical_recovery/SUMMARY.json'
recovery=json.loads(recovery_path.read_text()) if recovery_path.exists() else {'returned':0,'evaluated':0,'valid_seed_evaluations':0,'witness_programs':0,'dated_witness_programs':0}
recoveries=[json.loads(p.read_text()) for p in (ROOT/'technical_recovery').glob('GEM_*.json') if not p.name.endswith('_outputs.json')]
recovery_rows=[]
for rr in recoveries:
    ss=[s['score'] for s in rr['seeds'] if 'score' in s]
    match='n/a' if rr['trial_id'].startswith('missing_') else ('yes' if len(ss)==5 and all(s.get('oracle_weight_mae') is not None and s['oracle_weight_mae']<=1e-8 for s in ss) else 'no')
    recovery_rows.append(rr['trial_id'].replace('_',r'\_')+' & '+str(rr['valid_seeds'])+'/5 & '+str(int(rr['has_numerical_witness']))+' & '+match+r'\\')
model_runs=[json.loads(p.read_text()) for p in (ROOT/'results/model_evaluation').glob('*.json') if not p.name.endswith('_outputs.json')]
model_rows=[]
for schema in ['dates','missing','revisions']:
    for prompt in ['P0','P1','P2']:
        cells=[]
        for model in ['GPT-6 High','Gemini 3.1 Pro High']:
            rs=[r for r in model_runs if r['model']==model and r['trial'].startswith(schema+'_'+prompt+'_')]
            completed=sum(r['outcome']=='evaluated' for r in rs)
            valid=sum(r['valid_seeds']==5 for r in rs)
            witnesses=sum(r['has_numerical_witness'] for r in rs)
            abstentions=sum(bool(r['seeds']) and all(s.get('score',{}).get('status')=='insufficient_data' for s in r['seeds']) for r in rs)
            matches=sum(r['valid_seeds']==5 and all(s.get('score',{}).get('oracle_weight_mae') is not None and s['score']['oracle_weight_mae']<=1e-8 for s in r['seeds']) for r in rs)
            cells.extend([str(completed)+'/3',str(witnesses)+'/'+str(valid) if valid else '--',str(matches) if schema!='missing' else '--',str(abstentions) if valid else '--'])
        model_rows.append(schema+' / '+prompt+' & '+' & '.join(cells)+r'\\')
policies=['point_in_time','report_date','global_latest','fixed60','max_filing60']
labels=['Point-in-time','Report date','Latest overwrite','Fixed 60','Max(filing, 60)']
colors=['#286D66','#B34B45','#C18435','#7564A1','#587D9B']
fig,axes=plt.subplots(1,2,figsize=(10,3.3))
for ax,regime,title in zip(axes,['null','mixed'],['No planted return signal','Pre- and post-release signals']):
    for i,(policy,label,color) in enumerate(zip(policies,labels,colors)):
        item=next(x for x in v['economics'] if x['regime']==regime and x['policy']==policy)
        value=item['mean_sharpe']
        ax.bar(i,value,color=color,width=.65)
        ax.errorbar(i,value,yerr=[[value-item['min_sharpe']],[item['max_sharpe']-value]],fmt='none',color='#333333',capsize=3,lw=.8)
    ax.axhline(0,color='#666666',lw=.7)
    ax.set_xticks(range(5),labels,rotation=25,ha='right',fontsize=8)
    ax.set_title(title,fontsize=10)
    ax.set_ylabel('Annualized Sharpe (synthetic, gross)',fontsize=9)
    ax.spines[['top','right']].set_visible(False)
    ax.grid(axis='y',alpha=.15)
fig.suptitle('Hand-written control simulations: 20 fixed seeds per policy',fontsize=11)
fig.tight_layout();fig.savefig(OUT/'control_calibration.pdf');fig.savefig(OUT/'control_calibration.png',dpi=170);plt.close(fig)

rows=[]
for policy,label in zip(policies+['all_cash','future_price'],labels+['All cash','Future price']):
    counts=[]
    for schema in ['dates','missing','revisions']:
        ds=[x for x in v['audit_cases'] if x['schema']==schema]
        counts.append(f"{sum(bool(x['policies'][policy]['numerical_leakage_witness']) for x in ds)}/5")
    rows.append(label+' & '+' & '.join(counts)+r'\\')
table='\n'.join(rows)
metrics=[]
for regime in ['null','pre_only','post_only','mixed']:
    vals=[]
    for p in ['point_in_time','report_date','fixed60']:
        vals.append(f"{next(x['mean_sharpe'] for x in v['economics'] if x['regime']==regime and x['policy']==p):.2f}")
    metrics.append(regime.replace('_',' ')+ ' & '+' & '.join(vals)+r'\\')

tex=r'''\pdfoutput=1
\pdfmapfile{+lm.map}
\pdfmapfile{+cm.map}
\documentclass[10pt,a4paper]{article}
\usepackage[margin=20mm]{geometry}
\usepackage[T1]{fontenc}
\usepackage{lmodern,booktabs,tabularx,array,graphicx,amsmath,enumitem,xcolor,fancyhdr}
\usepackage[colorlinks=true,urlcolor=blue,linkcolor=blue,citecolor=blue]{hyperref}
\pagestyle{fancy}\fancyhf{}\fancyhead[L]{\small Disclosure code pilot}\fancyhead[R]{\small 7 November 2026}\fancyfoot[C]{\thepage}
\setlength{\headheight}{14pt}\setlength{\parindent}{0pt}\setlength{\parskip}{6pt}
\setlist{nosep,leftmargin=*}\renewcommand{\arraystretch}{1.17}
\newcolumntype{Y}{>{\raggedright\arraybackslash}X}
\begin{document}
\begin{center}{\LARGE From Disclosure Rules to Executable Backtests}\par\vspace{5pt}
{\large An availability-aware code-generation pilot}\par\vspace{5pt}
Prepared for Changyi Wu \quad 7 November 2026\end{center}

\textbf{Delivery status.} Of 54 primary slots, \textbf{@@RETURNED@@ answers returned}, @@MISSING@@ have technical missingness, @@UNSUBMITTED@@ are unattempted and @@PENDING@@ are pending. A03 separately recovered @@REC_RETURNED@@ answers, giving \textbf{@@COMBINED@@ actual model responses}. Primary and supplemental results remain separate. Before candidate execution, the isolated runtime passed nine isolation checks and 120 reference-output comparisons. This is a pilot report, not a publication-ready empirical paper.

\section*{1. The question worth testing}
When a model writes a historical holdings signal, does its program use the information actually available at each decision date? The disclosure-specific issues are the gap between a report's reference date and public release, subsequent restatements, and the absence of release dates in an otherwise usable-looking table.

The earlier N-PORT question-answering experiment yielded incorrect / incorrect / correct / correct answers under four formulations. That motivates testing executable behavior. It does \emph{not} identify an internal state of ``knowing but not using'', and isolated correct answers do not establish that all strong models preserve all time boundaries. Preserve the earlier negative and partial results unchanged.

\textbf{Proposed empirical contribution.} A narrow evaluation of how generated disclosure-data programs choose information availability, with separate measurements of temporal dependence, unnecessary delay, uncertainty handling and useful coverage. The timing distinction and the testing principle already exist; there is no new theorem or validated algorithm at this stage.

\section*{2. Fixed first-generation design}
\begin{tabularx}{\linewidth}{lYY}\toprule Factor & Levels & Purpose\\\midrule
Data schema & Both dates; missing filing date; both dates plus revisions & Separate original alignment, unidentified timing and vintage handling.\\
Prompt & P0: task only; P1: generic warning; P2: explicit date/version contract & Measure default behavior and two interventions.\\
Generation & Three fresh first answers per cell & Observe limited generation variability without repair.\\
Vendor & GPT-6 High; Gemini 3.1 Pro High & Target product labels; actual settings must be recorded.\\\bottomrule
\end{tabularx}

The planned total is $3\times3\times3\times2=\mathbf{54}$ first-generation slots; an attempted submission is not a returned answer. A third vendor would require a prospective amendment and increase the total to 81. The 27 prompt files per vendor have a fixed randomized order. Within a cell the three prompts are identical; every conversation starts fresh.

\textbf{Controlled scope.} One fund, eight synthetic assets, six quarterly snapshots, parsed public N-PORT weights, and 2022--2023 dates. The model returns daily target weights; the harness computes next-session execution and returns. This is a controlled signal-implementation task, not raw-report extraction, open-ended alpha discovery or an entire production trading workflow.

\newpage\section*{3. Score information use before performance}
The model receives a historical archive, not pre-filtered daily snapshots. For a cutoff date, the evaluator holds all observable past information fixed and creates changes confined to unavailable information:
\begin{enumerate}
\item Alter not-yet-public original holdings.
\item Alter not-yet-public revision values.
\item Remove records whose public filing occurs after the cutoff.
\item Alter future price observations while preserving earlier prices.
\end{enumerate}
If an earlier portfolio weight changes by more than $10^{-8}$, the run supplies a concrete temporal-dependence witness. An identical-input repeat first checks numerical stability. Execution failures, malformed outputs, unstable programs and intervention-triggered abstention are reported separately. A finite collection of passing probes does not certify global absence of leakage.

\textbf{Functional correctness and safety differ.} Fully dated cases also receive an oracle-weight error. That detects deviations from the requested signal, including unnecessary delays, but is not itself a leakage label. Cash-only programs receive zero active coverage; silence is not credited as useful completion. A legal conservative assumption should not be mislabeled as use of future data.

\textbf{Missing dates create non-identification.} Consider the same visible holdings table and price history at 26 May. An ordinary report might have been public on 20 May, or not until 7 June. Removing the release field makes both histories consistent with those inputs. Their correct historical positions differ. The package includes this paired example. Exact timing is therefore not uniquely recoverable from the supplied table.

For the missing-date condition, accept an explained inability to establish exact alignment. Record declared lag assumptions separately. Do not score a guessed date against an inaccessible unique answer. An assumption can nevertheless be stress-tested for early information use under each admissible synthetic history.

\textbf{Execution convention.} Synthetic public filing dates are usable for an end-of-day decision, with execution at the next listed session's open and liquidation at that session's close. This is specified measurement timing, not a claim about every real SEC acceptance timestamp. Confidential fields and real after-hours dissemination are excluded.

\section*{4. Returns are an illustration, not the detector}
Use four matched return regimes: no planted signal, a pre-release signal, a post-release signal, and both. Each regime reuses records and random noise for a seed. Five audit seeds test programs; twenty other seeds assess economic sensitivity. Seed repetitions are nested diagnostics, not independent model generations.

A leaky program can lose money in a noisy or null market; a correct program can earn a positive return. Thus a high Sharpe is neither necessary nor sufficient for leakage. Report paired differences and the full distribution instead of dividing by a near-zero benchmark Sharpe. Simulated profits are never presented as market alpha or losses caused by a model.

\newpage\section*{5. Completed calibration on hand-written controls}
\textbf{@@CHECKS@@ checks passed; no failed checks.} The controls include a point-in-time implementation, deliberate report-date use, global revision overwrite, fixed-60 alignment, a conservative maximum of actual filing and day 60, cash-only output, explicit abstention and a future-price leak. An independently specified tiny example checks the oracle's original/revision boundary. These are authored controls, not sampled model answers.

\begin{center}\begin{tabularx}{\linewidth}{Yrrr}\toprule
Control & Both dates & Missing date & Revisions\\\midrule
@@CONTROL_TABLE@@
\bottomrule\end{tabularx}\end{center}
Cells count seeds with a numerical witness out of five; they are not LLM error rates. The point-in-time policy abstains in the missing-date schema. Zero witnesses for cash-only output demonstrate why coverage must also be reported. The original-date control respects amendment release dates, isolating its intended flaw. The global-overwrite control deliberately retains the original date while replacing its value with the final revision.

\includegraphics[width=\linewidth]{control_calibration.pdf}
\textbf{Figure.} Bars are mean gross Sharpe; whiskers span the minimum and maximum across twenty seeds, not confidence intervals. The fixed generator also includes late records, so a blind day-60 rule can be early as well as unnecessarily late. No market or LLM performance is inferred.

\begin{center}\begin{tabular}{lrrr}\toprule
Return regime & Point-in-time & Report date & Fixed 60\\\midrule
@@METRIC_TABLE@@
\bottomrule\end{tabular}\end{center}
The table summarizes the completed \textbf{480 synthetic control runs}: four regimes, six policies, twenty seeds. All-cash Sharpe is undefined and stored as null. The harness separately supports a five-basis-point turnover-cost sensitivity; gross results are shown here.

\newpage\section*{6. Where prior work already overlaps}
\begin{tabularx}{\linewidth}{p{32mm}YY}\toprule Work & Established overlap & Remaining distinction to test\\\midrule
ALPHAQT-BENCH [1] & Generated OHLCV programs; dynamic truncation and functional tests. Strong models can already pass the temporal layer. & Disclosure availability and versions, rather than a new general code-leakage detector.\\
BacktestBench [2] & Strategy-to-code and backtest evaluation; Appendix H excludes corporate reports from its current scope. & Alignment and uncertainty specific to filed holdings.\\
Rigged Backtest [3] & Matched clean/flawed controls for reviewing existing code and prose. & Generating a program, with numerical behavioral checks.\\
Temporal non-interference [4] & Availability versus reference time and vintage reads already appear in its indexed abstract. & Empirical model behavior; full-method comparison remains incomplete.\\
Temporal Leakage [5]; Look-Ahead-Bench [6] & Model-memory contamination and financial workflow evaluation. & Executable input dependence, distinct from training memorization.\\
SynthFin [7] & Synthetic agents with point-in-time financials and filings. & The generated program must implement the availability filter.\\\bottomrule
\end{tabularx}

\textbf{Novelty conclusion.} A targeted search did not establish an identical evaluated design, but absence from this search is not proof of novelty. Neither ``LLMs can leak future data'', ``synthetic backtests'' nor ``two timestamps'' can be claimed as the contribution. The candidate contribution depends on a reproducible disclosure-specific failure or a carefully bounded negative result. Full-text access to [4] failed, and the working repository [7] was not independently reproduced.

\section*{7. What the existing real data can establish}
The earlier SEC metadata audit retained \textbf{349,673} original NPORT-P accessions. The median report-to-filing gap was \textbf{57 calendar days}. A hypothetical day-60 embargo added \textbf{4.13 days} on average, while \textbf{12,612 records (3.61\%)} were filed after day 60. These descriptive date-level findings are preserved in a separate provenance-linked JSON file.

They quantify the timing exposure of alternative alignments, not financial losses. Filing-date granularity cannot prove availability before a particular intraday trade, and an after-day-60 record is not automatically legally late. No real-holdings strategy, transaction-cost-adjusted market PnL or causal economic effect has been tested in this pilot. Do not multiply a planted synthetic return effect by filing counts to manufacture materiality.

\newpage\section*{8. Registration, stopping and current readiness}
\textbf{Local freeze.} @@FREEZE@@. Zero model responses existed at freeze. Immutable prompts, source code, seeds, references and scoring rules are SHA256-recorded in \path{FREEZE.json}. This is a local prospective record, not a public third-party preregistration.

\textbf{Primary analysis.} Count numerical witnesses per vendor, schema and prompt. Keep three generations per cell as the sampling unit; five execution seeds and multiple cutoffs do not increase that sample size. Also report execution failures, missing calls, observed tools, functional errors, active coverage and legitimate abstention. Three generations per cell support a feasibility decision, not precise prevalence estimates.

\textbf{Continuation.} Complete the planned grid without selecting favorable cells. If both vendors have no witnesses on dated inputs, report the negative pilot and stop broad expansion. Expand only if each vendor has failures in at least two mechanisms, with each repeated in at least two of three generations in a cell. Mechanism assignment needs intervention evidence and source-code review. Otherwise retain a bounded case. This allocates research effort rather than defining statistical significance.

\textbf{Execution amendment A01.} Before the first model submission, the unavailable Docker runner was replaced by bubblewrap plus a default-deny seccomp filter. Candidates receive only their source, the worker and public inputs; network operations and subprocess creation are denied. Nine isolation checks and 120 reference-output comparisons passed. Requested Python 3.11-compatible source is executed under CPython 3.13.5; version-specific errors must be separated from timing failures. Frozen prompts, seeds and scoring remain unchanged. Amendment A02, registered after one submission but before any final answer was inspected, permits up to three simultaneous independent conversations while retaining the frozen submission order.

\textbf{Preserve the task's meaning.} Removing the word ``backtest'' is not sufficient to create a valid test: a descriptive plot of holdings by report period may correctly use that period. Any later workflow variant must still require information that was available to the historical decision-maker. Conflicting retrieval sources and multi-turn tasks remain outside this frozen grid.

\textbf{Reproduce.} Run \texttt{python validate.py} for the controls. Read \path{registration.txt} for the complete protocol and \path{README.txt} for execution instructions. Never supply private fixtures, reference policies or scorer code to evaluated models. Record raw first answers and failed attempts without repair. Any frozen-design change gets a dated amendment.

\newpage\section*{9. Model results: observed answers only}
\textbf{Checkpoint.} @@UPDATED@@. Returned: @@RETURNED@@/54; evaluated programs: @@EVALUATED@@; valid within-program seed evaluations: @@SEEDS@@. The unit of model sampling is a first answer, not an execution seed. Login interruptions affected collection; only actual captured responses are counted, and unsubmitted cells are not negative findings.

\begin{center}\small\begin{tabular}{lrrrrrrrr}\toprule
 & \multicolumn{4}{c}{GPT-6 High} & \multicolumn{4}{c}{Gemini 3.1 Pro High}\\
Schema / prompt & N & W/V & Match & Abst. & N & W/V & Match & Abst.\\\midrule
@@MODEL_TABLE@@
\bottomrule\end{tabular}\end{center}
N counts evaluated programs against three planned slots. W/V is witness count over programs valid on all five seeds. Match counts programs matching the oracle on every seed; it is undefined for missing dates. Abst. counts valid insufficient-data responses on every seed. Zero witnesses do not prove safety; @@INVALID@@ programs have no valid seed output. Missing slots are not successes.

\textbf{Do not confuse format with reasoning.} For example, \path{GEM_missing_P2_r2} explicitly states that historical alignment is unidentified, but returns an empty weights list instead of omitting it. The frozen interface rejects that shape. This is retained as an output-format failure, with recognized abstention intent, not a timing failure. Declared fixed-lag assumptions in other missing-date programs can produce numerical witnesses under late-release stress cases; the evidence does not show that those models claimed to know the true missing dates.

\textbf{Observed contrast.} The first default dated GPT program used the later of actual filing and period end plus 60 days, followed by an additional day boundary. It had no witness but delayed the requested signal. Explicit-contract examples instead matched the oracle. These examples illustrate different error directions; the full cell table determines their frequency.

\textbf{Capture.} Actual product settings, raw first answers and complete execution outputs are retained. GPT code was copied through the code-block control because whole-message Copy truncated virtualized code; Gemini used whole-response Copy. Neither method semantically edits the generated program. Product labels do not identify reproducible backend snapshots.

\textbf{Aggregate interpretation.} This checkpoint contains @@DATED@@ dated programs with @@DATED_W@@ detected numerical witnesses: @@MATCH@@ match the oracle on every seed and @@DATED_ABSTAIN@@ validly abstain. The missing-date condition contains @@UNDATED@@ programs, @@UNDATED_W@@ with a witness in a late-release fixture and @@UNDATED_ABSTAIN@@ valid abstentions. Declared lag scenarios are not claims to know actual missing dates. For example, one Gemini program uses status ``ok'' but explicitly says ``Assumed'' in its explanation. These are synthetic stress results, not population rates. The 65- and 70-day assumptions with no detected witness are not certified safe; finite cutoffs can miss dependencies. Details and a concrete witness per affected program are in \path{results/interim_findings.json}.

\textbf{Effort-allocation decision.} @@DECISION@@ Financial materiality, model-family generality and publication-level novelty remain unestablished. A useful finding here must distinguish unnecessary delay, declared assumptions and genuine observed temporal dependence; they cannot be pooled into a single model error rate.

\newpage\section*{10. Separately registered technical recoveries}
Amendment A03 was recorded at 22:44:15 UTC on 7 November 2026, after 43 primary answers but before any supplemental answer. It permits exactly one new submission for each of the four Gemini slots that had closed with no visible user turn or model response. All four were eligible; no returned answer was eligible. The original randomized relative order, prompts, settings, seeds and scorer remain unchanged. The primary table retains its missing entries.

\textbf{Collection quality.} @@MISSING@@ attempted slots produced no model answer and are retained as technical missingness, not failures of reasoning. Drafts remained in the composer after ineffective Send clicks; those closed slots were not silently refilled. Four later GPT drafts were recovered by retargeting a visible Send control after verifying that no user turn or generation existed. Their recovery events are recorded. No generated answer was regenerated, selected or repaired. This UI issue prevents interpreting missingness as random across conditions.

\textbf{Supplemental count.} @@REC_RETURNED@@ answers returned, @@REC_EVALUATED@@ programs evaluated, @@REC_SEEDS@@ valid within-program seed scores. These are shown separately, not silently pooled into the primary sampling denominator.

\begin{center}\begin{tabular}{lrrr}\toprule
Recovered Gemini slot & Valid seeds & Witness & Oracle match\\\midrule
@@REC_TABLE@@
\bottomrule\end{tabular}\end{center}
An oracle match requires error at most $10^{-8}$ on every seed; it is not defined for missing dates. Witness denotes any repeat-stable numerical dependency in a fixed fixture. @@REC_W@@ supplemental programs have a witness; @@REC_DW@@ are dated programs.

\textbf{Why preserve both analyses?} Recovery addresses a delivery problem, but it is still a later generation. Treating it as if the first attempt had succeeded would erase collection history. The recovery-inclusive total is @@COMBINED@@ actual model answers, with every source assigned to its primary or A03 group. Execution seeds are never extra model samples. The original missingness, the prospective recovery rule and the separately stored outputs permit readers to inspect either analysis.

\textbf{Interpretation.} Recovery does not establish a different cognitive mechanism, market profitability or population prevalence. If dated recoveries also have no witness, they strengthen the bounded negative observation without proving global safety. A missing-date witness remains a failure of an assumed release schedule in the synthetic late-release world, not proof of awareness of true hidden dates.

\textbf{Audit.} \path{audit_recovery.py} checks supplemental raw/source identity, prompt hashes, prescribed recovery order, and reproduction of every retained score. \path{technical_recovery/} contains the complete responses and execution outputs. It never changes the primary \path{run_log.json}.

\newpage\section*{11. Sources and reproducibility}
\textbf{References and access scope}\par
\small
[1] Luo et al. \href{https://aclanthology.org/2026.findings-acl.138.pdf}{ALPHAQT-BENCH}. Findings of ACL, 2026. Publisher PDF checked.\par
[2] Wang et al. \href{https://arxiv.org/html/2605.17937v2}{BacktestBench}. arXiv:2605.17937v2; KDD 2026. Full HTML checked.\par
[3] Ulesov et al. \href{https://aclanthology.org/2026.finnlp-1.4.pdf}{Can LLMs Catch a Rigged Backtest?} FinNLP, 2026. Publisher PDF checked.\par
[4] Fonseca. \href{https://arxiv.org/abs/2607.04958}{Look-Ahead-Freedom as Temporal Non-Interference}. Indexed abstract checked; primary full text unavailable in this session.\par
[5] Zhang and Stadie. \href{https://arxiv.org/abs/2608.02985}{Temporal Leakage in LLM Backtesting}. Primary abstract checked.\par
[6] Benhenda. \href{https://arxiv.org/abs/2601.13770}{Look-Ahead-Bench}. Primary abstract checked.\par
[7] \href{https://github.com/David-Hedgefund/synthfin-trading-bench}{SynthFin Trading Bench}. Primary repository description checked; performance not independently validated.\par
[8] SEC. \href{https://www.sec.gov/files/rules/interim/2019/ic-33384.pdf}{Release IC-33384}, 2019. Third-fiscal-month public portions upon filing.\par
[9] SEC. \href{https://www.sec.gov/rules-regulations/staff-guidance/frequently-asked-questions-about-form-13f}{Form 13F FAQs}. Deadline and confidential treatment checked; 13F not in the primary grid.
\normalsize
\subsection*{Reproduction map}
\begin{itemize}
\item \path{FREEZE.json}, \path{registration.txt}, \path{run_order.json}: original immutable design and vendor-specific submission order.
\item \path{amendments/}: prospective runtime and scheduling amendments. No prompt, seed or scoring threshold was changed.
\item \path{run_log.json}, \path{attempts.json}, \path{capture_metadata/}: first-answer provenance, product settings, submission and observation timestamps. Capture delays are not model latency.
\item \path{model_responses/}: verbatim captured text and extracted source, without repair.
\item \path{results/model_evaluation/}: complete isolated execution outputs, scores and environment metadata for every seed, including format failures.
\item \path{audit_saved_results.py}: independently re-score stored outputs and verify immutable files, raw/source hashes and frozen submission order; it makes no model requests.
\item \path{sandbox_bwrap.py}, \path{evaluate_recorded.py}: isolated execution and scoring. Never execute untrusted candidate code directly on the host.
\item \path{operational_blockers.json}: current collection state and exact remaining trial positions. @@UNSUBMITTED@@ slots remain unattempted; closed technical missingness is retained separately.
\end{itemize}
\textbf{Audit command.} From the package directory, run \texttt{python audit\_saved\_results.py}. The retained audit report distinguishes re-scoring checks from model generations. Preserve original runtime-validation receipts; revalidation should use a working copy rather than overwrite prospective evidence.
\end{document}
'''
for k,value in {'CHECKS':str(v['passed']),'CONTROL_TABLE':table,'METRIC_TABLE':'\n'.join(metrics),
                'RETURNED':str(status['returned']),'EVALUATED':str(status['evaluated_answers']),
                'PENDING':str(len(status['pending'])),'SEEDS':str(status['valid_seed_evaluations']),
                'MISSING':str(status['missing']),'UNSUBMITTED':str(54-status['submitted']),
                'DATED':str(findings['dated_programs']),'DATED_W':str(findings['dated_numerical_witnesses']),
                'MATCH':str(findings['dated_oracle_matches']),'DATED_ABSTAIN':str(findings['dated_valid_abstentions']),
                'UNDATED':str(findings['missing_date_programs']),'UNDATED_W':str(findings['missing_date_numerical_witnesses']),
                'UNDATED_ABSTAIN':str(findings['missing_date_valid_abstentions']),
                'REC_RETURNED':str(recovery['returned']),'REC_EVALUATED':str(recovery['evaluated']),
                'REC_SEEDS':str(recovery['valid_seed_evaluations']),'REC_TABLE':'\n'.join(recovery_rows),
                'REC_W':str(recovery['witness_programs']),'REC_DW':str(recovery['dated_witness_programs']),
                'COMBINED':str(status['returned']+recovery['returned']),
                'DECISION':('The attempted grid is closed. No dated program from either vendor has a numerical witness in these fixtures, so the prospectively specified rule says to stop broad expansion. This is a negative result for the observed programs, with technical missingness limiting the grid; it is not proof that all planned or future programs are safe.' if not findings['interim'] and findings['dated_numerical_witnesses']==0 else 'Complete the remaining planned slots before applying the stopping rule. The observations so far do not establish the required cross-mechanism failure pattern.'),
                'INVALID':str(status.get('programs_with_no_valid_seed',0)),
                'UPDATED':status['updated_at'].replace('T',' ',1).replace('+00:00',' UTC'),
                'MODEL_TABLE':'\n'.join(model_rows),
                'FREEZE':f['timestamp_utc'].replace('T',' ',1).replace('+00:00',' UTC')}.items():
    tex=tex.replace('@@'+k+'@@',value)
assert '@@' not in tex
path=OUT/'Disclosure_Code_Pilot_2026-11-07.tex';path.write_text(tex)
# Reuse the already-built local TeX format in this environment if available.
fmt=ROOT.parent/'rule_history/report/pdflatex.fmt'
if fmt.exists():shutil.copyfile(fmt,OUT/'pdflatex.fmt')
env=dict(os.environ);env['TEXMF']='{/usr/share/texlive/texmf-dist,/usr/share/texmf,/etc/texmf}'
for _ in range(2):
    p=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',path.name],cwd=OUT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (OUT/'build_stdout.txt').write_text(p.stdout)
    if p.returncode:raise RuntimeError(p.stdout[-4000:])
print(OUT/'Disclosure_Code_Pilot_2026-11-07.pdf')
