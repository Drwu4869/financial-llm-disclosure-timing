"""Refresh operational notes and remove unnecessary authentication URL queries."""
import datetime as dt
import json
from pathlib import Path
import shutil
from urllib.parse import urlsplit, urlunsplit

ROOT=Path(__file__).resolve().parent
def scrub(x):
 if isinstance(x,dict):
  for k,v in x.items():
   if k=='response_url' and isinstance(v,str):
    u=urlsplit(v);x[k]=urlunsplit((u.scheme,u.netloc,u.path,'',''))
   else:scrub(v)
 elif isinstance(x,list):
  for v in x:scrub(v)
paths=[ROOT/'attempts.json',Path('/workspace/shared/disclosure_code_run/attempts.json')]
paths+=list((ROOT/'capture_metadata').glob('*.json'))
for p in paths:
 if p.exists():
  x=json.loads(p.read_text());scrub(x);p.write_text(json.dumps(x,indent=2)+'\n')
for d in [ROOT/'capture_metadata',Path('/workspace/shared/disclosure_code_run/raw')]:
 for p in d.glob('*.failure_ui.txt'):
  lines=p.read_text().splitlines()
  p.write_text('\n'.join(line for line in lines if 'Google 账号' not in line and 'accounts.google.com/SignOutOptions' not in line)+'\n')
s=json.loads((ROOT/'STATUS.json').read_text());f=json.loads((ROOT/'results/interim_findings.json').read_text());a=json.loads((ROOT/'attempts.json').read_text())
r=json.loads((ROOT/'technical_recovery/SUMMARY.json').read_text());order=json.loads((ROOT/'run_order.json').read_text())
old=ROOT/'operational_blockers.json';archive=ROOT/'archive/operational_blockers_at_30.json'
if not archive.exists():shutil.copyfile(old,archive)
state={'updated_at':dt.datetime.now(dt.timezone.utc).isoformat(),'access':'Google verification and GPT sign-in were completed through the authorized user flows; no current authentication blocker observed.',
       'primary':s,'supplemental':r,'remaining':{},
       'instruction':'Do not re-run returned answers or silently refill primary missing slots. A03 recoveries stay separate.'}
for model,seq in order.items():
 done={x['trial_id'] for x in a if x['model']==model}
 state['remaining'][model]=[t for t in seq if t not in done]
old.write_text(json.dumps(state,indent=2)+'\n')
audit=json.loads((ROOT/'results/saved_integrity_audit.json').read_text())
ra=json.loads((ROOT/'technical_recovery/AUDIT.json').read_text())
text=f'''DISCLOSURE CODE PILOT — 7 NOVEMBER 2026

Observed answers: {s['returned']+r['returned']} total = {s['returned']} primary + {r['returned']} A03 technical recoveries.
Primary design: 54 slots; {s['submitted']} attempted, {s['missing']} technical missing,
{len(s['pending'])} pending, {54-s['submitted']} unattempted.
Primary evaluated programs: {s['evaluated_answers']}; valid seed scores: {s['valid_seed_evaluations']}.
A03 evaluated programs: {r['evaluated']}; valid seed scores: {r['valid_seed_evaluations']}.
Seed runs are not independent model generations. No answer was regenerated or repaired.

Primary evidence
- Dated programs: {f['dated_programs']}; temporal witnesses: {f['dated_numerical_witnesses']}.
- Oracle matches on every seed: {f['dated_oracle_matches']}; valid dated abstentions: {f['dated_valid_abstentions']}.
- Missing-date programs: {f['missing_date_programs']}; stress witnesses: {f['missing_date_numerical_witnesses']}.
- Malformed-output programs: {len(f['programs_with_no_valid_seed'])}; they are not timing failures.
- A03 stress witnesses: {r['witness_programs']}; dated witnesses: {r['dated_witness_programs']}.
- Primary integrity audit: {audit['passed']}/{audit['total']}; A03 audit: {ra['passed']}/{ra['total']}.

Read first
report/Disclosure_Code_Pilot_2026-11-07.pdf and .tex: English report and LaTeX.
results/interim_findings.json: exact primary cell counts and witness provenance.
technical_recovery/SUMMARY.json: separate recovery counts.
STATUS.json and operational_blockers.json: exact current state.

Reproduction and provenance
FREEZE.json, registration.txt and run_order.json preserve the original design.
Amendments A01/A02 cover validated isolation and concurrency. A03 prospectively
permits one recovery for each of four draft-only technical failures. The primary
missing records remain unchanged; recovery-inclusive views are explicitly labelled.
model_responses/ and technical_recovery/ retain raw answers and unmodified source.
results/model_evaluation/ and technical_recovery/ retain complete seed outputs.
capture_metadata/ records UI settings, transport recovery and capture method.
GPT long code uses the code-block Copy control; Gemini uses whole-response Copy.
Unneeded authentication query strings and account labels were removed from
capture metadata, never from raw model code or scoring evidence.

Audit commands, run from this directory
  python audit_saved_results.py
  python audit_recovery.py
These re-score saved outputs; they do not request models or execute candidates.
evaluate_recorded.py and evaluate_recovery.py use the A01 isolated runner for
unevaluated answers only. Never execute candidate code directly on the host.
Runtime: bubblewrap plus default-deny seccomp; no network, host workspace,
credentials or subprocess access. Requested Python 3.11-compatible source runs
under CPython 3.13.5, a disclosed environment deviation.

Limits and stopping
This is a synthetic parsed-holdings implementation pilot, not market alpha,
financial loss estimation, general model safety, or publication-ready novelty.
An assumed release lag can fail under late-report stress without pretending
to know true missing dates. A conservative delay is not look-ahead. An abstaining
or cash-only program is not automatically useful task completion.
No dated witnesses across both vendors calls for stopping broad expansion under
the original effort-allocation rule; missing-date witnesses alone do not meet
the two-mechanism criterion. Do not choose harder cases merely to force failures.
Observation timestamps include collection/login delays and are not model latency.

Earlier manuscripts are not replaced. archive/README_at_freeze.txt and
archive/operational_blockers_at_30.json preserve earlier protocol/collection state.
'''
(ROOT/'README.txt').write_text(text)
print({'primary_returned':s['returned'],'supplemental_returned':r['returned'],'remaining':state['remaining']})
