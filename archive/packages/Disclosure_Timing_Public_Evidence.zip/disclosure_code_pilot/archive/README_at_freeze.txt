DISCLOSURE CODE PILOT - 7 NOVEMBER 2026

What this is
A runnable standard-library synthetic generator, availability-aware diagnostic
scorer, calibrated hand-written controls, 27 prompts per vendor, and a locally
frozen prospective pilot plan. This supplements the earlier rule-QA work; it
does not replace that report or turn its results into a stronger claim.

What is completed
- Synthetic data, public/private separation, four matched return regimes.
- Code-level temporal interventions and independent oracle boundary tests.
- Reference-policy validation and 480 economic control runs.
- A two-vendor 54-generation design with hashes and explicit stopping rules.
- English LaTeX/PDF protocol and literature/source audit.

What is NOT completed
- ZERO new external-model generations; ZERO model-generated programs evaluated.
- The Docker runner is supplied, but cannot be executed here: Docker is absent,
  and the available Linux namespace alternative failed its preflight. No local
  execution fallback was used. Validate the container before model evaluation.
- No real strategy PnL, no proven new algorithm, no publication-readiness claim.

Quick start (Python 3.11+, standard library)
  python validate.py
  python sandbox.py --preflight

The preflight must report ready before executing external code. On an appropriate
machine with Docker, build and retain the image ID:
  docker build -t disclosure-pilot:local .
  python sandbox.py --preflight
Run a trusted smoke candidate in that image first. Never pass private credentials
or mount the whole project into the candidate container.

A model returns a single code block defining build_strategy(payload). Record the
unaltered response using record_response.py with the frozen trial ID, actual
model/settings and timezone-aware submission/return times. The helper requires
exactly one fenced code block and never repairs code. Missing attempt records
must also be retained using --outcome missing --failure-reason TEXT (with
--returned-at as the observation-closed time); do not silently rerun first answers.

Example (replace placeholders with actual recorded values):
  python record_response.py --trial dates_P0_r1 --model 'GPT-6 High' \
    --raw raw_answer.txt --settings 'Actual observed model and reasoning setting' \
    --submitted-at '2026-11-07T18:00:00+00:00' \
    --returned-at '2026-11-07T18:01:00+00:00'
The timestamps above are examples, not evidence that any request was made.

Once the isolated runner is validated:
  python sandbox.py --candidate model_responses/GPT_dates_P0_r1.py \
    --schema dates --seed 101 --output results/GPT_dates_P0_r1_seed101.json
Repeat for the frozen five audit seeds and record the image digest. The command
records execution failures separately; it does not automatically call a model.

Files
  engine.py                  generator, oracle, controls, interventions, scores
  validate.py                independent boundary and positive/negative controls
  sandbox.py / worker.py     fail-closed isolated execution, no host fallback
  Dockerfile                 candidate worker image; stdlib-only contract
  build_study.py             refuses to overwrite FREEZE.json
  record_response.py         preserves raw first responses and hashes
  registration.txt           complete pre-analysis plan
  study_config.json          machine-readable design, seeds and stop rules
  source_audit.json          verified sources and limits on novelty claims
  prompts/                   27 individual prompt files
  Prompts_27.txt              all prompts, convenient for copying
  FREEZE.json                timestamp and immutable-file hashes
  run_order.json             vendor-specific randomized order
  run_log.json / STATUS.json  zero new model calls at delivery
  results/                   hand-written calibration only
  data/                      public examples, private fixtures, old-data summary
  report/                    English protocol PDF, LaTeX and calibration figure

Interpretation rules
1. Changing future/unpublished values must not change past decisions.
2. A witness is evidence of a dependency for that fixture. Passing finite probes
   is not a mathematical proof of global safety.
3. Missing filing dates are not uniquely reconstructible: abstention is allowed.
4. Conservative delay is not leakage; zero trading is not useful completion.
5. Sharpe is a secondary demonstration with planted effects, never the oracle.
6. Do not present the synthetic controls as strong-model results.
7. All raw data, examples and code are available for inspection. Withhold private
   fixtures, tests and reference policies from the evaluated models' contexts.
