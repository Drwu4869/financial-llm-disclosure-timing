"""Calibrate the test harness on known controls, not on model generations."""
import json
import pathlib
import statistics
from engine import *
ROOT=pathlib.Path(__file__).resolve().parent

def main():
    checks=[];details=[]
    def check(name,value):
        checks.append({'test':name,'passed':bool(value)})
        if not value: raise AssertionError(name)
    # A tiny independently specified vintage case guards the oracle itself.
    toy={'dates':['2022-04-01','2022-04-11','2022-04-20'],
         'assets':['a','b'],'prices':[],
         'filings':[{'row_id':'o1','asset':'a','period_end':'2022-03-31','filing_date':'2022-04-10','version':0,'weight_pct':60},
                    {'row_id':'o2','asset':'b','period_end':'2022-03-31','filing_date':'2022-04-10','version':0,'weight_pct':40},
                    {'row_id':'a1','asset':'a','period_end':'2022-03-31','filing_date':'2022-04-20','version':1,'weight_pct':40},
                    {'row_id':'a2','asset':'b','period_end':'2022-03-31','filing_date':'2022-04-20','version':1,'weight_pct':60}]}
    check('Independent vintage boundary example',reference(toy)['weights']==[[0.,0.],[.5,-.5],[-.5,.5]])
    ambiguous=make_fixture(101,'missing')
    early=copy.deepcopy(ambiguous);late=copy.deepcopy(ambiguous)
    for fx,release in [(early,'2022-05-20'),(late,'2022-06-07')]:
        for row in fx['gold']['rows']:
            if row['period_end']=='2022-03-31': row['filing_date']=release
    cut=ambiguous['payload']['dates'].index('2022-05-26')
    check('Same missing-date inputs admit different legal timelines',early['payload']==late['payload'] and oracle(early)['weights'][cut]!=oracle(late)['weights'][cut])
    (ROOT/'data/missing_date_identifiability.json').write_text(json.dumps({
      'decision_date':'2022-05-26','identical_observable_payload':True,
      'world_early_release':'2022-05-20','world_late_release':'2022-06-07',
      'early_oracle_weights':oracle(early)['weights'][cut],
      'late_oracle_weights':oracle(late)['weights'][cut],
      'meaning':'Exact availability cannot be reconstructed uniquely from the missing-date table, even with perfect arithmetic.'},indent=2))
    for schema in SCHEMAS:
        for seed in [101,202,303,404,505]:
            fx=make_fixture(seed,schema)
            group={}
            for r in fx['gold']['rows']:
                group.setdefault((r['period_end'],r['version']),[]).append(r['weight_pct'])
            check(f'Portfolio totals / {schema} / {seed}',all(sum(v)==100 for v in group.values()))
            results={p:audit_reference(fx,p) for p in POLICIES}
            details.append({'schema':schema,'seed':seed,'policies':results})
            check(f'Clean oracle no false witness / {schema} / {seed}',not results['point_in_time']['numerical_leakage_witness'])
            check(f'Report-date positive control / {schema} / {seed}',results['report_date']['numerical_leakage_witness'])
            check(f'Future-price positive control / {schema} / {seed}',results['future_price']['numerical_leakage_witness'])
            check(f'All-cash does not count as leakage / {schema} / {seed}',not results['all_cash']['numerical_leakage_witness'])
            check(f'Known-filing plus 60 is conservative / {schema} / {seed}',not results['max_filing60']['numerical_leakage_witness'])
            if schema=='missing':
                check(f'Missing-date abstention accepted / {seed}',results['missing_abstain']['status']=='insufficient_data')
                check(f'No impossible oracle accuracy / {seed}',results['fixed60']['oracle_weight_mae'] is None)
            else:
                check(f'Oracle functional accuracy / {schema} / {seed}',results['point_in_time']['oracle_weight_mae']<1e-12)
            if schema=='revisions':
                check(f'Global vintage positive control / {seed}',results['global_latest']['numerical_leakage_witness'])
                check(f'Report-date control isolates original timing / {seed}',not any(w['kind']=='future_revision_values' for w in results['report_date']['witnesses']))
    # Late records show why fixed day 60 is not universally conservative.
    check('Fixed60 can also use a not-yet-filed record',any(d['policies']['fixed60']['numerical_leakage_witness'] for d in details))
    # No-return-regime inference: timing scores must not depend on profitability.
    for policy in ('point_in_time','report_date','global_latest','fixed60'):
        outcomes=[audit_reference(make_fixture(101,'revisions',r),policy)['numerical_leakage_witness'] for r in REGIMES]
        check(f'Timing witness independent of return regime / {policy}',len(set(outcomes))==1)
    economics=[]
    for regime in REGIMES:
        for policy in ('point_in_time','report_date','global_latest','fixed60','max_filing60','all_cash'):
            observations=[]
            for seed in range(1001,1021):
                fx=make_fixture(seed,'revisions',regime)
                weights=validate_output(reference(fx['payload'],policy),fx['payload'])
                observations.append(strategy_metrics(weights,fx))
            sharpes=[x['annualized_sharpe'] for x in observations if x['annualized_sharpe'] is not None]
            economics.append({'regime':regime,'policy':policy,'seeds':20,
              'mean_sharpe':statistics.mean(sharpes) if sharpes else None,
              'min_sharpe':min(sharpes) if sharpes else None,
              'max_sharpe':max(sharpes) if sharpes else None,
              'mean_cumulative_return':statistics.mean(x['cumulative_return'] for x in observations),
              'raw':observations})
    result={'kind':'HAND_WRITTEN_HARNESS_CONTROLS_NOT_LLM_RESULTS',
       'checks':checks,'passed':len(checks),'failed':0,'model_generations':0,
       'audit_cases':details,'economics':economics}
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results/baseline_validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'passed':len(checks),'failed':0,'model_generations':0,'economic_runs':len(economics)*20},indent=2))

if __name__=='__main__':main()
