"""Post-hoc D01: full-horizon filing-dependence and timing-policy diagnostics.

Never modifies frozen results or model source. External code runs only through
the existing A01 isolation adapter. Identical daily interventions are deduplicated
by public-row set while the ENTIRE input date/price calendar is kept unchanged.
"""
import argparse
import copy
import datetime as dt
import gzip
import hashlib
import json
from pathlib import Path

from engine import make_fixture, normalize, reference, validate_output, add_days
from sandbox_bwrap import run_candidate

ROOT = Path(__file__).resolve().parent
DEST = ROOT / 'results/full_horizon'
SEEDS = [101, 202, 303, 404, 505]
TOL = 1e-8
REFUSAL = 'GPT_dates_P0_r3'
STRICT_FILING = 'GPT_dates_P1_r1'
INCLUSIVE_60 = 'GPT_revisions_P0_r1'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def records():
    out = []
    for folder, group in [('results/model_evaluation', 'primary'), ('technical_recovery', 'A03')]:
        for path in sorted((ROOT/folder).glob('*.json')):
            if path.name.endswith('_outputs.json') or not path.name.startswith(('GPT_', 'GEM_')):
                continue
            r = json.loads(path.read_text())
            trial = r.get('trial', r.get('trial_id', ''))
            if r.get('outcome') != 'evaluated' or trial.startswith('missing_'):
                continue
            token = path.stem
            source = ROOT / ('model_responses' if group == 'primary' else 'technical_recovery') / (token+'.py')
            is60 = token.startswith('GPT_') and trial.split('_')[1] in ('P0', 'P1') and token not in (REFUSAL, STRICT_FILING)
            rule = 'max_filing_period60' if is60 else 'filing_date'
            boundary = 'strict' if token.startswith('GPT_') and trial.split('_')[1] in ('P0', 'P1') and token != INCLUSIVE_60 else 'inclusive'
            out.append(dict(token=token, trial=trial, group=group, schema=trial.split('_')[0],
                            source=str(source.relative_to(ROOT)), source_sha256=sha(source),
                            rule=rule, boundary=boundary,
                            category='interface_refusal' if token == REFUSAL else ('sixty_day_floor' if is60 else ('filing_date_strict' if token == STRICT_FILING else 'oracle_alignment')),
                            result_path=str(path.relative_to(ROOT)), result=r))
    assert len(out) == 36 and sum(x['rule']=='max_filing_period60' for x in out)==10
    return out

def policy(payload, rule, boundary):
    by_asset = {a:[] for a in payload['assets']}
    for row in payload['filings']:
        use = row['filing_date']
        if rule == 'max_filing_period60':
            use = max(use, add_days(row['period_end'],60))
        by_asset[row['asset']].append((row, use))
    weights=[]
    for day in payload['dates']:
        levels=[]
        for asset in payload['assets']:
            eligible = [r for r, use in by_asset[asset] if use < day or (boundary=='inclusive' and use==day)]
            row=max(eligible,key=lambda r:(r['period_end'],r.get('version',0),r['filing_date'])) if eligible else None
            levels.append(row['weight_pct'] if row else 100/len(payload['assets']))
        weights.append(normalize(levels))
    return weights

def jobs_for(fixture):
    """Exact daily interventions; group only byte-identical payloads.

    For all cutoffs sharing a released-row set, holdings mutations/removals are
    identical. Checking every output prefix through the last cutoff is equivalent
    to checking each daily prefix separately for these particular interventions.
    Prices and input dates are never truncated, so execution-session validation
    is not confounded with availability changes.
    """
    p=fixture['payload']; groups={}
    for day in p['dates']:
        ids=tuple(sorted(r['row_id'] for r in p['filings'] if r['filing_date']<=day))
        groups.setdefault(ids,[]).append(day)
    jobs=[]
    for public_ids, days in groups.items():
        known=set(public_ids)
        for kind in ('remove_unavailable', 'future_original_values', 'future_revision_values'):
            q=copy.deepcopy(p); changed=0
            if kind=='remove_unavailable':
                q['filings']=[r for r in q['filings'] if r['row_id'] in known]
                changed=len(p['filings'])-len(q['filings'])
            else:
                version=0 if kind=='future_original_values' else 1
                for row in q['filings']:
                    if row['row_id'] not in known and row.get('version',0)==version:
                        row['weight_pct']=25-row['weight_pct'];changed+=1
            if changed:
                jobs.append(dict(kind=kind, cutoff=days[-1], first_cutoff=days[0],
                                 daily_cutoffs=days, changed_records=changed, payload=q))
    return jobs

def maxdiff(a,b):
    return max((abs(x-y) for ra,rb in zip(a,b) for x,y in zip(ra,rb)),default=0.)

def compare(base, outputs, fixture, jobs):
    p=fixture['payload']; bw=validate_output(base,p)
    checks=[]
    for out,job in zip(outputs,jobs):
        item={k:v for k,v in job.items() if k not in ('payload','daily_cutoffs')}
        item['daily_cutoff_count']=len(job['daily_cutoffs'])
        if base['status']=='insufficient_data':
            item.update(outcome='unassessable_baseline_refusal')
        else:
            try:
                ow=validate_output(out,p)
                if out['status']=='insufficient_data':
                    item.update(outcome='inconclusive_intervention_refusal',reason=out['reason'])
                else:
                    n=sum(day<=job['cutoff'] for day in p['dates'])
                    delta=maxdiff(bw[:n],ow[:n])
                    item.update(outcome='witness' if delta>TOL else 'no_witness',max_prefix_delta=delta)
            except (ValueError,TypeError,KeyError) as exc:
                item.update(outcome='invalid_intervention_output',error=str(exc))
        checks.append(item)
    return checks

def run_one(rec, baseline_only=False):
    result={k:v for k,v in rec.items() if k!='result'}
    result.update(analysis='D01 post-hoc, not preregistered',seeds=[])
    source=(ROOT/rec['source']).read_text()
    for seed in SEEDS:
        fixture=make_fixture(seed,rec['schema']);p=fixture['payload']
        s=next(x for x in rec['result']['seeds'] if x['seed']==seed)
        original=ROOT/Path(rec['result_path']).parent/s['outputs_file']
        base=json.loads(original.read_text())[0]
        item=dict(seed=seed,baseline_outputs_file=str(original.relative_to(ROOT)),baseline_outputs_sha256=sha(original),
                  decision_days=len(p['dates']),report_periods=len({r['period_end'] for r in p['filings']}),
                  baseline_status=base['status'],baseline_reason=base['reason'])
        if base['status']!='insufficient_data':
            bw=validate_output(base,p);expected=policy(p,rec['rule'],rec['boundary'])
            errors=[maxdiff([a],[b]) for a,b in zip(bw,expected)]
            oracle=policy(p,'filing_date','inclusive')
            item.update(policy_match_all_days=max(errors)<=TOL,max_policy_error=max(errors),
                        policy_mismatch_days=[d for d,e in zip(p['dates'],errors) if e>TOL],
                        oracle_difference_days=sum(maxdiff([a],[b])>TOL for a,b in zip(bw,oracle)))
        else:
            item.update(policy_match_all_days=None,excluded_from_numeric_success=True)
        if not baseline_only:
            jobs=jobs_for(fixture)
            payloads=[p]+[j['payload'] for j in jobs]
            outputs, environment=run_candidate(source,payloads)
            repeat=outputs[0]
            repeat_ok=(repeat['status']==base['status'] and maxdiff(validate_output(repeat,p),validate_output(base,p))<=TOL)
            assert repeat_ok,(rec['token'],seed,'non-reproducible baseline')
            name=rec['token']+'_'+str(seed)+'_outputs.json.gz'
            with gzip.open(DEST/name,'wt') as stream:
                json.dump(outputs,stream,separators=(',',':'))
            item.update(environment=environment,outputs_file=name,outputs_sha256=sha(DEST/name),
                        repeat_matches_saved=True,executions=len(outputs),
                        checks=compare(base,outputs[1:],fixture,jobs))
        result['seeds'].append(item)
    return result

def controls():
    items=[]
    for schema,flawed in [('dates','report_date'),('revisions','global_latest')]:
        for seed in SEEDS:
            f=make_fixture(seed,schema);jobs=jobs_for(f)
            for name in ('point_in_time',flawed,'all_cash'):
                base=reference(f['payload'],name)
                outputs=[reference(j['payload'],name) for j in jobs]
                findings=compare(base,outputs,f,jobs)
                witness=any(x['outcome']=='witness' for x in findings)
                assert witness==(name==flawed),(schema,seed,name)
                items.append(dict(schema=schema,seed=seed,policy=name,has_witness=witness))
    return items

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--baseline-only',action='store_true');args=parser.parse_args()
    DEST.mkdir(parents=True,exist_ok=True)
    for manifest in ['FREEZE.json','amendments/A01_runtime.json']:
        for name,digest in json.loads((ROOT/manifest).read_text())['files'].items():
            assert sha(ROOT/name)==digest,name
    control=controls()
    all_results=[]
    for rec in records():
        target=DEST/(rec['token']+('.baseline.json' if args.baseline_only else '.json'))
        if target.exists():
            result=json.loads(target.read_text())
            assert result['source_sha256']==rec['source_sha256']
        else:
            result=run_one(rec,args.baseline_only)
            target.write_text(json.dumps(result,indent=2)+'\n')
        all_results.append(result)
        print(json.dumps(dict(done=len(all_results),total=36,token=rec['token'],category=rec['category'],
                              policy_matches=[s['policy_match_all_days'] for s in result['seeds']],
                              witnesses=sum(c['outcome']=='witness' for s in result['seeds'] for c in s.get('checks',[])))),flush=True)
    seeds=[s for r in all_results for s in r['seeds']]
    checks=[c for s in seeds for c in s.get('checks',[])]
    summary=dict(analysis='D01 post-hoc full-horizon diagnostic; original primary scorer unchanged',
                 completed_at=dt.datetime.now(dt.timezone.utc).isoformat(),baseline_only=args.baseline_only,
                 program_count=len(all_results),weight_producing_programs=sum(r['category']!='interface_refusal' for r in all_results),
                 interface_refusals=[r['token'] for r in all_results if r['category']=='interface_refusal'],
                 sixty_day_floor_programs=[r['token'] for r in all_results if r['category']=='sixty_day_floor'],
                 filing_date_strict_programs=[r['token'] for r in all_results if r['category']=='filing_date_strict'],
                 oracle_aligned_programs=sum(r['category']=='oracle_alignment' for r in all_results),
                 generations_added=0,decision_days_per_seed=seeds[0]['decision_days'],report_periods_per_seed=6,
                 usable_program_seed_cases=sum(s['policy_match_all_days'] is not None for s in seeds),
                 all_day_policy_matches=sum(s['policy_match_all_days'] is True for s in seeds),
                 usable_daily_vectors=sum(s['decision_days'] for s in seeds if s['policy_match_all_days'] is not None),
                 isolated_executions=sum(s.get('executions',0) for s in seeds),
                 deduplicated_intervention_checks=len(checks),
                 outcome_counts={k:sum(c['outcome']==k for c in checks) for k in sorted({c['outcome'] for c in checks})},
                 usable_daily_interventions=sum(c['daily_cutoff_count'] for c in checks if c['outcome']=='no_witness'),
                 controls=control,
                 limits=['All dates in five fixed synthetic fixtures, not arbitrary unseen inputs.',
                         'Daily audit varies future filings, not future prices; original price probes remain limited.',
                         'Deduplication changes neither dates/prices nor model code.',
                         'Refusal is excluded from useful timing success; original raw status is retained.',
                         'Rule classification and full-horizon checks are post-hoc, prompted by reviewer correction.'])
    name='baseline_summary.json' if args.baseline_only else 'SUMMARY.json'
    (DEST/name).write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='controls'},indent=2),flush=True)

if __name__=='__main__':
    main()
