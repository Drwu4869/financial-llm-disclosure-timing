"""Compare isolated outputs to frozen hand-written controls before model calls."""
import datetime as dt
import json
import pathlib
from engine import make_fixture, interventions, reference, validate_output, SCHEMAS, POLICIES
from sandbox_bwrap import run_candidate, preflight
ROOT=pathlib.Path(__file__).resolve().parent

def main():
    pf=preflight()
    if not pf['ready']:raise RuntimeError('Isolation preflight failed')
    tests=[]
    base=(ROOT/'engine.py').read_text()
    for schema in SCHEMAS:
        for seed in [101,202,303,404,505]:
            fx=make_fixture(seed,schema)
            payloads=[fx['payload']]+[j['payload'] for j in interventions(fx)]
            for policy in POLICIES:
                source=base+f'\ndef build_strategy(payload):\n    return reference(payload,{policy!r})\n'
                outputs,meta=run_candidate(source,payloads)
                maximum=0.
                for p,out in zip(payloads,outputs):
                    expected=reference(p,policy)
                    if out.get('status')!=expected['status']:raise AssertionError((schema,seed,policy,out))
                    wa,wb=validate_output(out,p),validate_output(expected,p)
                    maximum=max(maximum,max(abs(a-b) for ra,rb in zip(wa,wb) for a,b in zip(ra,rb)))
                if len(outputs)!=len(payloads) or maximum>1e-8:raise AssertionError('Output parity failure')
                tests.append({'schema':schema,'seed':seed,'policy':policy,'payloads':len(payloads),'max_abs_difference':maximum,'passed':True})
                if len(tests)%20==0:print(f'Runtime parity {len(tests)}/120',flush=True)
    result={'timestamp_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'model_generations':0,
            'preflight':pf,'passed':len(tests),'failed':0,'comparisons':tests,
            'note':'Frozen Python 3.11-compatible prompt sources will be executed by CPython 3.13.5. This runtime change is declared before any model calls.'}
    (ROOT/'results/runtime_A01_validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'passed':len(tests),'failed':0,'model_generations':0},indent=2))

if __name__=='__main__':main()
