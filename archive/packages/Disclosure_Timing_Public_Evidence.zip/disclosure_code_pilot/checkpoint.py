"""Summarize completed answers separately from actual numerical evaluations."""
import datetime as dt
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
records=json.loads((ROOT/'run_log.json').read_text())
evaluations=[json.loads(p.read_text()) for p in (ROOT/'results/model_evaluation').glob('*.json') if not p.name.endswith('_outputs.json')]
attempt_path=Path('/workspace/shared/disclosure_code_run/attempts.json')
attempts=json.loads(attempt_path.read_text()) if attempt_path.exists() else []
pending=[a for a in attempts if not any(r['model']==a['model'] and r['trial']==a['trial_id'] for r in records)]
(ROOT/'attempts.json').write_text(json.dumps(attempts,indent=2)+'\n')
status={'updated_at':dt.datetime.now(dt.timezone.utc).isoformat(),'planned':54,
        'submitted':len(records)+len(pending),
        'returned':sum(r['outcome']=='returned' for r in records),
        'missing':sum(r['outcome']=='missing' for r in records),
        'pending':pending,'evaluated_answers':sum(r['outcome']=='evaluated' for r in evaluations),
        'answers_with_numerical_witness':sum(r['has_numerical_witness'] for r in evaluations),
        'valid_seed_evaluations':sum(r['valid_seeds'] for r in evaluations),
        'runtime_checks':{'isolation':9,'reference_parity':120},
        'scope':'These counts are interim. Witnesses require mechanism review. Reference checks are not model generations.'}
status['programs_with_all_five_valid_seeds']=sum(r['valid_seeds']==5 for r in evaluations)
status['programs_with_no_valid_seed']=sum(r['outcome']=='evaluated' and r['valid_seeds']==0 for r in evaluations)
status['collection_phase']='closed' if status['submitted']==54 and not pending else 'in_progress'
if status['collection_phase']=='closed':
    status['scope']='Primary attempt grid closed. A03 technical recoveries are reported separately. Reference checks and execution seeds are not model generations.'
status['by_vendor']={model:{'returned':sum(r['model']==model and r['outcome']=='returned' for r in records),
                          'pending':sum(a['model']==model for a in pending),
                          'evaluated':sum(r['model']==model and r['outcome']=='evaluated' for r in evaluations)}
                    for model in ['GPT-6 High','Gemini 3.1 Pro High']}
(ROOT/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
lines=['DISCLOSURE CODE PILOT — LIVE CHECKPOINT',status['updated_at'],'',
       f"Model first answers returned: {status['returned']}/54",f"Submitted: {status['submitted']}; pending: {len(pending)}; missing: {status['missing']}",
       f"Answers evaluated: {status['evaluated_answers']}; seed evaluations: {status['valid_seed_evaluations']}",
       f"Answers with a numerical witness: {status['answers_with_numerical_witness']} (mechanism review required)",'',
       'No model output is repaired. No missing request is scored as a wrong answer.',
       'Runtime A01 uses CPython 3.13.5 for requested Python 3.11-compatible source.',
       'The synthetic experiments do not establish real-market profitability.','']
for r in evaluations:
    scores=[s['score'] for s in r['seeds'] if 'score' in s]
    lines.append(f"{r['model']} | {r['trial']} | valid seeds={r['valid_seeds']} | numerical witness={r['has_numerical_witness']} | statuses={sorted(set(s['status'] for s in scores))}")
(ROOT/'Progress_2026-11-07.txt').write_text('\n'.join(lines)+'\n')
print(json.dumps(status,indent=2))
