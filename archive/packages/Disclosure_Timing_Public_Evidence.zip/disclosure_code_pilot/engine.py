"""Disclosure-code pilot: synthetic fixtures and availability-aware diagnostics.

Standard library only. The reference policies below are hand-written controls,
NOT model outputs. Model code must be run through sandbox.py, never imported here.
"""
import copy
import datetime as dt
import hashlib
import math
import random
import statistics

SCHEMAS = ('dates', 'missing', 'revisions')
REGIMES = ('null', 'pre_only', 'post_only', 'mixed')
POLICIES = ('point_in_time', 'report_date', 'global_latest', 'fixed60',
            'max_filing60', 'missing_abstain', 'all_cash', 'future_price')

def weekdays(start, end):
    x, last = dt.date.fromisoformat(start), dt.date.fromisoformat(end)
    out = []
    while x <= last:
        if x.weekday() < 5:
            out.append(x.isoformat())
        x += dt.timedelta(days=1)
    return out

def add_days(s, n):
    return (dt.date.fromisoformat(s) + dt.timedelta(days=n)).isoformat()

def weekday_on_or_after(s):
    d = dt.date.fromisoformat(s)
    while d.weekday() >= 5:
        d += dt.timedelta(days=1)
    return d.isoformat()

def normalize(values):
    if not values:
        return []
    mean = sum(values) / len(values)
    centered = [x - mean for x in values]
    gross = sum(abs(x) for x in centered)
    return [x / gross for x in centered] if gross else [0.0]*len(values)

def make_fixture(seed=101, schema='dates', regime='mixed'):
    if schema not in SCHEMAS or regime not in REGIMES:
        raise ValueError('Unknown schema or regime')
    rng = random.Random(seed)
    dates = weekdays('2022-01-03', '2023-10-31')
    assets = [f'Asset_{j+1:02}' for j in range(8)]
    periods = ['2022-03-31', '2022-06-30', '2022-09-30',
               '2022-12-31', '2023-03-31', '2023-06-30']
    # Include early, near-deadline and after-day-60 records. This distribution
    # is a stress fixture, not an estimate of SEC filing frequencies.
    lags = [40, 48, 57, 60, 64, 68]
    rng.shuffle(lags)
    gold_rows = []
    for i, (period, lag) in enumerate(zip(periods, lags)):
        filing = weekday_on_or_after(add_days(period, lag))
        values = [10.5]*4 + [14.5]*4
        rng.shuffle(values)
        versions = [(0, filing, values)]
        if schema == 'revisions' and i % 2 == 0:
            revised = [25.0-v for v in values]
            versions.append((1, weekday_on_or_after(add_days(filing, 14)), revised))
        for version, released, vals in versions:
            for j, asset in enumerate(assets):
                opaque=hashlib.sha256(f'{seed}/{i}/{version}/{j}'.encode()).hexdigest()[:16]
                gold_rows.append({'row_id':opaque,
                    'asset':asset, 'period_end':period, 'filing_date':released,
                    'version':version, 'weight_pct':vals[j]})
    rng.shuffle(gold_rows)
    public_rows = copy.deepcopy(gold_rows)
    if schema == 'missing':
        for row in public_rows:
            row.pop('filing_date')
    if schema != 'revisions':
        for row in public_rows:
            row.pop('version')
    # Generate four matched return regimes; all use exactly the same records
    # and random noise for a given seed. Returns are not a scoring oracle.
    pre_amp = 0.004 if regime in ('pre_only','mixed') else 0.0
    post_amp = 0.006 if regime in ('post_only','mixed') else 0.0
    noise = random.Random(seed + 900000)
    returns = [[noise.gauss(0, .012) for _ in assets] for _ in dates]
    by_date = {d:k for k,d in enumerate(dates)}
    for row in gold_rows:
        a = assets.index(row['asset'])
        sign = (row['weight_pct']-12.5)/2
        release = by_date[row['filing_date']]
        if row['version'] == 0:
            for k,d in enumerate(dates):
                if row['period_end'] < d < row['filing_date']:
                    returns[k][a] += pre_amp * sign
        else:
            for k in range(max(0,release-3),release):
                returns[k][a] += pre_amp * sign
        for k in range(release+1, min(release+4,len(dates))):
            returns[k][a] += post_amp * sign
    levels = [100.0]*len(assets)
    prices = []
    for d, r in zip(dates, returns):
        levels = [x*(1+y) for x,y in zip(levels,r)]
        prices.append({'date':d, 'close':list(levels)})
    payload = {'dates':dates,'assets':assets,'filings':public_rows,'prices':prices}
    return {'payload':payload, 'gold':{'rows':gold_rows,'returns':returns},
            'seed':seed,'schema':schema,'regime':regime}

def _selected_weights(payload, policy):
    rows = copy.deepcopy(payload['filings'])
    if policy == 'global_latest':
        groups = {}
        for r in rows:
            key=(r['asset'],r['period_end'])
            groups.setdefault(key,[]).append(r)
        selected=[]
        for group in groups.values():
            newest=max(group,key=lambda r:(r.get('version',0),r.get('filing_date','')))
            r=copy.deepcopy(newest)
            # Deliberately flawed: latest revision overwrites the earlier
            # value while retaining the first filing's availability date.
            r['filing_date']=min(x.get('filing_date',x['period_end']) for x in group)
            selected.append(r)
        rows=selected
    by_asset={a:[] for a in payload['assets']}
    for row in rows:
        if policy == 'report_date':
            # Isolate original-report alignment; do not simultaneously backdate
            # amendments (that is a separate positive control).
            row['_use']=row['period_end'] if row.get('version',0)==0 else row['filing_date']
        elif policy == 'fixed60':
            row['_use']=add_days(row['period_end'],60) if row.get('version',0)==0 else max(row['filing_date'],add_days(row['period_end'],60))
        elif policy == 'max_filing60':
            row['_use']=max(row.get('filing_date','9999-12-31'),add_days(row['period_end'],60))
        else:
            row['_use']=row.get('filing_date','9999-12-31')
        by_asset[row['asset']].append(row)
    out=[]
    for d in payload['dates']:
        values=[]
        for a in payload['assets']:
            choices=[r for r in by_asset[a] if r['_use']<=d]
            row=max(choices,key=lambda r:(r['period_end'],r.get('version',0),r['_use'])) if choices else None
            values.append(row['weight_pct'] if row else 12.5)
        out.append(normalize(values))
    return out

def reference(payload, policy='point_in_time'):
    if policy not in POLICIES:
        raise ValueError(policy)
    n,m=len(payload['dates']),len(payload['assets'])
    if policy=='all_cash':
        return {'status':'ok','reason':'Hand-written all-cash negative control.','weights':[[0.]*m for _ in range(n)]}
    if policy in ('point_in_time','missing_abstain') and any('filing_date' not in r for r in payload['filings']):
        return {'status':'insufficient_data','reason':'Public filing dates are unavailable; exact historical alignment is not identified.'}
    if policy=='future_price':
        prices={p['date']:p['close'] for p in payload['prices']}
        out=[]
        for i,d in enumerate(payload['dates']):
            nxt=payload['dates'][min(i+1,n-1)]
            out.append(normalize([y/x-1 for x,y in zip(prices[d],prices[nxt])]))
        return {'status':'ok','reason':'Deliberately flawed future-price positive control.','weights':out}
    p='point_in_time' if policy=='missing_abstain' else policy
    return {'status':'assumption' if p=='fixed60' else 'ok',
            'reason':'Hand-written control '+p,
            'weights':_selected_weights(payload,p)}

def oracle(fixture):
    p=copy.deepcopy(fixture['payload'])
    p['filings']=copy.deepcopy(fixture['gold']['rows'])
    return reference(p)

def validate_output(output, payload):
    if not isinstance(output,dict) or output.get('status') not in ('ok','assumption','insufficient_data'):
        raise ValueError('Invalid status')
    if not isinstance(output.get('reason'),str):
        raise ValueError('Missing reason')
    n,m=len(payload['dates']),len(payload['assets'])
    if output['status']=='insufficient_data':
        if not output['reason'].strip(): raise ValueError('Empty abstention reason')
        if 'weights' not in output:
            return [[0.]*m for _ in range(n)]
    weights=output.get('weights')
    if not isinstance(weights,list) or len(weights)!=n:
        raise ValueError('Wrong number of weight rows')
    for row in weights:
        if not isinstance(row,list) or len(row)!=m:
            raise ValueError('Wrong number of assets')
        if any(isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) for x in row):
            raise ValueError('Invalid weight number')
        if sum(abs(x) for x in row)>1+1e-8 or abs(sum(row))>1e-8:
            raise ValueError('Gross or neutrality constraint violated')
    if output['status']=='insufficient_data' and any(abs(v)>1e-10 for r in weights for v in r):
        raise ValueError('Abstention cannot also contain trades')
    return weights

def interventions(fixture):
    p=fixture['payload']; dates=p['dates']; gold=fixture['gold']['rows']
    # Two report blocks, including the first amended block, fixed before tests.
    periods=sorted({r['period_end'] for r in gold})[:2]
    cut_dates=set()
    for r in gold:
        if r['period_end'] in periods:
            for event in (r['period_end'],r['filing_date']):
                preceding=[d for d in dates if d<event]
                if preceding: cut_dates.add(preceding[-1])
                if event in dates: cut_dates.add(event)
    lookup={r['row_id']:r for r in gold}
    jobs=[{'kind':'repeat_identical_input','cutoff':dates[-1],
           'changed_records':0,'payload':copy.deepcopy(p)}]
    for cutoff in sorted(cut_dates):
        for kind in ('future_original_values','future_revision_values','remove_unavailable','future_prices'):
            q=copy.deepcopy(p); changed=0
            if kind=='future_prices':
                for row in q['prices']:
                    if row['date']>cutoff:
                        row['close']=[x*(1.25 if i%2 else .75) for i,x in enumerate(row['close'])];changed+=1
            elif kind=='remove_unavailable':
                before=len(q['filings'])
                q['filings']=[r for r in q['filings'] if lookup[r['row_id']]['filing_date']<=cutoff]
                changed=before-len(q['filings'])
            else:
                version=0 if kind=='future_original_values' else 1
                for row in q['filings']:
                    truth=lookup[row['row_id']]
                    if truth['filing_date']>cutoff and truth['version']==version:
                        row['weight_pct']=25-row['weight_pct'];changed+=1
            if changed:
                jobs.append({'kind':kind,'cutoff':cutoff,'changed_records':changed,'payload':q})
    return jobs

def strategy_metrics(weights, fixture, cost_bps=0):
    daily=[]; previous=[0.]*len(fixture['payload']['assets'])
    for t,w in enumerate(weights[:-1]):
        turnover=sum(abs(a-b) for a,b in zip(w,previous))
        daily.append(sum(a*b for a,b in zip(w,fixture['gold']['returns'][t+1]))-turnover*cost_bps/10000)
        previous=w
    mean=statistics.mean(daily); sd=statistics.stdev(daily)
    equity=1.;peak=1.;dd=0.
    for r in daily:
        equity*=1+r;peak=max(peak,equity);dd=min(dd,equity/peak-1)
    return {'annualized_sharpe':mean/sd*math.sqrt(252) if sd>1e-15 else None,
            'cumulative_return':equity-1,'max_drawdown':dd,
            'active_fraction':sum(any(abs(x)>1e-10 for x in w) for w in weights)/len(weights),
            'cost_bps':cost_bps}

def score(fixture, outputs, jobs):
    if len(outputs)!=1+len(jobs): raise ValueError('Output/job count mismatch')
    p=fixture['payload'];base=validate_output(outputs[0],p)
    findings=[];inconclusive=[];deterministic=True
    for out,job in zip(outputs[1:],jobs):
        try: other=validate_output(out,job['payload'])
        except (ValueError,TypeError,KeyError) as e:
            if job['kind']=='repeat_identical_input': deterministic=False
            inconclusive.append({'kind':job['kind'],'cutoff':job['cutoff'],'error':str(e)});continue
        # Runtime errors or conditional refusal are coverage failures, not
        # evidence of a numerical future-information dependency.
        if (outputs[0]['status']=='insufficient_data') != (out['status']=='insufficient_data'):
            if job['kind']=='repeat_identical_input': deterministic=False
            inconclusive.append({'kind':job['kind'],'cutoff':job['cutoff'],'error':'status changed to/from abstention'});continue
        diffs=[max(abs(x-y) for x,y in zip(a,b)) for d,a,b in zip(p['dates'],base,other) if d<=job['cutoff']]
        delta=max(diffs,default=0.)
        if job['kind']=='repeat_identical_input':
            deterministic=delta<=1e-8 and outputs[0]['status']==out['status']
            continue
        if delta>1e-8:
            findings.append({'kind':job['kind'],'cutoff':job['cutoff'],'max_prefix_weight_change':delta})
    truth=validate_output(oracle(fixture),p)
    mae=sum(abs(a-b) for x,y in zip(base,truth) for a,b in zip(x,y))/(len(base)*len(base[0]))
    return {'schema':fixture['schema'],'seed':fixture['seed'],'regime':fixture['regime'],
            'status':outputs[0]['status'],'reason':outputs[0]['reason'],
            'deterministic_on_repeat':deterministic,
            'numerical_leakage_witness':bool(findings) if deterministic else None,'witnesses':findings,
            'interventions':len(jobs),'inconclusive_interventions':inconclusive,
            'oracle_weight_mae':mae if fixture['schema']!='missing' else None,
            'missing_date_handling':'abstained' if outputs[0]['status']=='insufficient_data' else outputs[0]['status'],
            'metrics':[strategy_metrics(base,fixture,cost) for cost in (0,5)],
            'limits':'A witness establishes dependence for this fixture. No witness is not a proof of safety. Missing-date oracle accuracy is not scored. No generated-code model result is implied.'}

def audit_reference(fixture, policy):
    jobs=interventions(fixture)
    outputs=[reference(fixture['payload'],policy)]+[reference(j['payload'],policy) for j in jobs]
    return score(fixture,outputs,jobs)
