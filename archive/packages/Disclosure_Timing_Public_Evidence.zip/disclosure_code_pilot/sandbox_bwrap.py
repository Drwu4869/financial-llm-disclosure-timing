"""Runtime amendment A01: namespace isolation plus default-deny seccomp.

Preserves frozen prompts, worker, fixtures and scoring. Network namespace setup
is unavailable on this host. Socket/network syscalls are instead absent from a
default-deny allowlist, with a mandatory self-test before candidate execution.
No unsandboxed candidate fallback exists.
"""
import argparse
import ctypes
import ctypes.util
import hashlib
import json
import os
import pathlib
import resource
import shutil
import signal
import subprocess
import tempfile
import time

ROOT=pathlib.Path(__file__).resolve().parent
ALLOW='''read write readv writev pread64 pwrite64 close close_range fstat newfstatat
stat lstat statx lseek access faccessat faccessat2 open openat readlink readlinkat
getdents getdents64 mmap mprotect munmap mremap msync madvise brk rt_sigaction
rt_sigprocmask rt_sigreturn sigaltstack fcntl ioctl dup dup2 dup3 pipe pipe2 poll
ppoll select pselect6 futex set_robust_list rseq arch_prctl set_tid_address
prlimit64 getrlimit setrlimit getrusage getpid getppid gettid getuid geteuid
getgid getegid getgroups uname sysinfo clock_gettime clock_getres gettimeofday
time nanosleep clock_nanosleep getrandom sched_getaffinity sched_yield getcwd
chdir fchdir umask ftruncate truncate fsync fdatasync rename renameat renameat2
unlink unlinkat mkdir mkdirat rmdir exit exit_group execve execveat wait4 waitid'''.split()

def make_filter(destination):
    lib=ctypes.CDLL(ctypes.util.find_library('seccomp') or 'libseccomp.so.2')
    lib.seccomp_init.argtypes=[ctypes.c_uint32];lib.seccomp_init.restype=ctypes.c_void_p
    lib.seccomp_syscall_resolve_name.argtypes=[ctypes.c_char_p];lib.seccomp_syscall_resolve_name.restype=ctypes.c_int
    lib.seccomp_rule_add.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_int,ctypes.c_uint]
    lib.seccomp_export_bpf.argtypes=[ctypes.c_void_p,ctypes.c_int]
    lib.seccomp_release.argtypes=[ctypes.c_void_p]
    # Default EPERM; only explicitly listed file/runtime operations are allowed.
    ctx=lib.seccomp_init(0x00050000 | 1)
    if not ctx:raise RuntimeError('seccomp_init failed')
    try:
        for name in ALLOW:
            number=lib.seccomp_syscall_resolve_name(name.encode())
            if number>=0 and lib.seccomp_rule_add(ctx,0x7fff0000,number,0)!=0:
                raise RuntimeError('Could not allow syscall '+name)
        with open(destination,'wb') as f:
            if lib.seccomp_export_bpf(ctx,f.fileno())!=0:raise RuntimeError('Filter export failed')
    finally:lib.seccomp_release(ctx)

def limits():
    resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
    resource.setrlimit(resource.RLIMIT_CPU,(80,80))
    resource.setrlimit(resource.RLIMIT_FSIZE,(32_000_000,32_000_000))
    resource.setrlimit(resource.RLIMIT_NOFILE,(64,64))

def run_candidate(source,payloads,timeout=90):
    if not shutil.which('bwrap'):raise RuntimeError('bubblewrap unavailable')
    if len(source.encode())>256_000:raise ValueError('Candidate source too large')
    with tempfile.TemporaryDirectory(prefix='disclosure-isolated-') as folder:
        folder=pathlib.Path(folder)
        code=folder/'candidate.py';code.write_text(source)
        filt=folder/'filter.bpf';make_filter(filt)
        with filt.open('rb') as fd, tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
            cmd=['bwrap','--unshare-all','--unshare-user','--share-net','--disable-userns','--assert-userns-disabled',
                 '--die-with-parent','--new-session','--cap-drop','ALL','--clearenv',
                 '--setenv','PATH','/usr/bin:/bin','--setenv','PYTHONHASHSEED','0',
                 '--setenv','PYTHONDONTWRITEBYTECODE','1','--setenv','TMPDIR','/tmp',
                 '--ro-bind','/usr','/usr','--ro-bind','/lib','/lib','--ro-bind','/lib64','/lib64',
                 '--proc','/proc','--dev','/dev','--size','16777216','--tmpfs','/tmp',
                 '--ro-bind',str(ROOT/'worker.py'),'/worker.py','--ro-bind',str(code),'/candidate.py',
                 '--seccomp',str(fd.fileno()),'--chdir','/tmp','/usr/bin/python3','-I','/worker.py']
            start=time.monotonic()
            p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=out,stderr=err,
                pass_fds=(fd.fileno(),),start_new_session=True,preexec_fn=limits)
            try:
                p.communicate(json.dumps({'payloads':payloads}).encode(),timeout=timeout)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid,signal.SIGKILL);p.wait()
                raise RuntimeError('Isolated execution timeout')
            if out.tell()>32_000_000 or err.tell()>1_000_000:raise RuntimeError('Output limit exceeded')
            out.seek(0);err.seek(0);stdout=out.read();stderr=err.read().decode(errors='replace')
            if p.returncode:raise RuntimeError(f'Isolated worker exit {p.returncode}: '+stderr[-2000:])
            return json.loads(stdout),{'runtime':'bubblewrap+default-deny-seccomp',
                'python':'/usr/bin/python3','python_version':subprocess.check_output(['/usr/bin/python3','--version'],text=True).strip(),
                'bubblewrap':subprocess.check_output(['bwrap','--version'],text=True).strip(),
                'filter_sha256':hashlib.sha256(filt.read_bytes()).hexdigest(),
                'adapter_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
                'worker_sha256':hashlib.sha256((ROOT/'worker.py').read_bytes()).hexdigest(),
                'elapsed_seconds':time.monotonic()-start,'stderr':stderr}

PROBE='''def build_strategy(payload):
    import os, socket
    result={}
    for label,action in [
        ("inet_socket",lambda:socket.socket(socket.AF_INET,socket.SOCK_STREAM)),
        ("unix_socket",lambda:socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)),
        ("fork",lambda:os.fork()),
        ("host_file",lambda:open(payload["host_sentinel"]).read()),
        ("worker_write",lambda:open("/worker.py","w").write("bad"))]:
        try:
            action();result[label]=False
        except (PermissionError,FileNotFoundError,OSError): result[label]=True
    result["environment_cleared"]="DISCLOSURE_HOST_SENTINEL" not in os.environ
    result["no_workspace_mount"]=not os.path.exists("/workspace")
    result["temporary_write"]=open("/tmp/probe.txt","w").write("ok")==2
    return result
'''

def preflight():
    sentinel=ROOT/'results/host_isolation_sentinel.txt'
    sentinel.write_text('nonsecret sentinel; must be inaccessible from candidate')
    os.environ['DISCLOSURE_HOST_SENTINEL']='nonsecret-test'
    try:
        outputs,meta=run_candidate(PROBE,[{'host_sentinel':str(sentinel.resolve())}])
        checks=outputs[0]
        timeout_ok=False
        try:run_candidate('def build_strategy(payload):\n    while True: pass\n',[{}],timeout=1)
        except RuntimeError as e:timeout_ok='timeout' in str(e)
        checks['timeout_kills_worker']=timeout_ok
        return {'ready':all(v is True for v in checks.values()),'checks':checks,'environment':meta,
                'scope':'Practical execution boundary, not a formal security proof. Default-deny filtering blocks network and process creation; no host credentials or project mounted.'}
    finally:
        sentinel.unlink(missing_ok=True);os.environ.pop('DISCLOSURE_HOST_SENTINEL',None)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--preflight',action='store_true');p.add_argument('--output',type=pathlib.Path)
    a=p.parse_args();result=preflight()
    if a.output:a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if not result['ready']:raise SystemExit(1)
