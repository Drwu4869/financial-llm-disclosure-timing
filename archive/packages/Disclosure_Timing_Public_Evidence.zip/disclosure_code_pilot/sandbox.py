"""Fail-closed Docker runner for external model-generated Python.

The candidate sees only its source and submitted public payloads, never gold
release dates, return labels, evaluator source, other files or host credentials.
No local-process fallback is provided. Build the image before freezing a run.
"""
import argparse
import hashlib
import json
import pathlib
import shutil
import subprocess
import tempfile
import uuid
from engine import make_fixture, interventions, score

ROOT=pathlib.Path(__file__).resolve().parent

def preflight(image='disclosure-pilot:local'):
    if not shutil.which('docker'):
        return {'ready':False,'reason':'Docker unavailable; external candidate execution is disabled.'}
    try:
        r=subprocess.run(['docker','image','inspect',image,'--format','{{.Id}}'],capture_output=True,text=True,timeout=15)
    except (OSError,subprocess.TimeoutExpired) as e:
        return {'ready':False,'reason':str(e)}
    return {'ready':r.returncode==0,'image':image,'image_id':r.stdout.strip(),'error':r.stderr.strip()}

def run_candidate(source, payloads, image='disclosure-pilot:local'):
    check=preflight(image)
    if not check['ready']:
        raise RuntimeError(check['reason'] if 'reason' in check else check['error'])
    # Pin this invocation to inspected immutable image ID, not its mutable tag.
    name='disclosure-pilot-'+uuid.uuid4().hex
    with tempfile.TemporaryDirectory(prefix='disclosure-candidate-') as folder:
        code=pathlib.Path(folder)/'candidate.py'
        code.write_text(source)
        cmd=['docker','run','--rm','--name',name,'--network','none','--read-only',
             '--cap-drop','ALL','--security-opt','no-new-privileges',
             '--pids-limit','32','--memory','256m','--memory-swap','256m',
             '--cpus','1','--ulimit','nofile=64:64',
             '--user','65534:65534','--tmpfs','/tmp:rw,noexec,nosuid,size=16m',
             '--mount',f'type=bind,src={code},dst=/candidate.py,readonly',
             '-i',check['image_id']]
        try:
            with tempfile.TemporaryFile() as fout, tempfile.TemporaryFile() as ferr:
                process=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=fout,stderr=ferr)
                process.communicate(json.dumps({'payloads':payloads}).encode(),timeout=90)
                if fout.tell()>32_000_000 or ferr.tell()>1_000_000:
                    raise RuntimeError('Output size limit exceeded')
                fout.seek(0);ferr.seek(0)
                stdout=fout.read();stderr=ferr.read().decode(errors='replace')
                if process.returncode:
                    raise RuntimeError('Candidate execution failed: '+stderr[-2000:])
                return json.loads(stdout),check
        except subprocess.TimeoutExpired:
            raise RuntimeError('Candidate timeout; scored as execution failure, not a temporal error')
        finally:
            subprocess.run(['docker','rm','-f',name],capture_output=True,timeout=15)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--preflight',action='store_true')
    p.add_argument('--candidate',type=pathlib.Path)
    p.add_argument('--schema',choices=['dates','missing','revisions'],default='dates')
    p.add_argument('--seed',type=int,default=101)
    p.add_argument('--image',default='disclosure-pilot:local')
    p.add_argument('--output',type=pathlib.Path)
    a=p.parse_args()
    if a.preflight:
        print(json.dumps(preflight(a.image),indent=2));return
    if not a.candidate or not a.output: p.error('--candidate and --output required')
    fx=make_fixture(a.seed,a.schema)
    jobs=interventions(fx)
    source=a.candidate.read_text()
    try:
        outputs,environment=run_candidate(source,[fx['payload']]+[j['payload'] for j in jobs],a.image)
        result=score(fx,outputs,jobs)
        result['execution_environment']=environment
        result['raw_outputs']=outputs
    except (RuntimeError,ValueError,TypeError,KeyError,OSError) as exc:
        result={'status':'execution_or_infrastructure_failure','error':str(exc),
                'numerical_leakage_witness':None,'schema':a.schema,'seed':a.seed,
                'limits':'Failure is not automatically a temporal model error.'}
    result['candidate_sha256']=hashlib.sha256(source.encode()).hexdigest()
    a.output.write_text(json.dumps(result,indent=2))

if __name__=='__main__':main()
