"""Recompute saved scores and verify source identity and frozen submission order."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
from engine import make_fixture, interventions, score

ROOT=Path(__file__).resolve().parent
checks=[]
def check(label, ok):
    checks.append({'check':label,'passed':bool(ok)})

for manifest in ['FREEZE.json','amendments/A01_runtime.json']:
    for name,digest in json.loads((ROOT/manifest).read_text())['files'].items():
        check(manifest+':'+name,hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest)
log=json.loads((ROOT/'run_log.json').read_text())
attempts=json.loads((ROOT/'attempts.json').read_text())
order=json.loads((ROOT/'run_order.json').read_text())
check('unique first answers',len({(r['model'],r['trial']) for r in log})==len(log))
for model,sequence in order.items():
    submitted=[a['trial_id'] for a in attempts if a['model']==model]
    check('frozen submission prefix: '+model,submitted==sequence[:len(submitted)])
for record in log:
    raw=(ROOT/record['raw_response']).read_text()
    token=Path(record['raw_response']).stem
    check(token+':raw hash',hashlib.sha256(raw.encode()).hexdigest()==record['raw_sha256'])
    result=json.loads((ROOT/'results/model_evaluation'/(token+'.json')).read_text())
    if record['code_extracted']:
        source=(ROOT/record['code_file']).read_text()
        blocks=re.findall(r'```(?:python|py)?\s*\n(.*?)```',raw,re.S)
        check(token+':unmodified extraction',len(blocks)==1 and blocks[0]==source)
        check(token+':executed source hash',hashlib.sha256(source.encode()).hexdigest()==result['code_sha256'])
    for item in result['seeds']:
        fixture=make_fixture(item['seed'],record['trial'].split('_')[0])
        outputs=json.loads((ROOT/'results/model_evaluation'/item['outputs_file']).read_text())
        try:
            computed=score(fixture,outputs,interventions(fixture))
            check(token+':saved score '+str(item['seed']),computed==item.get('score'))
        except Exception as exc:
            check(token+':saved format failure '+str(item['seed']),
                  type(exc).__name__+': '+str(exc)==item.get('execution_or_scoring_error'))
report={'audited_at':dt.datetime.now(dt.timezone.utc).isoformat(),
        'passed':sum(c['passed'] for c in checks),'total':len(checks),
        'checks':checks,'scope':'Re-scoring retained outputs and verifying identity; no new model generation or candidate execution.'}
(ROOT/'results/saved_integrity_audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2))
if report['passed']!=report['total']:raise SystemExit('Integrity audit failed')
