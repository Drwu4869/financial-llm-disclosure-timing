from pathlib import Path
import json,hashlib,random,datetime
r=Path(__file__).resolve().parents[1]
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (r/'freeze.json').exists()
order=[f'{m}_Q{i:02d}' for m in ('gpt','gemini') for i in range(1,41)]
random.Random(918321).shuffle(order)
(r/'qa/audit_order.json').write_text(json.dumps(order))
paths=list((r/'blind').glob('*.txt'))+list((r/'design').glob('*.*'))+[r/'private/key.json',r/'qa/audit_order.json',r/'qa/decisions.txt',r/'qa/five_item_blind_review.txt']
(r/'freeze.json').write_text(json.dumps({'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'hosted_scored_trials_sent':0,'trial_order':[f'Q{i:02d}' for i in range(1,41)],'sha256':{str(p.relative_to(r)):h(p) for p in sorted(paths)}},indent=2))
