"""Reference implementation that receives the rendered prompt alone. No calls to generator."""
from pathlib import Path
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from fractions import Fraction
import json,re,collections
R=Path(__file__).resolve().parents[1];ny=ZoneInfo('America/New_York')
def parse(t):
    cutoff=datetime.strptime(re.search(r'check at ([\d-]+ [\d:]+) Europe/London',t)[1],'%Y-%m-%d %H:%M').replace(tzinfo=ZoneInfo('Europe/London'))
    weights=list(map(Fraction,re.search(r'allocates (\d+)% to A, (\d+)% to B and (\d+)% to W',t).groups()))
    records=[json.loads(l) for l in t.splitlines() if l.startswith('{')]
    return cutoff,weights,records
def solve(t):
    cutoff,weights,records=parse(t);parts=collections.defaultdict(list)
    for d in records:
        if d['form']=='N-PORT' and (int(d['period'][5:7])-d['fiscal_year_end_month'])%3:continue
        when=datetime.fromisoformat(d.get('public_wire_observation_ET',d['accepted_ET'])).replace(tzinfo=ny)
        if when<=cutoff: parts[d['book']].append(d)
    used={};span={}
    for b in 'ABWL':
        a=parts[b]
        if not a:used[b]=[];span[b]=(0,100);continue
        recent=max(d['period'] for d in a);v=sorted((d for d in a if d['period']==recent),key=lambda d:d['accepted_ET'])
        base=max(i for i,d in enumerate(v) if d.get('amendment')!='ADDS NEW HOLDINGS ENTRIES')
        chain=v[base:];used[b]=sorted(d['id'] for d in chain);d=chain[0]
        if 'ranks_m' in d:
            vals=[v for _,v in d['ranks_m']];x,y=0,min(min(vals),100-sum(vals))
        elif 'omitted' in d:
            known=d['visible_target_m']+sum(v['target_m'] for v in chain[1:]);room=100-d['other_visible_m']-d['visible_target_m']
            x=known;y=known+(room-sum(v['target_m']+v['other_added_m'] for v in chain[1:]))
        else: x=y=d.get('target_m',d.get('leaf_pct'))
        span[b]=[Fraction(str(x)),Fraction(str(y))]
    bounds=[weights[0]*span['A'][j]/100+weights[1]*span['B'][j]/100+weights[2]*span['W'][j]*span['L'][j]/10000 for j in range(2)]
    return used,bounds,'over' if bounds[0]>5 else 'within' if bounds[1]<=5 else 'undetermined'
if __name__=='__main__':
    key=json.loads((R/'private/key.json').read_text());pairs=collections.defaultdict(list);arms=collections.Counter()
    for id,k in key.items():
        txt=(R/'blind'/(id+'.txt')).read_text();used,bounds,dec=solve(txt)
        assert (used,bounds,dec)==(k['used'],[Fraction(k['low']),Fraction(k['high'])],k['decision']),(id,k,used,bounds,dec)
        arms[k['arm']]+=1
        if k['arm']=='C2':pairs[k['pair']].append((k,txt))
    assert arms=={'C0':6,'T10':6,'C2':28}
    for pair,((k,x),(h,y)) in pairs.items():
        assert k['decision']!=h['decision'] and parse(x)[2]==parse(y)[2] and parse(x)[1]==parse(y)[1]
        assert re.sub(r'check at [\d-]+ [\d:]+','check at CUTOFF',x)==re.sub(r'check at [\d-]+ [\d:]+','check at CUTOFF',y)
    assert len(pairs)==14
    print('PASS: 40 numerical ranges, 40 decisions and complete document-ID sets, 14 identical evidence bundles with decision flips, exact arm sizes.')
