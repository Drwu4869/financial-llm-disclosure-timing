"""Construct synthetic normalized event cards and a hand-specified before/after oracle."""
import json, random, calendar
from fractions import Fraction as F
from pathlib import Path
from datetime import datetime, date, timedelta
from zoneinfo import ZoneInfo
R=Path(__file__).resolve().parents[1]
NY=ZoneInfo('America/New_York'); LON=ZoneInfo('Europe/London')
rng=random.Random(611062)
def dt(s): return datetime.strptime(s,'%Y-%m-%d %H:%M').replace(tzinfo=NY)
def get_holidays(y):
    def obs(d):return d+timedelta(days={5:-1,6:1}.get(d.weekday(),0))
    def nth(m,w,i):
        ds=[date(y,m,d) for d in range(1,calendar.monthrange(y,m)[1]+1) if date(y,m,d).weekday()==w];return ds[i]
    return {obs(date(y,1,1)),nth(1,0,2),nth(2,0,2),nth(5,0,-1),obs(date(y,6,19)),obs(date(y,7,4)),nth(9,0,0),nth(10,0,1),obs(date(y,11,11)),nth(11,3,3),obs(date(y,12,25))}
def business(d):return d.weekday()<5 and d not in get_holidays(d.year)
def roll(d):
    while not business(d):d+=timedelta(days=1)
    return d
def priorq(d):
    x=date.fromisoformat(d)
    return (date(x.year,(x.month-1)//3*3+1,1)-timedelta(days=1)).isoformat()
def minus_month(d):
    x=date.fromisoformat(d);return (date(x.year,x.month,1)-timedelta(days=1)).isoformat()
def nice(f):return str(round(float(f),6)).rstrip('0').rstrip('.') if f else '0'
def jd(obj):return json.dumps(obj,ensure_ascii=False,separators=(',',':'))
# type, period, principal event public timestamp, relative before/after times, old, new, fiscal-year end
spec=[
 ('T1','2026-06-30','2026-08-12 11:00',-1440,1440,3,12,12),
 ('T2','2026-03-31','2026-05-15 06:07',-710,145,11,2,12),
 ('T3','2025-12-31','2026-02-17 12:20',-1460,140,None,2,12),
 ('T3','2022-06-30','2022-08-15 13:10',-1500,125,3,13,12),
 ('T4','2025-12-31','2026-03-19 12:55',-20,20,11,2,12),
 ('T4','2025-06-30','2025-10-28 12:55',-20,20,2,13,12),
 ('T5','2026-03-31','2026-06-08 13:00',-1450,1450,12,2,12),
 ('T6','2025-12-31','2026-04-14 11:45',-1440,1440,'ct',2,12),
 ('T6','2026-03-31','2026-07-09 10:40',-1430,1430,'ct',13,12),
 ('T7','2025-12-31','2026-02-23 10:00',-4300,150,2,12,12),
 ('T7','2026-03-31','2026-05-26 14:05',-1400,120,12,3,12),
 ('T8','2026-01-31','2026-03-24 11:40',-1440,1440,3,12,10),
 ('T8','2026-04-30','2026-06-23 10:10',-1440,1430,11,2,1),
 ('T9','2026-03-31','2026-04-22 12:20',-1440,1440,'top',2.75,12)]
def docs_case(i,s):
    typ,period,evt,bef,aft,old,new,fy=s
    rnd=random.Random(7823+29*i)
    evt=dt(evt);pre=evt+timedelta(minutes=bef);post=evt+timedelta(minutes=aft)
    a=[45,50,55,48,52][i%5]; b=[22,27,24][i%3]; w=100-a-b
    bval=4; leafval=4; mix=50; fixed=F(b*bval,100)+F(w*mix*leafval,10000)
    base=(evt-timedelta(days=150)).date()
    pub0=roll(base+timedelta(days=30))
    ticker='XZ'+str(134+i*17); docs=[]; pub={}; ids={}
    def add(name,book,form,per,accepted,payload,*,event=None,filing=None,transmit=None,sign=None):
        ident='D'+str(rnd.randrange(10000,99999))
        assert ident not in pub
        ac=dt(accepted) if isinstance(accepted,str) else accepted
        assert business(ac.date()) and ac.date()>=date.fromisoformat(per),(name,ac,per)
        record=dict(id=ident,book=book,form=form,period=per,signed=(sign or ac.date().isoformat()),tx_start_ET=(transmit or ac.strftime('%Y-%m-%d %H:%M')),accepted_ET=ac.strftime('%Y-%m-%d %H:%M'),filing_day=filing or ac.date().isoformat(),**payload)
        public=ac+timedelta(seconds=15) if event is None else event
        docs.append(record);pub[ident]=public.isoformat() if public else None;ids[name]=ident;return record
    ac0=datetime.combine(pub0,datetime.min.time(),NY)+timedelta(hours=11)
    anchor=base.isoformat()
    # Comparative and operative reports on every fixed path, without future changes.
    for book,form,vals in [('B','issuer signed holdings',{'target_m':bval}),('W','issuer signed holdings',{'leaf_pct':mix,'rest':'cash'}),('L','issuer signed holdings',{'target_m':leafval})]:
        add(book+'old',book,form,(base-timedelta(days=45)).isoformat(),ac0-timedelta(days=0), dict(vals))
        add(book,book,form,anchor,ac0,vals)
    is_np=typ in ('T7','T8'); amended=typ in ('T4','T5','T6')
    x=date.fromisoformat(period)
    prev=(date(x.year,x.month,1)-timedelta(days=65)).replace(day=1)-timedelta(days=1)
    # Pick the previous fiscal quarter end, also for non-calendar funds.
    prev_period=minus_month(minus_month(minus_month(period))) if is_np else priorq(period)
    orig_period=period if amended or typ=='T9' else prev_period
    if old is not None:
        olddate=roll(date.fromisoformat(orig_period)+timedelta(days=15))
        if typ=='T9':olddate=roll(date.fromisoformat(period)+timedelta(days=5))
        orig_ac=datetime.combine(olddate,datetime.min.time(),NY)+timedelta(hours=12)
        fmt='N-PORT' if is_np else '13F-HR'
        payload={'target_m':old} if isinstance(old,int) else {}
        if old=='ct':payload={'visible_target_m':0,'other_visible_m':80,'omitted':'confidential assets; identity and weights unavailable'}
        if old=='top':
            fmt='issuer ranked extract'
            payload={'scope':'ten largest long positions; ties possible','ranks_m':[[f'K{k}',v] for k,v in enumerate([12,11,10,9,8,7,6,5,4,3],1)]}
        if is_np:payload['fiscal_year_end_month']=fy
        add('old','A',fmt,orig_period,orig_ac,payload)
    # T9 before must straddle 5%. Shift a background exposure, avoiding disclosure of the target.
    if typ=='T9':
        bval=12
        next(d for d in docs if d['id']==ids['B'])['target_m']=bval
        fixed=F(b*bval,100)+F(w*mix*leafval,10000)
    if is_np:
        for months,val in [(1,18),(2,1)]:
            per=period
            for _ in range(months):per=minus_month(per)
            acday=roll(evt.date()-timedelta(days=7+months))
            rec=add('private'+str(months),'A','N-PORT',per,datetime.combine(acday,datetime.min.time(),NY)+timedelta(hours=13),{'target_m':val,'fiscal_year_end_month':fy},event=False)
    ac=evt
    fmt='N-PORT' if is_np else ('13F-HR/A' if amended else ('issuer holdings' if typ=='T9' else '13F-HR'))
    vals={'target_m':new}
    if amended:vals['amendment']='ADDS NEW HOLDINGS ENTRIES' if typ=='T6' else 'RESTATEMENT'
    if typ=='T6':
        vals.update({'other_added_m':20-new,'confidential_balance_remaining_m':0})
        delta_days=5 if i%2 else 4
        prior=evt.date();days=0
        while days<delta_days:
            prior-=timedelta(days=1);days+=int(business(prior))
        vals['confidential_treatment_expired']=prior.isoformat()
    if is_np:vals['fiscal_year_end_month']=fy
    if typ=='T2':
        ac=dt('2026-05-14 18:13');vals['public_wire_observation_ET']=evt.strftime('%Y-%m-%d %H:%M')
    if typ=='T4':vals['public_wire_observation_ET']=evt.strftime('%Y-%m-%d %H:%M')
    if typ=='T3': assert roll(x+timedelta(days=45))==evt.date()
    add('new','A',fmt,period,ac,vals,event=evt,filing=evt.date().isoformat(),transmit=(ac-timedelta(minutes=1)).strftime('%Y-%m-%d %H:%M'))
    if is_np: assert (x.month-fy)%3==0
    rnd.shuffle(docs)
    acc={'A':a,'B':b,'W':w}
    def key(after):
        span=(F(new),F(new)) if after else ((F(0),F(100)) if old is None else (F(0),F(20)) if old=='ct' else (F(0),F(3)) if old=='top' else (F(old),F(old)))
        l,u=[fixed+F(a,100)*v for v in span]
        adv='over' if l>5 else 'within' if u<=5 else 'undetermined'
        which=[ids['new']] if after else [ids['old']] if 'old' in ids else []
        if after and typ=='T6':which=[ids['old'],ids['new']]
        return dict(low=nice(l),high=nice(u),decision=adv,used={'A':sorted(which),**{k:[ids[k]] for k in ['B','W','L']}})
    K=[key(False),key(True)]
    assert K[0]['decision']!=K[1]['decision'],(i,K)
    return dict(typ=typ,ticker=ticker,weights=acc,docs=docs,pub=pub,ids=ids,pre=pre.isoformat(),post=post.isoformat(),switch=evt.isoformat(),gold=K)
def prompt(c,when,docs):
    at=datetime.fromisoformat(when).astimezone(LON)
    ticker=c['ticker'];a=c['weights']
    return f"""For a retrospective risk desk check at {at:%Y-%m-%d %H:%M} Europe/London, use only information publicly available by that decision time. What X exposure could the desk support from the latest publicly reported positions of each book, and did it exceed a strict 5% account limit? A value equal to 5% is within. Do not browse.

The model account allocates {a['A']}% to A, {a['B']}% to B and {a['W']}% to W; W holds L and cash. X is the sole target ({ticker}). Fictional long-only sleeves; no shorts, duplicate economic paths or other disclosure channels. Independent NAV is fixed at USD 100 million for each sleeve. Each target_m is a direct target position in USD millions, not a percent of a 13F table total. Use separate positions at their own latest publicly supported periods; W and L are separate books.

Archive extract below uses normalized filing families and extracts from manager copies and distributor records. Times in ET use America/New_York. An issuer statement is released at its recorded time. Complete extracts summarize all X lots within the scope of each record.

"""+'\n'.join(jd(d) for d in docs)+"""

Return one JSON object. Use keys decision (over, within or undetermined), low_pp and high_pp (tightest supported account exposure bounds, equal for a point, in percentage points on 0–100), used (object with A,B,W,L arrays of the operative position records used for that book, excluding documents consulted only to reject them; [] if none), and reason (one sentence)."""
def main():
    scenarios=[docs_case(i,s) for i,s in enumerate(spec)]
    rows=[]
    for i,c in enumerate(scenarios):
        for j,t in enumerate([c['pre'],c['post']]):
            rows.append((f'{i:02d}',j,'C2',c,t,c['docs'],c['gold'][j]))
    for i in [0,2,4,6,8,12]:
        c=scenarios[i];t=c['pre'];allowed=[d for d in c['docs'] if c['pub'][d['id']] and datetime.fromisoformat(c['pub'][d['id']])<=datetime.fromisoformat(t)]
        rows.append((f'{i:02d}',0,'C0',c,t,allowed,c['gold'][0]))
    for i in range(6):
        s=list(spec[i]);s[0]='T10';s[1]='2025-12-31';s[2]='2026-02-10 10:00';s[3:7]=[-1440,1440,3 if i%2 else 12,12 if i%2 else 3]
        c=docs_case(i+25,s);t='2026-03-02T11:00:00-05:00';rows.append((f'control{i}',1,'T10',c,t,c['docs'],c['gold'][1]))
    rng.shuffle(rows)
    key={}; manifest={}
    for n,(pair,j,typ,c,t,docs,g) in enumerate(rows,1):
        id=f'Q{n:02d}';s=prompt(c,t,docs)
        (R/'blind'/f'{id}.txt').write_text(s)
        key[id]=dict(pair=pair,time=t,arm=typ,trap=c['typ'],phase=['pre','post'][j],switch=c['switch'],pub=c['pub'],**g)
    (R/'private/key.json').write_text(json.dumps(key,indent=2));print('cases',len(key))
if __name__=='__main__':main()
