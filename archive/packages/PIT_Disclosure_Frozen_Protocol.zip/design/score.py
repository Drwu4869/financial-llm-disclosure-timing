"""Deterministic endpoints and ID scoring. Review ambiguous / composite error mechanisms separately."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime
import json,csv,re,collections,sys
R=Path(__file__).resolve().parents[1]
gold=json.loads((R/'private/key.json').read_text())
def evaluate(text,k,id):
    txt=text.strip()
    fence=re.fullmatch(r'\x60\x60\x60(?:json)?\s*(.*?)\s*\x60\x60\x60',txt,re.S|re.I)
    if fence:txt=fence[1]
    out=dict(primary=0,decision_ok=0,numeric005=0,numeric001=0,doc_ok=0,code='F',decision='',early_warning=0,delay_warning=0,lead_hours='',format_valid=0)
    try:
        x=json.loads(txt)
        dec=x['decision'];used=x['used'];assert dec in ('within','over','undetermined') and set(used)==set('ABWL')
        assert all(isinstance(v,list) and all(isinstance(i,str) for i in v) and len(v)==len(set(v)) for v in used.values())
        assert isinstance(x['reason'],str) and x['reason'].strip() and not any(isinstance(x[v],bool) for v in ('low_pp','high_pp'))
        lo,hi=F(str(x['low_pp'])),F(str(x['high_pp']));assert 0<=lo<=hi<=100
    except (KeyError,TypeError,ValueError,AssertionError,ZeroDivisionError):return out
    used={b:sorted(v) for b,v in used.items()};correct=k['used']
    err=max(abs(lo-F(k['low'])),abs(hi-F(k['high'])))
    out.update(format_valid=1,decision=dec,doc_ok=int(used==correct),decision_ok=int(dec==k['decision']),numeric005=int(err<=F(5,1000)),numeric001=int(err<=F(1,1000)))
    out['primary']=out['doc_ok']*out['decision_ok']
    s=datetime.fromisoformat(k['time']);public=k['pub'];allids=set(v for ids in used.values() for v in ids)
    wrong=used!=correct
    if any(v in public and (public[v] is None or datetime.fromisoformat(public[v])>s) for v in allids):code='L'
    elif any(v not in public for v in allids):code='U'
    elif k['trap'] in ('T5','T6') and k['phase']=='post' and wrong and set(used['A'])&set(correct['A']) and (len(used['A'])!=len(correct['A'])):code='R'
    elif k['high']!=k['low'] and lo==hi and abs(lo-F(k['low']))<=F(5,1000) and dec!='undetermined':code='Z'
    elif wrong and any(set(used[b])-set(correct[b]) for b in 'ABWL'):code='S'
    elif dec=='undetermined' and k['decision']!='undetermined' and err<=F(5,1000):code='S'
    elif wrong:code='U'
    elif not out['numeric005']:code='C'
    elif not out['decision_ok']:code='D'
    else:code='OK'
    out['code']=code
    if k['arm']=='C2' and k['phase']=='pre' and dec=='over' and k['decision']!='over':
        out['early_warning']=1
        if any(v['pair']==k['pair'] and v['arm']=='C2' and v['phase']=='post' and v['decision']=='over' for v in gold.values()):
            out['lead_hours']=round((datetime.fromisoformat(k['switch'])-s).total_seconds()/3600,3)
    if k['arm']=='C2' and k['phase']=='post' and k['decision']=='over' and dec!='over':out['delay_warning']=1
    return out
def aggregate(scores):
    for model in ['gpt','gemini']:
        print(model)
        for arm in ['C2','C0','T10']:
            vs=[a for a in scores if a['model']==model and a['arm']==arm]
            print(arm,len(vs),sum(a['primary'] for a in vs),dict(collections.Counter(a['code'] for a in vs)),flush=True)
if __name__=='__main__':
    scores=[]
    for f in sorted((R/'raw').glob('*.answer.json')):
        x=json.loads(f.read_text());k=gold[x['id']];o=evaluate(x['text'],k,x['id'])
        scores.append(dict(model=x['model'],id=x['id'],arm=k['arm'],trap=k['trap'],pair=k['pair'],phase=k['phase'],**o))
    if scores:
        with (R/'private/scores.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=scores[0]);w.writeheader();w.writerows(scores)
    aggregate(scores)
