POINT-IN-TIME DISCLOSURE PILOT | 6 NOVEMBER 2026

Start with report/Report.pdf (English, two pages). Report.tex is its LaTeX source.
status.json is the collection ledger and records the four undelivered Gemini attempts.

Coverage
Main series: all 40 GPT and 40 Gemini items attempted once. GPT returned 40 first answers. Gemini returned 36, including 25 newly archived during resumption. Q06, Q08, Q10 and Q39 have transport records only. No unsent items remain. The GPT targeted follow-up contains eight separate answers. The separate holiday-pair addendum is outside this packet.

Where to look
blind/ and extension/blind/ contain only the input questions. design/protocol.txt and freeze.json define the original design. extension/rule.txt and extension/freeze.json record the targeted follow-up decision after the main results and before any new submission. The reference keys are private/key.json and extension/private/key.json. The accounts and release events are simulated. Primary-source timing references are in design/source_audit.txt.
raw/ and extension/raw/ store submission receipts, original answer text and, where collected, display copies or transport status. Keys, reference answers, and audits should not be supplied to models under test.
private/audited_scores.csv has one row per assigned model-item slot, including missingness. strict_primary applies the frozen ID-string requirement after decoding known clipboard presentation escapes. id_scoring_primary is a separate post-hoc sensitivity permitting an explicit source ID embedded in a matching object. It does not fix a wrong time, file, or decision. Numeric columns use percentage points. private/baselines.csv contains deterministic comparators. extension/private/extension_scores.csv contains the eight follow-up rows. qa/ holds the sampling and assistant-led review records. No independent human review was performed.

Reproduce the checks from the extracted directory (Python 3.9+ with IANA time zone data):
  python3 design/verify.py
  python3 observed.py
  python3 baselines.py
  python3 extension/score_extension.py
Compare each freeze.json entry under sha256 with the file of that name relative to its own folder. The original score.py is archived to preserve the pre-run definition. Use observed.py to reproduce the reported product-text handling and both scoring views. Do not rebuild or overwrite the frozen inputs when merely verifying them.

Decision
Three of 28 original GPT traps selected the wrong disclosure as of the decision time and changed the warning. No such error recurred in the eight targeted follow-ups. The incomplete Gemini sample precludes a joint stopping claim. This release covers a synthetic time-selection pilot, not a test of original PDF layout, live holdings or realized returns.

November 6 final coverage update
In the resumed browser session a fresh Pro tab could default to low effort. Temporary-chat and Pro High indicators were checked before each submission. Twenty-one resumed records use the visible code when the Copy presentation could not be matched. Q38 also has a direct clipboard record re-read from its matched original tab. Q20 and Q38 contain an extra prefix and a complete legible answer. Both are F for frozen schema and count zero in id_scoring_primary; readable_primary and the separate numeric/decision columns allow their individually audited values. Feedback, regeneration, backend API substitution and answer-based retries were not used.
