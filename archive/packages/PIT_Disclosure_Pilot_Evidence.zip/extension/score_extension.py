from pathlib import Path
import csv,sys,json
from fractions import Fraction as F
r=Path(__file__).resolve().parent
sys.path.insert(0,str(r.parent))
from observed import unwrap,parse,evaluate
from verify import parse as prompt_rows
gold=json.loads((r/'private/key.json').read_text());rows=[]
for f in sorted((r/'raw').glob('*.answer.json')):
 a=json.loads(f.read_text());i=a['id'];k=gold[i];s=unwrap(a['text']);x=parse(s);v={b:[] for b in 'ABWL'}
 docs={d['id']:d for d in prompt_rows((r/'blind'/(i+'.txt')).read_text())[2]}
 for b,items in x['used'].items():
  for j in items:
   if isinstance(j,dict):
    ident=j['id'];assert all(docs[ident][k]==vv for k,vv in j.items())
   else:ident=j
   v[b].append(ident)
 strict=evaluate(s,k,i);sem=evaluate(json.dumps({**x,'used':v}),k,i)
 rows.append(dict(id=i,trap=k['trap'],pair=k['pair'],phase=k['phase'],decision=x['decision'],reference=k['decision'],low=x['low_pp'],high=x['high_pp'],ref_low=k['low'],ref_high=k['high'],strict_primary=strict['primary'],strict_code=strict['code'],decision_correct=sem['decision_ok'],id_scoring_primary=sem['primary'],numeric_005=sem['numeric005'],numeric_001=sem['numeric001'],code=sem['code'],reason=x['reason']))
with (r/'private/extension_scores.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
for a in rows:print(a['id'],a['phase'],a['trap'],a['low'],a['ref_low'],a['strict_code'],a['code'],a['reason'][:165])
