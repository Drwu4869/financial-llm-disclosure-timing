from pathlib import Path
import sys,json,random,hashlib
from datetime import datetime,timezone
from fractions import Fraction
r=Path(__file__).resolve().parent
sys.path.insert(0,str(r.parent/'design'))
from build import docs_case,prompt
from verify import solve
assert not (r/'freeze.json').exists()
spec=[('T7','2025-03-31','2025-04-28 10:30',-75,80,2,13,12),('T7','2025-06-30','2025-08-29 14:20',-1380,175,12,3,12),('T8','2025-07-31','2025-09-17 11:25',-95,125,11,2,10),('T8','2026-02-28','2026-04-29 13:40',-1440,95,3,12,11)]
items=[]
for i,s in enumerate(spec):
 c=docs_case(62+i,s)
 for j in (0,1):
  when=c['post' if j else 'pre'];txt=prompt(c,when,c['docs'])
  k=dict(pair='X'+str(i),time=when,arm='extension',trap=c['typ'],phase=['pre','post'][j],switch=c['switch'],pub=c['pub'],**c['gold'][j])
  ids,bounds,dec=solve(txt);assert ids==k['used'] and dec==k['decision'] and bounds==[Fraction(k['low']),Fraction(k['high'])]
  items.append([k,txt])
random.Random(201641).shuffle(items);gold={}
for i,(k,txt) in enumerate(items,1):
 id=f'E{i:02d}';(r/'blind'/(id+'.txt')).write_text(txt);gold[id]=k
(r/'private/key.json').write_text(json.dumps(gold,indent=2))
out='''GPT-6 High targeted grey-zone check, prospective with respect to these eight prompts only.
The main pilot contained three adjudicated time errors across T7 and T8. Only a delivered reply with unambiguous public-vintage failure counts as a temporal error; choose L,S,Z,R in registered priority and retain strict raw schema checks alongside semantic ID fidelity. Two new before/after pairs for each implicated type. Each pair has opposite decisions; latest quarter disclosure is released earlier than the statutory 60-day limit in two scenarios and on day 60 in two. The first answers alone are used. No additional control groups, relying on the already-completed original C0/T10. No pooling this enriched sample with 28 original items for an overall error rate. Because 8 differs from 28, scale the original 6/28 continuation proportion upwards and 2/28 stopping proportion downwards before dispatch: at least 2/8 is targeted recurrence, 0/8 is no recurrence, 1/8 remains inconclusive. These thresholds are a new implementation decision after seeing the main pilot: they do not retrospectively change the original decision. If delivery missingness crosses thresholds, label inconclusive. This is the single grey-zone round. C1 or real-return work is outside this targeted round; there is no double-model stop if the other model is incomplete.'''
(r/'rule.txt').write_text(out)
files=[*sorted((r/'blind').glob('*.txt')),r/'private/key.json',r/'rule.txt',Path(__file__)]
(r/'freeze.json').write_text(json.dumps({'at_utc':datetime.now(timezone.utc).isoformat(),'extension_submissions':0,'sha256':{str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}},indent=2))
print('8/8 independently verified')
