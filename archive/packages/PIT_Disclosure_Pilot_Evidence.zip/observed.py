"""Post-collection presentation audit. Frozen rules and original clipboard strings are preserved."""
import sys,json,csv,html,re,itertools,hashlib
from collections import Counter
from fractions import Fraction
from pathlib import Path
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'design'))
from score import evaluate
gold=json.loads((R/'private/key.json').read_text())
def unwrap(raw):
    s=raw.strip()
    if s.startswith('{\\\n') and '&#x20;' in s:
        s=html.unescape(s.replace('\\\n','\n'))
    return s

def parse(s):
    f=re.fullmatch(r'`{3}(?:json)?\s*(.*?)\s*`{3}',s,re.S|re.I)
    return json.loads(f[1] if f else s)
def semantic(x,id):
    from verify import parse as split_prompt
    available={a['id']:a for a in split_prompt((R/'blind'/f'{id}.txt').read_text())[2]}
    doc=x['used']; converted={}; mismatches=[]
    for b,items in doc.items():
        converted[b]=[]
        for v in items:
            if isinstance(v,dict):
                ident=v['id'];converted[b].append(ident)
                if ident not in available or any(available[ident].get(k)!=value for k,value in v.items()):
                    mismatches.append(ident)
            else:converted[b].append(v)
    return {**x,'used':converted},mismatches
def generate():
    rows=[]
    for id,k in sorted(gold.items()):
        for m in ['gpt','gemini']:
            p=R/'raw'/f'{m}_{id}.answer.json'
            row=dict(model=m,id=id,arm=k['arm'],trap=k['trap'],pair=k['pair'],phase=k['phase'],reference=k['decision'])
            if not p.exists():
                status='undelivered' if (R/'raw'/f'{m}_{id}.sent.json').exists() else 'not_sent'
                rows.append({**row,'status':status});continue
            t=json.loads(p.read_text())['text'];s=unwrap(t);frozen=evaluate(s,k,id);literal=evaluate(t,k,id)
            # Two delivered answers have a stray opening brace or a duplicated prefix.
            # Keep the structural failure in both algorithmic scores. Use the explicit
            # inner object only for a separate content read and secondary diagnostics.
            manual_only = False
            try:
                x = parse(s)
            except json.JSONDecodeError:
                if m != 'gemini' or id not in {'Q20','Q38'}:
                    raise
                view = json.loads(p.read_text())['displayed_code']
                prefix, marker, body = view.partition(chr(96)*3 + 'json\n')
                if not marker or not prefix.lstrip().startswith('{'):
                    raise
                x = json.loads(body)
                manual_only = True
            q,bad=semantic(x,id);audit=evaluate(json.dumps(q),k,id)
            packet='objects' if any(isinstance(y,dict) for v in x['used'].values() for y in v) else 'ID strings'
            row.update(status='received',copied_sha256=hashlib.sha256(t.encode()).hexdigest(),copy_serialization=int(s!=t),representation=packet,object_discrepancies='|'.join(bad),literal_primary=literal['primary'],strict_primary=frozen['primary'],strict_code=frozen['code'],id_scoring_primary=(0 if manual_only else audit['primary']),readable_primary=audit['primary'],manual_only=int(manual_only),semantic_doc_ok=audit['doc_ok'],decision_only=audit['decision_ok'],bounds005=audit['numeric005'],bounds001=audit['numeric001'],code=('F' if manual_only and audit['code']=='OK' else audit['code']),content_code=audit['code'],decision=x['decision'],low=x['low_pp'],high=x['high_pp'],reference_low=k['low'],reference_high=k['high'],ids=json.dumps(q['used'],sort_keys=True),reference_ids=json.dumps(k['used'],sort_keys=True),reason=x['reason'],early=audit['early_warning'],missed_after=audit['delay_warning'],lead_hours=audit['lead_hours'])
            rows.append(row)
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with (R/'private/audited_scores.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    for m in ['gpt','gemini']:
        for arm in ['C2','C0','T10']:
            a=[r for r in rows if r['model']==m and r['arm']==arm];obs=[r for r in a if r['status']=='received']
            print(m,arm,len(obs),'/',len(a),[(k,sum(r[k] for r in obs)) for k in ['strict_primary','id_scoring_primary','decision_only','bounds005','early','missed_after']],dict(Counter(r['code'] for r in obs)), 'bad embedded rows',[r['id'] for r in obs if r['object_discrepancies']])
    return rows
if __name__=='__main__':generate()
