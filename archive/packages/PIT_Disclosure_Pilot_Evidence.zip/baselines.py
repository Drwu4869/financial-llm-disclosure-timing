"""Contrast the public-clock reference with selecting records by period end only."""
import json,csv,sys
from pathlib import Path
from fractions import Fraction as F
from datetime import date
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'design'))
from verify import parse,solve
gold=json.loads((R/'private/key.json').read_text()); rows=[]
for i,k in gold.items():
 t=(R/'blind'/(i+'.txt')).read_text();cut,ws,records=parse(t);ids,v,dec=solve(t)
 eligible=[d for d in records if date.fromisoformat(d['period'])<=cut.date()]
 used={};s={}
 for b in 'ABWL':
  ds=[d for d in eligible if d['book']==b]
  if not ds: used[b]=[];s[b]=(F(0),F(100));continue
  last=max(d['period'] for d in ds);vints=sorted((d for d in ds if d['period']==last),key=lambda d:d['accepted_ET'])
  j=max(n for n,d in enumerate(vints) if d.get('amendment')!='ADDS NEW HOLDINGS ENTRIES')
  base,*adds=vints[j:];used[b]=sorted(d['id'] for d in vints[j:])
  if 'ranks_m' in base:
   w=[v for _,v in base['ranks_m']];l,h=0,min(min(w),100-sum(w))
  elif 'omitted' in base:
   l=base['visible_target_m']+sum(d['target_m'] for d in adds);h=100-base['other_visible_m']-sum(d['other_added_m'] for d in adds)
  else:l=h=base.get('target_m',base.get('leaf_pct'))
  s[b]=[F(str(l)),F(str(h))]
 lo,hi=[ws[0]*s['A'][v]/100+ws[1]*s['B'][v]/100+ws[2]*s['W'][v]*s['L'][v]/10000 for v in (0,1)]
 guessed='over' if lo>5 else 'within' if hi<=5 else 'undetermined'
 rows.append(dict(id=i,arm=k['arm'],phase=k['phase'],oracle=dec,period_only=guessed,time_filter_correct=int(ids==k['used'] and dec==k['decision']),period_only_primary=int(used==ids and guessed==dec),period_only_correct=int(guessed==dec)))
with (R/'private/baselines.csv').open('w',newline='') as file:
 w=csv.DictWriter(file,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
print('C2 period-only',sum(x['period_only_primary'] for x in rows if x['arm']=='C2'),'/28')
